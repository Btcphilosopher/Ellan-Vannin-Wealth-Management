"""Inventaire : stock, dépôts, emplacements, exemplaires, traçabilité, mouvements, corrections, contrôles."""
from __future__ import annotations

import uuid
from decimal import Decimal
from typing import Literal

from fastapi import APIRouter, Query
from pydantic import Field
from sqlalchemy import or_, select

from app.core.deps import CtxDep, PageDep, paginate
from app.core.errors import Conflict, NotFound, ValidationFailed
from app.core.refs import next_reference
from app.core.schemas import PositiveQty, StrictModel, dec
from app.modules.audit.service import audit
from app.modules.catalog.models import Item, ItemVariant, Lot
from app.modules.inventory import service as inv
from app.modules.inventory.models import (
    Asset,
    Depot,
    Inspection,
    InspectionResult,
    Location,
    LocationKind,
    MovementType,
    Reservation,
    StockBalance,
    StockMovement,
    StockStatus,
)
from app.modules.org.models import Organization, User

router = APIRouter(prefix="/v1", tags=["Stocks et traçabilité"])

LOCATION_KIND_LABELS = {
    "RECEIVING": "Quai de réception", "STORAGE": "Stockage", "QUARANTINE": "Quarantaine",
    "MAINTENANCE": "Atelier maintenance", "SHIPPING": "Expédition",
}


# ----------------------------------------------------------------------------- sérialisation
def depot_dict(d: Depot) -> dict:
    return {"id": d.id, "code": d.code, "name": d.name, "address": d.address, "organization_id": d.organization_id, "active": d.active}


def location_dict(loc: Location) -> dict:
    return {"id": loc.id, "depot_id": loc.depot_id, "code": loc.code, "label": loc.label, "kind": loc.kind,
            "kind_label": LOCATION_KIND_LABELS.get(loc.kind, loc.kind), "internal_tag": loc.internal_tag}


def asset_dict(ctx, a: Asset) -> dict:
    item = ctx.db.get(Item, a.item_id)
    loc = ctx.db.get(Location, a.location_id) if a.location_id else None
    depot = ctx.db.get(Depot, a.depot_id)
    org = ctx.db.get(Organization, a.custody_org_id) if a.custody_org_id else None
    variant = ctx.db.get(ItemVariant, a.variant_id) if a.variant_id else None
    lot = ctx.db.get(Lot, a.lot_id) if a.lot_id else None
    custody = {
        "type": a.custody_type,
        "organization": {"id": org.id, "code": org.code, "name": org.name} if org else None,
        "person": a.custody_person,
        "depot": {"id": depot.id, "code": depot.code, "name": depot.name} if depot else None,
    }
    return {
        "id": a.id, "serial_number": a.serial_number, "internal_tag": a.internal_tag,
        "item": {"id": item.id, "code": item.code, "designation": item.designation, "family_code": item.family_code,
                 "maintenance_interval_days": item.maintenance_interval_days},
        "variant": {"id": variant.id, "label": variant.label} if variant else None,
        "lot": {"id": lot.id, "lot_number": lot.lot_number} if lot else None,
        "depot": custody["depot"],
        "location": location_dict(loc) if loc else None,
        "stock_status": a.stock_status, "lifecycle": a.lifecycle, "technical_state": a.technical_state,
        "custody": custody, "next_inspection_due": a.next_inspection_due, "received_at": a.received_at,
        "version": a.version,
    }


def movement_dict(ctx, m: StockMovement, cache: dict) -> dict:
    def get(model, key):
        if key is None:
            return None
        ck = (model.__name__, key)
        if ck not in cache:
            cache[ck] = ctx.db.get(model, key)
        return cache[ck]

    item = get(Item, m.item_id)
    fl, tl = get(Location, m.from_location_id), get(Location, m.to_location_id)
    actor = get(User, m.actor_id)
    asset = get(Asset, m.asset_id)
    variant = get(ItemVariant, m.variant_id)
    lot = get(Lot, m.lot_id)
    depot = get(Depot, m.depot_id)
    return {
        "id": m.id, "seq": m.seq, "reference": m.reference, "type": m.movement_type,
        "item": {"id": item.id, "code": item.code, "designation": item.designation, "base_unit": item.base_unit},
        "variant_label": variant.label if variant else None, "lot_number": lot.lot_number if lot else None,
        "asset": {"id": asset.id, "serial_number": asset.serial_number, "internal_tag": asset.internal_tag} if asset else None,
        "quantity": dec(m.quantity), "entered_quantity": dec(m.entered_quantity), "entered_unit": m.entered_unit,
        "from_location": fl.code if fl else None, "from_status": m.from_status,
        "to_location": tl.code if tl else None, "to_status": m.to_status,
        "reserved_delta": dec(m.reserved_delta),
        "depot_code": depot.code if depot else None,
        "source_type": m.source_type, "source_id": m.source_id, "source_ref": m.source_ref,
        "corrects_movement_id": m.corrects_movement_id, "reason": m.reason,
        "actor": actor.full_name if actor else None, "request_id": m.request_id,
        "occurred_at": m.occurred_at, "recorded_at": m.recorded_at,
    }


# ----------------------------------------------------------------------------- dépôts
@router.get("/depots", tags=["Dépôts"])
def list_depots(ctx: CtxDep):
    ctx.require("stock.read")
    visible = ctx.visible_depot_ids()
    out = []
    for d in ctx.db.execute(select(Depot).where(Depot.id.in_(visible)).order_by(Depot.code)).scalars():
        row = depot_dict(d)
        row["locations"] = [location_dict(loc) for loc in d.locations]
        summary = inv.stock_overview(ctx, {d.id})
        row["totals"] = {
            k: float(sum((r[k] for r in summary), Decimal(0)))
            for k in ("physical", "reserved", "available", "blocked", "in_transit")
        }
        row["asset_count"] = ctx.db.query(Asset).filter(Asset.depot_id == d.id, Asset.lifecycle.in_(["IN_STOCK", "RESERVED"])).count()
        out.append(row)
    return out


@router.get("/depots/{depot_id}/locations", tags=["Dépôts"])
def list_locations(ctx: CtxDep, depot_id: uuid.UUID):
    ctx.require("stock.read", depot_id)
    rows = ctx.db.execute(select(Location).where(Location.depot_id == depot_id).order_by(Location.code)).scalars()
    return [location_dict(r) for r in rows]


# ----------------------------------------------------------------------------- stock
@router.get("/stock")
def get_stock(
    ctx: CtxDep,
    depot_id: uuid.UUID | None = None,
    item_id: uuid.UUID | None = None,
    family: str | None = None,
    q: str | None = Query(None, max_length=100),
):
    """Synthèse des stocks : physique · réservé · disponible · en transit · bloqué."""
    ctx.require("stock.read")
    visible = ctx.visible_depot_ids()
    if depot_id:
        ctx.require("stock.read", depot_id)
        visible = {depot_id}
    rows = inv.stock_overview(ctx, visible, item_id=item_id, family=family, search=q)
    for r in rows:
        for k in ("physical", "reserved", "available", "blocked", "in_transit", "min_stock"):
            r[k] = dec(r[k])
        r["below_min"] = r["min_stock"] is not None and r["available"] < r["min_stock"]
    return {"items": rows, "total": len(rows), "legend": {
        "physical": "Stock physique présent dans le dépôt (tous statuts)",
        "reserved": "Réservé pour une demande ou un transfert (non remis)",
        "available": "Disponible = utilisable contrôlé − réservé",
        "in_transit": "Expédié vers ce dépôt, non encore réceptionné (absent des deux dépôts)",
        "blocked": "Non contrôlé, en quarantaine ou en maintenance",
    }}


@router.get("/stock/positions")
def stock_positions(ctx: CtxDep, depot_id: uuid.UUID, item_id: uuid.UUID | None = None, location_id: uuid.UUID | None = None):
    """Détail des positions de stock (emplacement × article × variante × lot × statut)."""
    ctx.require("stock.read", depot_id)
    q = select(StockBalance).where(StockBalance.depot_id == depot_id, StockBalance.quantity > 0)
    if item_id:
        q = q.where(StockBalance.item_id == item_id)
    if location_id:
        q = q.where(StockBalance.location_id == location_id)
    out = []
    for b in ctx.db.execute(q).scalars():
        item, loc = ctx.db.get(Item, b.item_id), ctx.db.get(Location, b.location_id)
        v = ctx.db.get(ItemVariant, b.variant_id) if b.variant_id else None
        lot = ctx.db.get(Lot, b.lot_id) if b.lot_id else None
        out.append({
            "id": b.id, "location": location_dict(loc), "item_id": item.id, "item_code": item.code, "designation": item.designation,
            "variant_id": b.variant_id, "variant_label": v.label if v else None, "lot_id": b.lot_id, "lot_number": lot.lot_number if lot else None,
            "status": b.stock_status, "quantity": dec(b.quantity), "reserved": dec(b.reserved),
            "available": dec(b.quantity - b.reserved) if b.stock_status == StockStatus.USABLE else 0.0, "base_unit": item.base_unit,
        })
    out.sort(key=lambda r: (r["location"]["code"], r["item_code"], r["variant_label"] or ""))
    return out


@router.get("/movements")
def list_movements(
    ctx: CtxDep, page: PageDep, depot_id: uuid.UUID | None = None, item_id: uuid.UUID | None = None,
    asset_id: uuid.UUID | None = None, type: str | None = None, source_id: uuid.UUID | None = None,
):
    ctx.require("stock.read")
    visible = ctx.visible_depot_ids()
    stmt = select(StockMovement).where(StockMovement.depot_id.in_(visible)).order_by(StockMovement.seq.desc())
    if depot_id:
        stmt = stmt.where(StockMovement.depot_id == depot_id)
    if item_id:
        stmt = stmt.where(StockMovement.item_id == item_id)
    if asset_id:
        stmt = stmt.where(StockMovement.asset_id == asset_id)
    if type:
        stmt = stmt.where(StockMovement.movement_type == type)
    if source_id:
        stmt = stmt.where(StockMovement.source_id == source_id)
    cache: dict = {}
    return paginate(ctx, stmt, page, lambda m: movement_dict(ctx, m, cache))


class RelocationIn(StrictModel):
    from_location_id: uuid.UUID
    to_location_id: uuid.UUID
    item_id: uuid.UUID
    variant_id: uuid.UUID | None = None
    lot_id: uuid.UUID | None = None
    asset_id: uuid.UUID | None = None
    quantity: PositiveQty
    reason: str = Field(min_length=3, max_length=500)


@router.post("/stock/relocations", status_code=201)
def relocate(ctx: CtxDep, body: RelocationIn):
    """Mise en emplacement / déplacement interne de stock utilisable non réservé."""
    src = inv.get_location(ctx, body.from_location_id)
    dst = inv.get_location(ctx, body.to_location_id, src.depot_id)
    ctx.require("stock.relocate", src.depot_id)
    if dst.kind not in (LocationKind.STORAGE, LocationKind.RECEIVING, LocationKind.SHIPPING):
        raise ValidationFailed("La destination d'un déplacement doit être un emplacement de stockage.")
    item = ctx.db.get(Item, body.item_id)
    asset = ctx.db.get(Asset, body.asset_id) if body.asset_id else None
    if asset and asset.lifecycle != "IN_STOCK":
        raise Conflict("Un exemplaire réservé ou sorti ne peut être déplacé.")
    mv = inv.post_movement(
        ctx, mtype=MovementType.RELOCATION, item=item, quantity=body.quantity, variant_id=body.variant_id, lot_id=body.lot_id,
        asset=asset, from_location=src, from_status=StockStatus.USABLE, to_location=dst, to_status=StockStatus.USABLE,
        reason=body.reason, source=("RELOCATION", None, None),
    )
    audit(ctx, "stock.relocate", "MOVEMENT", mv.id, object_ref=mv.reference, depot_id=src.depot_id, reason=body.reason)
    ctx.commit()
    return movement_dict(ctx, mv, {})


class CorrectionIn(StrictModel):
    reason: str = Field(min_length=10, max_length=1000)
    corrected_to_location_id: uuid.UUID | None = None


@router.post("/movements/{movement_id}/correction", status_code=201)
def correct_movement(ctx: CtxDep, movement_id: uuid.UUID, body: CorrectionIn):
    """Corrige un mouvement par des mouvements liés (contre-passation + éventuelle écriture rectifiée).

    Le mouvement d'origine n'est jamais modifié.
    """
    orig = ctx.db.get(StockMovement, movement_id)
    if orig is None:
        raise NotFound("Mouvement introuvable.")
    ctx.require("stock.correct", orig.depot_id)
    if orig.movement_type not in (MovementType.PUTAWAY, MovementType.RELOCATION):
        raise ValidationFailed(
            "Seuls les mouvements d'emplacement se corrigent directement. Les autres écarts se traitent par l'action métier "
            "correspondante (contrôle, retour, ajustement d'inventaire approuvé).",
            code="correction_non_supportee",
        )
    already = ctx.db.execute(select(StockMovement.id).where(StockMovement.corrects_movement_id == orig.id)).first()
    if already:
        raise Conflict("Ce mouvement a déjà fait l'objet d'une correction.", code="deja_corrige")
    ctx.separate("sod.correction_by_other_actor", orig.actor_id, "La correction doit être réalisée par une autre personne que l'auteur du mouvement.")
    item = ctx.db.get(Item, orig.item_id)
    asset = ctx.db.get(Asset, orig.asset_id) if orig.asset_id else None
    wrong, back = ctx.db.get(Location, orig.to_location_id), ctx.db.get(Location, orig.from_location_id)
    status = StockStatus(orig.to_status)
    reversal = inv.post_movement(
        ctx, mtype=MovementType.CORRECTION, item=item, quantity=orig.quantity, variant_id=orig.variant_id, lot_id=orig.lot_id,
        asset=asset, from_location=wrong, from_status=status, to_location=back, to_status=StockStatus(orig.from_status),
        reason=f"Contre-passation de {orig.reference} : {body.reason}", source=("CORRECTION", orig.id, orig.reference), corrects_id=orig.id,
    )
    result = [reversal]
    if body.corrected_to_location_id:
        dst = inv.get_location(ctx, body.corrected_to_location_id, orig.depot_id)
        result.append(inv.post_movement(
            ctx, mtype=MovementType.CORRECTION, item=item, quantity=orig.quantity, variant_id=orig.variant_id, lot_id=orig.lot_id,
            asset=asset, from_location=back, from_status=StockStatus(orig.from_status), to_location=dst, to_status=status,
            reason=f"Écriture rectifiée de {orig.reference} : {body.reason}", source=("CORRECTION", orig.id, orig.reference), corrects_id=orig.id,
        ))
    audit(ctx, "movement.correct", "MOVEMENT", orig.id, object_ref=orig.reference, depot_id=orig.depot_id, reason=body.reason,
          details={"linked": [m.reference for m in result]})
    ctx.commit()
    cache: dict = {}
    return {"original": movement_dict(ctx, orig, cache), "corrections": [movement_dict(ctx, m, cache) for m in result]}


# ----------------------------------------------------------------------------- exemplaires
@router.get("/assets")
def list_assets(
    ctx: CtxDep, page: PageDep, depot_id: uuid.UUID | None = None, item_id: uuid.UUID | None = None,
    technical_state: str | None = None, lifecycle: str | None = None, q: str | None = Query(None, max_length=80),
):
    ctx.require("stock.read")
    visible = ctx.visible_depot_ids()
    stmt = select(Asset).where(Asset.depot_id.in_(visible)).order_by(Asset.internal_tag)
    if depot_id:
        stmt = stmt.where(Asset.depot_id == depot_id)
    if item_id:
        stmt = stmt.where(Asset.item_id == item_id)
    if technical_state:
        stmt = stmt.where(Asset.technical_state == technical_state)
    if lifecycle:
        stmt = stmt.where(Asset.lifecycle == lifecycle)
    if q:
        norm = inv.normalize_serial(q)
        stmt = stmt.where(or_(Asset.serial_normalized.contains(norm), Asset.internal_tag.ilike(f"%{q}%")))
    return paginate(ctx, stmt, page, lambda a: asset_dict(ctx, a))


def load_asset(ctx, asset_id: uuid.UUID) -> Asset:
    asset = ctx.db.get(Asset, asset_id)
    if asset is None:
        raise NotFound("Équipement introuvable.")
    ctx.require("stock.read", asset.depot_id)
    return asset


@router.get("/assets/{asset_id}")
def get_asset(ctx: CtxDep, asset_id: uuid.UUID):
    from app.modules.maintenance.models import MaintenanceOrder

    asset = load_asset(ctx, asset_id)
    out = asset_dict(ctx, asset)
    open_orders = ctx.db.execute(
        select(MaintenanceOrder).where(MaintenanceOrder.asset_id == asset.id, MaintenanceOrder.status.notin_(["CLOSED", "CANCELLED"]))
    ).scalars().all()
    out["open_maintenance_orders"] = [{"id": o.id, "reference": o.reference, "status": o.status} for o in open_orders]
    res = ctx.db.execute(select(Reservation).where(Reservation.asset_id == asset.id, Reservation.status == "ACTIVE")).scalars().first()
    out["active_reservation"] = {"id": res.id, "request_line_id": res.request_line_id, "transfer_line_id": res.transfer_line_id} if res else None
    out["explanation"] = explain_asset(ctx, asset)
    return out


def explain_asset(ctx, a: Asset) -> str:
    """Phrase explicable : localisation, état, responsable."""
    labels = {
        "IN_STOCK": "en stock", "RESERVED": "réservé", "ISSUED": "remis", "IN_TRANSIT": "en transit",
        "MISSING": "manquant (écart de transfert)", "CONDEMNED": "réformé",
    }
    tech = {
        "AWAITING_INSPECTION": "en attente de contrôle", "SERVICEABLE": "apte", "UNSERVICEABLE": "inapte",
        "IN_MAINTENANCE": "en maintenance", "CONDEMNED": "réformé",
    }
    loc = ctx.db.get(Location, a.location_id) if a.location_id else None
    depot = ctx.db.get(Depot, a.depot_id)
    where = f"à l'emplacement {loc.code} du {depot.name}" if loc else (
        "hors dépôt" if a.lifecycle != "IN_TRANSIT" else "entre deux dépôts")
    org = ctx.db.get(Organization, a.custody_org_id) if a.custody_org_id else None
    who = (f"sous la garde de {org.name}" + (f" (responsable : {a.custody_person})" if a.custody_person else "")) if org else (
        f"sous la garde du {depot.name}" if a.custody_type == "DEPOT" else "sous la garde du transporteur" if a.custody_type == "CARRIER" else "sans garde déclarée")
    return f"{labels.get(a.lifecycle, a.lifecycle).capitalize()} {where}, état technique : {tech.get(a.technical_state, a.technical_state)}, {who}."


PHASES = {
    MovementType.RECEIPT: "RECEPTION", MovementType.PUTAWAY: "EMPLACEMENT", MovementType.RELOCATION: "EMPLACEMENT",
    MovementType.TRANSFER_OUT: "EMPLACEMENT", MovementType.TRANSFER_IN: "EMPLACEMENT", MovementType.RESERVE: "AFFECTATION",
    MovementType.UNRESERVE: "AFFECTATION", MovementType.ISSUE: "AFFECTATION", MovementType.RETURN: "RETOUR",
    MovementType.STATUS_CHANGE: "ETAT", MovementType.QUARANTINE: "ETAT", MovementType.CONDEMNATION: "ETAT",
    MovementType.CORRECTION: "EMPLACEMENT", MovementType.ADJUSTMENT: "EMPLACEMENT", MovementType.LOSS: "ETAT",
    MovementType.CONSUMPTION: "ETAT",
}

MOVEMENT_LABELS = {
    "RECEIPT": "Réception", "PUTAWAY": "Mise en emplacement", "RELOCATION": "Déplacement interne",
    "STATUS_CHANGE": "Changement de statut", "QUARANTINE": "Mise en quarantaine", "RESERVE": "Réservation",
    "UNRESERVE": "Libération de réservation", "ISSUE": "Remise", "RETURN": "Retour", "TRANSFER_OUT": "Expédition (transfert)",
    "TRANSFER_IN": "Réception (transfert)", "CONSUMPTION": "Consommation", "CONDEMNATION": "Réforme",
    "ADJUSTMENT": "Ajustement d'inventaire", "LOSS": "Perte constatée", "CORRECTION": "Correction liée",
}


STATUS_FR = {"USABLE": "utilisable", "PENDING_INSPECTION": "non contrôlé", "QUARANTINE": "quarantaine", "MAINTENANCE": "maintenance"}


def movement_phase(m: StockMovement) -> str:
    """Phase de traçabilité d'un mouvement, déterminée d'après son origine métier."""
    by_source = {"MAINTENANCE_ORDER": "MAINTENANCE", "DECISION": "ETAT", "RETURN": "RETOUR", "INSPECTION": "RECEPTION",
                 "STOCKTAKE": "EMPLACEMENT", "TRANSFER": "EMPLACEMENT"}
    if m.movement_type in (MovementType.STATUS_CHANGE, MovementType.QUARANTINE, MovementType.CONDEMNATION) and m.source_type in by_source:
        return by_source[m.source_type]
    return PHASES.get(m.movement_type, "EMPLACEMENT")


@router.get("/assets/{asset_id}/history")
def asset_history(ctx: CtxDep, asset_id: uuid.UUID):
    """Traçabilité : réception → emplacements → affectations → retours → maintenance → état actuel."""
    from app.modules.documents.models import Document
    from app.modules.maintenance.models import MaintenanceOrder, ReleaseDecision
    from app.modules.requests.models import Allocation, AllocationLine, ReturnRecord

    asset = load_asset(ctx, asset_id)
    events: list[dict] = []
    cache: dict = {}
    for m in ctx.db.execute(select(StockMovement).where(StockMovement.asset_id == asset.id).order_by(StockMovement.seq)).scalars():
        d = movement_dict(ctx, m, cache)
        detail = " → ".join(x for x in [d["from_location"], d["to_location"]] if x) or ""
        if m.movement_type == MovementType.ISSUE and m.counterpart_org_id:
            org = ctx.db.get(Organization, m.counterpart_org_id)
            detail = f"Remis à {org.name}"
        events.append({
            "at": m.occurred_at, "seq": m.seq, "phase": movement_phase(m), "kind": "MOVEMENT",
            "title": MOVEMENT_LABELS.get(m.movement_type, m.movement_type), "reference": m.reference,
            "detail": detail, "status_change": (f"{STATUS_FR.get(m.from_status, 'hors stock')} → {STATUS_FR.get(m.to_status, 'hors stock')}"
                                                if m.from_status != m.to_status else None),
            "actor": d["actor"], "source_type": m.source_type, "source_id": m.source_id, "source_ref": m.source_ref, "reason": m.reason,
            "_t": m.recorded_at,
        })
    for i in ctx.db.execute(select(Inspection).where(Inspection.asset_id == asset.id)).scalars():
        u = ctx.db.get(User, i.inspector_id)
        events.append({
            "at": i.performed_at, "seq": None, "phase": {"RECEIPT": "RECEPTION", "RETURN": "RETOUR"}.get(i.kind, "MAINTENANCE"), "kind": "INSPECTION",
            "title": {"RECEIPT": "Contrôle de réception", "RETURN": "Contrôle de retour", "PRE_RELEASE": "Contrôle avant remise à disposition",
                      "PERIODIC": "Contrôle périodique"}.get(i.kind, "Contrôle"),
            "reference": i.reference, "detail": f"Résultat : {i.result}. {i.findings}".strip(), "actor": u.full_name if u else None,
            "source_type": "INSPECTION", "source_id": i.id, "_t": i.created_at,
        })
    for o in ctx.db.execute(select(MaintenanceOrder).where(MaintenanceOrder.asset_id == asset.id)).scalars():
        u = ctx.db.get(User, o.signaled_by)
        events.append({"at": o.signaled_at, "seq": None, "phase": "MAINTENANCE", "kind": "MAINTENANCE", "title": "Ordre de maintenance signalé",
                       "reference": o.reference, "detail": o.defect_description, "actor": u.full_name if u else None,
                       "source_type": "MAINTENANCE_ORDER", "source_id": o.id, "_t": o.created_at})
        if o.started_at:
            events.append({"at": o.started_at, "seq": None, "phase": "MAINTENANCE", "kind": "MAINTENANCE", "title": "Intervention démarrée",
                           "reference": o.reference, "detail": o.technician_name or "", "actor": None, "source_type": "MAINTENANCE_ORDER", "source_id": o.id,
                           "_t": o.updated_at})
        if o.closed_at:
            cu = ctx.db.get(User, o.closed_by) if o.closed_by else None
            events.append({"at": o.closed_at, "seq": None, "phase": "MAINTENANCE", "kind": "MAINTENANCE", "title": "Ordre clôturé (ne vaut pas aptitude)",
                           "reference": o.reference, "detail": o.work_result, "actor": cu.full_name if cu else None,
                           "source_type": "MAINTENANCE_ORDER", "source_id": o.id, "_t": o.updated_at})
    for r in ctx.db.execute(select(ReleaseDecision).where(ReleaseDecision.asset_id == asset.id)).scalars():
        u = ctx.db.get(User, r.decided_by)
        events.append({"at": r.decided_at, "seq": None, "phase": "ETAT", "kind": "DECISION",
                       "title": {"RETURN_TO_SERVICE": "Décision : remise à disposition", "CONDEMN": "Décision : réforme",
                                 "KEEP_UNSERVICEABLE": "Décision : maintien inapte"}.get(r.decision, r.decision),
                       "reference": r.reference, "detail": r.reason, "actor": u.full_name if u else None, "source_type": "DECISION", "source_id": r.id, "_t": r.created_at})
    for line in ctx.db.execute(select(AllocationLine).where(AllocationLine.asset_id == asset.id)).scalars():
        alloc = ctx.db.get(Allocation, line.allocation_id)
        for ret in ctx.db.execute(select(ReturnRecord).where(ReturnRecord.allocation_line_id == line.id)).scalars():
            events.append({"at": ret.returned_at, "seq": None, "phase": "RETOUR", "kind": "RETURN", "title": "Retour enregistré",
                           "reference": ret.reference, "detail": f"État constaté : {ret.condition}. {ret.observed_condition}",
                           "actor": ret.returned_by_name, "source_type": "RETURN", "source_id": ret.id, "_t": ret.created_at})
        events.append({"at": alloc.issued_at, "seq": None, "phase": "AFFECTATION", "kind": "ALLOCATION",
                       "title": "Prêt" if line.kind == "LOAN" else "Dotation", "reference": alloc.reference,
                       "detail": f"Bénéficiaire : {alloc.recipient_name} — échéance {line.due_date or '—'}", "actor": None,
                       "source_type": "ALLOCATION", "source_id": alloc.id, "_t": alloc.created_at})
    events.sort(key=lambda e: (e["at"], e["_t"]))
    for e in events:
        e.pop("_t", None)
    docs = ctx.db.execute(select(Document).where(Document.owner_type == "ASSET", Document.owner_id == asset.id)).scalars().all()
    phases = ["RECEPTION", "EMPLACEMENT", "AFFECTATION", "RETOUR", "MAINTENANCE", "ETAT"]
    return {
        "asset": asset_dict(ctx, asset),
        "explanation": explain_asset(ctx, asset),
        "phases": [{"code": p, "count": sum(1 for e in events if e["phase"] == p)} for p in phases],
        "events": events,
        "documents": [{"id": d.id, "reference": d.reference, "title": d.title, "kind": d.kind, "version": d.current_version} for d in docs],
    }


# ----------------------------------------------------------------------------- contrôles de stock
class StockInspectionIn(StrictModel):
    location_id: uuid.UUID
    item_id: uuid.UUID
    variant_id: uuid.UUID | None = None
    lot_id: uuid.UUID | None = None
    from_status: Literal["PENDING_INSPECTION", "QUARANTINE"]
    accepted_qty: Decimal = Field(ge=0)
    quarantined_qty: Decimal = Field(default=Decimal(0), ge=0)
    condemned_qty: Decimal = Field(default=Decimal(0), ge=0)
    findings: str = Field(min_length=3, max_length=2000)
    checklist: list[dict] = Field(default_factory=list)


@router.post("/inspections/stock", status_code=201, tags=["Contrôles"])
def inspect_stock(ctx: CtxDep, body: StockInspectionIn):
    """Contrôle d'une quantité bloquée (retours, quarantaine) : requalification attribuée."""
    loc = inv.get_location(ctx, body.location_id)
    ctx.require("inspection.stock", loc.depot_id)
    item = ctx.db.get(Item, body.item_id)
    if item is None or item.tracking == "SERIAL":
        raise ValidationFailed("Les exemplaires sérialisés se contrôlent individuellement (POST /v1/inspections/asset).")
    total = body.accepted_qty + body.quarantined_qty + body.condemned_qty
    if total <= 0:
        raise ValidationFailed("Aucune quantité contrôlée.")
    status = StockStatus(body.from_status)
    insp = Inspection(
        id=uuid.uuid4(), reference=next_reference(ctx.db, "inspection", ctx.now.year), kind="STOCK", subject_type="STOCK_POSITION",
        subject_id=loc.id, depot_id=loc.depot_id, result=InspectionResult.PASS if total == body.accepted_qty else InspectionResult.PARTIAL,
        accepted_qty=body.accepted_qty, rejected_qty=body.quarantined_qty + body.condemned_qty, checklist=body.checklist,
        findings=body.findings, inspector_id=ctx.user_id, performed_at=ctx.now,
    )
    ctx.db.add(insp)
    src = ("INSPECTION", insp.id, insp.reference)
    moves = []
    if body.accepted_qty > 0:
        moves.append(inv.change_status(ctx, item=item, location=loc, from_status=status, to_status=StockStatus.USABLE, quantity=body.accepted_qty,
                                       variant_id=body.variant_id, lot_id=body.lot_id, source=src, reason=body.findings))
    if body.quarantined_qty > 0 and status != StockStatus.QUARANTINE:
        qloc = inv.location_of_kind(ctx, loc.depot_id, LocationKind.QUARANTINE)
        moves.append(inv.change_status(ctx, item=item, location=loc, from_status=status, to_status=StockStatus.QUARANTINE,
                                       quantity=body.quarantined_qty, variant_id=body.variant_id, lot_id=body.lot_id, source=src,
                                       reason=body.findings, mtype=MovementType.QUARANTINE, to_location=qloc))
    if body.condemned_qty > 0:
        moves.append(inv.post_movement(ctx, mtype=MovementType.CONDEMNATION, item=item, quantity=body.condemned_qty, variant_id=body.variant_id,
                                       lot_id=body.lot_id, from_location=loc, from_status=status, source=src, reason=body.findings))
    audit(ctx, "inspection.stock", "INSPECTION", insp.id, object_ref=insp.reference, depot_id=loc.depot_id,
          details={"accepted": body.accepted_qty, "quarantined": body.quarantined_qty, "condemned": body.condemned_qty})
    ctx.commit()
    return {"id": insp.id, "reference": insp.reference, "movements": [m.reference for m in moves]}
