"""Encodeur Code 128 (jeu B) → SVG, pour les étiquettes internes (sans dépendance)."""
from __future__ import annotations

from xml.sax.saxutils import escape

PATTERNS = [
    "212222", "222122", "222221", "121223", "121322", "131222", "122213", "122312", "132212", "221213",
    "221312", "231212", "112232", "122132", "122231", "113222", "123122", "123221", "223211", "221132",
    "221231", "213212", "223112", "312131", "311222", "321122", "321221", "312212", "322112", "322211",
    "212123", "212321", "232121", "111323", "131123", "131321", "112313", "132113", "132311", "211313",
    "231113", "231311", "112133", "112331", "132131", "113123", "113321", "133121", "313121", "211331",
    "231131", "213113", "213311", "213131", "311123", "311321", "331121", "312113", "312311", "332111",
    "314111", "221411", "431111", "111224", "111422", "121124", "121421", "141122", "141221", "112214",
    "112412", "122114", "122411", "142112", "142211", "241211", "221114", "413111", "241112", "134111",
    "111242", "121142", "121241", "114212", "124112", "124211", "411212", "421112", "421211", "212141",
    "214121", "412121", "111143", "111341", "131141", "114113", "114311", "411113", "411311", "113141",
    "114131", "311141", "411131", "211412", "211214", "211232", "2331112",
]
START_B, STOP = 104, 106


def encode_b(text: str) -> list[int]:
    if not text or any(not (32 <= ord(c) <= 126) for c in text):
        raise ValueError("Code 128-B : caractères ASCII imprimables uniquement")
    values = [ord(c) - 32 for c in text]
    checksum = (START_B + sum(i * v for i, v in enumerate(values, start=1))) % 103
    return [START_B, *values, checksum, STOP]


def modules(text: str) -> list[int]:
    widths: list[int] = []
    for code in encode_b(text):
        widths.extend(int(c) for c in PATTERNS[code])
    return widths


def svg(text: str, caption: str | None = None, module: float = 2.0, height: int = 70) -> str:
    widths = modules(text)
    quiet = 10 * module
    total = sum(widths) * module + 2 * quiet
    x = quiet
    rects = []
    for i, w in enumerate(widths):
        if i % 2 == 0:
            rects.append(f'<rect x="{x:.1f}" y="8" width="{w * module:.1f}" height="{height}"/>')
        x += w * module
    label = escape(caption or text)
    return (
        f'<svg xmlns="http://www.w3.org/2000/svg" width="{total:.0f}" height="{height + 36}" viewBox="0 0 {total:.0f} {height + 36}" '
        f'role="img" aria-label="Étiquette {escape(text)}"><rect width="100%" height="100%" fill="#fff"/>'
        f'<g fill="#000">{"".join(rects)}</g>'
        f'<text x="{total / 2:.0f}" y="{height + 26}" font-family="monospace" font-size="14" text-anchor="middle">{label}</text></svg>'
    )
