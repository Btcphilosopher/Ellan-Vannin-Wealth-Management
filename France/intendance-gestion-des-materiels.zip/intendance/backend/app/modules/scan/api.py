"""Scan d'étiquettes internes : identifie un enregistrement, ne prouve ni l'état physique ni un contrôle."""
from __future__ import annotations

import uuid

from fastapi import APIRouter, Path
from fastapi.responses import Response
from sqlalchemy import select

from app.core.deps import CtxDep
from app.core.errors import NotFound
from app.modules.catalog.models import Item, Lot
from app.modules.inventory.models import Asset, Location
from app.modules.inventory.service import normalize_serial
from app.modules.scan.barcode import svg

router = APIRouter(prefix="/v1", tags=["Étiquettes et scan"])

WARNING = ("Un scan identifie un enregistrement ; il ne prouve ni l'état physique du matériel, "
           "ni sa présence effective, ni la réalisation d'un contrôle.")


@router.get("/scan/{code}")
def scan(ctx: CtxDep, code: str = Path(min_length=2, max_length=80)):
    ctx.require("stock.read")
    code = code.strip()
    visible = ctx.visible_depot_ids()
    matches = []
    asset = ctx.db.execute(select(Asset).where(Asset.internal_tag == code.upper())).scalar_one_or_none()
    if asset is None:
        asset = ctx.db.execute(select(Asset).where(Asset.serial_normalized == normalize_serial(code))).scalars().first()
    if asset is not None and asset.depot_id in visible:
        item = ctx.db.get(Item, asset.item_id)
        matches.append({"kind": "ASSET", "id": asset.id, "label": f"{item.designation} — n° {asset.serial_number}",
                        "reference": asset.internal_tag, "link": f"/equipements/{asset.id}"})
    loc = ctx.db.execute(select(Location).where(Location.internal_tag == code.upper())).scalar_one_or_none()
    if loc is not None and loc.depot_id in visible:
        matches.append({"kind": "LOCATION", "id": loc.id, "label": f"Emplacement {loc.code} — {loc.label}", "reference": loc.internal_tag,
                        "link": f"/stocks?location={loc.id}&depot={loc.depot_id}"})
    item = ctx.db.execute(select(Item).where(Item.code == code.upper())).scalar_one_or_none()
    if item is not None:
        matches.append({"kind": "ITEM", "id": item.id, "label": item.designation, "reference": item.code, "link": f"/catalogue/{item.id}"})
    for lot in ctx.db.execute(select(Lot).where(Lot.lot_number == code)).scalars():
        li = ctx.db.get(Item, lot.item_id)
        matches.append({"kind": "LOT", "id": lot.id, "label": f"Lot {lot.lot_number} — {li.designation}", "reference": lot.lot_number,
                        "link": f"/catalogue/{li.id}"})
    if not matches:
        raise NotFound("Aucun enregistrement ne correspond à ce code dans votre périmètre.")
    return {"code": code, "matches": matches, "warning": WARNING}


@router.get("/labels/assets/{asset_id}.svg")
def asset_label(ctx: CtxDep, asset_id: uuid.UUID):
    asset = ctx.db.get(Asset, asset_id)
    if asset is None:
        raise NotFound("Équipement introuvable.")
    ctx.require("stock.read", asset.depot_id)
    return Response(svg(asset.internal_tag, f"{asset.internal_tag} · {asset.serial_number}".encode("ascii", "replace").decode()),
                    media_type="image/svg+xml")


@router.get("/labels/locations/{location_id}.svg")
def location_label(ctx: CtxDep, location_id: uuid.UUID):
    loc = ctx.db.get(Location, location_id)
    if loc is None:
        raise NotFound("Emplacement introuvable.")
    ctx.require("stock.read", loc.depot_id)
    return Response(svg(loc.internal_tag, f"{loc.internal_tag} · {loc.code}"), media_type="image/svg+xml")
