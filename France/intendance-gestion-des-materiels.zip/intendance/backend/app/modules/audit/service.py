from __future__ import annotations

import uuid

from app.core.logging import redact
from app.db import SessionLocal
from app.modules.audit.models import AuditEvent


def _clean(details: dict | None) -> dict:
    if not details:
        return {}
    return redact(_jsonable(details))


def _jsonable(value):
    if isinstance(value, dict):
        return {str(k): _jsonable(v) for k, v in value.items()}
    if isinstance(value, (list, tuple, set)):
        return [_jsonable(v) for v in value]
    if isinstance(value, (str, int, float, bool)) or value is None:
        return value
    return str(value)


def audit(
    ctx,
    action: str,
    object_type: str | None = None,
    object_id=None,
    *,
    object_ref: str | None = None,
    depot_id: uuid.UUID | None = None,
    reason: str | None = None,
    details: dict | None = None,
    outcome: str = "SUCCESS",
) -> AuditEvent:
    event = AuditEvent(
        occurred_at=ctx.now,
        actor_id=ctx.user.id if ctx.user else None,
        actor_name=ctx.user.full_name if ctx.user else None,
        action=action,
        outcome=outcome,
        object_type=object_type,
        object_id=str(object_id) if object_id else None,
        object_ref=object_ref,
        depot_id=depot_id,
        reason=reason,
        request_id=ctx.request_id,
        ip=ctx.ip,
        details=_clean(details),
    )
    ctx.db.add(event)
    return event


def audit_out_of_band(ctx, action: str, *, outcome: str, details: dict | None = None, reason: str | None = None) -> None:
    """Journalise dans une transaction séparée (ex. refus d'accès : la transaction métier est annulée)."""
    with SessionLocal() as db:
        db.add(
            AuditEvent(
                occurred_at=ctx.now,
                actor_id=ctx.actor_id,
                actor_name=ctx.actor_name,
                action=action,
                outcome=outcome,
                request_id=ctx.request_id,
                ip=ctx.ip,
                reason=reason,
                details=_clean(details),
            )
        )
        db.commit()
