from __future__ import annotations

from datetime import datetime

from fastapi import APIRouter, Query
from sqlalchemy import select

from app.core.deps import CtxDep, PageDep, paginate
from app.modules.audit.models import AuditEvent

router = APIRouter(prefix="/v1", tags=["Audit"])


def event_dict(e: AuditEvent) -> dict:
    return {
        "id": e.id, "seq": e.seq, "occurred_at": e.occurred_at, "recorded_at": e.recorded_at, "actor_id": e.actor_id,
        "actor_name": e.actor_name, "action": e.action, "outcome": e.outcome, "object_type": e.object_type, "object_id": e.object_id,
        "object_ref": e.object_ref, "depot_id": e.depot_id, "reason": e.reason, "request_id": e.request_id, "ip": e.ip, "details": e.details,
    }


def audit_query(actor_id=None, action=None, object_type=None, object_id=None, outcome=None, request_id=None, since=None, until=None):
    stmt = select(AuditEvent).order_by(AuditEvent.seq.desc())
    if actor_id:
        stmt = stmt.where(AuditEvent.actor_id == actor_id)
    if action:
        stmt = stmt.where(AuditEvent.action.like(f"{action}%"))
    if object_type:
        stmt = stmt.where(AuditEvent.object_type == object_type)
    if object_id:
        stmt = stmt.where(AuditEvent.object_id == str(object_id))
    if outcome:
        stmt = stmt.where(AuditEvent.outcome == outcome)
    if request_id:
        stmt = stmt.where(AuditEvent.request_id == request_id)
    if since:
        stmt = stmt.where(AuditEvent.occurred_at >= since)
    if until:
        stmt = stmt.where(AuditEvent.occurred_at <= until)
    return stmt


@router.get("/audit-events")
def list_audit_events(
    ctx: CtxDep, page: PageDep, actor_id: str | None = None, action: str | None = Query(None, max_length=80),
    object_type: str | None = None, object_id: str | None = None, outcome: str | None = None, request_id: str | None = None,
    since: datetime | None = None, until: datetime | None = None,
):
    """Journal d'audit (acteur, action, objet, date, motif, identifiant de requête). Lecture réservée aux auditeurs."""
    ctx.require("audit.read")
    stmt = audit_query(actor_id, action, object_type, object_id, outcome, request_id, since, until)
    return paginate(ctx, stmt, page, event_dict)
