"""Documents versionnés : bons de réception, fiches techniques, PV de contrôle, justificatifs, rapports."""
from __future__ import annotations

import hashlib
import re
import uuid

from fastapi import APIRouter, File, Form, UploadFile
from fastapi.responses import Response
from sqlalchemy import select

from app.config import get_settings
from app.core.deps import CtxDep, PageDep, paginate
from app.core.errors import Forbidden, NotFound, ValidationFailed, expect_version
from app.core.refs import next_reference
from app.modules.audit.service import audit
from app.modules.documents.models import DOCUMENT_KINDS, Document, DocumentVersion
from app.modules.documents.storage import get_storage, new_key, sniff_type
from app.modules.org.models import User

router = APIRouter(prefix="/v1/documents", tags=["Documents"])

OWNER_TYPES = {"ITEM", "RECEIPT", "REQUEST", "ALLOCATION", "TRANSFER", "MAINTENANCE_ORDER", "ASSET", "STOCKTAKE", "INSPECTION", "REPORT"}


def owner_depot(ctx, owner_type: str, owner_id: uuid.UUID):
    """Retourne le dépôt de rattachement de l'objet propriétaire (None = catalogue, transverse)."""
    from app.modules.inventory.models import Asset, Inspection
    from app.modules.maintenance.models import MaintenanceOrder
    from app.modules.receipts.models import Receipt
    from app.modules.requests.models import Allocation, SupplyRequest
    from app.modules.stocktakes.models import Stocktake
    from app.modules.transfers.models import Transfer

    if owner_type in ("ITEM", "REPORT"):
        return None
    model = {"RECEIPT": Receipt, "REQUEST": SupplyRequest, "ALLOCATION": Allocation, "TRANSFER": Transfer, "MAINTENANCE_ORDER": MaintenanceOrder,
             "ASSET": Asset, "STOCKTAKE": Stocktake, "INSPECTION": Inspection}[owner_type]
    obj = ctx.db.get(model, owner_id)
    if obj is None:
        raise NotFound("Objet de rattachement introuvable.")
    return getattr(obj, "depot_id", None) or getattr(obj, "source_depot_id", None)


def can_read(ctx, doc: Document) -> bool:
    perm = "document.read_restricted" if doc.access_level == "RESTRICTED" else "document.read"
    if doc.owner_type == "REPORT":
        return ctx.can("report.export") or ctx.user_id == doc.created_by
    return ctx.can(perm, doc.depot_id)


def doc_dict(ctx, d: Document) -> dict:
    users = {u.id: u.full_name for u in ctx.db.execute(select(User)).scalars()}
    return {
        "id": d.id, "reference": d.reference, "kind": d.kind, "kind_label": DOCUMENT_KINDS.get(d.kind, d.kind), "title": d.title,
        "owner_type": d.owner_type, "owner_id": d.owner_id, "depot_id": d.depot_id, "access_level": d.access_level,
        "current_version": d.current_version, "version": d.version, "created_by": users.get(d.created_by),
        "versions": [{"version_no": v.version_no, "filename": v.filename, "content_type": v.content_type, "size_bytes": v.size_bytes,
                      "sha256": v.sha256, "author": users.get(v.author_id), "created_at": v.created_at, "comment": v.comment} for v in d.versions],
    }


def _safe_filename(name: str) -> str:
    base = re.sub(r"[^A-Za-z0-9._-]+", "_", (name or "fichier").rsplit("/", 1)[-1].rsplit("\\", 1)[-1])
    return base[:120] or "fichier"


def store_document(ctx, *, owner_type: str, owner_id: uuid.UUID, kind: str, title: str, filename: str, data: bytes,
                   declared_type: str | None = None, access_level: str = "INTERNAL", comment: str = "", document: Document | None = None) -> Document:
    if owner_type not in OWNER_TYPES:
        raise ValidationFailed("Type de rattachement inconnu.")
    if kind not in DOCUMENT_KINDS:
        raise ValidationFailed("Nature de document inconnue.")
    if not data:
        raise ValidationFailed("Fichier vide.")
    if len(data) > get_settings().max_upload_bytes:
        raise ValidationFailed("Fichier trop volumineux.")
    try:
        ctype = sniff_type(data, declared_type, filename)
    except ValueError as exc:
        raise ValidationFailed(str(exc), code="type_fichier_refuse") from exc
    depot_id = owner_depot(ctx, owner_type, owner_id)
    if owner_type == "ITEM":
        ctx.require("catalog.write")
    elif owner_type != "REPORT":
        ctx.require("document.write", depot_id)
    if document is None:
        document = Document(id=uuid.uuid4(), reference=next_reference(ctx.db, "document", ctx.now.year), kind=kind, title=title,
                            owner_type=owner_type, owner_id=owner_id, depot_id=depot_id, access_level=access_level, created_by=ctx.user_id,
                            current_version=0)
        ctx.db.add(document)
    key = new_key()
    get_storage().put(key, data, ctype)
    document.current_version += 1
    v = DocumentVersion(id=uuid.uuid4(), document_id=document.id, version_no=document.current_version, storage_key=key,
                        filename=_safe_filename(filename), content_type=ctype, size_bytes=len(data), sha256=hashlib.sha256(data).hexdigest(),
                        comment=comment, author_id=ctx.user_id, created_at=ctx.now)
    ctx.db.add(v)
    document.versions.append(v)
    audit(ctx, "document.version", "DOCUMENT", document.id, object_ref=document.reference, depot_id=depot_id,
          details={"version": document.current_version, "sha256": v.sha256, "owner": f"{owner_type}:{owner_id}"})
    return document


@router.get("")
def list_documents(ctx: CtxDep, page: PageDep, owner_type: str | None = None, owner_id: uuid.UUID | None = None, kind: str | None = None):
    ctx.require("document.read")
    vis = ctx.visible_depot_ids("document.read")
    restricted = ctx.visible_depot_ids("document.read_restricted")
    stmt = select(Document).where(
        ((Document.depot_id.is_(None)) & (Document.owner_type != "REPORT"))
        | ((Document.access_level == "INTERNAL") & Document.depot_id.in_(vis))
        | ((Document.access_level == "RESTRICTED") & Document.depot_id.in_(restricted))
        | ((Document.owner_type == "REPORT") & ((Document.created_by == ctx.user_id) | (ctx.can("report.export"))))
    ).order_by(Document.created_at.desc())
    if owner_type:
        stmt = stmt.where(Document.owner_type == owner_type)
    if owner_id:
        stmt = stmt.where(Document.owner_id == owner_id)
    if kind:
        stmt = stmt.where(Document.kind == kind)
    return paginate(ctx, stmt, page, lambda d: doc_dict(ctx, d))


@router.get("/kinds")
def kinds(ctx: CtxDep):
    return [{"code": k, "label": v} for k, v in DOCUMENT_KINDS.items()]


@router.post("", status_code=201)
async def upload_document(
    ctx: CtxDep,
    file: UploadFile = File(...),
    owner_type: str = Form(...),
    owner_id: uuid.UUID = Form(...),
    kind: str = Form(...),
    title: str = Form(..., min_length=2, max_length=200),
    access_level: str = Form("INTERNAL", pattern="^(INTERNAL|RESTRICTED)$"),
    comment: str = Form(""),
):
    data = await file.read(get_settings().max_upload_bytes + 1)
    doc = store_document(ctx, owner_type=owner_type, owner_id=owner_id, kind=kind, title=title, filename=file.filename or "fichier",
                         data=data, declared_type=file.content_type, access_level=access_level, comment=comment)
    ctx.commit()
    return doc_dict(ctx, doc)


def _load(ctx, document_id) -> Document:
    d = ctx.db.get(Document, document_id)
    if d is None:
        raise NotFound("Document introuvable.")
    if not can_read(ctx, d):
        raise Forbidden("Document hors de votre périmètre ou à diffusion restreinte.")
    return d


@router.get("/{document_id}")
def get_document(ctx: CtxDep, document_id: uuid.UUID):
    return doc_dict(ctx, _load(ctx, document_id))


@router.post("/{document_id}/versions", status_code=201)
async def new_version(ctx: CtxDep, document_id: uuid.UUID, file: UploadFile = File(...), version: int = Form(...), comment: str = Form("")):
    d = _load(ctx, document_id)
    expect_version(d, version)
    data = await file.read(get_settings().max_upload_bytes + 1)
    store_document(ctx, owner_type=d.owner_type, owner_id=d.owner_id, kind=d.kind, title=d.title, filename=file.filename or "fichier",
                   data=data, declared_type=file.content_type, comment=comment, document=d)
    ctx.commit()
    return doc_dict(ctx, d)


@router.get("/{document_id}/versions/{version_no}/content")
def download(ctx: CtxDep, document_id: uuid.UUID, version_no: int):
    d = _load(ctx, document_id)
    v = next((x for x in d.versions if x.version_no == version_no), None)
    if v is None:
        raise NotFound("Version introuvable.")
    data = get_storage().get(v.storage_key)
    if hashlib.sha256(data).hexdigest() != v.sha256:
        raise ValidationFailed("Intégrité du fichier non vérifiée (empreinte différente).", code="integrite")
    audit(ctx, "document.download", "DOCUMENT", d.id, object_ref=d.reference, depot_id=d.depot_id, details={"version": version_no})
    ctx.commit()
    return Response(content=data, media_type=v.content_type, headers={
        "Content-Disposition": f'attachment; filename="{v.filename}"', "X-Content-Type-Options": "nosniff",
        "Content-Security-Policy": "default-src 'none'; sandbox",
    })
