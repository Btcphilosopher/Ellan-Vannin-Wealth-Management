"""Stockage objet protégé : système de fichiers local (permissions 0600) ou S3 compatible (MinIO).

Les fichiers ne sont jamais servis directement : l'API vérifie les permissions puis diffuse le contenu.
Les clés de stockage sont aléatoires et ne révèlent ni le nom ni le propriétaire du fichier.
"""
from __future__ import annotations

import os
import uuid
from pathlib import Path
from typing import Protocol

from app.config import get_settings


class ObjectStorage(Protocol):
    def put(self, key: str, data: bytes, content_type: str) -> None: ...

    def get(self, key: str) -> bytes: ...


class LocalStorage:
    def __init__(self, root: str):
        self.root = Path(root).resolve()
        self.root.mkdir(parents=True, exist_ok=True, mode=0o700)

    def _path(self, key: str) -> Path:
        p = (self.root / key).resolve()
        if self.root not in p.parents:
            raise ValueError("Clé de stockage invalide")
        return p

    def put(self, key: str, data: bytes, content_type: str) -> None:
        p = self._path(key)
        p.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
        fd = os.open(p, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
        with os.fdopen(fd, "wb") as f:
            f.write(data)

    def get(self, key: str) -> bytes:
        return self._path(key).read_bytes()


class S3Storage:
    def __init__(self):
        import boto3

        s = get_settings()
        self.bucket = s.s3_bucket
        self.client = boto3.client("s3", endpoint_url=s.s3_endpoint_url, aws_access_key_id=s.s3_access_key, aws_secret_access_key=s.s3_secret_key)

    def put(self, key: str, data: bytes, content_type: str) -> None:
        self.client.put_object(Bucket=self.bucket, Key=key, Body=data, ContentType=content_type, ServerSideEncryption="AES256")

    def get(self, key: str) -> bytes:
        return self.client.get_object(Bucket=self.bucket, Key=key)["Body"].read()


_storage: ObjectStorage | None = None


def get_storage() -> ObjectStorage:
    global _storage
    if _storage is None:
        s = get_settings()
        _storage = S3Storage() if s.storage_backend == "s3" else LocalStorage(s.storage_local_path)
    return _storage


def new_key() -> str:
    k = uuid.uuid4().hex
    return f"{k[:2]}/{k}"


ALLOWED = {
    "application/pdf": (".pdf", [b"%PDF-"]),
    "image/png": (".png", [b"\x89PNG\r\n\x1a\n"]),
    "image/jpeg": (".jpg", [b"\xff\xd8\xff"]),
    "text/plain": (".txt", []),
    "text/csv": (".csv", []),
}


def sniff_type(data: bytes, declared: str | None, filename: str) -> str:
    """Détermine le type réel à partir du contenu ; refuse tout ce qui n'est pas sur la liste autorisée."""
    for ctype, (_, magics) in ALLOWED.items():
        if magics and any(data.startswith(m) for m in magics):
            return ctype
    if b"\x00" in data[:4096]:
        raise ValueError("Type de fichier non autorisé.")
    try:
        data[:65536].decode("utf-8")
    except UnicodeDecodeError as exc:
        raise ValueError("Type de fichier non autorisé.") from exc
    return "text/csv" if filename.lower().endswith(".csv") or declared == "text/csv" else "text/plain"
