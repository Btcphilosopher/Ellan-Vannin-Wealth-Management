from __future__ import annotations

import uuid
from datetime import datetime

from sqlalchemy import BigInteger, DateTime, ForeignKey, Integer, String, Text, UniqueConstraint
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.db import Base, Timestamped, Versioned, uuid_pk

DOCUMENT_KINDS = {
    "RECEIPT_NOTE": "Bon de réception",
    "TECHNICAL_SHEET": "Fiche technique",
    "INSPECTION_REPORT": "Procès-verbal de contrôle",
    "HANDOVER_PROOF": "Justificatif de remise",
    "MAINTENANCE_REPORT": "Rapport de maintenance",
    "TRANSFER_NOTE": "Bordereau de transfert",
    "REPORT_EXPORT": "Export de rapport",
    "OTHER": "Autre",
}


class Document(Base, Timestamped, Versioned):
    __tablename__ = "documents"
    id: Mapped[uuid.UUID] = uuid_pk()
    reference: Mapped[str] = mapped_column(String(32), unique=True)
    kind: Mapped[str] = mapped_column(String(32))
    title: Mapped[str] = mapped_column(String(200))
    owner_type: Mapped[str] = mapped_column(String(32), index=True)  # ITEM, RECEIPT, ASSET, ALLOCATION, ...
    owner_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), index=True)
    depot_id: Mapped[uuid.UUID | None] = mapped_column(UUID(as_uuid=True), ForeignKey("depots.id"))
    access_level: Mapped[str] = mapped_column(String(16), default="INTERNAL")  # INTERNAL | RESTRICTED
    current_version: Mapped[int] = mapped_column(Integer, default=0)
    created_by: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("users.id"))
    versions: Mapped[list["DocumentVersion"]] = relationship(lazy="selectin", order_by="DocumentVersion.version_no")


class DocumentVersion(Base):
    __tablename__ = "document_versions"
    __table_args__ = (UniqueConstraint("document_id", "version_no", name="doc_version"),)
    id: Mapped[uuid.UUID] = uuid_pk()
    document_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("documents.id", ondelete="CASCADE"))
    version_no: Mapped[int] = mapped_column(Integer)
    storage_key: Mapped[str] = mapped_column(String(200))
    filename: Mapped[str] = mapped_column(String(200))
    content_type: Mapped[str] = mapped_column(String(100))
    size_bytes: Mapped[int] = mapped_column(BigInteger)
    sha256: Mapped[str] = mapped_column(String(64))
    comment: Mapped[str] = mapped_column(Text, default="")
    author_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("users.id"))
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True))  # horloge métier
