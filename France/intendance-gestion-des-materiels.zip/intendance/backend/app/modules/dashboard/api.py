"""Tableau de bord « Chaque matériel. Chaque mouvement. » — tous les indicateurs sont calculés depuis la base."""
from __future__ import annotations

import uuid
from datetime import timedelta
from decimal import Decimal

from fastapi import APIRouter
from sqlalchemy import func, or_, select

from app.core.clock import clock_info
from app.core.deps import CtxDep
from app.modules.catalog.models import Item, ItemFamily
from app.modules.inventory import service as inv
from app.modules.inventory.models import Asset, AssetLifecycle, StockMovement, TechnicalState
from app.modules.maintenance.models import MaintenanceOrder, MaintenanceStatus
from app.modules.receipts.models import Receipt, ReceiptStatus
from app.modules.requests.models import Allocation, AllocationLine, LineKind, RequestStatus, SupplyRequest
from app.modules.stocktakes.models import LineStatus, Stocktake, StocktakeLine, StocktakeStatus
from app.modules.transfers.models import Transfer, TransferLine, TransferStatus

router = APIRouter(prefix="/v1", tags=["Tableau de bord"])

PENDING_REQUEST = [RequestStatus.SUBMITTED, RequestStatus.REVIEWED, RequestStatus.APPROVED]
ACTIVE_TRANSFER = [TransferStatus.REQUESTED, TransferStatus.APPROVED, TransferStatus.RESERVED, TransferStatus.IN_TRANSIT, TransferStatus.RECEIVED]


def _assets_to_inspect_filter(ctx, depots):
    warn = ctx.now.date() + timedelta(days=int(ctx.setting("maintenance.due_warning_days")))
    return (
        Asset.depot_id.in_(depots),
        Asset.lifecycle.in_([AssetLifecycle.IN_STOCK, AssetLifecycle.RESERVED, AssetLifecycle.ISSUED]),
        or_(
            Asset.technical_state.in_([TechnicalState.AWAITING_INSPECTION, TechnicalState.UNSERVICEABLE, TechnicalState.IN_MAINTENANCE]),
            Asset.next_inspection_due <= warn,
        ),
    )


@router.get("/dashboard")
def dashboard(ctx: CtxDep, depot_id: uuid.UUID | None = None):
    ctx.require("stock.read")
    depots = ctx.visible_depot_ids()
    if depot_id:
        ctx.require("stock.read", depot_id)
        depots = {depot_id}
    today = ctx.now.date()
    db = ctx.db

    items_count = db.execute(select(func.count()).select_from(Item).where(Item.active.is_(True))).scalar_one()
    serial_count = db.execute(select(func.count()).select_from(Asset).where(Asset.depot_id.in_(depots), Asset.lifecycle != AssetLifecycle.CONDEMNED)).scalar_one()
    pending_requests = db.execute(select(func.count()).select_from(SupplyRequest).where(SupplyRequest.depot_id.in_(depots), SupplyRequest.status.in_(PENDING_REQUEST))).scalar_one()
    awaiting_approval = db.execute(select(func.count()).select_from(SupplyRequest).where(SupplyRequest.depot_id.in_(depots), SupplyRequest.status == RequestStatus.REVIEWED)).scalar_one()
    to_inspect = db.execute(select(func.count()).select_from(Asset).where(*_assets_to_inspect_filter(ctx, depots))).scalar_one()
    overdue_inspections = db.execute(select(func.count()).select_from(Asset).where(Asset.depot_id.in_(depots), Asset.next_inspection_due < today,
                                                                                   Asset.lifecycle != AssetLifecycle.CONDEMNED)).scalar_one()
    transfers_q = select(Transfer).where(or_(Transfer.source_depot_id.in_(depots), Transfer.destination_depot_id.in_(depots)), Transfer.status.in_(ACTIVE_TRANSFER))
    transfers = db.execute(transfers_q).scalars().all()
    in_transit = sum(1 for t in transfers if t.status == TransferStatus.IN_TRANSIT)

    # État des stocks par famille
    overview = inv.stock_overview(ctx, depots)
    families = {f.code: f.label for f in db.execute(select(ItemFamily).order_by(ItemFamily.sort_order)).scalars()}
    by_family: dict[str, dict] = {}
    for r in overview:
        f = by_family.setdefault(r["family_code"], {k: Decimal(0) for k in ("physical", "reserved", "available", "in_transit", "blocked")})
        for k in f:
            f[k] += r[k] or 0
    stock_state = [{"family_code": code, "family_label": families.get(code, code), **{k: float(v) for k, v in vals.items()}}
                   for code, vals in sorted(by_family.items(), key=lambda kv: list(families).index(kv[0]) if kv[0] in families else 99)]
    totals = {k: float(sum((Decimal(str(s[k])) for s in stock_state), Decimal(0))) for k in ("physical", "reserved", "available", "in_transit", "blocked")}

    # Actions prioritaires (chaque action ouvre les enregistrements correspondants)
    actions: list[dict] = []
    for r in db.execute(select(Receipt).where(Receipt.depot_id.in_(depots), Receipt.status.in_([ReceiptStatus.RECEIVED, ReceiptStatus.IN_INSPECTION]))).scalars():
        pending = sum((ln.pending_qty for ln in r.lines), Decimal(0))
        actions.append({"severity": "HAUTE", "category": "Contrôle", "text": f"Réception {r.reference} : {float(pending):g} unité(s) en attente de contrôle — non disponibles",
                        "link": f"/receptions/{r.id}", "at": r.received_at})
    for t in transfers:
        if t.status == TransferStatus.RECEIVED:
            gap = sum((ln.in_transit_qty for ln in t.lines), Decimal(0))
            if gap:
                actions.append({"severity": "HAUTE", "category": "Transfert", "text": f"Transfert {t.reference} : écart de {float(gap):g} unité(s) à rapprocher",
                                "link": f"/transferts/{t.id}", "at": t.received_at})
            else:
                actions.append({"severity": "NORMALE", "category": "Transfert", "text": f"Transfert {t.reference} réceptionné : rapprochement à confirmer",
                                "link": f"/transferts/{t.id}", "at": t.received_at})
        elif t.status == TransferStatus.IN_TRANSIT and t.dispatched_at and t.dispatched_at < ctx.now - timedelta(days=3):
            actions.append({"severity": "NORMALE", "category": "Transfert", "text": f"Transfert {t.reference} en transit depuis plus de 3 jours",
                            "link": f"/transferts/{t.id}", "at": t.dispatched_at})
    overdue = db.execute(
        select(AllocationLine, Allocation).join(Allocation, Allocation.id == AllocationLine.allocation_id)
        .where(Allocation.depot_id.in_(depots), AllocationLine.kind == LineKind.LOAN, AllocationLine.due_date < today,
               AllocationLine.quantity > AllocationLine.returned_qty + AllocationLine.consumed_qty)
    ).all()
    for line, alloc in overdue:
        item = db.get(Item, line.item_id)
        actions.append({"severity": "CRITIQUE", "category": "Prêt", "text": f"Prêt {alloc.reference} — {item.designation} : échéance dépassée ({line.due_date:%d/%m/%Y})",
                        "link": f"/dotations/dotation/{alloc.id}", "at": None})
    for o in db.execute(select(MaintenanceOrder).where(MaintenanceOrder.depot_id.in_(depots), MaintenanceOrder.status.notin_([MaintenanceStatus.CLOSED, MaintenanceStatus.CANCELLED]))).scalars():
        asset = db.get(Asset, o.asset_id)
        if o.status == MaintenanceStatus.TO_INSPECT:
            actions.append({"severity": "HAUTE", "category": "Maintenance", "text": f"{o.reference} — {asset.serial_number} : contrôle avant remise à disposition à réaliser",
                            "link": f"/maintenance/{o.id}", "at": o.completed_at})
        elif o.due_date and o.due_date < today:
            actions.append({"severity": "CRITIQUE", "category": "Maintenance", "text": f"{o.reference} — {asset.serial_number} : échéance dépassée",
                            "link": f"/maintenance/{o.id}", "at": o.signaled_at})
        elif o.status == MaintenanceStatus.SIGNALED:
            actions.append({"severity": "NORMALE", "category": "Maintenance", "text": f"{o.reference} — {asset.serial_number} : défaut signalé, évaluation à faire",
                            "link": f"/maintenance/{o.id}", "at": o.signaled_at})
    decided_orders = {o.asset_id for o in db.execute(select(MaintenanceOrder).where(MaintenanceOrder.status.notin_([MaintenanceStatus.CLOSED, MaintenanceStatus.CANCELLED]))).scalars()}
    for a in db.execute(select(Asset).where(Asset.depot_id.in_(depots), Asset.lifecycle == AssetLifecycle.IN_STOCK,
                                            Asset.technical_state.in_([TechnicalState.AWAITING_INSPECTION, TechnicalState.IN_MAINTENANCE]))).scalars():
        if a.id not in decided_orders:
            actions.append({"severity": "HAUTE", "category": "Décision", "text": f"{a.serial_number} : en attente de contrôle et de décision de remise à disposition",
                            "link": f"/equipements/{a.id}", "at": None})
    for a in db.execute(select(Asset).where(Asset.depot_id.in_(depots), Asset.next_inspection_due < today, Asset.lifecycle != AssetLifecycle.CONDEMNED)).scalars():
        actions.append({"severity": "HAUTE", "category": "Échéance", "text": f"{a.serial_number} : contrôle périodique échu le {a.next_inspection_due:%d/%m/%Y}",
                        "link": f"/equipements/{a.id}", "at": None})
    for st in db.execute(select(Stocktake).where(Stocktake.depot_id.in_(depots), Stocktake.status.in_([StocktakeStatus.COUNTING, StocktakeStatus.REVIEW]))).scalars():
        n = sum(1 for ln in st.lines if ln.status in (LineStatus.VARIANCE_CONFIRMED, LineStatus.RECOUNT_REQUIRED))
        if n:
            actions.append({"severity": "NORMALE", "category": "Inventaire", "text": f"Inventaire {st.reference} : {n} ligne(s) à recompter ou à décider",
                            "link": f"/stocks/inventaires/{st.id}", "at": st.snapshot_at})
    if awaiting_approval:
        actions.append({"severity": "NORMALE", "category": "Demande", "text": f"{awaiting_approval} demande(s) revue(s) en attente d'approbation",
                        "link": "/dotations?status=REVIEWED", "at": None})
    for r in overview:
        if r["min_stock"] is not None and r["available"] < r["min_stock"]:
            actions.append({"severity": "NORMALE", "category": "Seuil", "text": f"{r['item_code']} {r['variant_label'] or ''} ({r['depot_code']}) : disponible {float(r['available']):g} sous le seuil {float(r['min_stock']):g}",
                            "link": f"/catalogue/{r['item_id']}", "at": None})
    order = {"CRITIQUE": 0, "HAUTE": 1, "NORMALE": 2}
    actions.sort(key=lambda a: order[a["severity"]])

    # Traçabilité mise en avant : dernier équipement ayant fait l'objet d'une décision de remise à disposition (GEN-DÉMO-024 dans la démonstration)
    from app.modules.maintenance.models import ReleaseDecision

    featured = db.execute(select(Asset).join(ReleaseDecision, ReleaseDecision.asset_id == Asset.id).where(Asset.depot_id.in_(depots))
                          .order_by(ReleaseDecision.decided_at.desc())).scalars().first()
    if featured is None:
        featured = db.execute(select(Asset).join(MaintenanceOrder, MaintenanceOrder.asset_id == Asset.id).where(Asset.depot_id.in_(depots))
                              .order_by(MaintenanceOrder.signaled_at.desc())).scalars().first()
    if featured is None:
        featured = db.execute(select(Asset).where(Asset.depot_id.in_(depots)).order_by(Asset.received_at.desc())).scalars().first()
    trace = None
    if featured is not None:
        from app.modules.inventory.api import asset_history

        hist = asset_history(ctx, featured.id)
        steps = []
        for phase, label in [("RECEPTION", "Réception"), ("EMPLACEMENT", "Emplacements"), ("AFFECTATION", "Affectations"),
                             ("RETOUR", "Retours"), ("MAINTENANCE", "Maintenance"), ("ETAT", "État actuel")]:
            evs = [e for e in hist["events"] if e["phase"] == phase]
            last = (evs[0] if phase == "RECEPTION" else evs[-1]) if evs else None
            steps.append({"phase": phase, "label": label, "count": len(evs), "last_at": last["at"] if last else None,
                          "last_title": last["title"] if last else None})
        steps[-1]["last_title"] = hist["explanation"]
        trace = {"asset": hist["asset"], "explanation": hist["explanation"], "steps": steps}

    cache: dict = {}
    from app.modules.inventory.api import movement_dict

    recent = [movement_dict(ctx, m, cache) for m in db.execute(
        select(StockMovement).where(StockMovement.depot_id.in_(depots)).order_by(StockMovement.seq.desc()).limit(10)).scalars()]

    return {
        "clock": clock_info(db),
        "scope_depot_ids": sorted(str(d) for d in depots),
        "kpis": {
            "items": {"value": items_count, "secondary": f"{serial_count} exemplaires sérialisés suivis", "link": "/catalogue"},
            "pending_requests": {"value": pending_requests, "secondary": f"dont {awaiting_approval} à approuver", "link": "/dotations?status=SUBMITTED,REVIEWED,APPROVED"},
            "assets_to_inspect": {"value": to_inspect, "secondary": f"{overdue_inspections} contrôle(s) périodique(s) échu(s)", "link": "/maintenance?vue=a-controler"},
            "transfers_in_progress": {"value": len(transfers), "secondary": f"{in_transit} en transit", "link": "/transferts?status=REQUESTED,APPROVED,RESERVED,IN_TRANSIT,RECEIVED"},
        },
        "stock_state": {"by_family": stock_state, "totals": totals},
        "priority_actions": actions[:12],
        "priority_actions_total": len(actions),
        "traceability": trace,
        "recent_movements": recent,
    }
