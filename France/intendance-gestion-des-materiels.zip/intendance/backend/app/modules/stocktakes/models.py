"""Inventaires physiques (campagnes de comptage).

Règle de prise en compte des mouvements pendant le comptage (documentée dans docs/REGLES_METIER.md) :
les mouvements ne sont pas gelés. À l'ouverture, un instantané est pris (quantité + numéro de séquence du
journal). Pour chaque comptage, la quantité théorique de référence est :
    instantané + Σ mouvements nets sur la position, postérieurs à l'instantané (seq > snapshot_seq)
    et dont la date métier est ≤ à l'heure physique du comptage déclarée par le compteur.
Le premier comptage n'est jamais appliqué automatiquement : tout écart exige un recomptage, puis une
approbation justifiée de l'ajustement.
"""
from __future__ import annotations

import uuid
from datetime import datetime
from decimal import Decimal
from enum import StrEnum

from sqlalchemy import BigInteger, Boolean, CheckConstraint, DateTime, ForeignKey, Integer, String, Text
from sqlalchemy.dialects.postgresql import JSONB, UUID
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.db import Base, Qty, Timestamped, Versioned, uuid_pk


class StocktakeStatus(StrEnum):
    DRAFT = "DRAFT"
    COUNTING = "COUNTING"
    REVIEW = "REVIEW"  # écarts à approuver
    CLOSED = "CLOSED"
    CANCELLED = "CANCELLED"


class LineStatus(StrEnum):
    TO_COUNT = "TO_COUNT"
    MATCHED = "MATCHED"
    RECOUNT_REQUIRED = "RECOUNT_REQUIRED"
    VARIANCE_CONFIRMED = "VARIANCE_CONFIRMED"
    ADJUSTED = "ADJUSTED"
    REJECTED = "REJECTED"  # ajustement refusé (aucune écriture)


class Stocktake(Base, Timestamped, Versioned):
    __tablename__ = "stocktakes"
    id: Mapped[uuid.UUID] = uuid_pk()
    reference: Mapped[str] = mapped_column(String(32), unique=True)
    depot_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("depots.id"), index=True)
    name: Mapped[str] = mapped_column(String(200))
    scope: Mapped[dict] = mapped_column(JSONB, default=dict)  # {location_ids: [...], family_codes: [...]}
    blind: Mapped[bool] = mapped_column(Boolean, default=True)
    status: Mapped[StocktakeStatus] = mapped_column(String(16), default=StocktakeStatus.DRAFT)
    snapshot_seq: Mapped[int | None] = mapped_column(BigInteger)
    snapshot_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    created_by: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("users.id"))
    closed_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    lines: Mapped[list["StocktakeLine"]] = relationship(
        back_populates="stocktake", lazy="selectin", cascade="all, delete-orphan", order_by="StocktakeLine.line_no"
    )


class StocktakeLine(Base, Timestamped, Versioned):
    __tablename__ = "stocktake_lines"
    id: Mapped[uuid.UUID] = uuid_pk()
    stocktake_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("stocktakes.id", ondelete="CASCADE"))
    line_no: Mapped[int] = mapped_column(Integer)
    location_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("locations.id"))
    item_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("items.id"))
    variant_id: Mapped[uuid.UUID | None] = mapped_column(UUID(as_uuid=True), ForeignKey("item_variants.id"))
    lot_id: Mapped[uuid.UUID | None] = mapped_column(UUID(as_uuid=True), ForeignKey("lots.id"))
    snapshot_qty: Mapped[Decimal] = mapped_column(Qty)
    status: Mapped[LineStatus] = mapped_column(String(24), default=LineStatus.TO_COUNT)
    final_counted_qty: Mapped[Decimal | None] = mapped_column(Qty)
    final_system_qty: Mapped[Decimal | None] = mapped_column(Qty)
    variance_qty: Mapped[Decimal | None] = mapped_column(Qty)
    adjustment_movement_id: Mapped[uuid.UUID | None] = mapped_column(UUID(as_uuid=True), ForeignKey("stock_movements.id"))
    approved_by: Mapped[uuid.UUID | None] = mapped_column(UUID(as_uuid=True), ForeignKey("users.id"))
    approved_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    justification: Mapped[str] = mapped_column(Text, default="")
    stocktake: Mapped[Stocktake] = relationship(back_populates="lines")
    counts: Mapped[list["StockCount"]] = relationship(lazy="selectin", order_by="StockCount.round_no")


class StockCount(Base):
    __tablename__ = "stock_counts"
    __table_args__ = (CheckConstraint("counted_qty >= 0", name="non_negative"),)
    id: Mapped[uuid.UUID] = uuid_pk()
    line_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("stocktake_lines.id", ondelete="CASCADE"))
    round_no: Mapped[int] = mapped_column(Integer)
    counted_qty: Mapped[Decimal] = mapped_column(Qty)
    system_qty_at_count: Mapped[Decimal] = mapped_column(Qty)
    counted_at: Mapped[datetime] = mapped_column(DateTime(timezone=True))  # heure physique déclarée
    counter_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("users.id"))
    recorded_at: Mapped[datetime] = mapped_column(DateTime(timezone=True))
    note: Mapped[str] = mapped_column(Text, default="")
