"""Inventaires physiques : campagne, périmètre, comptage à l'aveugle, recomptage, écarts, ajustements approuvés."""
from __future__ import annotations

import uuid
from datetime import datetime
from decimal import Decimal

from fastapi import APIRouter
from pydantic import Field
from sqlalchemy import and_, func, or_, select

from app.core.deps import CtxDep, PageDep, paginate
from app.core.errors import Conflict, NotFound, ValidationFailed, expect_status, expect_version
from app.core.refs import next_reference
from app.core.schemas import NonNegQty, StrictModel, VersionedAction, dec
from app.modules.audit.service import audit
from app.modules.catalog.models import Item, ItemVariant, Lot, Tracking
from app.modules.inventory import service as inv
from app.modules.inventory.models import Depot, Location, LocationKind, MovementType, StockBalance, StockMovement, StockStatus
from app.modules.org.models import User
from app.modules.stocktakes.models import LineStatus as L, StockCount, Stocktake, StocktakeLine, StocktakeStatus as S

router = APIRouter(prefix="/v1/stocktakes", tags=["Inventaires physiques"])


class StocktakeIn(StrictModel):
    depot_id: uuid.UUID
    name: str = Field(min_length=3, max_length=200)
    location_ids: list[uuid.UUID] = Field(default_factory=list)
    family_codes: list[str] = Field(default_factory=list)
    blind: bool = True


class CountLineIn(StrictModel):
    line_id: uuid.UUID
    counted_qty: NonNegQty
    counted_at: datetime | None = None
    note: str = ""


class CountsIn(StrictModel):
    lines: list[CountLineIn] = Field(min_length=1)


class AdjustmentDecisionIn(StrictModel):
    line_id: uuid.UUID
    approve: bool
    justification: str = Field(min_length=10, max_length=2000)


class AdjustmentsIn(VersionedAction):
    decisions: list[AdjustmentDecisionIn] = Field(min_length=1)


def _is_large(ctx, line: StocktakeLine) -> bool:
    item = ctx.db.get(Item, line.item_id)
    var = abs(line.variance_qty or 0)
    value = var * (item.unit_value or 0)
    return var > Decimal(str(ctx.setting("stocktake.approval_threshold_qty"))) or value > Decimal(str(ctx.setting("stocktake.approval_threshold_value")))


def stocktake_dict(ctx, st: Stocktake) -> dict:
    users = {u.id: u.full_name for u in ctx.db.execute(select(User)).scalars()}
    depot = ctx.db.get(Depot, st.depot_id)
    see = not st.blind or ctx.can("stocktake.see_expected", st.depot_id) or st.status in (S.REVIEW, S.CLOSED)
    lines = []
    for ln in st.lines:
        item, loc = ctx.db.get(Item, ln.item_id), ctx.db.get(Location, ln.location_id)
        v = ctx.db.get(ItemVariant, ln.variant_id) if ln.variant_id else None
        lot = ctx.db.get(Lot, ln.lot_id) if ln.lot_id else None
        lines.append({
            "id": ln.id, "line_no": ln.line_no, "location_code": loc.code, "item_code": item.code, "designation": item.designation,
            "base_unit": item.base_unit, "variant_label": v.label if v else None, "lot_number": lot.lot_number if lot else None,
            "status": ln.status,
            "snapshot_qty": dec(ln.snapshot_qty) if see else None,
            "final_counted_qty": dec(ln.final_counted_qty), "final_system_qty": dec(ln.final_system_qty) if see else None,
            "variance_qty": dec(ln.variance_qty) if see else None,
            "requires_approver": _is_large(ctx, ln) if (ln.variance_qty and see) else False,
            "counts": [{"round": c.round_no, "counted_qty": dec(c.counted_qty), "system_qty": dec(c.system_qty_at_count) if see else None,
                        "counter": users.get(c.counter_id), "counted_at": c.counted_at, "note": c.note} for c in ln.counts],
            "approved_by": users.get(ln.approved_by), "approved_at": ln.approved_at, "justification": ln.justification, "version": ln.version,
        })
    counts = {s: sum(1 for x in st.lines if x.status == s) for s in L}
    return {
        "id": st.id, "reference": st.reference, "name": st.name, "status": st.status, "version": st.version, "blind": st.blind,
        "expected_visible": see, "depot": {"id": depot.id, "code": depot.code, "name": depot.name}, "scope": st.scope,
        "snapshot_at": st.snapshot_at, "snapshot_seq": st.snapshot_seq, "created_by": users.get(st.created_by), "closed_at": st.closed_at,
        "lines": lines, "line_status_counts": {k: v for k, v in counts.items() if v},
        "policy": ("Mouvements non gelés pendant le comptage : la quantité théorique d'un comptage = instantané + mouvements "
                   "postérieurs à l'instantané et antérieurs à l'heure de comptage déclarée. Tout écart impose un recomptage ; "
                   "aucun ajustement n'est appliqué sans approbation justifiée."),
    }


@router.get("")
def list_stocktakes(ctx: CtxDep, page: PageDep, depot_id: uuid.UUID | None = None):
    ctx.require("stock.read")
    stmt = select(Stocktake).where(Stocktake.depot_id.in_(ctx.visible_depot_ids())).order_by(Stocktake.created_at.desc())
    if depot_id:
        stmt = stmt.where(Stocktake.depot_id == depot_id)
    return paginate(ctx, stmt, page, lambda s: stocktake_dict(ctx, s))


def load(ctx, sid) -> Stocktake:
    st = ctx.db.execute(select(Stocktake).where(Stocktake.id == sid).with_for_update().execution_options(populate_existing=True)).scalar_one_or_none()
    if st is None:
        raise NotFound("Inventaire introuvable.")
    ctx.require("stock.read", st.depot_id)
    return st


@router.get("/{stocktake_id}")
def get_stocktake(ctx: CtxDep, stocktake_id: uuid.UUID):
    return stocktake_dict(ctx, load(ctx, stocktake_id))


@router.post("", status_code=201)
def create_stocktake(ctx: CtxDep, body: StocktakeIn):
    ctx.require("stocktake.manage", body.depot_id)
    for lid in body.location_ids:
        inv.get_location(ctx, lid, body.depot_id)
    st = Stocktake(id=uuid.uuid4(), reference=next_reference(ctx.db, "stocktake", ctx.now.year), depot_id=body.depot_id, name=body.name,
                   scope={"location_ids": [str(x) for x in body.location_ids], "family_codes": body.family_codes}, blind=body.blind,
                   created_by=ctx.user_id)
    ctx.db.add(st)
    audit(ctx, "stocktake.create", "STOCKTAKE", st.id, object_ref=st.reference, depot_id=st.depot_id, details=st.scope)
    ctx.commit()
    return stocktake_dict(ctx, st)


@router.post("/{stocktake_id}/start")
def start_stocktake(ctx: CtxDep, stocktake_id: uuid.UUID, body: VersionedAction):
    """Ouvre le comptage : instantané des positions du périmètre (tous statuts confondus)."""
    st = load(ctx, stocktake_id)
    ctx.require("stocktake.manage", st.depot_id)
    expect_version(st, body.version)
    expect_status(st, {S.DRAFT}, "ouverture du comptage")
    q = (select(StockBalance.location_id, StockBalance.item_id, StockBalance.variant_id, StockBalance.lot_id, func.sum(StockBalance.quantity))
         .join(Item, Item.id == StockBalance.item_id).join(Location, Location.id == StockBalance.location_id)
         .where(StockBalance.depot_id == st.depot_id, Location.kind.in_([LocationKind.STORAGE, LocationKind.RECEIVING]))
         .group_by(StockBalance.location_id, StockBalance.item_id, StockBalance.variant_id, StockBalance.lot_id))
    if st.scope.get("location_ids"):
        q = q.where(StockBalance.location_id.in_([uuid.UUID(x) for x in st.scope["location_ids"]]))
    if st.scope.get("family_codes"):
        q = q.where(Item.family_code.in_(st.scope["family_codes"]))
    st.snapshot_seq = ctx.db.execute(select(func.coalesce(func.max(StockMovement.seq), 0))).scalar_one()
    st.snapshot_at = ctx.now
    rows = sorted(ctx.db.execute(q).all(), key=lambda r: (str(r[0]), str(r[1]), str(r[2]), str(r[3])))
    n = 0
    for loc_id, item_id, variant_id, lot_id, qty in rows:
        if qty <= 0:
            continue
        n += 1
        st.lines.append(StocktakeLine(id=uuid.uuid4(), line_no=n, location_id=loc_id, item_id=item_id, variant_id=variant_id, lot_id=lot_id, snapshot_qty=qty))
    if n == 0:
        raise Conflict("Aucune position de stock dans le périmètre.")
    st.status = S.COUNTING
    audit(ctx, "stocktake.start", "STOCKTAKE", st.id, object_ref=st.reference, depot_id=st.depot_id, details={"lines": n, "snapshot_seq": st.snapshot_seq})
    ctx.commit()
    return stocktake_dict(ctx, st)


def system_qty_at(ctx, st: Stocktake, ln: StocktakeLine, at: datetime) -> Decimal:
    """Instantané + mouvements nets postérieurs à l'instantané et antérieurs ou égaux à l'heure de comptage."""
    base = and_(StockMovement.seq > st.snapshot_seq, StockMovement.occurred_at <= at, StockMovement.item_id == ln.item_id,
                StockMovement.variant_id.is_(None) if ln.variant_id is None else StockMovement.variant_id == ln.variant_id,
                StockMovement.lot_id.is_(None) if ln.lot_id is None else StockMovement.lot_id == ln.lot_id)
    inflow = ctx.db.execute(select(func.coalesce(func.sum(StockMovement.quantity), 0)).where(
        base, StockMovement.to_location_id == ln.location_id,
        or_(StockMovement.from_location_id.is_(None), StockMovement.from_location_id != ln.location_id))).scalar_one()
    outflow = ctx.db.execute(select(func.coalesce(func.sum(StockMovement.quantity), 0)).where(
        base, StockMovement.from_location_id == ln.location_id,
        or_(StockMovement.to_location_id.is_(None), StockMovement.to_location_id != ln.location_id))).scalar_one()
    return ln.snapshot_qty + Decimal(inflow) - Decimal(outflow)


@router.post("/{stocktake_id}/counts")
def record_counts(ctx: CtxDep, stocktake_id: uuid.UUID, body: CountsIn):
    """Saisie de comptage (à l'aveugle si configuré). Le premier comptage n'est jamais appliqué automatiquement."""
    st = load(ctx, stocktake_id)
    ctx.require("stocktake.count", st.depot_id)
    expect_status(st, {S.COUNTING}, "comptage")
    lines = {ln.id: ln for ln in st.lines}
    recount_rule = bool(ctx.setting("stocktake.recount_on_any_variance"))
    for cl in body.lines:
        ln = lines.get(cl.line_id)
        if ln is None:
            raise ValidationFailed("Ligne d'inventaire inconnue.")
        if ln.status not in (L.TO_COUNT, L.RECOUNT_REQUIRED):
            raise Conflict(f"Ligne {ln.line_no} : comptage déjà conclu ({ln.status}).")
        item = ctx.db.get(Item, ln.item_id)
        inv.check_integral(ctx, item, cl.counted_qty)
        at = cl.counted_at or ctx.now
        if at < st.snapshot_at:
            raise ValidationFailed("L'heure de comptage ne peut précéder l'ouverture de l'inventaire.")
        system = system_qty_at(ctx, st, ln, at)
        round_no = len(ln.counts) + 1
        count = StockCount(id=uuid.uuid4(), line_id=ln.id, round_no=round_no, counted_qty=cl.counted_qty, system_qty_at_count=system,
                           counted_at=at, counter_id=ctx.user_id, recorded_at=ctx.now, note=cl.note)
        ctx.db.add(count)
        ln.counts.append(count)
        prev = ln.counts[-2] if round_no > 1 else None
        variance = cl.counted_qty - system
        if variance == 0:
            ln.status = L.MATCHED
        elif round_no == 1 and recount_rule:
            ln.status = L.RECOUNT_REQUIRED
        elif prev is not None and (prev.counted_qty - prev.system_qty_at_count) == variance or round_no >= 3 or not recount_rule:
            ln.status = L.VARIANCE_CONFIRMED
        else:
            ln.status = L.RECOUNT_REQUIRED
        ln.final_counted_qty, ln.final_system_qty, ln.variance_qty = cl.counted_qty, system, variance
    audit(ctx, "stocktake.count", "STOCKTAKE", st.id, object_ref=st.reference, depot_id=st.depot_id, details={"lines": len(body.lines)})
    from sqlalchemy.orm.attributes import flag_modified

    flag_modified(st, "name")
    ctx.commit()
    return stocktake_dict(ctx, st)


@router.post("/{stocktake_id}/review")
def review(ctx: CtxDep, stocktake_id: uuid.UUID, body: VersionedAction):
    st = load(ctx, stocktake_id)
    ctx.require("stocktake.manage", st.depot_id)
    expect_version(st, body.version)
    expect_status(st, {S.COUNTING}, "passage en revue")
    pending = [ln.line_no for ln in st.lines if ln.status in (L.TO_COUNT, L.RECOUNT_REQUIRED)]
    if pending:
        raise Conflict(f"Lignes non comptées ou à recompter : {pending[:10]}", code="comptage_incomplet")
    st.status = S.REVIEW
    audit(ctx, "stocktake.review", "STOCKTAKE", st.id, object_ref=st.reference, depot_id=st.depot_id)
    ctx.commit()
    return stocktake_dict(ctx, st)


@router.post("/{stocktake_id}/adjustments")
def approve_adjustments(ctx: CtxDep, stocktake_id: uuid.UUID, body: AdjustmentsIn):
    """Approbation justifiée des ajustements. Écarts importants : approbateur, distinct des compteurs de la ligne."""
    st = load(ctx, stocktake_id)
    expect_version(st, body.version)
    expect_status(st, {S.REVIEW}, "approbation des ajustements")
    lines = {ln.id: ln for ln in st.lines}
    src = ("STOCKTAKE", st.id, st.reference)
    for d in body.decisions:
        ln = lines.get(d.line_id)
        if ln is None or ln.status != L.VARIANCE_CONFIRMED:
            raise ValidationFailed("Seules les lignes à écart confirmé se décident.")
        ctx.require("stocktake.approve_large" if _is_large(ctx, ln) else "stocktake.approve_small", st.depot_id, action="ajustement d'inventaire")
        for c in ln.counts:
            ctx.separate("sod.adjustment_approver_not_counter", c.counter_id, "L'approbateur d'un ajustement ne peut pas avoir compté la ligne.")
        ln.approved_by, ln.approved_at, ln.justification = ctx.user_id, ctx.now, d.justification
        if not d.approve:
            ln.status = L.REJECTED
            audit(ctx, "stocktake.adjustment_rejected", "STOCKTAKE", st.id, object_ref=st.reference, depot_id=st.depot_id, reason=d.justification)
            continue
        item = ctx.db.get(Item, ln.item_id)
        if item.tracking == Tracking.SERIAL:
            raise ValidationFailed("Écart sur article sérialisé : rechercher l'exemplaire et traiter par l'action métier (retour, perte, réforme).")
        loc = ctx.db.get(Location, ln.location_id)
        var = ln.variance_qty
        if var > 0:
            mv = inv.post_movement(ctx, mtype=MovementType.ADJUSTMENT, item=item, quantity=var, variant_id=ln.variant_id, lot_id=ln.lot_id,
                                   to_location=loc, to_status=StockStatus.USABLE, source=src, reason=d.justification)
        else:
            mv = inv.post_movement(ctx, mtype=MovementType.ADJUSTMENT, item=item, quantity=-var, variant_id=ln.variant_id, lot_id=ln.lot_id,
                                   from_location=loc, from_status=StockStatus.USABLE, source=src, reason=d.justification)
        ln.adjustment_movement_id = mv.id
        ln.status = L.ADJUSTED
        audit(ctx, "stocktake.adjustment_approved", "STOCKTAKE", st.id, object_ref=st.reference, depot_id=st.depot_id, reason=d.justification,
              details={"line": ln.line_no, "variance": var, "movement": mv.reference, "large": _is_large(ctx, ln)})
    from sqlalchemy.orm.attributes import flag_modified

    flag_modified(st, "name")
    ctx.commit()
    return stocktake_dict(ctx, st)


@router.post("/{stocktake_id}/close")
def close(ctx: CtxDep, stocktake_id: uuid.UUID, body: VersionedAction):
    st = load(ctx, stocktake_id)
    ctx.require("stocktake.manage", st.depot_id)
    expect_version(st, body.version)
    expect_status(st, {S.REVIEW}, "clôture")
    open_lines = [ln.line_no for ln in st.lines if ln.status == L.VARIANCE_CONFIRMED]
    if open_lines:
        raise Conflict(f"Écarts non décidés : lignes {open_lines[:10]}", code="ecarts_non_decides")
    st.status, st.closed_at = S.CLOSED, ctx.now
    audit(ctx, "stocktake.close", "STOCKTAKE", st.id, object_ref=st.reference, depot_id=st.depot_id)
    ctx.commit()
    return stocktake_dict(ctx, st)
