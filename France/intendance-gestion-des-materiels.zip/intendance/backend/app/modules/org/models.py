"""Organisations, utilisateurs, rôles, appartenances et paramètres."""
from __future__ import annotations

import uuid
from datetime import datetime
from enum import StrEnum

from sqlalchemy import JSON, Boolean, CheckConstraint, DateTime, ForeignKey, Integer, String, Text, UniqueConstraint
from sqlalchemy.dialects.postgresql import JSONB, UUID
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.db import Base, Timestamped, Versioned, uuid_pk


class RoleCode(StrEnum):
    VIEWER = "VIEWER"  # Consultation
    STOREKEEPER = "STOREKEEPER"  # Magasinier
    DEPOT_MANAGER = "DEPOT_MANAGER"  # Responsable de dépôt
    MAINTENANCE = "MAINTENANCE"  # Maintenance
    APPROVER = "APPROVER"  # Approbateur
    AUDITOR = "AUDITOR"  # Auditeur
    ADMIN = "ADMIN"  # Administrateur


ROLE_LABELS = {
    RoleCode.VIEWER: "Consultation",
    RoleCode.STOREKEEPER: "Magasinier",
    RoleCode.DEPOT_MANAGER: "Responsable de dépôt",
    RoleCode.MAINTENANCE: "Maintenance",
    RoleCode.APPROVER: "Approbateur",
    RoleCode.AUDITOR: "Auditeur",
    RoleCode.ADMIN: "Administrateur",
}


class OrgKind(StrEnum):
    SUPPORT = "SUPPORT"  # organisation gestionnaire des dépôts
    BENEFICIARY = "BENEFICIARY"  # organisation bénéficiaire de dotations
    SUPPLIER = "SUPPLIER"  # fournisseur fictif
    PROVIDER = "PROVIDER"  # prestataire de maintenance fictif


class Organization(Base, Timestamped, Versioned):
    __tablename__ = "organizations"
    id: Mapped[uuid.UUID] = uuid_pk()
    code: Mapped[str] = mapped_column(String(32), unique=True)
    name: Mapped[str] = mapped_column(String(200))
    kind: Mapped[OrgKind] = mapped_column(String(20))
    parent_id: Mapped[uuid.UUID | None] = mapped_column(UUID(as_uuid=True), ForeignKey("organizations.id"))
    auth_mode: Mapped[str] = mapped_column(String(20), default="LOCAL")  # LOCAL | OIDC (adaptateur)
    active: Mapped[bool] = mapped_column(Boolean, default=True)


class Role(Base):
    __tablename__ = "roles"
    code: Mapped[str] = mapped_column(String(32), primary_key=True)
    label: Mapped[str] = mapped_column(String(100))
    description: Mapped[str] = mapped_column(Text, default="")


class User(Base, Timestamped, Versioned):
    __tablename__ = "users"
    id: Mapped[uuid.UUID] = uuid_pk()
    username: Mapped[str] = mapped_column(String(64), unique=True)
    full_name: Mapped[str] = mapped_column(String(200))
    email: Mapped[str | None] = mapped_column(String(200))
    organization_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("organizations.id"))
    password_hash: Mapped[str | None] = mapped_column(String(255))
    mfa_secret: Mapped[str | None] = mapped_column(String(64))
    mfa_enabled: Mapped[bool] = mapped_column(Boolean, default=False)
    active: Mapped[bool] = mapped_column(Boolean, default=True)
    failed_logins: Mapped[int] = mapped_column(Integer, default=0)
    locked_until: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))

    organization: Mapped[Organization] = relationship()
    memberships: Mapped[list["Membership"]] = relationship(back_populates="user", lazy="selectin")


class Membership(Base, Timestamped):
    """Appartenance : un utilisateur détient un rôle dans une organisation, éventuellement limité à un dépôt."""

    __tablename__ = "memberships"
    __table_args__ = (UniqueConstraint("user_id", "organization_id", "depot_id", "role_code", name="membership"),)
    id: Mapped[uuid.UUID] = uuid_pk()
    user_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("users.id", ondelete="CASCADE"))
    organization_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("organizations.id"))
    depot_id: Mapped[uuid.UUID | None] = mapped_column(UUID(as_uuid=True), ForeignKey("depots.id"))
    role_code: Mapped[str] = mapped_column(String(32), ForeignKey("roles.code"))

    user: Mapped[User] = relationship(back_populates="memberships")


class Setting(Base, Timestamped, Versioned):
    """Paramètres configurables (règles de séparation des tâches, seuils, horloge de démonstration)."""

    __tablename__ = "settings"
    key: Mapped[str] = mapped_column(String(100), primary_key=True)
    value: Mapped[dict] = mapped_column(JSONB().with_variant(JSON(), "sqlite"))
    description: Mapped[str] = mapped_column(Text, default="")


class ReferenceCounter(Base):
    __tablename__ = "reference_counters"
    prefix: Mapped[str] = mapped_column(String(16), primary_key=True)
    year: Mapped[int] = mapped_column(Integer, primary_key=True)
    value: Mapped[int] = mapped_column(Integer, default=0)
    __table_args__ = (CheckConstraint("value >= 0", name="positive"),)
