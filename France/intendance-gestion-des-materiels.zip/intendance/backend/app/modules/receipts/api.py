"""Réceptions : brouillon → soumise → reçue physiquement → contrôlée → acceptée (partiellement/totalement) → clôturée."""
from __future__ import annotations

import uuid
from datetime import date, timedelta
from decimal import Decimal

from fastapi import APIRouter
from pydantic import Field
from sqlalchemy import select

from app.core.deps import CtxDep, PageDep, paginate
from app.core.errors import Conflict, NotFound, ValidationFailed, expect_status, expect_version
from app.core.refs import next_reference
from app.core.schemas import NonNegQty, PositiveQty, StrictModel, VersionedAction, dec
from app.modules.audit.service import audit
from app.modules.catalog.models import Item, ItemVariant, Lot, Tracking
from app.modules.inventory import service as inv
from app.modules.inventory.models import (
    Asset,
    AssetLifecycle,
    CustodyType,
    Depot,
    Inspection,
    InspectionResult,
    Location,
    LocationKind,
    MovementType,
    StockStatus,
    TechnicalState,
)
from app.modules.org.models import Organization, OrgKind, User
from app.modules.receipts.models import Receipt, ReceiptLine, ReceiptStatus as S

router = APIRouter(prefix="/v1/receipts", tags=["Réceptions"])


class ReceiptLineIn(StrictModel):
    item_id: uuid.UUID
    variant_id: uuid.UUID | None = None
    unit: str | None = None
    expected_quantity: PositiveQty
    lot_number: str | None = None


class ReceiptIn(StrictModel):
    depot_id: uuid.UUID
    supplier_id: uuid.UUID
    supplier_document_ref: str = Field(min_length=2, max_length=80)
    expected_on: date | None = None
    notes: str = ""
    lines: list[ReceiptLineIn] = Field(min_length=1, max_length=200)
    submit: bool = False


class PhysicalLineIn(StrictModel):
    line_id: uuid.UUID
    received_quantity: NonNegQty  # dans l'unité saisie de la ligne
    lot_number: str | None = None
    lot_expires_on: date | None = None
    serial_numbers: list[str] = Field(default_factory=list)
    observed_condition: str = ""
    discrepancy_note: str = ""


class PhysicalReceiptIn(VersionedAction):
    lines: list[PhysicalLineIn] = Field(min_length=1)


class InspectionLineIn(StrictModel):
    line_id: uuid.UUID
    accepted_qty: NonNegQty = Decimal(0)
    rejected_qty: NonNegQty = Decimal(0)
    rejected_serials: list[str] = Field(default_factory=list)
    findings: str = ""


class InspectionIn(VersionedAction):
    lines: list[InspectionLineIn] = Field(min_length=1)
    checklist: list[dict] = Field(default_factory=list)
    findings: str = Field(default="", max_length=4000)


class PutawayLineIn(StrictModel):
    line_id: uuid.UUID
    location_id: uuid.UUID
    quantity: PositiveQty
    asset_ids: list[uuid.UUID] = Field(default_factory=list)


class PutawayIn(VersionedAction):
    lines: list[PutawayLineIn] = Field(min_length=1)


# ----------------------------------------------------------------------------- lecture
def receipt_dict(ctx, r: Receipt) -> dict:
    depot = ctx.db.get(Depot, r.depot_id)
    sup = ctx.db.get(Organization, r.supplier_id)
    users = {u.id: u.full_name for u in ctx.db.execute(select(User)).scalars()}
    lines = []
    for ln in r.lines:
        item = ctx.db.get(Item, ln.item_id)
        v = ctx.db.get(ItemVariant, ln.variant_id) if ln.variant_id else None
        lines.append({
            "id": ln.id, "line_no": ln.line_no, "item_id": item.id, "item_code": item.code, "designation": item.designation,
            "tracking": item.tracking, "base_unit": item.base_unit, "variant_id": ln.variant_id, "variant_label": v.label if v else None,
            "entered_unit": ln.entered_unit, "expected_entered_qty": dec(ln.expected_entered_qty),
            "expected_qty": dec(ln.expected_qty), "received_qty": dec(ln.received_qty), "accepted_qty": dec(ln.accepted_qty),
            "rejected_qty": dec(ln.rejected_qty), "pending_qty": dec(ln.pending_qty), "put_away_qty": dec(ln.put_away_qty),
            "discrepancy_qty": dec(ln.discrepancy_qty) if r.received_at else None, "lot_number": ln.lot_number,
            "serial_numbers": ln.serial_numbers, "observed_condition": ln.observed_condition, "discrepancy_note": ln.discrepancy_note,
            "inspection_level": item.inspection_level, "inspection_requirements": item.inspection_requirements, "version": ln.version,
        })
    inspections = ctx.db.execute(
        select(Inspection).where(Inspection.subject_type == "RECEIPT", Inspection.subject_id == r.id).order_by(Inspection.performed_at)
    ).scalars().all()
    totals = {k: float(sum((getattr(ln, k) for ln in r.lines), Decimal(0))) for k in ("expected_qty", "received_qty", "accepted_qty", "rejected_qty", "put_away_qty")}
    totals["pending_qty"] = totals["received_qty"] - totals["accepted_qty"] - totals["rejected_qty"]
    return {
        "id": r.id, "reference": r.reference, "status": r.status, "version": r.version,
        "depot": {"id": depot.id, "code": depot.code, "name": depot.name},
        "supplier": {"id": sup.id, "code": sup.code, "name": sup.name}, "supplier_document_ref": r.supplier_document_ref,
        "expected_on": r.expected_on, "notes": r.notes, "created_by": users.get(r.created_by),
        "submitted_at": r.submitted_at, "received_at": r.received_at, "received_by": users.get(r.received_by),
        "inspected_at": r.inspected_at, "closed_at": r.closed_at, "lines": lines, "totals": totals,
        "inspections": [
            {"id": i.id, "reference": i.reference, "result": i.result, "accepted_qty": dec(i.accepted_qty), "rejected_qty": dec(i.rejected_qty),
             "findings": i.findings, "checklist": i.checklist, "inspector": users.get(i.inspector_id), "performed_at": i.performed_at}
            for i in inspections
        ],
    }


@router.get("")
def list_receipts(ctx: CtxDep, page: PageDep, status: str | None = None, depot_id: uuid.UUID | None = None):
    ctx.require("stock.read")
    stmt = select(Receipt).where(Receipt.depot_id.in_(ctx.visible_depot_ids())).order_by(Receipt.created_at.desc())
    if status:
        stmt = stmt.where(Receipt.status.in_(status.split(",")))
    if depot_id:
        stmt = stmt.where(Receipt.depot_id == depot_id)
    return paginate(ctx, stmt, page, lambda r: receipt_dict(ctx, r))


def load(ctx, receipt_id: uuid.UUID, *, lock: bool = True) -> Receipt:
    stmt = select(Receipt).where(Receipt.id == receipt_id)
    if lock:
        stmt = stmt.with_for_update().execution_options(populate_existing=True)
    r = ctx.db.execute(stmt).scalar_one_or_none()
    if r is None:
        raise NotFound("Réception introuvable.")
    ctx.require("stock.read", r.depot_id)
    return r


@router.get("/{receipt_id}")
def get_receipt(ctx: CtxDep, receipt_id: uuid.UUID):
    return receipt_dict(ctx, load(ctx, receipt_id, lock=False))


# ----------------------------------------------------------------------------- création
def create_receipt(ctx, body: ReceiptIn) -> Receipt:
    ctx.require("receipt.create", body.depot_id)
    sup = ctx.db.get(Organization, body.supplier_id)
    if sup is None or sup.kind != OrgKind.SUPPLIER:
        raise ValidationFailed("Fournisseur inconnu.")
    r = Receipt(
        id=uuid.uuid4(), reference=next_reference(ctx.db, "receipt", ctx.now.year), depot_id=body.depot_id, supplier_id=sup.id,
        supplier_document_ref=body.supplier_document_ref, expected_on=body.expected_on, notes=body.notes, created_by=ctx.user_id,
        status=S.DRAFT,
    )
    ctx.db.add(r)
    for n, ln in enumerate(body.lines, start=1):
        item = ctx.db.get(Item, ln.item_id)
        if item is None or not item.active:
            raise ValidationFailed(f"Ligne {n} : article inconnu ou inactif.")
        if item.variants and not ln.variant_id:
            raise ValidationFailed(f"Ligne {n} : variante obligatoire pour {item.code}.")
        if ln.variant_id and not any(v.id == ln.variant_id for v in item.variants):
            raise ValidationFailed(f"Ligne {n} : variante incompatible avec l'article.")
        unit = ln.unit or item.base_unit
        base_qty = inv.to_base_quantity(ctx, item, ln.expected_quantity, unit, purpose="receipt")
        r.lines.append(ReceiptLine(
            id=uuid.uuid4(), line_no=n, item_id=item.id, variant_id=ln.variant_id, entered_unit=unit,
            expected_entered_qty=ln.expected_quantity, expected_qty=base_qty, lot_number=ln.lot_number,
        ))
    if body.submit:
        r.status = S.SUBMITTED
        r.submitted_at = ctx.now
    audit(ctx, "receipt.create", "RECEIPT", r.id, object_ref=r.reference, depot_id=r.depot_id, details={"lines": len(body.lines), "submitted": body.submit})
    return r


@router.post("", status_code=201)
def post_receipt(ctx: CtxDep, body: ReceiptIn):
    r = create_receipt(ctx, body)
    ctx.commit()
    return receipt_dict(ctx, r)


@router.post("/{receipt_id}/submit")
def submit(ctx: CtxDep, receipt_id: uuid.UUID, body: VersionedAction):
    r = load(ctx, receipt_id)
    ctx.require("receipt.create", r.depot_id)
    expect_version(r, body.version)
    expect_status(r, {S.DRAFT}, "soumettre")
    r.status, r.submitted_at = S.SUBMITTED, ctx.now
    audit(ctx, "receipt.submit", "RECEIPT", r.id, object_ref=r.reference, depot_id=r.depot_id)
    ctx.commit()
    return receipt_dict(ctx, r)


# ----------------------------------------------------------------------------- réception physique
@router.post("/{receipt_id}/physical-receipt")
def physical_receipt(ctx: CtxDep, receipt_id: uuid.UUID, body: PhysicalReceiptIn):
    """Enregistre les quantités réellement reçues. Tout entre en « non contrôlé » (bloqué) au quai de réception."""
    r = load(ctx, receipt_id)
    ctx.require("receipt.receive", r.depot_id)
    expect_version(r, body.version)
    expect_status(r, {S.SUBMITTED}, "réception physique")
    lines = {ln.id: ln for ln in r.lines}
    dock = inv.location_of_kind(ctx, r.depot_id, LocationKind.RECEIVING)
    seen = set()
    for pl in body.lines:
        ln = lines.get(pl.line_id)
        if ln is None or pl.line_id in seen:
            raise ValidationFailed("Ligne de réception inconnue ou en double.")
        seen.add(pl.line_id)
        item = ctx.db.get(Item, ln.item_id)
        if pl.received_quantity == 0:
            ln.received_qty = Decimal(0)
            ln.observed_condition, ln.discrepancy_note = pl.observed_condition, pl.discrepancy_note or "Non livré"
            continue
        qty = inv.to_base_quantity(ctx, item, pl.received_quantity, ln.entered_unit, purpose="receipt")
        ln.received_qty = qty
        ln.observed_condition, ln.discrepancy_note = pl.observed_condition, pl.discrepancy_note
        if qty != ln.expected_qty and not pl.discrepancy_note:
            raise ValidationFailed(f"Ligne {ln.line_no} : écart avec la quantité attendue, motif d'écart obligatoire.")
        lot = inv.get_or_create_lot(ctx, item, pl.lot_number or ln.lot_number, pl.lot_expires_on)
        ln.lot_id, ln.lot_number = (lot.id, lot.lot_number) if lot else (None, None)
        src = ("RECEIPT", r.id, r.reference)
        if item.tracking == Tracking.SERIAL:
            serials = [s.strip() for s in pl.serial_numbers if s.strip()]
            if len(serials) != int(qty) or len({inv.normalize_serial(s) for s in serials}) != len(serials):
                raise ValidationFailed(f"Ligne {ln.line_no} : {int(qty)} numéros de série distincts attendus, {len(serials)} fournis.")
            ln.serial_numbers = serials
            for s in serials:
                asset = inv.create_asset(ctx, item, s, r.depot_id, ln.variant_id, ln.lot_id)
                ctx.db.add(asset)
                asset.lifecycle = AssetLifecycle.IN_STOCK
                asset.custody_type = CustodyType.DEPOT
                inv.post_movement(ctx, mtype=MovementType.RECEIPT, item=item, quantity=1, asset=asset, to_location=dock,
                                  to_status=StockStatus.PENDING_INSPECTION, source=src, counterpart_org_id=r.supplier_id)
        else:
            if pl.serial_numbers:
                raise ValidationFailed(f"Ligne {ln.line_no} : article non sérialisé, numéros de série refusés.")
            inv.post_movement(ctx, mtype=MovementType.RECEIPT, item=item, quantity=qty, variant_id=ln.variant_id, lot_id=ln.lot_id,
                              to_location=dock, to_status=StockStatus.PENDING_INSPECTION, source=src, counterpart_org_id=r.supplier_id,
                              entered=(pl.received_quantity, ln.entered_unit))
    missing = set(lines) - seen
    if missing:
        raise ValidationFailed("Toutes les lignes doivent être renseignées (quantité 0 si non livrée).")
    r.status, r.received_at, r.received_by = S.RECEIVED, ctx.now, ctx.user_id
    audit(ctx, "receipt.physical", "RECEIPT", r.id, object_ref=r.reference, depot_id=r.depot_id,
          details={"received": {str(ln.line_no): ln.received_qty for ln in r.lines}})
    ctx.commit()
    return receipt_dict(ctx, r)


# ----------------------------------------------------------------------------- contrôle
@router.post("/{receipt_id}/inspection")
def inspect_receipt(ctx: CtxDep, receipt_id: uuid.UUID, body: InspectionIn):
    """Contrôle : acceptation totale ou partielle. Seules les quantités acceptées deviennent disponibles."""
    r = load(ctx, receipt_id)
    ctx.require("receipt.inspect", r.depot_id)
    expect_version(r, body.version)
    expect_status(r, {S.RECEIVED, S.IN_INSPECTION}, "contrôle")
    ctx.separate("sod.receipt_inspector_not_receiver", r.received_by,
                 "Le contrôle doit être réalisé par une autre personne que l'agent ayant reçu la livraison.")
    lines = {ln.id: ln for ln in r.lines}
    dock = inv.location_of_kind(ctx, r.depot_id, LocationKind.RECEIVING)
    qloc = inv.location_of_kind(ctx, r.depot_id, LocationKind.QUARANTINE)
    insp = Inspection(
        id=uuid.uuid4(), reference=next_reference(ctx.db, "inspection", ctx.now.year), kind="RECEIPT", subject_type="RECEIPT",
        subject_id=r.id, depot_id=r.depot_id, result=InspectionResult.PASS, checklist=body.checklist, findings=body.findings,
        inspector_id=ctx.user_id, performed_at=ctx.now, accepted_qty=Decimal(0), rejected_qty=Decimal(0),
    )
    ctx.db.add(insp)
    src = ("INSPECTION", insp.id, insp.reference)
    for il in body.lines:
        ln = lines.get(il.line_id)
        if ln is None:
            raise ValidationFailed("Ligne inconnue.")
        item = ctx.db.get(Item, ln.item_id)
        if il.accepted_qty + il.rejected_qty > ln.pending_qty:
            raise ValidationFailed(f"Ligne {ln.line_no} : quantités contrôlées supérieures au reliquat en attente ({ln.pending_qty}).")
        inv.check_integral(ctx, item, il.accepted_qty)
        inv.check_integral(ctx, item, il.rejected_qty)
        interval = item.maintenance_interval_days
        if item.tracking == Tracking.SERIAL:
            pending_assets = list(ctx.db.execute(
                select(Asset).where(Asset.item_id == item.id, Asset.location_id == dock.id, Asset.stock_status == StockStatus.PENDING_INSPECTION,
                                    Asset.serial_number.in_(ln.serial_numbers)).order_by(Asset.internal_tag)
            ).scalars())
            rejected_norm = {inv.normalize_serial(s) for s in il.rejected_serials}
            if len(rejected_norm) != il.rejected_qty:
                raise ValidationFailed(f"Ligne {ln.line_no} : indiquer les numéros de série rejetés ({il.rejected_qty}).")
            rejected = [a for a in pending_assets if a.serial_normalized in rejected_norm]
            if len(rejected) != len(rejected_norm):
                raise ValidationFailed(f"Ligne {ln.line_no} : numéro de série rejeté inconnu ou déjà contrôlé.")
            others = [a for a in pending_assets if a.serial_normalized not in rejected_norm]
            accepted = others[: int(il.accepted_qty)]
            if len(accepted) != il.accepted_qty:
                raise ValidationFailed(f"Ligne {ln.line_no} : pas assez d'exemplaires en attente de contrôle.")
            for a in accepted:
                inv.change_status(ctx, item=item, location=dock, from_status=StockStatus.PENDING_INSPECTION, to_status=StockStatus.USABLE,
                                  quantity=1, asset=a, source=src, reason=il.findings or "Contrôle de réception conforme")
                a.technical_state = TechnicalState.SERVICEABLE
                if interval:
                    a.next_inspection_due = (ctx.now + timedelta(days=interval)).date()
            for a in rejected:
                inv.change_status(ctx, item=item, location=dock, from_status=StockStatus.PENDING_INSPECTION, to_status=StockStatus.QUARANTINE,
                                  quantity=1, asset=a, source=src, reason=il.findings or "Rejet au contrôle", mtype=MovementType.QUARANTINE,
                                  to_location=qloc)
                a.technical_state = TechnicalState.UNSERVICEABLE
        else:
            if il.accepted_qty > 0:
                inv.change_status(ctx, item=item, location=dock, from_status=StockStatus.PENDING_INSPECTION, to_status=StockStatus.USABLE,
                                  quantity=il.accepted_qty, variant_id=ln.variant_id, lot_id=ln.lot_id, source=src,
                                  reason=il.findings or "Contrôle de réception conforme")
            if il.rejected_qty > 0:
                inv.change_status(ctx, item=item, location=dock, from_status=StockStatus.PENDING_INSPECTION, to_status=StockStatus.QUARANTINE,
                                  quantity=il.rejected_qty, variant_id=ln.variant_id, lot_id=ln.lot_id, source=src,
                                  reason=il.findings or "Rejet au contrôle", mtype=MovementType.QUARANTINE, to_location=qloc)
        ln.accepted_qty += il.accepted_qty
        ln.rejected_qty += il.rejected_qty
        insp.accepted_qty += il.accepted_qty
        insp.rejected_qty += il.rejected_qty
    if insp.rejected_qty > 0:
        insp.result = InspectionResult.PARTIAL if insp.accepted_qty > 0 else InspectionResult.FAIL
    pending = sum((ln.pending_qty for ln in r.lines), Decimal(0))
    accepted = sum((ln.accepted_qty for ln in r.lines), Decimal(0))
    rejected = sum((ln.rejected_qty for ln in r.lines), Decimal(0))
    if pending > 0:
        r.status = S.IN_INSPECTION
    elif rejected == 0:
        r.status = S.ACCEPTED
    elif accepted == 0:
        r.status = S.REJECTED
    else:
        r.status = S.PARTIALLY_ACCEPTED
    r.inspected_at = ctx.now
    audit(ctx, "receipt.inspect", "RECEIPT", r.id, object_ref=r.reference, depot_id=r.depot_id,
          details={"inspection": insp.reference, "accepted": insp.accepted_qty, "rejected": insp.rejected_qty, "pending": pending})
    ctx.commit()
    return receipt_dict(ctx, r)


# ----------------------------------------------------------------------------- mise en stock
@router.post("/{receipt_id}/putaway")
def putaway(ctx: CtxDep, receipt_id: uuid.UUID, body: PutawayIn):
    r = load(ctx, receipt_id)
    ctx.require("receipt.putaway", r.depot_id)
    expect_version(r, body.version)
    expect_status(r, {S.IN_INSPECTION, S.ACCEPTED, S.PARTIALLY_ACCEPTED}, "mise en stock")
    lines = {ln.id: ln for ln in r.lines}
    dock = inv.location_of_kind(ctx, r.depot_id, LocationKind.RECEIVING)
    for pl in body.lines:
        ln = lines.get(pl.line_id)
        if ln is None:
            raise ValidationFailed("Ligne inconnue.")
        dst = inv.get_location(ctx, pl.location_id, r.depot_id)
        if dst.kind != LocationKind.STORAGE:
            raise ValidationFailed("La mise en stock se fait vers un emplacement de stockage.")
        if ln.put_away_qty + pl.quantity > ln.accepted_qty:
            raise ValidationFailed(f"Ligne {ln.line_no} : seule la quantité acceptée peut être mise en stock ({ln.accepted_qty - ln.put_away_qty} restant).")
        item = ctx.db.get(Item, ln.item_id)
        src = ("RECEIPT", r.id, r.reference)
        if item.tracking == Tracking.SERIAL:
            q = select(Asset).where(Asset.item_id == item.id, Asset.location_id == dock.id, Asset.stock_status == StockStatus.USABLE,
                                    Asset.lifecycle == AssetLifecycle.IN_STOCK, Asset.serial_number.in_(ln.serial_numbers))
            if pl.asset_ids:
                q = q.where(Asset.id.in_(pl.asset_ids))
            assets = list(ctx.db.execute(q.order_by(Asset.internal_tag).limit(int(pl.quantity))).scalars())
            if len(assets) != pl.quantity:
                raise Conflict("Exemplaires acceptés introuvables au quai de réception.")
            for a in assets:
                inv.post_movement(ctx, mtype=MovementType.PUTAWAY, item=item, quantity=1, asset=a, from_location=dock,
                                  from_status=StockStatus.USABLE, to_location=dst, to_status=StockStatus.USABLE, source=src)
        else:
            inv.post_movement(ctx, mtype=MovementType.PUTAWAY, item=item, quantity=pl.quantity, variant_id=ln.variant_id, lot_id=ln.lot_id,
                              from_location=dock, from_status=StockStatus.USABLE, to_location=dst, to_status=StockStatus.USABLE, source=src)
        ln.put_away_qty += pl.quantity
    audit(ctx, "receipt.putaway", "RECEIPT", r.id, object_ref=r.reference, depot_id=r.depot_id)
    _touch(r)
    ctx.commit()
    return receipt_dict(ctx, r)


def _touch(r: Receipt) -> None:
    """Force l'incrément de version de l'en-tête quand seules les lignes changent."""
    from sqlalchemy.orm.attributes import flag_modified

    flag_modified(r, "notes")


@router.post("/{receipt_id}/close")
def close(ctx: CtxDep, receipt_id: uuid.UUID, body: VersionedAction):
    r = load(ctx, receipt_id)
    ctx.require("receipt.close", r.depot_id)
    expect_version(r, body.version)
    expect_status(r, {S.ACCEPTED, S.PARTIALLY_ACCEPTED, S.REJECTED}, "clôturer")
    pending = sum((ln.pending_qty for ln in r.lines), Decimal(0))
    if pending > 0:
        raise Conflict("Des quantités sont encore en attente de contrôle : clôture impossible.", code="controle_incomplet")
    r.status, r.closed_at, r.closed_by = S.CLOSED, ctx.now, ctx.user_id
    audit(ctx, "receipt.close", "RECEIPT", r.id, object_ref=r.reference, depot_id=r.depot_id)
    ctx.commit()
    return receipt_dict(ctx, r)


__all__ = ["router", "Location", "Lot"]
