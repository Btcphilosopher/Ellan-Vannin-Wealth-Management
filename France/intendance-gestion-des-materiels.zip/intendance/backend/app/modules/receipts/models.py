from __future__ import annotations

import uuid
from datetime import date, datetime
from decimal import Decimal
from enum import StrEnum

from sqlalchemy import CheckConstraint, Date, DateTime, ForeignKey, Integer, String, Text
from sqlalchemy.dialects.postgresql import JSONB, UUID
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.db import Base, Qty, Timestamped, Versioned, uuid_pk


class ReceiptStatus(StrEnum):
    DRAFT = "DRAFT"  # brouillon
    SUBMITTED = "SUBMITTED"  # soumise
    RECEIVED = "RECEIVED"  # reçue physiquement
    IN_INSPECTION = "IN_INSPECTION"  # contrôle en cours (quantités en attente)
    ACCEPTED = "ACCEPTED"  # acceptée totalement
    PARTIALLY_ACCEPTED = "PARTIALLY_ACCEPTED"
    REJECTED = "REJECTED"
    CLOSED = "CLOSED"  # clôturée
    CANCELLED = "CANCELLED"


class Receipt(Base, Timestamped, Versioned):
    __tablename__ = "receipts"
    id: Mapped[uuid.UUID] = uuid_pk()
    reference: Mapped[str] = mapped_column(String(32), unique=True)
    depot_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("depots.id"), index=True)
    supplier_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("organizations.id"))
    supplier_document_ref: Mapped[str] = mapped_column(String(80))
    expected_on: Mapped[date | None] = mapped_column(Date)
    status: Mapped[ReceiptStatus] = mapped_column(String(24), default=ReceiptStatus.DRAFT, index=True)
    notes: Mapped[str] = mapped_column(Text, default="")
    created_by: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("users.id"))
    submitted_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    received_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    received_by: Mapped[uuid.UUID | None] = mapped_column(UUID(as_uuid=True), ForeignKey("users.id"))
    inspected_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    closed_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    closed_by: Mapped[uuid.UUID | None] = mapped_column(UUID(as_uuid=True), ForeignKey("users.id"))
    lines: Mapped[list["ReceiptLine"]] = relationship(
        back_populates="receipt", order_by="ReceiptLine.line_no", lazy="selectin", cascade="all, delete-orphan"
    )


class ReceiptLine(Base, Timestamped, Versioned):
    """Quantités distinctes : attendue, reçue, acceptée, rejetée, en attente (= reçue − acceptée − rejetée)."""

    __tablename__ = "receipt_lines"
    __table_args__ = (
        CheckConstraint("received_qty >= 0 AND accepted_qty >= 0 AND rejected_qty >= 0", name="non_negative"),
        CheckConstraint("accepted_qty + rejected_qty <= received_qty", name="inspection_bounded"),
        CheckConstraint("put_away_qty <= accepted_qty", name="putaway_bounded"),
    )
    id: Mapped[uuid.UUID] = uuid_pk()
    receipt_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("receipts.id", ondelete="CASCADE"))
    line_no: Mapped[int] = mapped_column(Integer)
    item_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("items.id"))
    variant_id: Mapped[uuid.UUID | None] = mapped_column(UUID(as_uuid=True), ForeignKey("item_variants.id"))
    lot_id: Mapped[uuid.UUID | None] = mapped_column(UUID(as_uuid=True), ForeignKey("lots.id"))
    lot_number: Mapped[str | None] = mapped_column(String(60))
    entered_unit: Mapped[str] = mapped_column(String(16))
    expected_entered_qty: Mapped[Decimal] = mapped_column(Qty)
    expected_qty: Mapped[Decimal] = mapped_column(Qty)  # en unité de base
    received_qty: Mapped[Decimal] = mapped_column(Qty, default=Decimal(0))
    accepted_qty: Mapped[Decimal] = mapped_column(Qty, default=Decimal(0))
    rejected_qty: Mapped[Decimal] = mapped_column(Qty, default=Decimal(0))
    put_away_qty: Mapped[Decimal] = mapped_column(Qty, default=Decimal(0))
    serial_numbers: Mapped[list] = mapped_column(JSONB, default=list)
    observed_condition: Mapped[str] = mapped_column(Text, default="")
    discrepancy_note: Mapped[str] = mapped_column(Text, default="")
    receipt: Mapped[Receipt] = relationship(back_populates="lines")

    @property
    def pending_qty(self) -> Decimal:
        return self.received_qty - self.accepted_qty - self.rejected_qty

    @property
    def discrepancy_qty(self) -> Decimal:
        return self.received_qty - self.expected_qty
