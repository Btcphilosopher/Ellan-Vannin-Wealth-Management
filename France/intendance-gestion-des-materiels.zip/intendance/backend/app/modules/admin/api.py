"""Administration : utilisateurs, appartenances, MFA, paramètres de séparation des tâches, horloge de démonstration."""
from __future__ import annotations

import uuid
from datetime import datetime, timedelta

from fastapi import APIRouter
from pydantic import Field
from sqlalchemy import select

from app.config import get_settings
from app.core.clock import business_now, clock_info, set_clock
from app.core.context import PERMISSIONS
from app.core.deps import CtxDep
from app.core.errors import Conflict, NotFound, ValidationFailed
from app.core.schemas import StrictModel
from app.core.security import get_mfa_adapter, hash_password
from app.core.settings_store import DEFAULTS, all_settings, set_setting
from app.modules.audit.service import audit
from app.modules.inventory.models import Depot
from app.modules.org.models import ROLE_LABELS, Membership, Organization, Role, User

router = APIRouter(prefix="/v1", tags=["Administration"])


class UserIn(StrictModel):
    username: str = Field(min_length=3, max_length=64, pattern=r"^[a-z0-9._-]+$")
    full_name: str = Field(min_length=2, max_length=200)
    organization_id: uuid.UUID
    password: str = Field(min_length=12, max_length=256)


class MembershipIn(StrictModel):
    organization_id: uuid.UUID
    depot_id: uuid.UUID | None = None
    role_code: str


class SettingIn(StrictModel):
    value: bool | int | float
    reason: str = Field(min_length=5, max_length=500)


class ClockIn(StrictModel):
    at: datetime | None = None
    advance_days: int | None = Field(default=None, ge=-365, le=365)
    advance_hours: int | None = Field(default=None, ge=-720, le=720)
    real_time: bool = False
    reason: str = Field(min_length=3, max_length=500)


def user_dict(ctx, u: User) -> dict:
    depots = {d.id: d.code for d in ctx.db.execute(select(Depot)).scalars()}
    org = ctx.db.get(Organization, u.organization_id)
    return {"id": u.id, "username": u.username, "full_name": u.full_name, "active": u.active, "mfa_enabled": u.mfa_enabled,
            "organization": {"id": org.id, "code": org.code, "name": org.name},
            "memberships": [{"id": m.id, "role": m.role_code, "role_label": ROLE_LABELS.get(m.role_code), "organization_id": m.organization_id,
                             "depot_id": m.depot_id, "depot_code": depots.get(m.depot_id)} for m in u.memberships]}


@router.get("/organizations", tags=["Référentiels"])
def list_organizations(ctx: CtxDep, kind: str | None = None):
    ctx.require("catalog.read")
    q = select(Organization).order_by(Organization.kind, Organization.name)
    if kind:
        q = q.where(Organization.kind == kind)
    return [{"id": o.id, "code": o.code, "name": o.name, "kind": o.kind, "auth_mode": o.auth_mode} for o in ctx.db.execute(q).scalars()]


@router.get("/admin/roles")
def roles(ctx: CtxDep):
    ctx.require("catalog.read")
    out = []
    for r in ctx.db.execute(select(Role)).scalars():
        out.append({"code": r.code, "label": r.label, "description": r.description,
                    "permissions": sorted(p for p, roles in PERMISSIONS.items() if r.code in roles)})
    return out


@router.get("/admin/users")
def list_users(ctx: CtxDep):
    ctx.require("admin.users")
    return [user_dict(ctx, u) for u in ctx.db.execute(select(User).order_by(User.username)).scalars()]


@router.post("/admin/users", status_code=201)
def create_user(ctx: CtxDep, body: UserIn):
    ctx.require("admin.users")
    if ctx.db.execute(select(User.id).where(User.username == body.username)).first():
        raise Conflict("Identifiant déjà utilisé.")
    u = User(id=uuid.uuid4(), username=body.username, full_name=body.full_name, organization_id=body.organization_id,
             password_hash=hash_password(body.password))
    ctx.db.add(u)
    audit(ctx, "admin.user_create", "USER", u.id, object_ref=u.username)
    ctx.commit()
    ctx.db.refresh(u)
    return user_dict(ctx, u)


@router.post("/admin/users/{user_id}/memberships", status_code=201)
def add_membership(ctx: CtxDep, user_id: uuid.UUID, body: MembershipIn):
    ctx.require("admin.users")
    u = ctx.db.get(User, user_id)
    if u is None:
        raise NotFound("Utilisateur introuvable.")
    if ctx.db.get(Role, body.role_code) is None:
        raise ValidationFailed("Rôle inconnu.")
    if body.depot_id:
        d = ctx.db.get(Depot, body.depot_id)
        if d is None or d.organization_id != body.organization_id:
            raise ValidationFailed("Le dépôt n'appartient pas à l'organisation.")
    if u.id == ctx.user_id and body.role_code != "ADMIN":
        raise Conflict("Un administrateur ne peut s'attribuer lui-même un rôle opérationnel.", code="separation_des_taches")
    m = Membership(id=uuid.uuid4(), user_id=u.id, organization_id=body.organization_id, depot_id=body.depot_id, role_code=body.role_code)
    ctx.db.add(m)
    audit(ctx, "admin.membership_add", "USER", u.id, object_ref=u.username, details=body.model_dump())
    ctx.commit()
    ctx.db.refresh(u)
    return user_dict(ctx, u)


@router.delete("/admin/users/{user_id}/memberships/{membership_id}")
def remove_membership(ctx: CtxDep, user_id: uuid.UUID, membership_id: uuid.UUID):
    ctx.require("admin.users")
    m = ctx.db.get(Membership, membership_id)
    if m is None or m.user_id != user_id:
        raise NotFound("Appartenance introuvable.")
    ctx.db.delete(m)
    audit(ctx, "admin.membership_remove", "USER", user_id, details={"role": m.role_code, "depot_id": m.depot_id})
    ctx.commit()
    return user_dict(ctx, ctx.db.get(User, user_id))


@router.post("/admin/users/{user_id}/mfa")
def enroll_mfa(ctx: CtxDep, user_id: uuid.UUID):
    """Enrôlement MFA (adaptateur configuré). Le secret n'est affiché qu'une fois."""
    ctx.require("admin.users")
    u = ctx.db.get(User, user_id)
    if u is None:
        raise NotFound("Utilisateur introuvable.")
    adapter = get_mfa_adapter(get_settings().mfa_adapter)
    secret = adapter.new_secret()
    u.mfa_secret, u.mfa_enabled = secret, True
    audit(ctx, "admin.mfa_enroll", "USER", u.id, object_ref=u.username, details={"adapter": adapter.name})
    ctx.commit()
    return {"adapter": adapter.name, "secret": secret, "provisioning_uri": adapter.provisioning_uri(secret, u.username)}


@router.post("/admin/users/{user_id}/deactivate")
def deactivate(ctx: CtxDep, user_id: uuid.UUID):
    ctx.require("admin.users")
    u = ctx.db.get(User, user_id)
    if u is None or u.id == ctx.user_id:
        raise ValidationFailed("Désactivation impossible.")
    u.active = False
    audit(ctx, "admin.user_deactivate", "USER", u.id, object_ref=u.username)
    ctx.commit()
    return user_dict(ctx, u)


@router.get("/admin/settings")
def get_settings_list(ctx: CtxDep):
    ctx.require("catalog.read")
    return all_settings(ctx.db)


@router.patch("/admin/settings/{key}")
def update_setting(ctx: CtxDep, key: str, body: SettingIn):
    ctx.require("admin.settings")
    if key not in DEFAULTS:
        raise NotFound("Paramètre inconnu.")
    if type(DEFAULTS[key][0]) is bool and not isinstance(body.value, bool):
        raise ValidationFailed("Valeur booléenne attendue.")
    set_setting(ctx.db, key, body.value)
    audit(ctx, "admin.setting_update", "SETTING", None, object_ref=key, reason=body.reason, details={"value": body.value})
    ctx.commit()
    return all_settings(ctx.db)


@router.get("/admin/clock")
def get_clock(ctx: CtxDep):
    return clock_info(ctx.db)


@router.post("/admin/clock")
def update_clock(ctx: CtxDep, body: ClockIn):
    """Horloge de démonstration : fixer, avancer ou repasser en heure réelle."""
    ctx.require("admin.clock")
    before = business_now(ctx.db)
    if body.real_time:
        set_clock(ctx.db, real=True)
    elif body.at:
        set_clock(ctx.db, at=body.at)
    else:
        set_clock(ctx.db, advance=timedelta(days=body.advance_days or 0, hours=body.advance_hours or 0))
    audit(ctx, "admin.clock", "SETTING", None, object_ref="demo_clock", reason=body.reason,
          details={"before": before.isoformat(), "after": business_now(ctx.db).isoformat()})
    ctx.commit()
    return clock_info(ctx.db)
