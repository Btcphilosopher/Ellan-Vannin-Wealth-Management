"""Maintenance : signalé → évalué → planifié → en intervention → à contrôler → clôturé.

Un ordre clôturé ne rend jamais un équipement apte : la remise à disposition est une décision explicite,
attribuée, fondée sur un contrôle conforme réalisé par une autre personne.
"""
from __future__ import annotations

import uuid
from datetime import date, timedelta
from decimal import Decimal
from typing import Literal

from fastapi import APIRouter
from pydantic import Field
from sqlalchemy import select

from app.core.deps import CtxDep, PageDep, paginate
from app.core.errors import Conflict, NotFound, ValidationFailed, expect_status, expect_version
from app.core.refs import next_reference
from app.core.schemas import PositiveQty, StrictModel, VersionedAction, dec
from app.modules.audit.service import audit
from app.modules.catalog.models import Item, Lot
from app.modules.inventory import service as inv
from app.modules.inventory.models import (
    Asset,
    AssetLifecycle,
    Inspection,
    InspectionResult,
    Location,
    LocationKind,
    MovementType,
    StockStatus,
    TechnicalState,
)
from app.modules.maintenance.models import (
    MaintenanceLabour,
    MaintenanceOrder,
    MaintenancePart,
    MaintenanceStatus as S,
    ReleaseDecision,
)
from app.modules.org.models import Organization, OrgKind, User

router = APIRouter(prefix="/v1", tags=["Maintenance"])


class OrderIn(StrictModel):
    asset_id: uuid.UUID
    defect_description: str = Field(min_length=5, max_length=4000)
    priority: Literal["LOW", "NORMAL", "HIGH", "CRITICAL"] = "NORMAL"
    origin: Literal["USER_REPORT", "PERIODIC", "INSPECTION", "RETURN"] = "USER_REPORT"
    due_date: date | None = None


class AssessmentIn(VersionedAction):
    diagnosis: str = Field(min_length=5, max_length=4000)
    estimated_cost: Decimal | None = Field(default=None, ge=0)


class PlanningIn(VersionedAction):
    planned_start: date
    provider_id: uuid.UUID | None = None
    technician_name: str = Field(min_length=2, max_length=200)
    due_date: date | None = None


class LabourIn(StrictModel):
    technician_name: str = Field(min_length=2, max_length=200)
    provider_id: uuid.UUID | None = None
    hours: Decimal = Field(gt=0, le=500)
    cost: Decimal = Field(ge=0)
    description: str = ""
    performed_on: date | None = None


class PartIn(StrictModel):
    item_id: uuid.UUID
    variant_id: uuid.UUID | None = None
    lot_id: uuid.UUID | None = None
    location_id: uuid.UUID
    quantity: PositiveQty


class CompletionIn(VersionedAction):
    work_result: str = Field(min_length=5, max_length=4000)


class AssetInspectionIn(StrictModel):
    asset_id: uuid.UUID
    kind: Literal["PRE_RELEASE", "PERIODIC", "RETURN"]
    result: Literal["PASS", "FAIL"]
    maintenance_order_id: uuid.UUID | None = None
    checklist: list[dict] = Field(default_factory=list)
    findings: str = Field(min_length=3, max_length=4000)


class ReleaseDecisionIn(VersionedAction):
    decision: Literal["RETURN_TO_SERVICE", "KEEP_UNSERVICEABLE", "CONDEMN"]
    inspection_id: uuid.UUID | None = None
    reason: str = Field(min_length=5, max_length=2000)
    to_location_id: uuid.UUID | None = None


def order_dict(ctx, o: MaintenanceOrder) -> dict:
    users = {u.id: u.full_name for u in ctx.db.execute(select(User)).scalars()}
    asset = ctx.db.get(Asset, o.asset_id)
    item = ctx.db.get(Item, asset.item_id)
    provider = ctx.db.get(Organization, o.provider_id) if o.provider_id else None
    inspections = ctx.db.execute(select(Inspection).where(Inspection.maintenance_order_id == o.id).order_by(Inspection.performed_at)).scalars().all()
    parts = []
    for p in o.parts:
        pi = ctx.db.get(Item, p.item_id)
        parts.append({"item_code": pi.code, "designation": pi.designation, "quantity": dec(p.quantity), "unit_cost": dec(p.unit_cost),
                      "lot_number": (ctx.db.get(Lot, p.lot_id).lot_number if p.lot_id else None)})
    labour_cost = sum((x.cost for x in o.labour), Decimal(0))
    parts_cost = sum(((p.unit_cost or 0) * p.quantity for p in o.parts), Decimal(0))
    decision = ctx.db.execute(select(ReleaseDecision).where(ReleaseDecision.maintenance_order_id == o.id)).scalars().first()
    return {
        "id": o.id, "reference": o.reference, "status": o.status, "version": o.version, "priority": o.priority, "origin": o.origin,
        "depot_id": o.depot_id,
        "asset": {"id": asset.id, "serial_number": asset.serial_number, "internal_tag": asset.internal_tag, "item_code": item.code,
                  "designation": item.designation, "technical_state": asset.technical_state, "lifecycle": asset.lifecycle,
                  "version": asset.version},
        "defect_description": o.defect_description, "diagnosis": o.diagnosis, "estimated_cost": dec(o.estimated_cost),
        "due_date": o.due_date, "overdue": bool(o.due_date and o.due_date < ctx.now.date() and o.status not in (S.CLOSED, S.CANCELLED)),
        "planned_start": o.planned_start, "provider": {"id": provider.id, "name": provider.name} if provider else None,
        "technician_name": o.technician_name, "work_result": o.work_result,
        "signaled_by": users.get(o.signaled_by), "signaled_at": o.signaled_at, "assessed_by": users.get(o.assessed_by),
        "started_at": o.started_at, "completed_at": o.completed_at, "completed_by": users.get(o.completed_by),
        "closed_at": o.closed_at, "closed_by": users.get(o.closed_by),
        "labour": [{"technician_name": x.technician_name, "hours": dec(x.hours), "cost": dec(x.cost), "description": x.description,
                    "performed_on": x.performed_on} for x in o.labour],
        "parts": parts,
        "costs": {"labour": dec(labour_cost), "parts": dec(parts_cost), "total": dec(labour_cost + parts_cost),
                  "hours": dec(sum((x.hours for x in o.labour), Decimal(0)))},
        "inspections": [{"id": i.id, "reference": i.reference, "kind": i.kind, "result": i.result, "findings": i.findings,
                         "inspector": users.get(i.inspector_id), "performed_at": i.performed_at, "checklist": i.checklist} for i in inspections],
        "release_decision": {"reference": decision.reference, "decision": decision.decision, "reason": decision.reason,
                             "decided_by": users.get(decision.decided_by), "decided_at": decision.decided_at} if decision else None,
    }


def signal_order(ctx, asset: Asset, defect: str, *, origin: str, priority: str = "NORMAL", due_date: date | None = None) -> MaintenanceOrder:
    """Crée un ordre « signalé ». Si l'exemplaire était utilisable en stock, il est bloqué (quarantaine)."""
    ctx.require("maintenance.signal", asset.depot_id)
    if asset.lifecycle == AssetLifecycle.RESERVED:
        raise Conflict("L'exemplaire est réservé : libérez la réservation avant de le signaler en maintenance.")
    if asset.lifecycle not in (AssetLifecycle.IN_STOCK,):
        raise Conflict("L'exemplaire doit être présent au dépôt pour être pris en maintenance.")
    o = MaintenanceOrder(
        id=uuid.uuid4(), reference=next_reference(ctx.db, "maintenance", ctx.now.year), asset_id=asset.id, depot_id=asset.depot_id,
        origin=origin, priority=priority, defect_description=defect, due_date=due_date or (ctx.now + timedelta(days=14)).date(),
        signaled_by=ctx.user_id, signaled_at=ctx.now,
    )
    ctx.db.add(o)
    if asset.stock_status == StockStatus.USABLE:
        item = ctx.db.get(Item, asset.item_id)
        loc = ctx.db.get(Location, asset.location_id)
        qloc = inv.location_of_kind(ctx, asset.depot_id, LocationKind.QUARANTINE)
        inv.change_status(ctx, item=item, location=loc, from_status=StockStatus.USABLE, to_status=StockStatus.QUARANTINE, quantity=1,
                          asset=asset, source=("MAINTENANCE_ORDER", o.id, o.reference), reason=defect, mtype=MovementType.QUARANTINE,
                          to_location=qloc)
    asset.technical_state = TechnicalState.AWAITING_INSPECTION if origin == "PERIODIC" else TechnicalState.UNSERVICEABLE
    audit(ctx, "maintenance.signal", "MAINTENANCE_ORDER", o.id, object_ref=o.reference, depot_id=asset.depot_id, reason=defect,
          details={"asset": asset.serial_number, "origin": origin})
    return o


@router.get("/maintenance-orders")
def list_orders(ctx: CtxDep, page: PageDep, status: str | None = None, depot_id: uuid.UUID | None = None, asset_id: uuid.UUID | None = None):
    ctx.require("stock.read")
    stmt = select(MaintenanceOrder).where(MaintenanceOrder.depot_id.in_(ctx.visible_depot_ids())).order_by(MaintenanceOrder.signaled_at.desc())
    if status:
        stmt = stmt.where(MaintenanceOrder.status.in_(status.split(",")))
    if depot_id:
        stmt = stmt.where(MaintenanceOrder.depot_id == depot_id)
    if asset_id:
        stmt = stmt.where(MaintenanceOrder.asset_id == asset_id)
    return paginate(ctx, stmt, page, lambda o: order_dict(ctx, o))


def load(ctx, order_id) -> MaintenanceOrder:
    o = ctx.db.execute(select(MaintenanceOrder).where(MaintenanceOrder.id == order_id).with_for_update().execution_options(populate_existing=True)).scalar_one_or_none()
    if o is None:
        raise NotFound("Ordre de maintenance introuvable.")
    ctx.require("stock.read", o.depot_id)
    return o


@router.get("/maintenance-orders/{order_id}")
def get_order(ctx: CtxDep, order_id: uuid.UUID):
    return order_dict(ctx, load(ctx, order_id))


@router.post("/maintenance-orders", status_code=201)
def create_order(ctx: CtxDep, body: OrderIn):
    asset = ctx.db.execute(select(Asset).where(Asset.id == body.asset_id).with_for_update()).scalar_one_or_none()
    if asset is None:
        raise NotFound("Équipement introuvable.")
    o = signal_order(ctx, asset, body.defect_description, origin=body.origin, priority=body.priority, due_date=body.due_date)
    ctx.commit()
    return order_dict(ctx, o)


@router.post("/maintenance-orders/{order_id}/assessment")
def assess(ctx: CtxDep, order_id: uuid.UUID, body: AssessmentIn):
    o = load(ctx, order_id)
    ctx.require("maintenance.manage", o.depot_id)
    expect_version(o, body.version)
    expect_status(o, {S.SIGNALED}, "évaluation")
    o.status, o.diagnosis, o.estimated_cost, o.assessed_by = S.ASSESSED, body.diagnosis, body.estimated_cost, ctx.user_id
    audit(ctx, "maintenance.assess", "MAINTENANCE_ORDER", o.id, object_ref=o.reference, depot_id=o.depot_id)
    ctx.commit()
    return order_dict(ctx, o)


@router.post("/maintenance-orders/{order_id}/planning")
def plan(ctx: CtxDep, order_id: uuid.UUID, body: PlanningIn):
    o = load(ctx, order_id)
    ctx.require("maintenance.manage", o.depot_id)
    expect_version(o, body.version)
    expect_status(o, {S.ASSESSED}, "planification")
    if body.provider_id:
        p = ctx.db.get(Organization, body.provider_id)
        if p is None or p.kind != OrgKind.PROVIDER:
            raise ValidationFailed("Prestataire inconnu.")
    o.status, o.planned_start, o.provider_id, o.technician_name = S.PLANNED, body.planned_start, body.provider_id, body.technician_name
    if body.due_date:
        o.due_date = body.due_date
    audit(ctx, "maintenance.plan", "MAINTENANCE_ORDER", o.id, object_ref=o.reference, depot_id=o.depot_id)
    ctx.commit()
    return order_dict(ctx, o)


@router.post("/maintenance-orders/{order_id}/start")
def start(ctx: CtxDep, order_id: uuid.UUID, body: VersionedAction):
    o = load(ctx, order_id)
    ctx.require("maintenance.manage", o.depot_id)
    expect_version(o, body.version)
    expect_status(o, {S.PLANNED}, "début d'intervention")
    asset = ctx.db.execute(select(Asset).where(Asset.id == o.asset_id).with_for_update()).scalar_one()
    item = ctx.db.get(Item, asset.item_id)
    if asset.lifecycle != AssetLifecycle.IN_STOCK:
        raise Conflict("L'exemplaire n'est pas présent au dépôt.")
    shop = inv.location_of_kind(ctx, o.depot_id, LocationKind.MAINTENANCE)
    inv.post_movement(ctx, mtype=MovementType.STATUS_CHANGE, item=item, quantity=1, asset=asset,
                      from_location=ctx.db.get(Location, asset.location_id), from_status=StockStatus(asset.stock_status),
                      to_location=shop, to_status=StockStatus.MAINTENANCE, source=("MAINTENANCE_ORDER", o.id, o.reference),
                      reason="Entrée en atelier")
    asset.technical_state = TechnicalState.IN_MAINTENANCE
    o.status, o.started_at = S.IN_PROGRESS, ctx.now
    audit(ctx, "maintenance.start", "MAINTENANCE_ORDER", o.id, object_ref=o.reference, depot_id=o.depot_id)
    ctx.commit()
    return order_dict(ctx, o)


@router.post("/maintenance-orders/{order_id}/labour", status_code=201)
def add_labour(ctx: CtxDep, order_id: uuid.UUID, body: LabourIn):
    o = load(ctx, order_id)
    ctx.require("maintenance.manage", o.depot_id)
    expect_status(o, {S.IN_PROGRESS}, "saisie de temps")
    ctx.db.add(MaintenanceLabour(id=uuid.uuid4(), order_id=o.id, technician_name=body.technician_name, provider_id=body.provider_id,
                                 hours=body.hours, cost=body.cost, description=body.description,
                                 performed_on=body.performed_on or ctx.now.date(), recorded_by=ctx.user_id))
    audit(ctx, "maintenance.labour", "MAINTENANCE_ORDER", o.id, object_ref=o.reference, depot_id=o.depot_id,
          details={"hours": body.hours, "cost": body.cost})
    ctx.commit()
    ctx.db.refresh(o)
    return order_dict(ctx, o)


@router.post("/maintenance-orders/{order_id}/parts", status_code=201)
def consume_part(ctx: CtxDep, order_id: uuid.UUID, body: PartIn):
    """Pièces consommées : mouvement de consommation depuis un stock utilisable non réservé."""
    o = load(ctx, order_id)
    ctx.require("maintenance.manage", o.depot_id)
    expect_status(o, {S.IN_PROGRESS}, "consommation de pièces")
    item = ctx.db.get(Item, body.item_id)
    loc = inv.get_location(ctx, body.location_id, o.depot_id)
    mv = inv.post_movement(ctx, mtype=MovementType.CONSUMPTION, item=item, quantity=body.quantity, variant_id=body.variant_id,
                           lot_id=body.lot_id, from_location=loc, from_status=StockStatus.USABLE,
                           source=("MAINTENANCE_ORDER", o.id, o.reference), reason=f"Pièce consommée sur {o.reference}")
    ctx.db.add(MaintenancePart(id=uuid.uuid4(), order_id=o.id, item_id=item.id, lot_id=body.lot_id, quantity=body.quantity,
                               unit_cost=item.unit_value, movement_id=mv.id, recorded_by=ctx.user_id))
    audit(ctx, "maintenance.part", "MAINTENANCE_ORDER", o.id, object_ref=o.reference, depot_id=o.depot_id,
          details={"item": item.code, "quantity": body.quantity, "movement": mv.reference})
    ctx.commit()
    ctx.db.refresh(o)
    return order_dict(ctx, o)


@router.post("/maintenance-orders/{order_id}/completion")
def complete(ctx: CtxDep, order_id: uuid.UUID, body: CompletionIn):
    o = load(ctx, order_id)
    ctx.require("maintenance.manage", o.depot_id)
    expect_version(o, body.version)
    expect_status(o, {S.IN_PROGRESS}, "fin d'intervention")
    if not o.labour:
        raise ValidationFailed("Saisir au moins un temps d'intervention avant de terminer.")
    asset = ctx.db.get(Asset, o.asset_id)
    asset.technical_state = TechnicalState.AWAITING_INSPECTION
    o.status, o.work_result, o.completed_at, o.completed_by = S.TO_INSPECT, body.work_result, ctx.now, ctx.user_id
    audit(ctx, "maintenance.complete", "MAINTENANCE_ORDER", o.id, object_ref=o.reference, depot_id=o.depot_id)
    ctx.commit()
    return order_dict(ctx, o)


@router.post("/maintenance-orders/{order_id}/closure")
def close_order(ctx: CtxDep, order_id: uuid.UUID, body: VersionedAction):
    """Clôture administrative. L'équipement reste « en attente de décision » : aucune aptitude automatique."""
    o = load(ctx, order_id)
    ctx.require("maintenance.manage", o.depot_id)
    expect_version(o, body.version)
    expect_status(o, {S.TO_INSPECT}, "clôture")
    has_inspection = ctx.db.execute(select(Inspection.id).where(Inspection.maintenance_order_id == o.id)).first()
    if not has_inspection:
        raise Conflict("Contrôle manquant : un contrôle avant remise à disposition doit être enregistré avant clôture.", code="controle_manquant")
    o.status, o.closed_at, o.closed_by = S.CLOSED, ctx.now, ctx.user_id
    audit(ctx, "maintenance.close", "MAINTENANCE_ORDER", o.id, object_ref=o.reference, depot_id=o.depot_id)
    ctx.commit()
    return order_dict(ctx, o)


# ----------------------------------------------------------------------------- contrôles et décisions
@router.post("/inspections/asset", status_code=201, tags=["Contrôles"])
def inspect_asset(ctx: CtxDep, body: AssetInspectionIn):
    asset = ctx.db.execute(select(Asset).where(Asset.id == body.asset_id).with_for_update()).scalar_one_or_none()
    if asset is None:
        raise NotFound("Équipement introuvable.")
    ctx.require("inspection.stock" if body.kind == "RETURN" else "maintenance.inspect", asset.depot_id)
    if body.maintenance_order_id:
        o = load(ctx, body.maintenance_order_id)
        if o.asset_id != asset.id:
            raise ValidationFailed("L'ordre ne concerne pas cet équipement.")
        if o.status != S.TO_INSPECT:
            raise Conflict("Le contrôle d'un ordre se fait au statut « à contrôler ».")
    insp = Inspection(
        id=uuid.uuid4(), reference=next_reference(ctx.db, "inspection", ctx.now.year), kind=body.kind, subject_type="ASSET",
        subject_id=asset.id, asset_id=asset.id, maintenance_order_id=body.maintenance_order_id, depot_id=asset.depot_id,
        result=InspectionResult(body.result), checklist=body.checklist, findings=body.findings, inspector_id=ctx.user_id, performed_at=ctx.now,
    )
    ctx.db.add(insp)
    audit(ctx, "inspection.asset", "INSPECTION", insp.id, object_ref=insp.reference, depot_id=asset.depot_id,
          details={"asset": asset.serial_number, "result": body.result, "kind": body.kind})
    ctx.commit()
    return {"id": insp.id, "reference": insp.reference, "result": insp.result, "asset_id": asset.id,
            "note": "Un contrôle conforme ne remet pas l'équipement à disposition : une décision explicite est requise."}


@router.post("/assets/{asset_id}/release-decision", status_code=201, tags=["Contrôles"])
def release_decision(ctx: CtxDep, asset_id: uuid.UUID, body: ReleaseDecisionIn):
    asset = ctx.db.execute(select(Asset).where(Asset.id == asset_id).with_for_update().execution_options(populate_existing=True)).scalar_one_or_none()
    if asset is None:
        raise NotFound("Équipement introuvable.")
    ctx.require("asset.release_decision", asset.depot_id)
    expect_version(asset, body.version)
    if asset.lifecycle != AssetLifecycle.IN_STOCK or asset.technical_state == TechnicalState.SERVICEABLE and asset.stock_status == StockStatus.USABLE:
        raise Conflict("Aucune décision attendue pour cet équipement (déjà apte et disponible, ou absent du dépôt).")
    open_orders = ctx.db.execute(
        select(MaintenanceOrder).where(MaintenanceOrder.asset_id == asset.id, MaintenanceOrder.status.notin_([S.CLOSED, S.CANCELLED]))
    ).scalars().all()
    last_order = ctx.db.execute(
        select(MaintenanceOrder).where(MaintenanceOrder.asset_id == asset.id).order_by(MaintenanceOrder.signaled_at.desc())
    ).scalars().first()
    insp = ctx.db.get(Inspection, body.inspection_id) if body.inspection_id else None
    item = ctx.db.get(Item, asset.item_id)
    if body.decision == "RETURN_TO_SERVICE":
        if insp is None or insp.asset_id != asset.id:
            raise Conflict("Contrôle manquant : une remise à disposition exige un contrôle de l'équipement.", code="controle_manquant")
        if open_orders:
            raise Conflict(f"Ordre de maintenance {open_orders[0].reference} non clôturé : remise à disposition impossible.", code="ordre_ouvert")
        if insp.result != InspectionResult.PASS:
            raise Conflict("Le contrôle référencé n'est pas conforme.", code="controle_non_conforme")
        if last_order and last_order.completed_at and insp.performed_at < last_order.completed_at:
            raise Conflict("Le contrôle est antérieur à la dernière intervention.", code="controle_perime")
        if ctx.db.execute(select(ReleaseDecision.id).where(ReleaseDecision.inspection_id == insp.id)).first():
            raise Conflict("Ce contrôle a déjà fondé une décision.")
        ctx.separate("sod.release_decider_not_inspector", insp.inspector_id,
                     "La décision de remise à disposition doit être prise par une autre personne que le contrôleur.")
        if body.to_location_id is None:
            raise ValidationFailed("Emplacement de remise en stock obligatoire.")
        dst = inv.get_location(ctx, body.to_location_id, asset.depot_id)
        if dst.kind != LocationKind.STORAGE:
            raise ValidationFailed("La remise à disposition se fait vers un emplacement de stockage.")
    decision = ReleaseDecision(
        id=uuid.uuid4(), reference=next_reference(ctx.db, "decision", ctx.now.year), asset_id=asset.id,
        maintenance_order_id=last_order.id if last_order and not open_orders else None, inspection_id=insp.id if insp else None,
        decision=body.decision, reason=body.reason, decided_by=ctx.user_id, decided_at=ctx.now,
    )
    ctx.db.add(decision)
    src = ("DECISION", decision.id, decision.reference)
    cur_loc = ctx.db.get(Location, asset.location_id)
    if body.decision == "RETURN_TO_SERVICE":
        inv.post_movement(ctx, mtype=MovementType.STATUS_CHANGE, item=item, quantity=1, asset=asset, from_location=cur_loc,
                          from_status=StockStatus(asset.stock_status), to_location=dst, to_status=StockStatus.USABLE, source=src, reason=body.reason)
        asset.technical_state = TechnicalState.SERVICEABLE
        if item.maintenance_interval_days:
            asset.next_inspection_due = (ctx.now + timedelta(days=item.maintenance_interval_days)).date()
    elif body.decision == "CONDEMN":
        if open_orders:
            for o in open_orders:
                o.status = S.CANCELLED
        inv.post_movement(ctx, mtype=MovementType.CONDEMNATION, item=item, quantity=1, asset=asset, from_location=cur_loc,
                          from_status=StockStatus(asset.stock_status), source=src, reason=body.reason)
        asset.lifecycle, asset.technical_state = AssetLifecycle.CONDEMNED, TechnicalState.CONDEMNED
    else:
        asset.technical_state = TechnicalState.UNSERVICEABLE
    audit(ctx, f"asset.decision.{body.decision.lower()}", "ASSET", asset.id, object_ref=asset.serial_number, depot_id=asset.depot_id,
          reason=body.reason, details={"decision": decision.reference, "inspection": insp.reference if insp else None})
    ctx.commit()
    return {"id": decision.id, "reference": decision.reference, "decision": decision.decision,
            "asset": {"id": asset.id, "technical_state": asset.technical_state, "lifecycle": asset.lifecycle,
                      "stock_status": asset.stock_status, "next_inspection_due": asset.next_inspection_due, "version": asset.version}}


@router.get("/providers", tags=["Maintenance"])
def providers(ctx: CtxDep):
    ctx.require("stock.read")
    return [{"id": o.id, "code": o.code, "name": o.name}
            for o in ctx.db.execute(select(Organization).where(Organization.kind == OrgKind.PROVIDER)).scalars()]
