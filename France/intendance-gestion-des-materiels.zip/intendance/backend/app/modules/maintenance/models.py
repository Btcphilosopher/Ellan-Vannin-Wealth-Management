"""Maintenance : ordres de travail, temps, pièces, prestataires, décisions de remise à disposition."""
from __future__ import annotations

import uuid
from datetime import date, datetime
from decimal import Decimal
from enum import StrEnum

from sqlalchemy import CheckConstraint, Date, DateTime, ForeignKey, String, Text
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.db import Base, Money, Qty, Timestamped, Versioned, uuid_pk


class MaintenanceStatus(StrEnum):
    SIGNALED = "SIGNALED"  # signalé
    ASSESSED = "ASSESSED"  # évalué
    PLANNED = "PLANNED"  # planifié
    IN_PROGRESS = "IN_PROGRESS"  # en intervention
    TO_INSPECT = "TO_INSPECT"  # à contrôler
    CLOSED = "CLOSED"  # clôturé (ne vaut PAS aptitude)
    CANCELLED = "CANCELLED"


class MaintenanceOrder(Base, Timestamped, Versioned):
    __tablename__ = "maintenance_orders"
    id: Mapped[uuid.UUID] = uuid_pk()
    reference: Mapped[str] = mapped_column(String(32), unique=True)
    asset_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("assets.id"), index=True)
    depot_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("depots.id"), index=True)
    origin: Mapped[str] = mapped_column(String(24))  # RETURN | PERIODIC | INSPECTION | USER_REPORT
    priority: Mapped[str] = mapped_column(String(16), default="NORMAL")  # LOW NORMAL HIGH CRITICAL
    status: Mapped[MaintenanceStatus] = mapped_column(String(16), default=MaintenanceStatus.SIGNALED, index=True)
    defect_description: Mapped[str] = mapped_column(Text)
    diagnosis: Mapped[str] = mapped_column(Text, default="")
    estimated_cost: Mapped[Decimal | None] = mapped_column(Money)
    due_date: Mapped[date | None] = mapped_column(Date)
    planned_start: Mapped[date | None] = mapped_column(Date)
    provider_id: Mapped[uuid.UUID | None] = mapped_column(UUID(as_uuid=True), ForeignKey("organizations.id"))
    technician_name: Mapped[str | None] = mapped_column(String(200))
    work_result: Mapped[str] = mapped_column(Text, default="")
    signaled_by: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("users.id"))
    signaled_at: Mapped[datetime] = mapped_column(DateTime(timezone=True))
    assessed_by: Mapped[uuid.UUID | None] = mapped_column(UUID(as_uuid=True), ForeignKey("users.id"))
    started_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    completed_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    completed_by: Mapped[uuid.UUID | None] = mapped_column(UUID(as_uuid=True), ForeignKey("users.id"))
    closed_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    closed_by: Mapped[uuid.UUID | None] = mapped_column(UUID(as_uuid=True), ForeignKey("users.id"))
    labour: Mapped[list["MaintenanceLabour"]] = relationship(lazy="selectin", order_by="MaintenanceLabour.performed_on")
    parts: Mapped[list["MaintenancePart"]] = relationship(lazy="selectin")


class MaintenanceLabour(Base, Timestamped):
    __tablename__ = "maintenance_labour"
    __table_args__ = (CheckConstraint("hours > 0", name="hours_positive"), CheckConstraint("cost >= 0", name="cost"))
    id: Mapped[uuid.UUID] = uuid_pk()
    order_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("maintenance_orders.id", ondelete="CASCADE"))
    technician_name: Mapped[str] = mapped_column(String(200))
    provider_id: Mapped[uuid.UUID | None] = mapped_column(UUID(as_uuid=True), ForeignKey("organizations.id"))
    hours: Mapped[Decimal] = mapped_column(Qty)
    cost: Mapped[Decimal] = mapped_column(Money)
    description: Mapped[str] = mapped_column(Text, default="")
    performed_on: Mapped[date] = mapped_column(Date)
    recorded_by: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("users.id"))


class MaintenancePart(Base, Timestamped):
    __tablename__ = "maintenance_parts"
    id: Mapped[uuid.UUID] = uuid_pk()
    order_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("maintenance_orders.id", ondelete="CASCADE"))
    item_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("items.id"))
    lot_id: Mapped[uuid.UUID | None] = mapped_column(UUID(as_uuid=True), ForeignKey("lots.id"))
    quantity: Mapped[Decimal] = mapped_column(Qty)
    unit_cost: Mapped[Decimal | None] = mapped_column(Money)
    movement_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("stock_movements.id"))
    recorded_by: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("users.id"))


class ReleaseDecision(Base, Timestamped):
    """Décision explicite et attribuée de remise à disposition (ou de réforme)."""

    __tablename__ = "release_decisions"
    id: Mapped[uuid.UUID] = uuid_pk()
    reference: Mapped[str] = mapped_column(String(32), unique=True)
    asset_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("assets.id"), index=True)
    maintenance_order_id: Mapped[uuid.UUID | None] = mapped_column(UUID(as_uuid=True), ForeignKey("maintenance_orders.id"))
    inspection_id: Mapped[uuid.UUID | None] = mapped_column(UUID(as_uuid=True), ForeignKey("inspections.id"))
    decision: Mapped[str] = mapped_column(String(24))  # RETURN_TO_SERVICE | KEEP_UNSERVICEABLE | CONDEMN
    reason: Mapped[str] = mapped_column(Text)
    decided_by: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("users.id"))
    decided_at: Mapped[datetime] = mapped_column(DateTime(timezone=True))
