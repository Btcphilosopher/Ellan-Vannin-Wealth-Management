"""Génération des rapports (CSV, PDF). Utilisé en direct et par le traitement en arrière-plan."""
from __future__ import annotations

import csv
import io
import uuid
from datetime import datetime

from sqlalchemy import select

from app.core.errors import NotFound, ValidationFailed
from app.core.pdf import render_pdf

REPORTS = {
    "stock": {"title": "État des stocks", "perm": "stock.read", "params": ["depot_id"]},
    "movements": {"title": "Journal des mouvements", "perm": "stock.read", "params": ["depot_id", "since", "until"]},
    "asset-trace": {"title": "Traçabilité d'un équipement", "perm": "stock.read", "params": ["asset_id"]},
    "transfers": {"title": "Transferts et écarts", "perm": "stock.read", "params": ["depot_id"]},
    "maintenance": {"title": "Ordres de maintenance et coûts", "perm": "stock.read", "params": ["depot_id"]},
    "stocktake": {"title": "Résultat d'inventaire physique", "perm": "stock.read", "params": ["stocktake_id"]},
    "audit": {"title": "Journal d'audit", "perm": "audit.read", "params": ["since", "until"]},
}


def _fmt(v) -> str:
    if v is None:
        return ""
    if isinstance(v, float):
        return f"{v:g}"
    if isinstance(v, datetime):
        return v.strftime("%d/%m/%Y %H:%M")
    return str(v)


def build_rows(ctx, kind: str, params: dict) -> tuple[str, list[str], list[list]]:
    if kind not in REPORTS:
        raise NotFound("Rapport inconnu.")
    spec = REPORTS[kind]
    ctx.require(spec["perm"])
    depots = ctx.visible_depot_ids()
    if params.get("depot_id"):
        did = uuid.UUID(str(params["depot_id"]))
        ctx.require("stock.read", did)
        depots = {did}
    title = spec["title"]
    if kind == "stock":
        from app.modules.inventory.service import stock_overview

        header = ["Dépôt", "Code", "Désignation", "Variante", "Unité", "Physique", "Réservé", "Disponible", "En transit", "Bloqué"]
        rows = [[r["depot_code"], r["item_code"], r["designation"], r["variant_label"] or "", r["base_unit"], float(r["physical"]),
                 float(r["reserved"]), float(r["available"]), float(r["in_transit"]), float(r["blocked"])] for r in stock_overview(ctx, depots)]
    elif kind == "movements":
        from app.modules.inventory.api import movement_dict
        from app.modules.inventory.models import StockMovement

        q = select(StockMovement).where(StockMovement.depot_id.in_(depots)).order_by(StockMovement.seq)
        if params.get("since"):
            q = q.where(StockMovement.occurred_at >= datetime.fromisoformat(params["since"]))
        if params.get("until"):
            q = q.where(StockMovement.occurred_at <= datetime.fromisoformat(params["until"]))
        cache: dict = {}
        header = ["Référence", "Date", "Type", "Article", "Variante/Lot", "Exemplaire", "Quantité", "De", "Vers", "Statuts", "Acteur", "Origine", "Motif"]
        rows = []
        for m in ctx.db.execute(q).scalars():
            d = movement_dict(ctx, m, cache)
            rows.append([d["reference"], d["occurred_at"], d["type"], d["item"]["code"], d["variant_label"] or d["lot_number"] or "",
                         d["asset"]["serial_number"] if d["asset"] else "", d["quantity"], d["from_location"] or "", d["to_location"] or "",
                         f"{d['from_status'] or '—'} → {d['to_status'] or '—'}", d["actor"], d["source_ref"] or "", d["reason"] or ""])
    elif kind == "asset-trace":
        from app.modules.inventory.api import asset_history

        if not params.get("asset_id"):
            raise ValidationFailed("Paramètre asset_id obligatoire.")
        h = asset_history(ctx, uuid.UUID(str(params["asset_id"])))
        title = f"Traçabilité — {h['asset']['item']['designation']} n° {h['asset']['serial_number']}"
        header = ["Date", "Phase", "Événement", "Référence", "Détail", "Acteur"]
        rows = [[e["at"], e["phase"], e["title"], e["reference"], e.get("detail") or "", e.get("actor") or ""] for e in h["events"]]
        rows.append([ctx.now, "ETAT", "État actuel", h["asset"]["internal_tag"], h["explanation"], ""])
    elif kind == "transfers":
        from app.modules.transfers.api import transfer_dict
        from app.modules.transfers.models import Transfer

        header = ["Transfert", "Statut", "Origine", "Destination", "Article", "Expédié", "Reçu", "Endommagé", "Perte", "Écart restant"]
        rows = []
        for t in ctx.db.execute(select(Transfer).where(Transfer.source_depot_id.in_(depots) | Transfer.destination_depot_id.in_(depots)).order_by(Transfer.requested_at)).scalars():
            d = transfer_dict(ctx, t)
            for ln in d["lines"]:
                rows.append([d["reference"], d["status"], d["source_depot"]["code"], d["destination_depot"]["code"], ln["item_code"], ln["shipped_qty"],
                             ln["received_qty"], ln["damaged_qty"], ln["written_off_qty"], ln["discrepancy_qty"] or ln["in_transit_qty"]])
    elif kind == "maintenance":
        from app.modules.maintenance.api import order_dict
        from app.modules.maintenance.models import MaintenanceOrder

        header = ["Ordre", "Statut", "Équipement", "Défaut", "Heures", "Coût main-d'œuvre", "Coût pièces", "Total", "Décision"]
        rows = []
        for o in ctx.db.execute(select(MaintenanceOrder).where(MaintenanceOrder.depot_id.in_(depots)).order_by(MaintenanceOrder.signaled_at)).scalars():
            d = order_dict(ctx, o)
            rows.append([d["reference"], d["status"], d["asset"]["serial_number"], d["defect_description"][:60], d["costs"]["hours"], d["costs"]["labour"],
                         d["costs"]["parts"], d["costs"]["total"], d["release_decision"]["decision"] if d["release_decision"] else "en attente"])
    elif kind == "stocktake":
        from app.modules.stocktakes.api import stocktake_dict
        from app.modules.stocktakes.models import Stocktake

        st = ctx.db.get(Stocktake, uuid.UUID(str(params.get("stocktake_id"))))
        if st is None:
            raise NotFound("Inventaire introuvable.")
        ctx.require("stock.read", st.depot_id)
        d = stocktake_dict(ctx, st)
        title = f"Inventaire {d['reference']} — {d['name']}"
        header = ["Ligne", "Emplacement", "Article", "Variante", "Instantané", "Compté", "Théorique au comptage", "Écart", "Statut", "Justification"]
        rows = [[ln["line_no"], ln["location_code"], ln["item_code"], ln["variant_label"] or "", ln["snapshot_qty"], ln["final_counted_qty"],
                 ln["final_system_qty"], ln["variance_qty"], ln["status"], ln["justification"]] for ln in d["lines"]]
    else:  # audit
        from app.modules.audit.api import audit_query

        q = audit_query(since=datetime.fromisoformat(params["since"]) if params.get("since") else None,
                        until=datetime.fromisoformat(params["until"]) if params.get("until") else None)
        header = ["N°", "Date", "Acteur", "Action", "Résultat", "Objet", "Référence", "Motif", "Requête"]
        rows = [[e.seq, e.occurred_at, e.actor_name or "", e.action, e.outcome, e.object_type or "", e.object_ref or "", e.reason or "", e.request_id or ""]
                for e in ctx.db.execute(q.limit(5000)).scalars()]
    return title, header, rows


def render(ctx, kind: str, fmt: str, params: dict) -> tuple[bytes, str, str]:
    title, header, rows = build_rows(ctx, kind, params)
    stamp = ctx.now.strftime("%Y%m%d-%H%M")
    if fmt == "csv":
        buf = io.StringIO()
        w = csv.writer(buf, delimiter=";")
        w.writerow([f"# {title} — généré le {ctx.now:%d/%m/%Y %H:%M} (horloge métier) par {ctx.user.full_name} — données fictives"])
        w.writerow(header)
        for r in rows:
            w.writerow([_fmt(v) for v in r])
        return ("﻿" + buf.getvalue()).encode("utf-8"), "text/csv", f"intendance-{kind}-{stamp}.csv"
    if fmt == "pdf":
        lines = [f"Généré le {ctx.now:%d/%m/%Y %H:%M} (horloge métier) par {ctx.user.full_name}", "", " | ".join(header), "-" * 100]
        lines += [" | ".join(_fmt(v) for v in r) for r in rows]
        return render_pdf(f"INTENDANCE — {title}", lines), "application/pdf", f"intendance-{kind}-{stamp}.pdf"
    raise ValidationFailed("Format inconnu (csv ou pdf).")
