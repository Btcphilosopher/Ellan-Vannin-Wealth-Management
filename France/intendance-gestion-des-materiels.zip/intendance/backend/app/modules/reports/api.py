from __future__ import annotations

import uuid
from typing import Literal

from fastapi import APIRouter, Request
from fastapi.responses import Response
from pydantic import Field

from app.core.deps import CtxDep
from app.core.errors import NotFound
from app.core.models import Job
from app.core.schemas import StrictModel
from app.jobs import enqueue
from app.modules.audit.service import audit
from app.modules.reports.service import REPORTS, render

router = APIRouter(prefix="/v1/reports", tags=["Rapports"])


class ExportIn(StrictModel):
    kind: str
    format: Literal["csv", "pdf"] = "csv"
    params: dict = Field(default_factory=dict)


@router.get("")
def list_reports(ctx: CtxDep):
    return [{"kind": k, "title": v["title"], "params": v["params"], "allowed": ctx.can(v["perm"]) and ctx.can("report.export")}
            for k, v in REPORTS.items()]


@router.get("/{kind}/download")
def download(ctx: CtxDep, kind: str, request: Request, format: Literal["csv", "pdf"] = "csv"):
    """Export immédiat (synchrone)."""
    ctx.require("report.export")
    params = {k: v for k, v in request.query_params.items() if k != "format"}
    data, ctype, filename = render(ctx, kind, format, params)
    audit(ctx, "report.export", "REPORT", None, object_ref=kind, details={"format": format, "params": params, "size": len(data)})
    ctx.commit()
    return Response(content=data, media_type=ctype, headers={"Content-Disposition": f'attachment; filename="{filename}"'})


@router.post("/exports", status_code=202)
def create_export(ctx: CtxDep, body: ExportIn):
    """Export en arrière-plan : le fichier produit est conservé comme document versionné."""
    ctx.require("report.export")
    if body.kind not in REPORTS:
        raise NotFound("Rapport inconnu.")
    ctx.require(REPORTS[body.kind]["perm"])
    job = enqueue(ctx.db, "report_export", body.model_dump(), created_by=ctx.user_id)
    audit(ctx, "report.export_requested", "JOB", job.id, object_ref=body.kind, details={"format": body.format, "params": body.params})
    ctx.commit()
    return {"job_id": job.id, "status": job.status}


@router.get("/exports/{job_id}")
def export_status(ctx: CtxDep, job_id: uuid.UUID):
    job = ctx.db.get(Job, job_id)
    if job is None or (job.created_by != ctx.user_id and not ctx.can("audit.read")):
        raise NotFound("Export introuvable.")
    return {"job_id": job.id, "status": job.status, "attempts": job.attempts, "result": job.result, "error": job.error,
            "created_at": job.created_at, "finished_at": job.finished_at}
