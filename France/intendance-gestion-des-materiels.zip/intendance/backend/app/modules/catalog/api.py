"""Catalogue : GET/POST /v1/items, détail, modification versionnée, familles, unités."""
from __future__ import annotations

import uuid
from decimal import Decimal
from typing import Literal

from fastapi import APIRouter, Query
from pydantic import Field
from sqlalchemy import or_, select

from app.core.deps import CtxDep, PageDep, paginate
from app.core.errors import Conflict, NotFound, ValidationFailed, expect_version
from app.core.schemas import StrictModel, dec
from app.modules.audit.service import audit
from app.modules.catalog.models import (
    Dimension,
    Item,
    ItemFamily,
    ItemPackaging,
    ItemVariant,
    Tracking,
    UnitOfMeasure,
)

router = APIRouter(prefix="/v1", tags=["Catalogue"])


class VariantIn(StrictModel):
    code: str = Field(min_length=1, max_length=32)
    label: str = Field(min_length=1, max_length=120)
    attributes: dict = Field(default_factory=dict)


class PackagingIn(StrictModel):
    unit_code: str
    label: str
    factor: Decimal = Field(gt=0)
    allowed_for_receipt: bool = True
    allowed_for_issue: bool = True


class ItemIn(StrictModel):
    code: str = Field(min_length=2, max_length=40, pattern=r"^[A-Z0-9][A-Z0-9-]*$")
    designation: str = Field(min_length=2, max_length=200)
    family_code: str
    description: str = ""
    base_unit: str
    tracking: Literal["QUANTITY", "LOT", "SERIAL"]
    inspection_level: Literal["VISUAL", "FUNCTIONAL", "TECHNICAL"] = "VISUAL"
    inspection_requirements: list[str] = Field(default_factory=list)
    maintenance_interval_days: int | None = Field(default=None, gt=0)
    loanable: bool = False
    consumable: bool = False
    min_stock: Decimal | None = Field(default=None, ge=0)
    unit_value: Decimal | None = Field(default=None, ge=0)
    variants: list[VariantIn] = Field(default_factory=list)
    packagings: list[PackagingIn] = Field(default_factory=list)


class ItemUpdate(StrictModel):
    version: int
    designation: str | None = None
    description: str | None = None
    inspection_requirements: list[str] | None = None
    min_stock: Decimal | None = None
    active: bool | None = None
    maintenance_interval_days: int | None = None


def item_dict(item: Item, families: dict | None = None) -> dict:
    return {
        "id": item.id,
        "code": item.code,
        "designation": item.designation,
        "family_code": item.family_code,
        "family_label": (families or {}).get(item.family_code),
        "description": item.description,
        "base_unit": item.base_unit,
        "tracking": item.tracking,
        "inspection_level": item.inspection_level,
        "inspection_requirements": item.inspection_requirements,
        "maintenance_interval_days": item.maintenance_interval_days,
        "loanable": item.loanable,
        "consumable": item.consumable,
        "min_stock": dec(item.min_stock),
        "unit_value": dec(item.unit_value),
        "active": item.active,
        "version": item.version,
        "variants": [{"id": v.id, "code": v.code, "label": v.label, "attributes": v.attributes} for v in item.variants],
        "packagings": [
            {"unit_code": p.unit_code, "label": p.label, "factor": dec(p.factor),
             "allowed_for_receipt": p.allowed_for_receipt, "allowed_for_issue": p.allowed_for_issue}
            for p in item.packagings
        ],
        "conversions": [f"1 {p.unit_code} = {dec(p.factor):g} {item.base_unit}" for p in item.packagings],
    }


def families_map(ctx) -> dict:
    return {f.code: f.label for f in ctx.db.execute(select(ItemFamily)).scalars()}


@router.get("/families")
def list_families(ctx: CtxDep):
    ctx.require("catalog.read")
    return [{"code": f.code, "label": f.label} for f in ctx.db.execute(select(ItemFamily).order_by(ItemFamily.sort_order)).scalars()]


@router.get("/units")
def list_units(ctx: CtxDep):
    ctx.require("catalog.read")
    return [
        {"code": u.code, "label": u.label, "dimension": u.dimension, "decimals_allowed": u.decimals_allowed}
        for u in ctx.db.execute(select(UnitOfMeasure).order_by(UnitOfMeasure.code)).scalars()
    ]


@router.get("/items")
def list_items(
    ctx: CtxDep,
    page: PageDep,
    q: str | None = Query(None, max_length=100),
    family: str | None = None,
    tracking: str | None = None,
    active: bool | None = True,
):
    ctx.require("catalog.read")
    stmt = select(Item).order_by(Item.family_code, Item.code)
    if q:
        like = f"%{q}%"
        stmt = stmt.where(or_(Item.code.ilike(like), Item.designation.ilike(like)))
    if family:
        stmt = stmt.where(Item.family_code == family)
    if tracking:
        stmt = stmt.where(Item.tracking == tracking)
    if active is not None:
        stmt = stmt.where(Item.active.is_(active))
    fam = families_map(ctx)
    return paginate(ctx, stmt, page, lambda i: item_dict(i, fam))


@router.get("/items/{item_id}")
def get_item(ctx: CtxDep, item_id: uuid.UUID):
    ctx.require("catalog.read")
    item = ctx.db.get(Item, item_id)
    if item is None:
        raise NotFound("Article introuvable.")
    return item_dict(item, families_map(ctx))


def create_item(ctx, body: ItemIn) -> Item:
    ctx.require("catalog.write")
    if ctx.db.execute(select(Item.id).where(Item.code == body.code)).first():
        raise Conflict(f"Le code article {body.code} existe déjà.", code="code_en_double")
    if ctx.db.get(ItemFamily, body.family_code) is None:
        raise ValidationFailed("Famille inconnue.")
    base = ctx.db.get(UnitOfMeasure, body.base_unit)
    if base is None or base.dimension == Dimension.PACKAGE:
        raise ValidationFailed("L'unité de base doit être une unité de mesure (pas un conditionnement).")
    if body.tracking == Tracking.SERIAL and body.base_unit != "PCE":
        raise ValidationFailed("Un article suivi par numéro de série se gère à la pièce (PCE).")
    item = Item(
        id=uuid.uuid4(),
        **body.model_dump(exclude={"variants", "packagings"}),
    )
    ctx.db.add(item)
    seen = set()
    for v in body.variants:
        if v.code in seen:
            raise ValidationFailed(f"Variante {v.code} en double.")
        seen.add(v.code)
        ctx.db.add(ItemVariant(id=uuid.uuid4(), item_id=item.id, code=v.code, label=v.label, attributes=v.attributes))
    for p in body.packagings:
        unit = ctx.db.get(UnitOfMeasure, p.unit_code)
        if unit is None:
            raise ValidationFailed(f"Unité inconnue : {p.unit_code}.")
        if unit.dimension not in (Dimension.PACKAGE, base.dimension):
            raise ValidationFailed(
                f"Conversion incohérente : {p.unit_code} ({unit.dimension}) ne peut être converti en {body.base_unit} ({base.dimension}).",
                code="conversion_interdite",
            )
        if body.tracking == Tracking.SERIAL and p.factor != p.factor.to_integral_value():
            raise ValidationFailed("Facteur entier requis pour un article sérialisé.")
        ctx.db.add(ItemPackaging(id=uuid.uuid4(), item_id=item.id, **p.model_dump()))
    audit(ctx, "item.create", "ITEM", item.id, object_ref=item.code, details={"tracking": body.tracking})
    return item


@router.post("/items", status_code=201)
def post_item(ctx: CtxDep, body: ItemIn):
    item = create_item(ctx, body)
    ctx.commit()
    ctx.db.refresh(item)
    return item_dict(item, families_map(ctx))


@router.patch("/items/{item_id}")
def patch_item(ctx: CtxDep, item_id: uuid.UUID, body: ItemUpdate):
    ctx.require("catalog.write")
    item = ctx.db.get(Item, item_id)
    if item is None:
        raise NotFound("Article introuvable.")
    expect_version(item, body.version)
    changes = body.model_dump(exclude_unset=True, exclude={"version"})
    for k, v in changes.items():
        setattr(item, k, v)
    audit(ctx, "item.update", "ITEM", item.id, object_ref=item.code, details={"fields": sorted(changes)})
    ctx.commit()
    return item_dict(item, families_map(ctx))
