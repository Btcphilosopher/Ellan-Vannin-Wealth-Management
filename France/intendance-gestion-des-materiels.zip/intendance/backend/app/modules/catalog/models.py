"""Catalogue : références d'articles, variantes, unités, conditionnements et lots."""
from __future__ import annotations

import uuid
from datetime import date
from decimal import Decimal
from enum import StrEnum

from sqlalchemy import Boolean, CheckConstraint, Date, ForeignKey, Integer, String, Text, UniqueConstraint
from sqlalchemy.dialects.postgresql import JSONB, UUID
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.db import Base, Qty, Timestamped, Versioned, uuid_pk


class Dimension(StrEnum):
    COUNT = "COUNT"  # pièces, paires, jeux
    MASS = "MASS"
    VOLUME = "VOLUME"
    LENGTH = "LENGTH"
    PACKAGE = "PACKAGE"  # conditionnement (carton, palette) : toujours converti vers l'unité de base


class Tracking(StrEnum):
    QUANTITY = "QUANTITY"
    LOT = "LOT"
    SERIAL = "SERIAL"


class InspectionLevel(StrEnum):
    VISUAL = "VISUAL"  # contrôle visuel et quantitatif
    FUNCTIONAL = "FUNCTIONAL"  # essai de fonctionnement
    TECHNICAL = "TECHNICAL"  # contrôle technique par la maintenance


class UnitOfMeasure(Base):
    __tablename__ = "units"
    code: Mapped[str] = mapped_column(String(16), primary_key=True)
    label: Mapped[str] = mapped_column(String(60))
    dimension: Mapped[Dimension] = mapped_column(String(16))
    decimals_allowed: Mapped[bool] = mapped_column(Boolean, default=False)


class ItemFamily(Base):
    __tablename__ = "item_families"
    code: Mapped[str] = mapped_column(String(32), primary_key=True)
    label: Mapped[str] = mapped_column(String(120))
    sort_order: Mapped[int] = mapped_column(Integer, default=0)


class Item(Base, Timestamped, Versioned):
    __tablename__ = "items"
    __table_args__ = (
        CheckConstraint("tracking <> 'SERIAL' OR base_unit = 'PCE'", name="serial_in_pieces"),
        CheckConstraint("maintenance_interval_days IS NULL OR maintenance_interval_days > 0", name="interval"),
    )
    id: Mapped[uuid.UUID] = uuid_pk()
    code: Mapped[str] = mapped_column(String(40), unique=True)
    designation: Mapped[str] = mapped_column(String(200))
    family_code: Mapped[str] = mapped_column(String(32), ForeignKey("item_families.code"))
    description: Mapped[str] = mapped_column(Text, default="")
    base_unit: Mapped[str] = mapped_column(String(16), ForeignKey("units.code"))
    tracking: Mapped[Tracking] = mapped_column(String(16))
    inspection_level: Mapped[InspectionLevel] = mapped_column(String(16), default=InspectionLevel.VISUAL)
    inspection_requirements: Mapped[list] = mapped_column(JSONB, default=list)
    maintenance_interval_days: Mapped[int | None] = mapped_column(Integer)
    loanable: Mapped[bool] = mapped_column(Boolean, default=False)
    consumable: Mapped[bool] = mapped_column(Boolean, default=False)
    min_stock: Mapped[Decimal | None] = mapped_column(Qty)
    unit_value: Mapped[Decimal | None] = mapped_column(Qty)  # valeur indicative fictive (€)
    active: Mapped[bool] = mapped_column(Boolean, default=True)

    variants: Mapped[list["ItemVariant"]] = relationship(back_populates="item", lazy="selectin", order_by="ItemVariant.code")
    packagings: Mapped[list["ItemPackaging"]] = relationship(back_populates="item", lazy="selectin")


class ItemVariant(Base, Timestamped):
    __tablename__ = "item_variants"
    __table_args__ = (UniqueConstraint("item_id", "code", name="item_code"),)
    id: Mapped[uuid.UUID] = uuid_pk()
    item_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("items.id", ondelete="CASCADE"))
    code: Mapped[str] = mapped_column(String(32))
    label: Mapped[str] = mapped_column(String(120))
    attributes: Mapped[dict] = mapped_column(JSONB, default=dict)
    active: Mapped[bool] = mapped_column(Boolean, default=True)
    item: Mapped[Item] = relationship(back_populates="variants")


class ItemPackaging(Base, Timestamped):
    """Conditionnement autorisé : 1 <unité> = factor × unité de base de l'article."""

    __tablename__ = "item_packagings"
    __table_args__ = (
        UniqueConstraint("item_id", "unit_code", name="item_unit"),
        CheckConstraint("factor > 0", name="factor_positive"),
    )
    id: Mapped[uuid.UUID] = uuid_pk()
    item_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("items.id", ondelete="CASCADE"))
    unit_code: Mapped[str] = mapped_column(String(16), ForeignKey("units.code"))
    label: Mapped[str] = mapped_column(String(120))
    factor: Mapped[Decimal] = mapped_column(Qty)
    allowed_for_receipt: Mapped[bool] = mapped_column(Boolean, default=True)
    allowed_for_issue: Mapped[bool] = mapped_column(Boolean, default=True)
    item: Mapped[Item] = relationship(back_populates="packagings")


class Lot(Base, Timestamped):
    __tablename__ = "lots"
    __table_args__ = (UniqueConstraint("item_id", "lot_number", name="item_lot"),)
    id: Mapped[uuid.UUID] = uuid_pk()
    item_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("items.id"))
    lot_number: Mapped[str] = mapped_column(String(60))
    manufactured_on: Mapped[date | None] = mapped_column(Date)
    expires_on: Mapped[date | None] = mapped_column(Date)
    supplier_ref: Mapped[str | None] = mapped_column(String(100))
