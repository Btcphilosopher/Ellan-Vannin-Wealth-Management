"""Références lisibles et stables (REC-2026-00012), générées atomiquement."""
from __future__ import annotations

from sqlalchemy import text
from sqlalchemy.orm import Session

PREFIXES = {
    "receipt": "REC",
    "request": "DEM",
    "allocation": "DOT",
    "return": "RET",
    "transfer": "TRF",
    "stocktake": "INV",
    "maintenance": "OTM",
    "inspection": "CTL",
    "decision": "DRD",
    "document": "DOC",
    "movement": "MVT",
}


def next_reference(db: Session, kind: str, year: int) -> str:
    prefix = PREFIXES[kind]
    value = db.execute(
        text(
            "INSERT INTO reference_counters (prefix, year, value) VALUES (:p, :y, 1) "
            "ON CONFLICT (prefix, year) DO UPDATE SET value = reference_counters.value + 1 RETURNING value"
        ),
        {"p": prefix, "y": year},
    ).scalar_one()
    width = 6 if kind == "movement" else 5
    return f"{prefix}-{year}-{value:0{width}d}"
