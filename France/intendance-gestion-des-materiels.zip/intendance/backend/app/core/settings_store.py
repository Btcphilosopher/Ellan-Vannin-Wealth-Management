"""Paramètres métier configurables (table settings) avec valeurs par défaut documentées."""
from __future__ import annotations

from sqlalchemy import select
from sqlalchemy.orm import Session

from app.modules.org.models import Setting

DEFAULTS: dict[str, tuple[object, str]] = {
    "sod.receipt_inspector_not_receiver": (True, "Le contrôleur d'une réception doit être distinct de l'agent qui l'a reçue physiquement."),
    "sod.request_approver_not_creator": (True, "L'approbateur d'une demande doit être distinct de son auteur."),
    "sod.transfer_approver_not_requester": (True, "L'approbateur d'un transfert doit être distinct du demandeur."),
    "sod.adjustment_approver_not_counter": (True, "L'approbateur d'un ajustement d'inventaire ne doit pas avoir compté la ligne."),
    "sod.release_decider_not_inspector": (True, "La décision de remise à disposition est prise par une autre personne que le contrôleur."),
    "sod.correction_by_other_actor": (False, "Une correction de mouvement doit être faite par une autre personne que l'auteur initial."),
    "stocktake.recount_on_any_variance": (True, "Tout écart au premier comptage impose un recomptage."),
    "stocktake.approval_threshold_qty": (5, "Au-delà de cet écart absolu (unités de base), l'ajustement exige un approbateur."),
    "stocktake.approval_threshold_value": (500, "Au-delà de cette valeur (€ fictifs), l'ajustement exige un approbateur."),
    "transfer.writeoff_requires_approver": (True, "Toute passation en perte d'un écart de transfert exige un approbateur."),
    "loan.max_extensions": (2, "Nombre maximal de prolongations d'un prêt."),
    "loan.max_extension_days": (30, "Durée maximale d'une prolongation (jours)."),
    "maintenance.due_warning_days": (14, "Délai d'alerte avant échéance de contrôle périodique (jours)."),
}


def get_setting(db: Session, key: str):
    row = db.execute(select(Setting).where(Setting.key == key)).scalar_one_or_none()
    if row is not None:
        return row.value.get("v")
    return DEFAULTS[key][0] if key in DEFAULTS else None


def all_settings(db: Session) -> list[dict]:
    stored = {s.key: s for s in db.execute(select(Setting)).scalars()}
    out = []
    for key, (default, description) in DEFAULTS.items():
        row = stored.get(key)
        out.append(
            {
                "key": key,
                "value": row.value.get("v") if row else default,
                "default": default,
                "description": description,
                "version": row.version if row else 0,
            }
        )
    return out


def set_setting(db: Session, key: str, value) -> Setting:
    if key not in DEFAULTS and key != "demo_clock":
        raise KeyError(key)
    row = db.get(Setting, key)
    if row is None:
        row = Setting(key=key, value={"v": value}, description=DEFAULTS.get(key, (None, "Horloge de démonstration"))[1])
        db.add(row)
    else:
        row.value = {"v": value}
    return row
