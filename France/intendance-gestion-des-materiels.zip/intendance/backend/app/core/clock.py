"""Horloge métier configurable.

En démonstration, l'heure métier est figée (paramètre ``demo_clock`` en base, à défaut
INTENDANCE_DEMO_CLOCK) afin que les échéances des données fictives restent cohérentes.
Les horodatages techniques (recorded_at, created_at) restent en heure réelle.
"""
from __future__ import annotations

from datetime import datetime, timedelta, timezone
from zoneinfo import ZoneInfo

from sqlalchemy.orm import Session

from app.config import get_settings
from app.core.settings_store import get_setting, set_setting

PARIS = ZoneInfo("Europe/Paris")


def business_now(db: Session) -> datetime:
    stored = get_setting(db, "demo_clock")
    if stored:
        if stored.get("mode") == "real":
            return datetime.now(timezone.utc).astimezone(PARIS)
        return datetime.fromisoformat(stored["at"]).astimezone(PARIS)
    configured = get_settings().demo_clock
    if configured:
        return datetime.fromisoformat(configured).astimezone(PARIS)
    return datetime.now(timezone.utc).astimezone(PARIS)


def clock_info(db: Session) -> dict:
    stored = get_setting(db, "demo_clock")
    mode = "real" if (stored and stored.get("mode") == "real") or (not stored and not get_settings().demo_clock) else "fixed"
    return {"mode": mode, "now": business_now(db).isoformat()}


def set_clock(db: Session, at: datetime | None = None, advance: timedelta | None = None, real: bool = False) -> datetime:
    if real:
        set_setting(db, "demo_clock", {"mode": "real"})
        return business_now(db)
    if at is None:
        at = business_now(db) + (advance or timedelta())
    if at.tzinfo is None:
        at = at.replace(tzinfo=PARIS)
    set_setting(db, "demo_clock", {"mode": "fixed", "at": at.isoformat()})
    return at
