"""Erreurs métier. Chaque erreur porte un code stable et un message en français."""
from __future__ import annotations


class DomainError(Exception):
    status_code = 400
    code = "erreur_metier"

    def __init__(self, message: str, *, code: str | None = None, details: dict | None = None):
        super().__init__(message)
        self.message = message
        if code:
            self.code = code
        self.details = details or {}


class NotFound(DomainError):
    status_code = 404
    code = "introuvable"


class Unauthorized(DomainError):
    status_code = 401
    code = "non_authentifie"


class Forbidden(DomainError):
    status_code = 403
    code = "acces_refuse"


class Conflict(DomainError):
    status_code = 409
    code = "conflit"


class VersionConflict(Conflict):
    code = "version_obsolete"


class InvalidTransition(Conflict):
    code = "transition_invalide"


class InsufficientStock(Conflict):
    code = "stock_insuffisant"


class SeparationOfDuties(Forbidden):
    code = "separation_des_taches"


class ValidationFailed(DomainError):
    status_code = 422
    code = "donnees_invalides"


def expect_version(obj, version: int | None) -> None:
    """Refuse une action fondée sur une version obsolète de l'enregistrement."""
    if version is None:
        raise ValidationFailed("Le champ « version » est obligatoire pour cette action.")
    if obj.version != version:
        raise VersionConflict(
            f"L'enregistrement a été modifié entre-temps (version actuelle {obj.version}, reçue {version}).",
            details={"current_version": obj.version},
        )


def expect_status(obj, allowed: set, action: str) -> None:
    if obj.status not in allowed:
        raise InvalidTransition(
            f"Action « {action} » impossible depuis le statut {obj.status}.",
            details={"status": str(obj.status), "allowed": sorted(str(a) for a in allowed)},
        )
