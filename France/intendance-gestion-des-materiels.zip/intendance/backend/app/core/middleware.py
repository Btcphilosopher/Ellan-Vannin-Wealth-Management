"""Middlewares ASGI : identifiant de requête, en-têtes de sécurité, idempotence des POST."""
from __future__ import annotations

import hashlib
import json
import re
import uuid
from datetime import datetime, timezone

from sqlalchemy import select
from sqlalchemy.exc import IntegrityError

from app.config import get_settings
from app.core.logging import request_id_var
from app.core.models import IdempotencyRecord
from app.core.security import token_hash
from app.db import SessionLocal
from app.modules.auth.models import UserSession

_RID = re.compile(r"^[A-Za-z0-9._-]{8,64}$")


class RequestIdMiddleware:
    def __init__(self, app):
        self.app = app

    async def __call__(self, scope, receive, send):
        if scope["type"] != "http":
            return await self.app(scope, receive, send)
        headers = dict(scope.get("headers") or [])
        incoming = headers.get(b"x-request-id", b"").decode()
        rid = incoming if _RID.match(incoming) else uuid.uuid4().hex
        token = request_id_var.set(rid)

        async def send_wrapper(message):
            if message["type"] == "http.response.start":
                extra = [
                    (b"x-request-id", rid.encode()),
                    (b"x-content-type-options", b"nosniff"),
                    (b"x-frame-options", b"DENY"),
                    (b"referrer-policy", b"no-referrer"),
                    (b"cache-control", b"no-store"),
                ]
                if get_settings().cookie_secure:
                    extra.append((b"strict-transport-security", b"max-age=31536000; includeSubDomains"))
                message.setdefault("headers", [])
                message["headers"] = list(message["headers"]) + extra
            await send(message)

        try:
            await self.app(scope, receive, send_wrapper)
        finally:
            request_id_var.reset(token)


def _scope_for(headers: dict) -> str | None:
    """Rattache la clé d'idempotence à l'utilisateur authentifié (et non au seul jeton)."""
    token = None
    auth = headers.get(b"authorization", b"").decode()
    if auth.lower().startswith("bearer "):
        token = auth[7:].strip()
    else:
        cookie_name = get_settings().session_cookie_name
        for part in headers.get(b"cookie", b"").decode().split(";"):
            k, _, v = part.strip().partition("=")
            if k == cookie_name:
                token = v
    if not token:
        return None
    with SessionLocal() as db:
        sess = db.execute(select(UserSession).where(UserSession.token_hash == token_hash(token))).scalar_one_or_none()
        if sess is None or sess.revoked_at is not None or sess.expires_at < datetime.now(timezone.utc):
            return None
        return f"user:{sess.user_id}"


class IdempotencyMiddleware:
    """Rejoue la réponse d'une requête POST déjà traitée avec la même clé « Idempotency-Key ».

    - même clé + même contenu : réponse d'origine rejouée (en-tête Idempotent-Replayed: true) ;
    - même clé + contenu différent : 422 ;
    - même clé encore en cours de traitement (requêtes dupliquées simultanées) : 409.
    Seules les réponses 2xx sont mémorisées : une requête refusée peut être corrigée et rejouée.
    """

    def __init__(self, app):
        self.app = app

    async def __call__(self, scope, receive, send):
        if scope["type"] != "http" or scope["method"] != "POST" or not scope["path"].startswith("/v1/") or scope["path"].startswith("/v1/auth/"):
            return await self.app(scope, receive, send)
        headers = dict(scope.get("headers") or [])
        key = headers.get(b"idempotency-key", b"").decode().strip()
        if not key:
            return await self.app(scope, receive, send)
        if len(key) > 128:
            return await _json(send, 422, {"code": "cle_idempotence_invalide", "message": "Clé d'idempotence trop longue."})

        chunks = []
        more = True
        while more:
            msg = await receive()
            chunks.append(msg.get("body", b""))
            more = msg.get("more_body", False)
        body = b"".join(chunks)
        req_hash = hashlib.sha256(scope["method"].encode() + scope["path"].encode() + b"\n" + body).hexdigest()
        user_scope = _scope_for(headers)
        if user_scope is None:
            return await self.app(scope, _replay_receive(body), send)

        with SessionLocal() as db:
            rec = IdempotencyRecord(scope=user_scope, key=key, method="POST", path=scope["path"], request_hash=req_hash)
            db.add(rec)
            try:
                db.commit()
                rec_id = rec.id
            except IntegrityError:
                db.rollback()
                existing = db.execute(
                    select(IdempotencyRecord).where(IdempotencyRecord.scope == user_scope, IdempotencyRecord.key == key)
                ).scalar_one()
                if existing.request_hash != req_hash:
                    return await _json(send, 422, {"code": "cle_idempotence_reutilisee", "message": "Cette clé d'idempotence a déjà servi pour une requête différente."})
                if existing.state != "DONE":
                    return await _json(send, 409, {"code": "requete_en_cours", "message": "Une requête identique est en cours de traitement."})
                _log_replay(user_scope, key, scope["path"])
                return await _raw(
                    send, existing.status_code, existing.response_body.encode(), existing.response_type or "application/json",
                    replayed=True,
                )

        status = {"code": 500}
        captured: list[bytes] = []
        ctype = {"v": "application/json"}

        async def send_capture(message):
            if message["type"] == "http.response.start":
                status["code"] = message["status"]
                for k, v in message.get("headers", []):
                    if k.lower() == b"content-type":
                        ctype["v"] = v.decode()
            elif message["type"] == "http.response.body":
                captured.append(message.get("body", b""))
            await send(message)

        try:
            await self.app(scope, _replay_receive(body), send_capture)
        finally:
            with SessionLocal() as db:
                rec = db.get(IdempotencyRecord, rec_id)
                if 200 <= status["code"] < 300:
                    rec.state = "DONE"
                    rec.status_code = status["code"]
                    rec.response_body = b"".join(captured).decode("utf-8", "replace")
                    rec.response_type = ctype["v"]
                else:
                    db.delete(rec)
                db.commit()


def _log_replay(user_scope: str, key: str, path: str) -> None:
    from app.core.clock import business_now
    from app.modules.audit.models import AuditEvent

    with SessionLocal() as db:
        uid = user_scope.split(":", 1)[1]
        db.add(
            AuditEvent(
                occurred_at=business_now(db), actor_id=uuid.UUID(uid), action="request.idempotent_replay", outcome="SUCCESS",
                object_type="HTTP", object_ref=path[:80], request_id=request_id_var.get(),
                details={"idempotency_key": key[:16] + "…", "path": path},
            )
        )
        db.commit()


def _replay_receive(body: bytes):
    sent = {"done": False}

    async def receive():
        if not sent["done"]:
            sent["done"] = True
            return {"type": "http.request", "body": body, "more_body": False}
        return {"type": "http.disconnect"}

    return receive


async def _json(send, status: int, payload: dict):
    await _raw(send, status, json.dumps(payload, ensure_ascii=False).encode(), "application/json")


async def _raw(send, status: int, body: bytes, ctype: str, replayed: bool = False):
    headers = [(b"content-type", ctype.encode()), (b"content-length", str(len(body)).encode())]
    if replayed:
        headers.append((b"idempotent-replayed", b"true"))
    await send({"type": "http.response.start", "status": status, "headers": headers})
    await send({"type": "http.response.body", "body": body})
