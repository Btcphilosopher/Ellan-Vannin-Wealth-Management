"""Mots de passe, jetons de session, CSRF et adaptateurs MFA."""
from __future__ import annotations

import base64
import hashlib
import hmac
import secrets
import struct
import time
from typing import Protocol

from argon2 import PasswordHasher
from argon2.exceptions import VerificationError

_hasher = PasswordHasher()


def hash_password(password: str) -> str:
    return _hasher.hash(password)


def verify_password(password_hash: str | None, password: str) -> bool:
    if not password_hash:
        return False
    try:
        return _hasher.verify(password_hash, password)
    except VerificationError:
        return False
    except Exception:  # hash invalide
        return False


def new_token() -> str:
    return secrets.token_urlsafe(32)


def token_hash(token: str) -> str:
    return hashlib.sha256(token.encode()).hexdigest()


# ---------------------------------------------------------------------------- MFA
class MFAAdapter(Protocol):
    name: str

    def new_secret(self) -> str: ...

    def verify(self, secret: str, code: str, at: float | None = None) -> bool: ...

    def provisioning_uri(self, secret: str, username: str) -> str: ...


class TOTPAdapter:
    """TOTP RFC 6238 (SHA-1, 6 chiffres, pas de 30 s, tolérance ±1 pas)."""

    name = "totp"

    def new_secret(self) -> str:
        return base64.b32encode(secrets.token_bytes(20)).decode().rstrip("=")

    @staticmethod
    def code_at(secret: str, at: float | None = None, step: int = 30) -> str:
        padded = secret + "=" * (-len(secret) % 8)
        key = base64.b32decode(padded.upper())
        counter = int((at if at is not None else time.time()) // step)
        digest = hmac.new(key, struct.pack(">Q", counter), hashlib.sha1).digest()
        offset = digest[-1] & 0x0F
        value = (struct.unpack(">I", digest[offset : offset + 4])[0] & 0x7FFFFFFF) % 1_000_000
        return f"{value:06d}"

    def verify(self, secret: str, code: str, at: float | None = None) -> bool:
        now = at if at is not None else time.time()
        code = (code or "").strip().replace(" ", "")
        return any(hmac.compare_digest(self.code_at(secret, now + d * 30), code) for d in (-1, 0, 1))

    def provisioning_uri(self, secret: str, username: str) -> str:
        return f"otpauth://totp/Intendance:{username}?secret={secret}&issuer=Intendance"


def get_mfa_adapter(name: str) -> MFAAdapter:
    adapters = {"totp": TOTPAdapter()}
    if name not in adapters:
        raise ValueError(f"Adaptateur MFA inconnu : {name}")
    return adapters[name]


# ------------------------------------------------------------------ fournisseurs d'identité
class IdentityProvider(Protocol):
    """Adaptateur d'authentification organisationnelle (LOCAL opérationnel, OIDC à brancher)."""

    mode: str


class LocalIdentityProvider:
    mode = "LOCAL"


class OIDCIdentityProvider:
    """Point d'extension : délégation à un fournisseur OpenID Connect de l'organisation.

    Non branché dans ce prototype : aucune connexion à un système réel n'est effectuée.
    """

    mode = "OIDC"
