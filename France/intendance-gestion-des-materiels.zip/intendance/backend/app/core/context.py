"""Contexte d'exécution d'une requête : utilisateur, périmètre, horloge, permissions côté serveur."""
from __future__ import annotations

import uuid
from dataclasses import dataclass, field
from datetime import datetime

from sqlalchemy import select
from sqlalchemy.orm import Session

from app.core.errors import Forbidden, SeparationOfDuties
from app.core.settings_store import get_setting
from app.modules.org.models import RoleCode as R
from app.modules.org.models import User

ALL = frozenset(R)
READ_ROLES = frozenset({R.VIEWER, R.STOREKEEPER, R.DEPOT_MANAGER, R.MAINTENANCE, R.APPROVER, R.AUDITOR, R.ADMIN})

# Matrice des permissions (aucun rôle n'est « super-utilisateur » : l'administrateur administre,
# il n'approuve ni ne déplace de stock).
PERMISSIONS: dict[str, frozenset] = {
    "catalog.read": READ_ROLES,
    "catalog.write": frozenset({R.DEPOT_MANAGER, R.ADMIN}),
    "stock.read": READ_ROLES,
    "stock.correct": frozenset({R.DEPOT_MANAGER}),
    "stock.relocate": frozenset({R.STOREKEEPER, R.DEPOT_MANAGER}),
    "receipt.create": frozenset({R.STOREKEEPER, R.DEPOT_MANAGER}),
    "receipt.receive": frozenset({R.STOREKEEPER, R.DEPOT_MANAGER}),
    "receipt.inspect": frozenset({R.STOREKEEPER, R.DEPOT_MANAGER, R.MAINTENANCE}),
    "receipt.putaway": frozenset({R.STOREKEEPER, R.DEPOT_MANAGER}),
    "receipt.close": frozenset({R.DEPOT_MANAGER}),
    "request.create": frozenset({R.STOREKEEPER, R.DEPOT_MANAGER}),
    "request.review": frozenset({R.DEPOT_MANAGER}),
    "request.approve": frozenset({R.APPROVER}),
    "request.reserve": frozenset({R.STOREKEEPER, R.DEPOT_MANAGER}),
    "request.issue": frozenset({R.STOREKEEPER, R.DEPOT_MANAGER}),
    "request.close": frozenset({R.DEPOT_MANAGER}),
    "loan.extend": frozenset({R.APPROVER, R.DEPOT_MANAGER}),
    "return.create": frozenset({R.STOREKEEPER, R.DEPOT_MANAGER}),
    "inspection.stock": frozenset({R.STOREKEEPER, R.DEPOT_MANAGER, R.MAINTENANCE}),
    "transfer.create": frozenset({R.STOREKEEPER, R.DEPOT_MANAGER}),
    "transfer.approve": frozenset({R.APPROVER}),
    "transfer.dispatch": frozenset({R.STOREKEEPER, R.DEPOT_MANAGER}),
    "transfer.receive": frozenset({R.STOREKEEPER, R.DEPOT_MANAGER}),
    "transfer.reconcile": frozenset({R.DEPOT_MANAGER}),
    "transfer.writeoff_approve": frozenset({R.APPROVER}),
    "stocktake.manage": frozenset({R.DEPOT_MANAGER}),
    "stocktake.count": frozenset({R.STOREKEEPER, R.DEPOT_MANAGER}),
    "stocktake.approve_small": frozenset({R.DEPOT_MANAGER, R.APPROVER}),
    "stocktake.approve_large": frozenset({R.APPROVER}),
    "stocktake.see_expected": frozenset({R.DEPOT_MANAGER, R.APPROVER, R.AUDITOR}),
    "maintenance.signal": frozenset({R.STOREKEEPER, R.DEPOT_MANAGER, R.MAINTENANCE}),
    "maintenance.manage": frozenset({R.MAINTENANCE}),
    "maintenance.inspect": frozenset({R.MAINTENANCE}),
    "asset.release_decision": frozenset({R.DEPOT_MANAGER}),
    "document.read": READ_ROLES,
    "document.read_restricted": frozenset({R.DEPOT_MANAGER, R.APPROVER, R.AUDITOR, R.MAINTENANCE}),
    "document.write": frozenset({R.STOREKEEPER, R.DEPOT_MANAGER, R.MAINTENANCE, R.APPROVER}),
    "report.export": frozenset({R.DEPOT_MANAGER, R.APPROVER, R.AUDITOR, R.ADMIN}),
    "audit.read": frozenset({R.AUDITOR, R.ADMIN}),
    "admin.users": frozenset({R.ADMIN}),
    "admin.settings": frozenset({R.ADMIN}),
    "admin.clock": frozenset({R.ADMIN}),
}


@dataclass
class Ctx:
    db: Session
    user: User | None
    now: datetime
    request_id: str = "-"
    ip: str | None = None
    actor_id: uuid.UUID | None = None  # copie figée (utilisable après fermeture de la session)
    actor_name: str | None = None
    _depot_orgs: dict = field(default_factory=dict)

    # ------------------------------------------------------------------ périmètre
    @property
    def user_id(self) -> uuid.UUID:
        assert self.user is not None
        return self.user.id

    def roles(self) -> set[str]:
        return {m.role_code for m in self.user.memberships} if self.user else set()

    def _depot_org(self, depot_id: uuid.UUID):
        if depot_id not in self._depot_orgs:
            from app.modules.inventory.models import Depot

            depot = self.db.get(Depot, depot_id)
            self._depot_orgs[depot_id] = depot.organization_id if depot else None
        return self._depot_orgs[depot_id]

    def can(self, perm: str, depot_id: uuid.UUID | None = None) -> bool:
        if self.user is None:
            return False
        allowed = PERMISSIONS[perm]
        for m in self.user.memberships:
            if m.role_code not in allowed:
                continue
            if depot_id is None:
                return True
            if m.depot_id == depot_id:
                return True
            if m.depot_id is None and m.organization_id == self._depot_org(depot_id):
                return True
        return False

    def require(self, perm: str, depot_id: uuid.UUID | None = None, *, action: str | None = None) -> None:
        if not self.can(perm, depot_id):
            raise Forbidden(
                "Vous n'avez pas l'autorisation requise pour cette action dans ce périmètre.",
                details={"permission": perm, "depot_id": str(depot_id) if depot_id else None, "action": action},
            )

    def visible_depot_ids(self, perm: str = "stock.read") -> set[uuid.UUID]:
        from app.modules.inventory.models import Depot

        if self.user is None:
            return set()
        allowed = PERMISSIONS[perm]
        ids: set[uuid.UUID] = set()
        depots = self.db.execute(select(Depot.id, Depot.organization_id)).all()
        for m in self.user.memberships:
            if m.role_code not in allowed:
                continue
            for depot_id, org_id in depots:
                if m.depot_id == depot_id or (m.depot_id is None and m.organization_id == org_id):
                    ids.add(depot_id)
        return ids

    # ------------------------------------------------------------------ séparation des tâches
    def separate(self, rule: str, other_user_id: uuid.UUID | None, message: str) -> None:
        if other_user_id is not None and other_user_id == self.user_id and get_setting(self.db, rule):
            raise SeparationOfDuties(message, details={"rule": rule})

    def setting(self, key: str):
        return get_setting(self.db, key)

    def commit(self) -> None:
        self.db.commit()
