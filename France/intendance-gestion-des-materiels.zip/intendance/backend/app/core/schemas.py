from __future__ import annotations

from decimal import Decimal
from typing import Annotated

from pydantic import BaseModel, ConfigDict, Field

PositiveQty = Annotated[Decimal, Field(gt=0, max_digits=14, decimal_places=3)]
NonNegQty = Annotated[Decimal, Field(ge=0, max_digits=14, decimal_places=3)]


class StrictModel(BaseModel):
    model_config = ConfigDict(extra="forbid", str_strip_whitespace=True)


class VersionedAction(StrictModel):
    version: int = Field(..., ge=1, description="Version connue de l'enregistrement (contrôle de concurrence).")


def dec(v):
    return float(v) if v is not None else None
