"""Dépendances FastAPI : session base de données, authentification, contexte."""
from __future__ import annotations

import hmac
from datetime import datetime, timedelta, timezone
from typing import Annotated

from fastapi import Depends, Query, Request
from sqlalchemy import select

from app.config import get_settings
from app.core.clock import business_now
from app.core.context import Ctx
from app.core.errors import Forbidden, Unauthorized
from app.core.logging import request_id_var
from app.core.security import token_hash
from app.db import SessionLocal
from app.modules.auth.models import UserSession
from app.modules.org.models import User

SAFE_METHODS = {"GET", "HEAD", "OPTIONS"}


def extract_token(request: Request) -> tuple[str | None, bool]:
    """Retourne (jeton, via_cookie)."""
    auth = request.headers.get("authorization", "")
    if auth.lower().startswith("bearer "):
        return auth[7:].strip(), False
    cookie = request.cookies.get(get_settings().session_cookie_name)
    return (cookie, True) if cookie else (None, False)


def _open_ctx(request: Request, *, require_auth: bool, allow_pending_mfa: bool = False):
    settings = get_settings()
    db = SessionLocal()
    ctx = Ctx(db=db, user=None, now=business_now(db), request_id=request_id_var.get(), ip=request.client.host if request.client else None)
    request.state.ctx = ctx
    token, via_cookie = extract_token(request)
    if token:
        sess = db.execute(select(UserSession).where(UserSession.token_hash == token_hash(token))).scalar_one_or_none()
        real_now = datetime.now(timezone.utc)
        valid = (
            sess is not None
            and sess.revoked_at is None
            and sess.expires_at > real_now
            and sess.last_seen_at > real_now - timedelta(minutes=settings.session_idle_minutes)
        )
        if valid:
            user = db.get(User, sess.user_id)
            if user is not None and user.active:
                if not sess.mfa_verified and not allow_pending_mfa:
                    db.close()
                    raise Unauthorized("Vérification MFA requise.", code="mfa_requise")
                if via_cookie and request.method not in SAFE_METHODS:
                    header = request.headers.get("x-csrf-token", "")
                    if not hmac.compare_digest(header, sess.csrf_token):
                        db.close()
                        raise Forbidden("Jeton CSRF absent ou invalide.", code="csrf_invalide")
                if sess.last_seen_at < real_now - timedelta(minutes=1):
                    sess.last_seen_at = real_now
                    db.commit()
                ctx.user = user
                ctx.actor_id, ctx.actor_name = user.id, user.full_name
                request.state.session = sess
    if require_auth and ctx.user is None:
        db.close()
        raise Unauthorized("Authentification requise.")
    return ctx


def get_ctx(request: Request):
    ctx = _open_ctx(request, require_auth=True)
    try:
        yield ctx
    finally:
        ctx.db.rollback()
        ctx.db.close()


def get_ctx_pending_mfa(request: Request):
    ctx = _open_ctx(request, require_auth=True, allow_pending_mfa=True)
    try:
        yield ctx
    finally:
        ctx.db.rollback()
        ctx.db.close()


def get_public_ctx(request: Request):
    ctx = _open_ctx(request, require_auth=False)
    try:
        yield ctx
    finally:
        ctx.db.rollback()
        ctx.db.close()


CtxDep = Annotated[Ctx, Depends(get_ctx)]


class Page:
    def __init__(self, page: int = Query(1, ge=1), page_size: int = Query(50, ge=1, le=200)):
        self.page = page
        self.page_size = page_size

    @property
    def offset(self) -> int:
        return (self.page - 1) * self.page_size


PageDep = Annotated[Page, Depends(Page)]


def paginate(ctx: Ctx, stmt, page: Page, mapper):
    from sqlalchemy import func

    total = ctx.db.execute(select(func.count()).select_from(stmt.order_by(None).subquery())).scalar_one()
    rows = ctx.db.execute(stmt.offset(page.offset).limit(page.page_size)).scalars().all()
    return {"items": [mapper(r) for r in rows], "total": total, "page": page.page, "page_size": page.page_size}
