"""Générateur PDF minimal (texte, plusieurs pages) sans dépendance externe.

Utilisé pour les documents de démonstration et l'export PDF des rapports. Police Helvetica
(WinAnsiEncoding) : les caractères accentués usuels du français sont pris en charge.
"""
from __future__ import annotations


def _esc(text: str) -> bytes:
    raw = text.encode("cp1252", "replace")
    return raw.replace(b"\\", b"\\\\").replace(b"(", b"\\(").replace(b")", b"\\)")


def render_pdf(title: str, lines: list[str], footer: str = "INTENDANCE — données fictives — NON CLASSIFIÉ") -> bytes:
    per_page = 48
    pages = [lines[i : i + per_page] for i in range(0, max(len(lines), 1), per_page)] or [[]]
    objects: list[bytes] = []

    def add(obj: bytes) -> int:
        objects.append(obj)
        return len(objects)

    font = add(b"<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica /Encoding /WinAnsiEncoding >>")
    bold = add(b"<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Bold /Encoding /WinAnsiEncoding >>")
    pages_id_placeholder = len(objects) + 1
    add(b"")  # réservé pour /Pages
    page_ids = []
    for n, chunk in enumerate(pages, start=1):
        stream = [b"BT /F2 15 Tf 50 800 Td (" + _esc(title) + b") Tj ET"]
        stream.append(b"0.69 0.55 0.24 RG 2 w 50 790 m 545 790 l S")
        y = 770
        for line in chunk:
            stream.append(b"BT /F1 9.5 Tf 50 " + str(y).encode() + b" Td (" + _esc(line[:110]) + b") Tj ET")
            y -= 15
        stream.append(b"BT /F1 7.5 Tf 50 30 Td (" + _esc(f"{footer} — page {n}/{len(pages)}") + b") Tj ET")
        data = b"\n".join(stream)
        content = add(b"<< /Length " + str(len(data)).encode() + b" >>\nstream\n" + data + b"\nendstream")
        page_ids.append(add(
            b"<< /Type /Page /Parent " + str(pages_id_placeholder).encode() + b" 0 R /MediaBox [0 0 595 842] "
            b"/Resources << /Font << /F1 " + str(font).encode() + b" 0 R /F2 " + str(bold).encode() + b" 0 R >> >> "
            b"/Contents " + str(content).encode() + b" 0 R >>"
        ))
    kids = b" ".join(str(p).encode() + b" 0 R" for p in page_ids)
    objects[pages_id_placeholder - 1] = b"<< /Type /Pages /Kids [" + kids + b"] /Count " + str(len(page_ids)).encode() + b" >>"
    catalog = add(b"<< /Type /Catalog /Pages " + str(pages_id_placeholder).encode() + b" 0 R >>")
    out = bytearray(b"%PDF-1.4\n%\xe2\xe3\xcf\xd3\n")
    offsets = []
    for i, obj in enumerate(objects, start=1):
        offsets.append(len(out))
        out += str(i).encode() + b" 0 obj\n" + obj + b"\nendobj\n"
    xref = len(out)
    out += b"xref\n0 " + str(len(objects) + 1).encode() + b"\n0000000000 65535 f \n"
    for off in offsets:
        out += f"{off:010d} 00000 n \n".encode()
    out += b"trailer\n<< /Size " + str(len(objects) + 1).encode() + b" /Root " + str(catalog).encode() + b" 0 R >>\nstartxref\n"
    out += str(xref).encode() + b"\n%%EOF\n"
    return bytes(out)
