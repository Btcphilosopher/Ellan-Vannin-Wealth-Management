"""Configuration de l'application.

Les secrets sont lus depuis l'environnement ou depuis un fichier (convention
Docker secrets : VARIABLE_FILE=/run/secrets/...). Aucune valeur sensible n'est
codée en dur pour la production : le démarrage échoue si la clé par défaut est
utilisée avec ENVIRONMENT=production.
"""
from __future__ import annotations

import os
from functools import lru_cache
from pathlib import Path

from pydantic import model_validator
from pydantic_settings import BaseSettings, SettingsConfigDict

_DEV_SECRET = "dev-only-insecure-secret-change-me"


def _read_file_secrets() -> None:
    """Charge les variables INTENDANCE_*_FILE -> INTENDANCE_* (secrets Docker). Limité à notre préfixe."""
    for key, value in list(os.environ.items()):
        if key.startswith("INTENDANCE_") and key.endswith("_FILE") and key[:-5] not in os.environ:
            path = Path(value)
            if path.is_file():
                os.environ[key[:-5]] = path.read_text(encoding="utf-8").strip()


_read_file_secrets()


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_prefix="INTENDANCE_", env_file=".env", extra="ignore")

    environment: str = "development"  # development | test | production
    database_url: str = "postgresql+psycopg://intendance:intendance@localhost:5432/intendance"
    database_sslmode: str | None = None  # "require" / "verify-full" en production
    secret_key: str = _DEV_SECRET

    # Sessions
    session_cookie_name: str = "intendance_session"
    csrf_cookie_name: str = "intendance_csrf"
    session_ttl_minutes: int = 480
    session_idle_minutes: int = 60
    cookie_secure: bool = False  # True derrière TLS (compose de production)
    login_max_failures: int = 5
    login_lock_minutes: int = 15

    # MFA : "totp" (opérationnel) ou "none"
    mfa_adapter: str = "totp"
    mfa_required_roles: str = "ADMIN"

    # Horloge de démonstration : date ISO fixe, ou vide pour l'heure réelle.
    demo_clock: str | None = "2026-11-27T09:00:00+01:00"

    # Stockage objet : "local" (système de fichiers protégé) ou "s3" (MinIO / S3)
    storage_backend: str = "local"
    storage_local_path: str = "./var/objects"
    s3_endpoint_url: str | None = None
    s3_bucket: str = "intendance-documents"
    s3_access_key: str | None = None
    s3_secret_key: str | None = None
    max_upload_bytes: int = 10 * 1024 * 1024

    idempotency_ttl_hours: int = 48
    cors_origins: str = "http://localhost:3000"
    log_level: str = "INFO"

    @model_validator(mode="after")
    def _check_production(self) -> "Settings":
        if self.environment == "production":
            if self.secret_key == _DEV_SECRET or len(self.secret_key) < 32:
                raise ValueError("INTENDANCE_SECRET_KEY doit être défini (≥ 32 caractères) en production")
            if not self.cookie_secure:
                raise ValueError("INTENDANCE_COOKIE_SECURE doit valoir true en production")
        return self

    @property
    def sqlalchemy_connect_args(self) -> dict:
        return {"sslmode": self.database_sslmode} if self.database_sslmode else {}


@lru_cache
def get_settings() -> Settings:
    return Settings()
