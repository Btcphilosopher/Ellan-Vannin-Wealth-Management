"""Traitements en arrière-plan (file en base, verrouillage SKIP LOCKED, reprises bornées)."""
from __future__ import annotations

import logging
import traceback
import uuid
from datetime import datetime, timedelta, timezone

from sqlalchemy import delete, select

from app.core.clock import business_now
from app.core.context import Ctx
from app.core.models import IdempotencyRecord, Job
from app.db import SessionLocal

log = logging.getLogger("intendance.jobs")


def enqueue(db, kind: str, payload: dict, created_by: uuid.UUID | None = None, run_after: datetime | None = None) -> Job:
    job = Job(id=uuid.uuid4(), kind=kind, payload=payload, created_by=created_by, run_after=run_after or datetime.now(timezone.utc))
    db.add(job)
    return job


def _run_report_export(db, job: Job) -> dict:
    from app.modules.documents.api import store_document
    from app.modules.org.models import User
    from app.modules.reports.service import REPORTS, render

    user = db.get(User, job.created_by)
    ctx = Ctx(db=db, user=user, now=business_now(db), request_id=f"job-{job.id.hex[:12]}")
    data, ctype, filename = render(ctx, job.payload["kind"], job.payload["format"], job.payload.get("params") or {})
    doc = store_document(ctx, owner_type="REPORT", owner_id=job.id, kind="REPORT_EXPORT",
                         title=f"{REPORTS[job.payload['kind']]['title']} ({job.payload['format'].upper()})", filename=filename, data=data,
                         declared_type=ctype)
    return {"document_id": str(doc.id), "filename": filename, "size": len(data)}


def _run_purge(db, job: Job) -> dict:
    from app.modules.auth.models import UserSession

    now = datetime.now(timezone.utc)
    s = db.execute(delete(UserSession).where(UserSession.expires_at < now - timedelta(days=7))).rowcount
    i = db.execute(delete(IdempotencyRecord).where(IdempotencyRecord.created_at < now - timedelta(hours=48))).rowcount
    return {"sessions_purged": s, "idempotency_purged": i}


HANDLERS = {"report_export": _run_report_export, "purge": _run_purge}


def run_one() -> bool:
    """Traite au plus un traitement dû. Retourne False s'il n'y avait rien à faire."""
    with SessionLocal() as db:
        job = db.execute(
            select(Job).where(Job.status == "PENDING", Job.run_after <= datetime.now(timezone.utc))
            .order_by(Job.created_at).with_for_update(skip_locked=True).limit(1)
        ).scalar_one_or_none()
        if job is None:
            return False
        job.status, job.attempts = "RUNNING", job.attempts + 1
        db.commit()
        job_id = job.id
    with SessionLocal() as db:
        job = db.get(Job, job_id)
        try:
            result = HANDLERS[job.kind](db, job)
            job.status, job.result, job.finished_at = "DONE", result, datetime.now(timezone.utc)
            db.commit()
        except Exception as exc:  # noqa: BLE001
            db.rollback()
            job = db.get(Job, job_id)
            log.error("Traitement %s en échec : %s", job_id, exc)
            job.error = "".join(traceback.format_exception_only(type(exc), exc))[-2000:]
            if job.attempts >= job.max_attempts:
                job.status, job.finished_at = "FAILED", datetime.now(timezone.utc)
            else:
                job.status, job.run_after = "PENDING", datetime.now(timezone.utc) + timedelta(seconds=30 * job.attempts)
            db.commit()
    return True


def run_pending(limit: int = 50) -> int:
    n = 0
    while n < limit and run_one():
        n += 1
    return n
