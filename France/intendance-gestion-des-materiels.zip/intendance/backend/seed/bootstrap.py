"""Référentiel fictif : organisations, dépôts, emplacements, utilisateurs, familles, catalogue.

Toutes les organisations, personnes, matériels et références sont FICTIFS.
"""
from __future__ import annotations

import uuid
from decimal import Decimal

from sqlalchemy.orm import Session

from app.core.security import hash_password
from app.modules.catalog.models import Item, ItemFamily, ItemPackaging, ItemVariant
from app.modules.inventory.models import Depot, Location
from app.modules.org.models import Membership, Organization, User

DEMO_PASSWORD = "Intendance-Demo-2026!"
ADMIN_TOTP_SECRET = "JBSWY3DPEHPK3PXPJBSWY3DPEHPK3PXP"  # secret de DÉMONSTRATION uniquement

ORGS = [
    ("GSFA", "Groupement de Soutien Fictif Alpha", "SUPPORT", "LOCAL"),
    ("UIB", "Unité d'Instruction Bravo (fictive)", "BENEFICIARY", "LOCAL"),
    ("CFC", "Centre de Formation Charlie (fictif)", "BENEFICIARY", "LOCAL"),
    ("TXD", "Textiles du Delta SARL (fictif)", "SUPPLIER", "LOCAL"),
    ("EQO", "Équipements Orion SAS (fictif)", "SUPPLIER", "LOCAL"),
    ("AEM", "Atelier Électromécanique du Mistral (fictif)", "PROVIDER", "LOCAL"),
    ("OPE", "Organisation Partenaire Écho (fictive)", "BENEFICIARY", "OIDC"),
]

DEPOTS = [
    ("DN", "Dépôt Nord — Site des Tilleuls (fictif)", "12 allée des Tilleuls, 00100 Villefictive-Nord"),
    ("DS", "Dépôt Sud — Site des Garrigues (fictif)", "4 chemin des Garrigues, 00200 Villefictive-Sud"),
]

LOCATIONS = [
    ("QUAI", "Quai de réception", "RECEIVING"),
    ("A-01", "Allée A — travée 01", "STORAGE"),
    ("A-02", "Allée A — travée 02", "STORAGE"),
    ("B-01", "Allée B — travée 01 (matériels lourds)", "STORAGE"),
    ("QUAR", "Zone de quarantaine", "QUARANTINE"),
    ("ATEL", "Atelier de maintenance", "MAINTENANCE"),
    ("EXP", "Zone d'expédition", "SHIPPING"),
]

FAMILIES = [
    ("HAB", "Vêtements et équipements individuels"),
    ("OUT", "Outillage"),
    ("MOB", "Mobilier"),
    ("GEN", "Groupes électrogènes"),
    ("FOR", "Matériel de formation"),
    ("COM", "Équipements de communication d'exercice"),
    ("FOU", "Fournitures conditionnées"),
    ("PDR", "Pièces détachées"),
]

# code, désignation, famille, unité, suivi, contrôle, exigences, intervalle, prêtable, consommable, seuil, valeur, variantes, conditionnements
ITEMS = [
    ("HAB-VPL-01", "Veste de pluie d'exercice", "HAB", "PCE", "QUANTITY", "VISUAL",
     ["Contrôle visuel des coutures et fermetures", "Conformité de la taille à l'étiquette"], None, False, False, 20, 45,
     [("M", "Taille M"), ("L", "Taille L"), ("XL", "Taille XL")], [("CARTON", "Carton de 20 vestes", 20)]),
    ("HAB-GNT-02", "Gants de manutention", "HAB", "PAIRE", "QUANTITY", "VISUAL", ["Contrôle visuel"], None, False, True, 50, 6,
     [], [("CARTON", "Carton de 50 paires", 50)]),
    ("OUT-CAO-10", "Caisse à outils mécanique complète", "OUT", "PCE", "SERIAL", "FUNCTIONAL",
     ["Inventaire du contenu selon nomenclature", "Contrôle de l'état des clés"], 365, True, False, None, 380, [], []),
    ("OUT-PER-11", "Perceuse-visseuse sans fil 18 V", "OUT", "PCE", "SERIAL", "FUNCTIONAL",
     ["Essai de fonctionnement", "État de la batterie"], 365, True, False, None, 210, [], []),
    ("MOB-TAB-20", "Table pliante de formation", "MOB", "PCE", "QUANTITY", "VISUAL", ["Stabilité et mécanisme de pliage"], None, True, False, 10, 75, [], []),
    ("GEN-5KVA-30", "Groupe électrogène 5 kVA d'exercice", "GEN", "PCE", "SERIAL", "TECHNICAL",
     ["Essai en charge 30 min", "Contrôle isolement et terre", "Niveaux huile / carburant", "Absence de fuite"], 180, True, False, None, 3200, [], []),
    ("FOR-KIT-40", "Kit pédagogique de signalisation", "FOR", "JEU", "QUANTITY", "VISUAL", ["Complétude du kit"], None, True, False, 4, 120, [], []),
    ("COM-RAD-50", "Radio portative d'exercice (simulation)", "COM", "PCE", "SERIAL", "FUNCTIONAL",
     ["Essai émission/réception sur banc", "Autonomie batterie"], 365, True, False, None, 450, [], []),
    ("FOU-HUI-60", "Huile moteur 4 temps", "FOU", "L", "LOT", "VISUAL", ["Date de péremption", "Intégrité des bidons"], None, False, True, 10, 9,
     [], [("BIDON", "Bidon de 5 L", 5)]),
    ("FOU-RUB-61", "Rouleau de ruban de balisage", "FOU", "PCE", "QUANTITY", "VISUAL", [], None, False, True, 24, 4,
     [], [("CARTON", "Carton de 24 rouleaux", 24)]),
    ("PDR-FIL-70", "Filtre à air pour groupe 5 kVA", "PDR", "PCE", "QUANTITY", "VISUAL", ["Référence compatible"], None, False, True, 10, 18, [], []),
    ("PDR-BOU-71", "Bougie d'allumage pour groupe 5 kVA", "PDR", "PCE", "QUANTITY", "VISUAL", ["Référence compatible"], None, False, True, 10, 7, [], []),
]

# identifiant, nom, organisation, rôles [(rôle, dépôt ou None)]
USERS = [
    ("admin", "Alix Admin (démo)", "GSFA", [("ADMIN", None)], True),
    ("c.marchand", "Camille Marchand", "GSFA", [("STOREKEEPER", "DN")], False),
    ("l.perrin", "Léa Perrin", "GSFA", [("STOREKEEPER", "DS")], False),
    ("r.garnier", "Romain Garnier", "GSFA", [("DEPOT_MANAGER", "DN")], False),
    ("s.benali", "Sami Benali", "GSFA", [("DEPOT_MANAGER", "DS")], False),
    ("a.lefevre", "Anne Lefèvre", "GSFA", [("APPROVER", None)], False),
    ("m.roux", "Maxime Roux", "GSFA", [("MAINTENANCE", None)], False),
    ("j.morel", "Jeanne Morel", "GSFA", [("AUDITOR", None)], False),
    ("v.consult", "Victor Consult", "GSFA", [("VIEWER", "DN")], False),
    ("e.partenaire", "Elsa Partenaire", "OPE", [], False),
]


def bootstrap(db: Session) -> dict:
    ids: dict = {"orgs": {}, "depots": {}, "locations": {}, "items": {}, "variants": {}, "users": {}}
    for code, name, kind, auth in ORGS:
        o = Organization(id=uuid.uuid4(), code=code, name=name, kind=kind, auth_mode=auth)
        db.add(o)
        ids["orgs"][code] = o.id
    db.flush()
    for code, name, address in DEPOTS:
        d = Depot(id=uuid.uuid4(), code=code, name=name, address=address, organization_id=ids["orgs"]["GSFA"])
        db.add(d)
        ids["depots"][code] = d.id
        for lcode, label, kind in LOCATIONS:
            loc = Location(id=uuid.uuid4(), depot_id=d.id, code=lcode, label=label, kind=kind, internal_tag=f"LOC-{code}-{lcode.replace('-', '')}")
            db.add(loc)
            ids["locations"][f"{code}:{lcode}"] = loc.id
    for n, (code, label) in enumerate(FAMILIES):
        db.add(ItemFamily(code=code, label=label, sort_order=n))
    db.flush()
    for (code, des, fam, unit, tracking, level, reqs, interval, loanable, consumable, minimum, value, variants, packs) in ITEMS:
        item = Item(id=uuid.uuid4(), code=code, designation=des, family_code=fam, base_unit=unit, tracking=tracking, inspection_level=level,
                    inspection_requirements=reqs, maintenance_interval_days=interval, loanable=loanable, consumable=consumable,
                    min_stock=Decimal(minimum) if minimum is not None else None, unit_value=Decimal(value),
                    description=f"Article fictif de démonstration — {des.lower()}.")
        db.add(item)
        ids["items"][code] = item.id
        for vcode, vlabel in variants:
            v = ItemVariant(id=uuid.uuid4(), item_id=item.id, code=vcode, label=vlabel, attributes={"taille": vcode})
            db.add(v)
            ids["variants"][f"{code}:{vcode}"] = v.id
        for ucode, plabel, factor in packs:
            db.add(ItemPackaging(id=uuid.uuid4(), item_id=item.id, unit_code=ucode, label=plabel, factor=Decimal(factor)))
    db.flush()
    pw = hash_password(DEMO_PASSWORD)
    for username, name, org, roles, mfa in USERS:
        u = User(id=uuid.uuid4(), username=username, full_name=name, organization_id=ids["orgs"][org], password_hash=pw,
                 mfa_enabled=mfa, mfa_secret=ADMIN_TOTP_SECRET if mfa else None, email=f"{username}@exemple.invalid")
        db.add(u)
        ids["users"][username] = u.id
        db.flush()
        for role, depot in roles:
            db.add(Membership(id=uuid.uuid4(), user_id=u.id, organization_id=ids["orgs"][org],
                              depot_id=ids["depots"][depot] if depot else None, role_code=role))
    db.commit()
    return ids
