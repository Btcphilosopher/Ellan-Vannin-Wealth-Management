"""Données de démonstration : rejoue le scénario complet À TRAVERS L'API (permissions, idempotence, audit réels).

    python -m seed.demo --reset      # recrée le schéma puis charge le scénario
    python -m seed.demo              # charge le scénario sur une base vide (migrée)

Tout est fictif. Le scénario couvre les 14 étapes du cahier des charges et les cas limites :
réservations simultanées, requêtes dupliquées, contrôles manquants, accès non autorisés.
"""
from __future__ import annotations

import argparse
import json
import threading
import uuid
from pathlib import Path

from fastapi.testclient import TestClient

from app.core.security import TOTPAdapter
from app.db import SessionLocal
from seed.bootstrap import ADMIN_TOTP_SECRET, DEMO_PASSWORD, bootstrap

LOG: list[dict] = []


def note(step: str, text: str, **data) -> None:
    LOG.append({"step": step, "text": text, **data})
    print(f"[{step}] {text}" + (f" {json.dumps(data, ensure_ascii=False, default=str)}" if data else ""))


class Api:
    """Client d'API authentifié par jeton (un client par utilisateur fictif)."""

    def __init__(self, app, username: str):
        self.username = username
        self.c = TestClient(app)
        r = self.c.post("/v1/auth/login", json={"username": username, "password": DEMO_PASSWORD})
        assert r.status_code == 200, r.text
        self.h = {"Authorization": f"Bearer {r.json()['token']}"}
        if r.json()["mfa_required"]:
            code = TOTPAdapter.code_at(ADMIN_TOTP_SECRET)
            r2 = self.c.post("/v1/auth/mfa", json={"code": code}, headers=self.h)
            assert r2.status_code == 200, r2.text

    def get(self, path, **params):
        r = self.c.get(path, params=params, headers=self.h)
        assert r.status_code == 200, f"GET {path} → {r.status_code} {r.text}"
        return r.json()

    def post(self, path, body, idem: str | None = None):
        headers = dict(self.h)
        headers["Idempotency-Key"] = idem or uuid.uuid4().hex
        r = self.c.post(path, json=body, headers=headers)
        assert r.status_code in (200, 201, 202), f"POST {path} ({self.username}) → {r.status_code} {r.text}"
        return r.json()

    def attempt(self, path, body, idem: str | None = None):
        headers = dict(self.h)
        if idem:
            headers["Idempotency-Key"] = idem
        r = self.c.post(path, json=body, headers=headers)
        return r.status_code, r.json(), r.headers


def run(app) -> dict:
    with SessionLocal() as db:
        ids = bootstrap(db)
    admin = Api(app, "admin")
    cm, lp = Api(app, "c.marchand"), Api(app, "l.perrin")
    rg, sb = Api(app, "r.garnier"), Api(app, "s.benali")
    al, mr = Api(app, "a.lefevre"), Api(app, "m.roux")
    vc = Api(app, "v.consult")
    DN, DS = str(ids["depots"]["DN"]), str(ids["depots"]["DS"])
    loc = {k: str(v) for k, v in ids["locations"].items()}
    item = {k: str(v) for k, v in ids["items"].items()}
    var = {k: str(v) for k, v in ids["variants"].items()}
    org = {k: str(v) for k, v in ids["orgs"].items()}

    def clock(at: str, why: str):
        admin.post("/v1/admin/clock", {"at": at, "reason": why})

    def receive_all(receiver, inspector, closer, depot, supplier, docref, lines, put_loc, *, inspect_lines=None):
        r = receiver.post("/v1/receipts", {"depot_id": depot, "supplier_id": supplier, "supplier_document_ref": docref, "lines": [
            {k: v for k, v in ln.items() if k in ("item_id", "variant_id", "unit", "expected_quantity", "lot_number")} for ln in lines], "submit": True})
        phys = []
        for rl, ln in zip(r["lines"], lines):
            phys.append({"line_id": rl["id"], "received_quantity": ln.get("received", ln["expected_quantity"]), "serial_numbers": ln.get("serials", []),
                         "lot_number": ln.get("lot_number"), "observed_condition": ln.get("condition", "Conforme"),
                         "discrepancy_note": ln.get("discrepancy", "")})
        r = receiver.post(f"/v1/receipts/{r['id']}/physical-receipt", {"version": r["version"], "lines": phys})
        il = inspect_lines(r) if inspect_lines else [{"line_id": x["id"], "accepted_qty": x["received_qty"], "rejected_qty": 0} for x in r["lines"]]
        r = inspector.post(f"/v1/receipts/{r['id']}/inspection", {"version": r["version"], "lines": il, "findings": "Contrôle de réception",
                                                                  "checklist": [{"point": "Quantités", "ok": True}, {"point": "État visuel", "ok": True}]})
        pa = [{"line_id": x["id"], "location_id": put_loc[x["item_code"]] if isinstance(put_loc, dict) else put_loc, "quantity": x["accepted_qty"]}
              for x in r["lines"] if x["accepted_qty"] > 0]
        r = receiver.post(f"/v1/receipts/{r['id']}/putaway", {"version": r["version"], "lines": pa})
        if closer:
            r = closer.post(f"/v1/receipts/{r['id']}/close", {"version": r["version"]})
        return r

    # ------------------------------------------------------------------ stock d'ouverture (septembre)
    clock("2026-09-02T09:00:00+02:00", "Chargement du stock d'ouverture fictif")
    gens = [f"GEN-DÉMO-0{n}" for n in range(21, 27)]
    receive_all(cm, rg, rg, DN, org["EQO"], "BL-EQO-2026-0871", [
        {"item_id": item["GEN-5KVA-30"], "expected_quantity": 6, "serials": gens},
        {"item_id": item["COM-RAD-50"], "expected_quantity": 6, "serials": [f"RAD-DÉMO-1{n:02d}" for n in range(1, 7)]},
        {"item_id": item["OUT-CAO-10"], "expected_quantity": 4, "serials": [f"CAO-DÉMO-0{n}" for n in range(1, 5)]},
        {"item_id": item["PDR-FIL-70"], "expected_quantity": 40},
        {"item_id": item["PDR-BOU-71"], "expected_quantity": 60},
        {"item_id": item["FOU-HUI-60"], "unit": "BIDON", "expected_quantity": 4, "lot_number": "H-2609-A"},
        {"item_id": item["MOB-TAB-20"], "expected_quantity": 30},
        {"item_id": item["FOR-KIT-40"], "expected_quantity": 12},
    ], {"GEN-5KVA-30": loc["DN:B-01"], "COM-RAD-50": loc["DN:A-02"], "OUT-CAO-10": loc["DN:B-01"], "PDR-FIL-70": loc["DN:A-02"],
        "PDR-BOU-71": loc["DN:A-02"], "FOU-HUI-60": loc["DN:B-01"], "MOB-TAB-20": loc["DN:A-01"], "FOR-KIT-40": loc["DN:A-02"]})
    receive_all(lp, sb, sb, DS, org["EQO"], "BL-EQO-2026-0874", [
        {"item_id": item["GEN-5KVA-30"], "expected_quantity": 2, "serials": ["GEN-DÉMO-031", "GEN-DÉMO-032"]},
        {"item_id": item["COM-RAD-50"], "expected_quantity": 4, "serials": [f"RAD-DÉMO-2{n:02d}" for n in range(1, 5)]},
        {"item_id": item["HAB-GNT-02"], "unit": "CARTON", "expected_quantity": 4},
        {"item_id": item["MOB-TAB-20"], "expected_quantity": 10},
        {"item_id": item["FOU-RUB-61"], "unit": "CARTON", "expected_quantity": 2},
    ], loc["DS:A-01"])
    note("0", "Stock d'ouverture réceptionné, contrôlé et mis en stock dans les deux dépôts fictifs.")

    gen024 = cm.get("/v1/assets", q="GEN-DÉMO-024")["items"][0]
    # ------------------------------------------------------------------ prêt du générateur (octobre)
    clock("2026-10-20T10:00:00+02:00", "Prêt d'un groupe électrogène pour un exercice")
    loan = cm.post("/v1/requests", {"depot_id": DN, "beneficiary_org_id": org["CFC"], "responsible_name": "Cne fictif Durand",
                                    "administrative_destination": "Exercice de formation « Brume » (fictif)", "justification": "Alimentation du poste de formation",
                                    "lines": [{"item_id": item["GEN-5KVA-30"], "quantity": 1, "kind": "LOAN", "due_date": "2026-11-15"}]})
    loan = rg.post(f"/v1/requests/{loan['id']}/review", {"version": loan["version"], "comment": "Besoin cohérent avec le calendrier d'exercice"})
    loan = al.post(f"/v1/requests/{loan['id']}/approval", {"version": loan["version"], "decision": "APPROVE", "comment": "Prêt approuvé"})
    clock("2026-10-21T08:30:00+02:00", "Préparation du prêt")
    loan = cm.post(f"/v1/requests/{loan['id']}/reservation", {"version": loan["version"], "allow_partial": False,
                                                              "asset_selection": {loan["lines"][0]["id"]: [gen024["id"]]}})
    loan = cm.post(f"/v1/requests/{loan['id']}/preparation", {"version": loan["version"]})
    alloc_loan = cm.post("/v1/allocations", {"request_id": loan["id"], "version": loan["version"], "recipient_name": "Adj. fictif Morin",
                                             "proof_reference": "JR-2026-0388", "lines": [{"request_line_id": loan["lines"][0]["id"], "quantity": 1}]})
    note("pré-9", "GEN-DÉMO-024 prêté au Centre de Formation Charlie (échéance 15/11).", allocation=alloc_loan["reference"])

    # ------------------------------------------------------------------ 1. réception de 120 vêtements
    clock("2026-11-03T08:45:00+01:00", "Réception de vêtements")
    rec = cm.post("/v1/receipts", {"depot_id": DN, "supplier_id": org["TXD"], "supplier_document_ref": "BL-TXD-2026-1142", "submit": True, "lines": [
        {"item_id": item["HAB-VPL-01"], "variant_id": var["HAB-VPL-01:M"], "unit": "CARTON", "expected_quantity": 3},
        {"item_id": item["HAB-VPL-01"], "variant_id": var["HAB-VPL-01:L"], "unit": "CARTON", "expected_quantity": 2},
        {"item_id": item["HAB-VPL-01"], "variant_id": var["HAB-VPL-01:XL"], "expected_quantity": 20},
    ]})
    status, body, _ = cm.attempt(f"/v1/receipts/{rec['id']}/physical-receipt", {"version": rec["version"], "lines": [
        {"line_id": rec["lines"][0]["id"], "received_quantity": 2.5}]})
    note("1", "Garde-fou : saisie de 2,5 cartons refusée (un conditionnement se saisit en entier).", status=status, code=body.get("code"))
    rec = cm.post(f"/v1/receipts/{rec['id']}/physical-receipt", {"version": rec["version"], "lines": [
        {"line_id": rec["lines"][0]["id"], "received_quantity": 3, "observed_condition": "Cartons intacts"},
        {"line_id": rec["lines"][1]["id"], "received_quantity": 2, "observed_condition": "Un carton légèrement humide"},
        {"line_id": rec["lines"][2]["id"], "received_quantity": 20, "observed_condition": "Conforme"},
    ]})
    note("1", f"Réception {rec['reference']} : {rec['totals']['received_qty']:g} vestes reçues physiquement, toutes « non contrôlées » (bloquées).")

    # Contrôle manquant : tentative de réservation de vestes non contrôlées
    early = cm.post("/v1/requests", {"depot_id": DN, "beneficiary_org_id": org["UIB"], "responsible_name": "Lt fictif Bernard",
                                     "administrative_destination": "Section d'instruction 2 (fictive)", "justification": "Besoin urgent",
                                     "lines": [{"item_id": item["HAB-VPL-01"], "variant_id": var["HAB-VPL-01:M"], "quantity": 10}]})
    early = rg.post(f"/v1/requests/{early['id']}/review", {"version": early["version"], "comment": "Urgent"})
    early = al.post(f"/v1/requests/{early['id']}/approval", {"version": early["version"], "decision": "APPROVE", "comment": "Approuvé"})
    status, body, _ = cm.attempt(f"/v1/requests/{early['id']}/reservation", {"version": early["version"], "allow_partial": True})
    note("cas limite", "Réservation de vestes non contrôlées refusée : le stock en attente de contrôle n'est pas disponible.", status=status, code=body.get("code"))
    rg.post(f"/v1/requests/{early['id']}/close", {"version": early["version"], "reason": "Demande reportée : matériel non encore contrôlé"})

    # Séparation des tâches : le réceptionnaire ne peut pas contrôler sa propre réception
    status, body, _ = cm.attempt(f"/v1/receipts/{rec['id']}/inspection", {"version": rec["version"], "lines": [
        {"line_id": rec["lines"][0]["id"], "accepted_qty": 60}]})
    note("cas limite", "Contrôle par l'agent ayant reçu la livraison refusé (séparation des tâches).", status=status, code=body.get("code"))

    # ------------------------------------------------------------------ 2. contrôle avec acceptation partielle
    clock("2026-11-04T10:15:00+01:00", "Contrôle de réception")
    rec = rg.post(f"/v1/receipts/{rec['id']}/inspection", {"version": rec["version"], "findings": "8 vestes non conformes (coutures, fermetures)",
        "checklist": [{"point": "Coutures", "ok": False, "remarque": "6 défauts"}, {"point": "Fermetures", "ok": False, "remarque": "2 défauts"},
                      {"point": "Étiquetage taille", "ok": True}], "lines": [
        {"line_id": rec["lines"][0]["id"], "accepted_qty": 56, "rejected_qty": 4, "findings": "4 coutures défaillantes"},
        {"line_id": rec["lines"][1]["id"], "accepted_qty": 38, "rejected_qty": 2, "findings": "2 fermetures cassées"},
        {"line_id": rec["lines"][2]["id"], "accepted_qty": 18, "rejected_qty": 2, "findings": "2 coutures défaillantes"},
    ]})
    note("2", f"Contrôle : {rec['totals']['accepted_qty']:g} acceptées, {rec['totals']['rejected_qty']:g} rejetées (quarantaine) — statut {rec['status']}.")

    # ------------------------------------------------------------------ 3. mise en stock
    rec = cm.post(f"/v1/receipts/{rec['id']}/putaway", {"version": rec["version"], "lines": [
        {"line_id": rec["lines"][0]["id"], "location_id": loc["DN:A-01"], "quantity": 56},
        {"line_id": rec["lines"][1]["id"], "location_id": loc["DN:A-02"], "quantity": 38},
        {"line_id": rec["lines"][2]["id"], "location_id": loc["DN:A-02"], "quantity": 18},
    ]})
    # Correction liée : les L devaient aller en A-01 → contre-passation + écriture rectifiée (jamais de réécriture)
    mv = rg.get("/v1/movements", source_id=rec["id"], type="PUTAWAY")["items"]
    wrong = next(m for m in mv if m["variant_label"] == "Taille L")
    corr = rg.post(f"/v1/movements/{wrong['id']}/correction", {"reason": "Erreur d'emplacement : les vestes L sont rangées en A-01",
                                                                 "corrected_to_location_id": loc["DN:A-01"]})
    rec = rg.post(f"/v1/receipts/{rec['id']}/close", {"version": rec["version"]})
    note("3", f"Mise en stock de 112 vestes ; correction liée {', '.join(m['reference'] for m in corr['corrections'])} ; réception clôturée.")

    # ------------------------------------------------------------------ 4. demande de dotation
    clock("2026-11-05T09:00:00+01:00", "Demande de dotation")
    dem = cm.post("/v1/requests", {"depot_id": DN, "beneficiary_org_id": org["UIB"], "responsible_name": "Lt fictif Bernard",
                                   "administrative_destination": "Section d'instruction 2 (fictive)", "needed_by": "2026-11-12",
                                   "justification": "Dotation saisonnière des stagiaires (fictif)", "lines": [
        {"item_id": item["HAB-VPL-01"], "variant_id": var["HAB-VPL-01:M"], "quantity": 20},
        {"item_id": item["HAB-VPL-01"], "variant_id": var["HAB-VPL-01:L"], "quantity": 15},
        {"item_id": item["HAB-VPL-01"], "variant_id": var["HAB-VPL-01:XL"], "quantity": 5}]}, idem="demo-dem-saison")
    status, replay, headers = cm.attempt("/v1/requests", {"depot_id": DN, "beneficiary_org_id": org["UIB"], "responsible_name": "Lt fictif Bernard",
                                   "administrative_destination": "Section d'instruction 2 (fictive)", "needed_by": "2026-11-12",
                                   "justification": "Dotation saisonnière des stagiaires (fictif)", "lines": [
        {"item_id": item["HAB-VPL-01"], "variant_id": var["HAB-VPL-01:M"], "quantity": 20},
        {"item_id": item["HAB-VPL-01"], "variant_id": var["HAB-VPL-01:L"], "quantity": 15},
        {"item_id": item["HAB-VPL-01"], "variant_id": var["HAB-VPL-01:XL"], "quantity": 5}]}, idem="demo-dem-saison")
    note("cas limite", "Requête dupliquée (même clé d'idempotence) : réponse rejouée, aucune seconde demande créée.",
         status=status, replayed=headers.get("idempotent-replayed"), same_reference=replay["reference"] == dem["reference"])
    dem = rg.post(f"/v1/requests/{dem['id']}/review", {"version": dem["version"], "comment": "Quantités conformes au barème fictif"})
    note("4", f"Demande {dem['reference']} : 40 vestes, revue par le responsable de dépôt.")

    # ------------------------------------------------------------------ 5. approbation et réservation
    status, body, _ = vc.attempt(f"/v1/requests/{dem['id']}/approval", {"version": dem["version"], "decision": "APPROVE", "comment": "Tentative"})
    note("cas limite", "Approbation tentée par un profil Consultation : refusée.", status=status, code=body.get("code"))
    dem = al.post(f"/v1/requests/{dem['id']}/approval", {"version": dem["version"], "decision": "APPROVE", "comment": "Approuvé"})
    status, body, _ = cm.attempt(f"/v1/requests/{dem['id']}/reservation", {"version": dem["version"] - 1, "allow_partial": False})
    note("cas limite", "Action fondée sur une version obsolète refusée (contrôle de concurrence).", status=status, code=body.get("code"))
    dem = cm.post(f"/v1/requests/{dem['id']}/reservation", {"version": dem["version"], "allow_partial": False})
    note("5", f"Demande approuvée puis réservée : {sum(ln['reserved_open_qty'] for ln in dem['lines']):g} vestes réservées (non remises).")

    # ------------------------------------------------------------------ 6. remise partielle
    clock("2026-11-06T14:00:00+01:00", "Remise partielle")
    dem = cm.post(f"/v1/requests/{dem['id']}/preparation", {"version": dem["version"]})
    alloc = cm.post("/v1/allocations", {"request_id": dem["id"], "version": dem["version"], "recipient_name": "Sgt fictif Petit",
                                        "proof_reference": "JR-2026-0412", "notes": "Reliquat L/XL à remettre après retour de taille", "lines": [
        {"request_line_id": dem["lines"][0]["id"], "quantity": 15}, {"request_line_id": dem["lines"][1]["id"], "quantity": 10}]})
    dem = cm.get(f"/v1/requests/{dem['id']}")
    note("6", f"Remise partielle {alloc['reference']} : 25 vestes remises, reliquat toujours réservé — statut {dem['status']}.")

    # ------------------------------------------------------------------ réservations simultanées (cas limite)
    clock("2026-11-07T09:00:00+01:00", "Demandes concurrentes de groupes électrogènes")
    reqs = []
    for who in ("Section A (fictive)", "Section B (fictive)"):
        d = lp.post("/v1/requests", {"depot_id": DS, "beneficiary_org_id": org["UIB"], "responsible_name": "Adj. fictif Lambert",
                                     "administrative_destination": who, "lines": [
            {"item_id": item["GEN-5KVA-30"], "quantity": 2, "kind": "LOAN", "due_date": "2026-12-15"}]})
        d = sb.post(f"/v1/requests/{d['id']}/review", {"version": d["version"], "comment": "Besoin validé"})
        d = al.post(f"/v1/requests/{d['id']}/approval", {"version": d["version"], "decision": "APPROVE", "comment": "Besoin validé"})
        reqs.append(d)
    results = {}

    def reserve(d):
        api = Api(app, "l.perrin")
        results[d["reference"]] = api.attempt(f"/v1/requests/{d['id']}/reservation", {"version": d["version"], "allow_partial": False})[0]

    threads = [threading.Thread(target=reserve, args=(d,)) for d in reqs]
    for t in threads:
        t.start()
    for t in threads:
        t.join()
    note("cas limite", "Deux réservations simultanées des 2 seuls groupes du Dépôt Sud : une seule aboutit, aucune double allocation.", results=results)
    for d in reqs:
        cur = lp.get(f"/v1/requests/{d['id']}")
        if cur["status"] != "RESERVED":
            sb.post(f"/v1/requests/{d['id']}/close", {"version": cur["version"], "reason": "Matériel indisponible (réservé par une autre demande)"})

    # ------------------------------------------------------------------ 7. transfert entre dépôts
    clock("2026-11-09T09:30:00+01:00", "Transfert inter-dépôts")
    trf = rg.post("/v1/transfers", {"source_depot_id": DN, "destination_depot_id": DS, "reason": "Rééquilibrage des tailles avant la saison", "lines": [
        {"item_id": item["HAB-VPL-01"], "variant_id": var["HAB-VPL-01:M"], "quantity": 10},
        {"item_id": item["HAB-VPL-01"], "variant_id": var["HAB-VPL-01:L"], "quantity": 10},
        {"item_id": item["HAB-VPL-01"], "variant_id": var["HAB-VPL-01:XL"], "quantity": 10}]})
    trf = al.post(f"/v1/transfers/{trf['id']}/approval", {"version": trf["version"], "decision": "APPROVE", "comment": "Rééquilibrage validé"})
    trf = cm.post(f"/v1/transfers/{trf['id']}/reservation", {"version": trf["version"]})
    clock("2026-11-10T07:45:00+01:00", "Expédition")
    trf = cm.post(f"/v1/transfers/{trf['id']}/dispatch", {"version": trf["version"], "carrier": "Transports Fictifs Express", "waybill_ref": "LV-2026-5531"})
    stock_dn = cm.get("/v1/stock", depot_id=DN, q="HAB-VPL")["items"]
    stock_ds = lp.get("/v1/stock", depot_id=DS, q="HAB-VPL")["items"]
    note("7", f"Transfert {trf['reference']} expédié : 30 vestes en transit, absentes des deux dépôts.",
         transit_DS=sum(r["in_transit"] for r in stock_ds), physique_DS=sum(r["physical"] for r in stock_ds),
         physique_DN=sum(r["physical"] for r in stock_dn))

    # ------------------------------------------------------------------ 8. écart à la réception
    clock("2026-11-12T11:00:00+01:00", "Réception du transfert")
    status, body, _ = cm.attempt(f"/v1/transfers/{trf['id']}/receipt", {"version": trf["version"], "lines": [
        {"line_id": trf["lines"][0]["id"], "received_qty": 10}]})
    note("cas limite", "Réception du transfert par un agent du dépôt expéditeur refusée (dépôt destinataire seulement).", status=status, code=body.get("code"))
    trf = lp.post(f"/v1/transfers/{trf['id']}/receipt", {"version": trf["version"], "lines": [
        {"line_id": trf["lines"][0]["id"], "received_qty": 10},
        {"line_id": trf["lines"][1]["id"], "received_qty": 9, "damaged_qty": 1, "note": "1 veste déchirée (emballage percé)"},
        {"line_id": trf["lines"][2]["id"], "received_qty": 8, "note": "2 vestes XL manquantes au déballage"}]})
    note("8", "Réception au Dépôt Sud : 27 bonnes, 1 endommagée (quarantaine), écart de 2 à traiter.",
         discrepancy=sum(ln["discrepancy_qty"] for ln in trf["lines"]))
    status, body, _ = sb.attempt(f"/v1/transfers/{trf['id']}/reconciliation", {"version": trf["version"], "lines": [
        {"line_id": trf["lines"][2]["id"], "action": "WRITE_OFF", "quantity": 2, "justification": "Perte en transport constatée"}]})
    note("cas limite", "Passation en perte par le responsable de dépôt refusée : approbation requise.", status=status, code=body.get("code"))
    clock("2026-11-13T16:00:00+01:00", "Rapprochement du transfert")
    trf = al.post(f"/v1/transfers/{trf['id']}/reconciliation", {"version": trf["version"], "lines": [
        {"line_id": trf["lines"][2]["id"], "action": "WRITE_OFF", "quantity": 2,
         "justification": "Perte en transport constatée, déclaration au transporteur fictif n° LT-0098"}]})
    note("8", f"Transfert rapproché ({trf['status']}) : perte de 2 approuvée et justifiée.")

    # ------------------------------------------------------------------ 9. retour d'un équipement
    clock("2026-11-14T15:30:00+01:00", "Retour du groupe électrogène")
    ret = cm.post("/v1/returns", {"allocation_line_id": alloc_loan["lines"][0]["id"], "asset_id": gen024["id"], "quantity": 1, "condition": "DAMAGED",
                                  "observed_condition": "Démarrage difficile, légère fuite d'huile au carter", "returned_by_name": "Adj. fictif Morin",
                                  "report_defect": True, "defect_description": "Démarrage difficile et suintement d'huile au carter après exercice"})
    note("9", f"Retour {ret['reference']} de GEN-DÉMO-024 : en quarantaine, ordre {ret['maintenance_order']['reference']} signalé.")

    # ------------------------------------------------------------------ 10. maintenance du générateur
    oid = ret["maintenance_order"]["id"]
    clock("2026-11-16T09:00:00+01:00", "Évaluation maintenance")
    o = mr.get(f"/v1/maintenance-orders/{oid}")
    o = mr.post(f"/v1/maintenance-orders/{oid}/assessment", {"version": o["version"], "diagnosis": "Filtre à air colmaté, bougie encrassée, joint de carter à reprendre", "estimated_cost": 420})
    o = mr.post(f"/v1/maintenance-orders/{oid}/planning", {"version": o["version"], "planned_start": "2026-11-17", "provider_id": org["AEM"],
                                                            "technician_name": "Technicien fictif Garcia", "due_date": "2026-11-21"})
    clock("2026-11-17T08:30:00+01:00", "Intervention")
    o = mr.post(f"/v1/maintenance-orders/{oid}/start", {"version": o["version"]})
    mr.post(f"/v1/maintenance-orders/{oid}/labour", {"technician_name": "Technicien fictif Garcia", "provider_id": org["AEM"], "hours": 3.5, "cost": 245,
                                                     "description": "Remplacement filtre et bougie, reprise du joint de carter"})
    mr.post(f"/v1/maintenance-orders/{oid}/parts", {"item_id": item["PDR-FIL-70"], "location_id": loc["DN:A-02"], "quantity": 1})
    mr.post(f"/v1/maintenance-orders/{oid}/parts", {"item_id": item["PDR-BOU-71"], "location_id": loc["DN:A-02"], "quantity": 1})
    lot = mr.get("/v1/stock/positions", depot_id=DN, item_id=item["FOU-HUI-60"])[0]
    o = mr.post(f"/v1/maintenance-orders/{oid}/parts", {"item_id": item["FOU-HUI-60"], "lot_id": lot["lot_id"], "location_id": loc["DN:B-01"], "quantity": 1.5})
    clock("2026-11-19T11:00:00+01:00", "Fin d'intervention")
    o = mr.post(f"/v1/maintenance-orders/{oid}/completion", {"version": o["version"], "work_result": "Intervention terminée, essai à vide satisfaisant"})
    note("10", f"Maintenance {o['reference']} : {o['costs']['hours']:g} h, coût total {o['costs']['total']:g} € (fictif) — statut {o['status']}.")

    # ------------------------------------------------------------------ 11. contrôle avant remise à disposition
    status, body, _ = mr.attempt(f"/v1/maintenance-orders/{oid}/closure", {"version": o["version"]})
    note("cas limite", "Clôture de l'ordre sans contrôle refusée (contrôle manquant).", status=status, code=body.get("code"))
    a = rg.get(f"/v1/assets/{gen024['id']}")
    status, body, _ = rg.attempt(f"/v1/assets/{gen024['id']}/release-decision", {"version": a["version"], "decision": "RETURN_TO_SERVICE",
                                                                                 "reason": "Tentative sans contrôle", "to_location_id": loc["DN:B-01"]})
    note("cas limite", "Remise à disposition sans contrôle refusée.", status=status, code=body.get("code"))
    clock("2026-11-20T10:00:00+01:00", "Contrôle avant remise à disposition")
    insp = mr.post("/v1/inspections/asset", {"asset_id": gen024["id"], "kind": "PRE_RELEASE", "result": "PASS", "maintenance_order_id": oid,
                                             "findings": "Essai en charge 30 min conforme, absence de fuite, isolement conforme",
                                             "checklist": [{"point": "Essai en charge 30 min", "ok": True}, {"point": "Isolement et terre", "ok": True},
                                                           {"point": "Niveaux", "ok": True}, {"point": "Absence de fuite", "ok": True}]})
    o = mr.get(f"/v1/maintenance-orders/{oid}")
    o = mr.post(f"/v1/maintenance-orders/{oid}/closure", {"version": o["version"]})
    a = rg.get(f"/v1/assets/{gen024['id']}")
    note("11", f"Ordre clôturé : l'équipement reste « {a['technical_state']} » tant qu'aucune décision n'est prise.")
    status, body, _ = mr.attempt(f"/v1/assets/{gen024['id']}/release-decision", {"version": a["version"], "decision": "RETURN_TO_SERVICE",
                                                                                 "inspection_id": insp["id"], "reason": "Tentative", "to_location_id": loc["DN:B-01"]})
    note("cas limite", "Décision de remise à disposition par un profil maintenance refusée (rôle non habilité).", status=status, code=body.get("code"))
    dec_ = rg.post(f"/v1/assets/{gen024['id']}/release-decision", {"version": a["version"], "decision": "RETURN_TO_SERVICE", "inspection_id": insp["id"],
                                                                    "reason": "Contrôle CTL conforme, remise à disposition", "to_location_id": loc["DN:B-01"]})
    note("11", f"Décision {dec_['reference']} : GEN-DÉMO-024 remis à disposition par le responsable de dépôt (prochain contrôle {dec_['asset']['next_inspection_due']}).")

    # ------------------------------------------------------------------ 12. inventaire physique et ajustement approuvé
    clock("2026-11-24T08:00:00+01:00", "Inventaire tournant allée A-01")
    st = rg.post("/v1/stocktakes", {"depot_id": DN, "name": "Inventaire tournant — allée A-01", "location_ids": [loc["DN:A-01"]], "blind": True})
    st = rg.post(f"/v1/stocktakes/{st['id']}/start", {"version": st["version"]})
    blind_view = cm.get(f"/v1/stocktakes/{st['id']}")
    note("12", f"Inventaire {st['reference']} ouvert (à l'aveugle : quantités théoriques masquées au compteur = {not blind_view['expected_visible']}).")
    clock("2026-11-24T09:10:00+01:00", "Mouvement pendant le comptage")
    tables = cm.get("/v1/stock/positions", depot_id=DN, item_id=item["MOB-TAB-20"])[0]
    cm.post("/v1/stock/relocations", {"from_location_id": loc["DN:A-01"], "to_location_id": loc["DN:B-01"], "item_id": item["MOB-TAB-20"],
                                      "quantity": 5, "reason": "Préparation salle de formation"})
    clock("2026-11-24T10:00:00+01:00", "Comptage")
    lines = {ln["item_code"] + (ln["variant_label"] or ""): ln for ln in rg.get(f"/v1/stocktakes/{st['id']}")["lines"]}
    expected = {k: ln["snapshot_qty"] for k, ln in lines.items()}
    counts = []
    for key, ln in lines.items():
        q = expected[key]
        if key == "MOB-TAB-20":
            q = expected[key] - 5 - 8  # 5 déplacées pendant le comptage (prises en compte), 8 manquantes
        elif key == "HAB-VPL-01Taille M":
            q = expected[key] - 1
        counts.append({"line_id": ln["id"], "counted_qty": q})
    st = cm.post(f"/v1/stocktakes/{st['id']}/counts", {"lines": counts})
    clock("2026-11-24T11:30:00+01:00", "Recomptage")
    rec_lines = [ln for ln in st["lines"] if ln["status"] == "RECOUNT_REQUIRED"]
    st = cm.post(f"/v1/stocktakes/{st['id']}/counts", {"lines": [{"line_id": ln["id"], "counted_qty": ln["final_counted_qty"]} for ln in rec_lines]})
    st = rg.post(f"/v1/stocktakes/{st['id']}/review", {"version": rg.get(f"/v1/stocktakes/{st['id']}")["version"]})
    big = next(ln for ln in st["lines"] if ln["item_code"] == "MOB-TAB-20")
    small = next(ln for ln in st["lines"] if ln["item_code"] == "HAB-VPL-01" and ln["variant_label"] == "Taille M")
    status, body, _ = rg.attempt(f"/v1/stocktakes/{st['id']}/adjustments", {"version": st["version"], "decisions": [
        {"line_id": big["id"], "approve": True, "justification": "Tentative d'approbation d'un écart important"}]})
    note("cas limite", "Ajustement important (-8 tables) refusé au responsable de dépôt : approbateur requis.", status=status, code=body.get("code"))
    st = rg.post(f"/v1/stocktakes/{st['id']}/adjustments", {"version": st["version"], "decisions": [
        {"line_id": small["id"], "approve": True, "justification": "Écart confirmé par recomptage : 1 veste M non retrouvée"}]})
    st = al.post(f"/v1/stocktakes/{st['id']}/adjustments", {"version": st["version"], "decisions": [
        {"line_id": big["id"], "approve": True, "justification": "8 tables prêtées hors procédure lors d'une formation (fictif) ; enquête ouverte"}]})
    st = rg.post(f"/v1/stocktakes/{st['id']}/close", {"version": st["version"]})
    note("12", f"Inventaire clôturé : écarts M {small['variance_qty']:g} et tables {big['variance_qty']:g} ajustés après recomptage et approbation ; "
               "le déplacement de 5 tables pendant le comptage a été pris en compte.")

    # ------------------------------------------------------------------ 13. traçabilité, accès non autorisés, 14. export
    # ------------------------------------------------------------------ travaux en cours au jour de la démonstration
    clock("2026-11-10T10:00:00+01:00", "Prêt d'une radio d'exercice")
    rad = cm.get("/v1/assets", q="RAD-DÉMO-102")["items"][0]
    pr = cm.post("/v1/requests", {"depot_id": DN, "beneficiary_org_id": org["UIB"], "responsible_name": "Sgt fictif Petit",
                                  "administrative_destination": "Exercice de transmissions « Écho » (fictif)",
                                  "lines": [{"item_id": item["COM-RAD-50"], "quantity": 1, "kind": "LOAN", "due_date": "2026-11-20"}]})
    pr = rg.post(f"/v1/requests/{pr['id']}/review", {"version": pr["version"], "comment": "Exercice programmé"})
    pr = al.post(f"/v1/requests/{pr['id']}/approval", {"version": pr["version"], "decision": "APPROVE", "comment": "Prêt approuvé"})
    pr = cm.post(f"/v1/requests/{pr['id']}/reservation", {"version": pr["version"], "asset_selection": {pr["lines"][0]["id"]: [rad["id"]]}})
    pr = cm.post(f"/v1/requests/{pr['id']}/preparation", {"version": pr["version"]})
    cm.post("/v1/allocations", {"request_id": pr["id"], "version": pr["version"], "recipient_name": "Sgt fictif Petit", "proof_reference": "JR-2026-0431",
                                "lines": [{"request_line_id": pr["lines"][0]["id"], "quantity": 1}]})
    clock("2026-11-25T14:00:00+01:00", "Signalement d'un défaut")
    rad5 = cm.get("/v1/assets", q="RAD-DÉMO-105")["items"][0]
    cm.post("/v1/maintenance-orders", {"asset_id": rad5["id"], "defect_description": "Antenne cassée constatée lors d'un contrôle visuel",
                                       "priority": "NORMAL", "due_date": "2026-12-09"})
    clock("2026-11-26T08:15:00+01:00", "Transfert d'un groupe électrogène")
    tg = rg.post("/v1/transfers", {"source_depot_id": DN, "destination_depot_id": DS, "reason": "Renfort pour une formation au Dépôt Sud",
                                   "lines": [{"item_id": item["GEN-5KVA-30"], "quantity": 1}]})
    tg = al.post(f"/v1/transfers/{tg['id']}/approval", {"version": tg["version"], "decision": "APPROVE", "comment": "Renfort validé"})
    tg = cm.post(f"/v1/transfers/{tg['id']}/reservation", {"version": tg["version"]})
    cm.post(f"/v1/transfers/{tg['id']}/dispatch", {"version": tg["version"], "carrier": "Transports Fictifs Express", "waybill_ref": "LV-2026-5602"})
    clock("2026-11-26T10:30:00+01:00", "Réception en attente de contrôle")
    rr = lp.post("/v1/receipts", {"depot_id": DS, "supplier_id": org["TXD"], "supplier_document_ref": "BL-TXD-2026-1207", "submit": True, "lines": [
        {"item_id": item["HAB-GNT-02"], "unit": "CARTON", "expected_quantity": 2}]})
    lp.post(f"/v1/receipts/{rr['id']}/physical-receipt", {"version": rr["version"], "lines": [
        {"line_id": rr["lines"][0]["id"], "received_quantity": 2, "observed_condition": "Cartons intacts"}]})
    clock("2026-11-26T15:00:00+01:00", "Demande en attente d'approbation")
    dq = cm.post("/v1/requests", {"depot_id": DN, "beneficiary_org_id": org["CFC"], "responsible_name": "Cne fictif Durand",
                                  "administrative_destination": "Stage d'encadrement (fictif)", "justification": "Équipement d'une salle de cours",
                                  "lines": [{"item_id": item["MOB-TAB-20"], "quantity": 6, "kind": "LOAN", "due_date": "2026-12-18"},
                                            {"item_id": item["FOR-KIT-40"], "quantity": 2, "kind": "LOAN", "due_date": "2026-12-18"}]})
    rg.post(f"/v1/requests/{dq['id']}/review", {"version": dq["version"], "comment": "Disponibilité vérifiée"})
    note("état final", "Travaux en cours : prêt de radio échu, défaut signalé, groupe en transit, réception à contrôler, demande à approuver.")

    clock("2026-11-27T09:00:00+01:00", "Horloge de démonstration finale")
    hist = rg.get(f"/v1/assets/{gen024['id']}/history")
    note("13", f"Traçabilité GEN-DÉMO-024 : {len(hist['events'])} événements — {hist['explanation']}")
    r = vc.c.get("/v1/audit-events", headers=vc.h)
    note("cas limite", "Lecture du journal d'audit par un profil Consultation refusée.", status=r.status_code)
    r = vc.c.get(f"/v1/stock?depot_id={DS}", headers=vc.h)
    note("cas limite", "Consultation du Dépôt Sud par un profil limité au Dépôt Nord refusée.", status=r.status_code)
    job = rg.post("/v1/reports/exports", {"kind": "asset-trace", "format": "pdf", "params": {"asset_id": gen024["id"]}})
    job2 = rg.post("/v1/reports/exports", {"kind": "stock", "format": "csv", "params": {}})
    from app.jobs import run_pending

    run_pending()
    st1, st2 = rg.get(f"/v1/reports/exports/{job['job_id']}"), rg.get(f"/v1/reports/exports/{job2['job_id']}")
    note("14", "Exports produits en arrière-plan et conservés comme documents versionnés.", traceability=st1["status"], stock=st2["status"])

    # Documents fictifs attachés (PDF générés)
    from app.core.pdf import render_pdf

    def attach(api, owner_type, owner_id, kind, title, lines):
        data = render_pdf(title, lines)
        r = api.c.post("/v1/documents", headers=api.h, data={"owner_type": owner_type, "owner_id": owner_id, "kind": kind, "title": title},
                       files={"file": (f"{kind.lower()}.pdf", data, "application/pdf")})
        assert r.status_code == 201, r.text
        return r.json()

    attach(cm, "RECEIPT", rec["id"], "RECEIPT_NOTE", f"Bon de réception {rec['reference']}", ["Fournisseur : Textiles du Delta SARL (fictif)", "BL-TXD-2026-1142", "120 vestes reçues"])
    attach(rg, "RECEIPT", rec["id"], "INSPECTION_REPORT", f"PV de contrôle {rec['reference']}", ["112 acceptées", "8 rejetées : coutures et fermetures"])
    attach(cm, "ALLOCATION", alloc["id"], "HANDOVER_PROOF", f"Justificatif de remise {alloc['reference']}", ["JR-2026-0412", "25 vestes remises", "Signé : Sgt fictif Petit"])
    attach(mr, "MAINTENANCE_ORDER", oid, "MAINTENANCE_REPORT", f"Rapport de maintenance {o['reference']}", ["Filtre et bougie remplacés", "Joint de carter repris", "Essai en charge conforme"])
    attach(admin, "ITEM", item["GEN-5KVA-30"], "TECHNICAL_SHEET", "Fiche technique — groupe 5 kVA (fictive)", ["Puissance : 5 kVA", "Carburant : essence (fictif)"])
    return {"ids": ids, "log": LOG}


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--reset", action="store_true", help="Supprime et recrée le schéma avant chargement")
    parser.add_argument("--log", default="var/demo-log.json")
    args = parser.parse_args()
    if args.reset:
        from alembic import command
        from alembic.config import Config

        cfg = Config("alembic.ini")
        command.downgrade(cfg, "base")
        command.upgrade(cfg, "head")
    from app.main import app

    out = run(app)
    Path(args.log).parent.mkdir(parents=True, exist_ok=True)
    Path(args.log).write_text(json.dumps(out["log"], ensure_ascii=False, indent=2, default=str), encoding="utf-8")
    print(f"\nScénario chargé ({len(out['log'])} étapes journalisées) → {args.log}")


if __name__ == "__main__":
    main()
