Secrets Docker (jamais versionnés). Générer avec ./scripts/generate-secrets.sh
Fichiers : db_password.txt, minio_password.txt, app_secret_key.txt, pgpass
