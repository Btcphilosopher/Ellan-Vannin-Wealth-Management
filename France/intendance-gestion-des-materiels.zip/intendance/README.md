# INTENDANCE — Gestion des matériels

> **Chaque matériel. Chaque mouvement.**

Application de gestion des stocks, dépôts, réceptions, dotations, transferts, inventaires physiques et maintenance
de matériels de soutien (habillement, outillage, mobilier, groupes électrogènes, matériel de formation, équipements
de communication d'exercice, fournitures conditionnées, pièces détachées).

> **Concept logiciel indépendant.** Organisations, personnes, matériels et mouvements sont **entièrement fictifs**.
> Aucune affiliation officielle, aucune connexion à des systèmes militaires ou administratifs réels.
> **Prototype non apte au traitement d'informations classifiées.**

Parcours principal : **réception → contrôle → stockage → réservation → affectation ou transfert → retour → maintenance → réintégration ou réforme**.

---

## 1. Contenu de l'archive

```
intendance/
├── backend/                 API FastAPI (monolithe modulaire), Alembic, données fictives, tests pytest
│   ├── app/core/            configuration, contexte, permissions, sécurité, idempotence, horloge, journaux expurgés
│   ├── app/modules/         catalog · inventory · receipts · requests · transfers · stocktakes · maintenance
│   │                        documents · audit · auth · org · dashboard · reports · scan · admin
│   ├── app/jobs.py, worker.py   traitements en arrière-plan (file en base, SKIP LOCKED)
│   ├── alembic/versions/    0001 schéma · 0002 journal immuable (déclencheurs) + référentiels
│   ├── seed/                référentiel fictif + scénario de démonstration rejoué via l'API
│   └── tests/               44 tests (unitaires, contraintes, concurrence, parcours, sécurité, restauration)
├── frontend/                Next.js 16 (App Router) + React 19 + TypeScript — 22 écrans
├── deploy/Caddyfile         terminaison TLS
├── docker-compose.yml       PostgreSQL · MinIO · API · worker · web · Caddy
├── scripts/                 generate-secrets.sh · backup.sh · restore.sh
└── docs/                    API, architecture, règles métier, dépendances/licences, état des fonctionnalités,
                             résultats de tests, OpenAPI, journal du scénario, captures d'écran
```

## 2. Démarrage rapide (Docker Compose)

```bash
./scripts/generate-secrets.sh
```

```bash
cp .env.example .env
```

```bash
docker compose up -d --build
```

```bash
docker compose run --rm api python -m seed.demo
```

Puis ouvrir **https://localhost** (certificat local émis par Caddy `tls internal`).

> Le fichier Compose a été validé (`docker compose config`), mais la pile conteneurisée **n'a pas pu être démarrée**
> dans l'environnement de développement (pas de démon Docker). L'application a été exécutée et testée en local
> (PostgreSQL 16, Python 3.13, Node 22) comme décrit ci-dessous.

## 3. Démarrage en local (sans Docker)

Prérequis : PostgreSQL 16, Python 3.12+, Node 22.

```bash
createuser -P intendance && createdb -O intendance intendance && createdb -O intendance intendance_test
```

```bash
cd backend && python -m venv .venv && . .venv/bin/activate && pip install -r requirements-dev.txt
```

```bash
alembic upgrade head && python -m seed.demo
```

```bash
uvicorn app.main:app --port 8000
```

```bash
python -m app.worker
```

```bash
cd frontend && npm ci && npm run build && npm start
```

Interface : http://localhost:3000 (l'interface relaie `/v1/*` vers l'API : même origine, cookies `SameSite=Strict`).
Documentation interactive de l'API : http://localhost:8000/v1/docs.

Variables principales (préfixe `INTENDANCE_`, voir `backend/app/config.py`) : `DATABASE_URL`, `DATABASE_SSLMODE`,
`SECRET_KEY` (ou `SECRET_KEY_FILE`), `COOKIE_SECURE`, `DEMO_CLOCK`, `STORAGE_BACKEND` (`local`|`s3`), `MFA_ADAPTER`,
`MFA_REQUIRED_ROLES`. En `ENVIRONMENT=production`, le démarrage est refusé sans secret fort ni cookies `Secure`.

## 4. Comptes de démonstration (fictifs)

Mot de passe commun : **`Intendance-Demo-2026!`**

| Identifiant | Personne fictive | Rôle · périmètre |
|---|---|---|
| `admin` | Alix Admin | Administrateur (MFA TOTP obligatoire, secret de démo `JBSWY3DPEHPK3PXPJBSWY3DPEHPK3PXP`) |
| `c.marchand` | Camille Marchand | Magasinier · Dépôt Nord |
| `l.perrin` | Léa Perrin | Magasinière · Dépôt Sud |
| `r.garnier` | Romain Garnier | Responsable de dépôt · Dépôt Nord |
| `s.benali` | Sami Benali | Responsable de dépôt · Dépôt Sud |
| `a.lefevre` | Anne Lefèvre | Approbatrice · tous dépôts |
| `m.roux` | Maxime Roux | Maintenance · tous dépôts |
| `j.morel` | Jeanne Morel | Auditrice |
| `v.consult` | Victor Consult | Consultation · Dépôt Nord |
| `e.partenaire` | Elsa Partenaire | Organisation en authentification OIDC → connexion locale refusée (démonstration de l'adaptateur) |

Code TOTP de l'administrateur sans application d'authentification :
`python -c "from app.core.security import TOTPAdapter as T; print(T.code_at('JBSWY3DPEHPK3PXPJBSWY3DPEHPK3PXP'))"`.

## 5. Démonstration

`python -m seed.demo` recrée le référentiel fictif puis **rejoue le scénario à travers l'API réelle** (permissions,
idempotence, audit inclus), avec une horloge de démonstration qui avance de septembre au **27/11/2026 09:00** :

1. réception de 120 vestes (3 cartons M + 2 cartons L + 20 XL) ; 2. contrôle avec acceptation partielle (112 acceptées,
8 en quarantaine) ; 3. mise en stock + correction d'emplacement par mouvements liés ; 4. demande de dotation ;
5. approbation et réservation ; 6. remise partielle (25/40) ; 7. transfert Dépôt Nord → Dépôt Sud ; 8. écart à la
réception (1 endommagée, 2 manquantes passées en perte par l'approbatrice) ; 9. retour du groupe **GEN-DÉMO-024**
endommagé ; 10. maintenance (diagnostic, prestataire fictif, 3,5 h, pièces consommées) ; 11. contrôle avant remise à
disposition puis décision attribuée ; 12. inventaire à l'aveugle avec mouvement pendant le comptage, recomptage et
ajustements approuvés ; 13. traçabilité ; 14. exports de rapports en arrière-plan.
Cas limites rejoués : réservations simultanées, requêtes dupliquées, contrôles manquants, accès non autorisés,
séparation des tâches, version obsolète. Journal complet : `docs/demo-log.json`.

## 6. Tests

```bash
cd backend && pytest
```

Résultat obtenu : **44 tests réussis** (détail dans `docs/RESULTATS.md`). Les tests utilisent la base `intendance_test`
(variable `INTENDANCE_DATABASE_URL`) et rejouent les migrations Alembic.

## 7. Documentation

- `docs/ARCHITECTURE.md` — modules, modèle de données, transactions, sécurité.
- `docs/REGLES_METIER.md` — règles de stock, réceptions, dotations, transferts, inventaires, maintenance.
- `docs/API.md` + `docs/openapi.json` — référence de l'API (101 opérations).
- `docs/DEPENDANCES.md` — versions et licences vérifiées.
- `docs/ETAT_DES_FONCTIONNALITES.md` — opérationnel / simulé / intégré / reporté.
- `docs/RESULTATS.md` — résultats réels (tests, scénario, sauvegarde/restauration, build).
- `docs/captures/` — captures d'écran de l'application en fonctionnement.
