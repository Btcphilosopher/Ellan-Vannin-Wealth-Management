# Résultats réels

Exécutions réalisées le 28/11/2026 dans l'environnement de développement : Linux, PostgreSQL 16.15, Python 3.13,
Node 22, Chromium (Playwright) pour les captures. Docker : client présent, **démon absent** — la pile Compose a été
validée syntaxiquement (`docker compose config`) mais pas lancée.

## 1. Tests automatisés backend — `cd backend && pytest -rA`

**44 réussis, 0 échec** (≈ 37 s). Liste exacte :

```
PASSED tests/test_backup_restore.py::test_sauvegarde_puis_restauration
PASSED tests/test_catalog_receipts.py::test_creation_article_et_regles_catalogue
PASSED tests/test_catalog_receipts.py::test_modification_article_versionnee
PASSED tests/test_catalog_receipts.py::test_reception_partielle_quantites_distinctes
PASSED tests/test_catalog_receipts.py::test_controle_par_le_receptionnaire_refuse
PASSED tests/test_catalog_receipts.py::test_series_distinctes_et_position_unique
PASSED tests/test_catalog_receipts.py::test_scan_identifie_sans_prouver
PASSED tests/test_demo_scenario.py::test_scenario_complet
PASSED tests/test_flows.py::test_reservation_n_est_pas_une_remise_et_remise_partielle
PASSED tests/test_flows.py::test_approbateur_distinct_et_remise_sans_reservation
PASSED tests/test_flows.py::test_pret_prolongation_retour_bloque
PASSED tests/test_flows.py::test_transfert_transit_ecart_et_permissions
PASSED tests/test_flows.py::test_cloture_ne_vaut_pas_aptitude
PASSED tests/test_flows.py::test_decision_remise_a_disposition_attribuee
PASSED tests/test_flows.py::test_inventaire_aveugle_recomptage_mouvement_pendant_comptage
PASSED tests/test_flows.py::test_ajustement_important_exige_approbateur_distinct
PASSED tests/test_security_documents.py::test_perimetre_par_depot
PASSED tests/test_security_documents.py::test_refus_journalises_avec_identifiant_de_requete
PASSED tests/test_security_documents.py::test_session_cookie_csrf_et_deconnexion
PASSED tests/test_security_documents.py::test_mfa_obligatoire_pour_l_administrateur
PASSED tests/test_security_documents.py::test_verrouillage_et_authentification_organisationnelle
PASSED tests/test_security_documents.py::test_administrateur_n_approuve_pas
PASSED tests/test_security_documents.py::test_documents_versions_types_et_acces
PASSED tests/test_security_documents.py::test_rapports_et_export_en_arriere_plan
PASSED tests/test_security_documents.py::test_tableau_de_bord_issu_de_la_base
PASSED tests/test_stock_concurrency.py::test_contraintes_base_disponible_jamais_negatif
PASSED tests/test_stock_concurrency.py::test_journal_non_modifiable
PASSED tests/test_stock_concurrency.py::test_grand_livre_coherent_avec_les_soldes
PASSED tests/test_stock_concurrency.py::test_correction_par_mouvements_lies
PASSED tests/test_stock_concurrency.py::test_reservations_simultanees_sans_double_allocation
PASSED tests/test_stock_concurrency.py::test_reservations_simultanees_exemplaires
PASSED tests/test_stock_concurrency.py::test_requete_dupliquee_rejouee
PASSED tests/test_stock_concurrency.py::test_requetes_dupliquees_simultanees
PASSED tests/test_stock_concurrency.py::test_version_obsolete
PASSED tests/test_units.py::test_conversion_carton_vers_piece
PASSED tests/test_units.py::test_conversion_non_declaree_refusee
PASSED tests/test_units.py::test_fractions_interdites_pour_les_pieces_autorisees_pour_les_litres
PASSED tests/test_units.py::test_quantite_nulle_refusee
PASSED tests/test_units.py::test_totp_rfc6238
PASSED tests/test_units.py::test_mot_de_passe_argon2
PASSED tests/test_units.py::test_code128_table_et_somme_de_controle
PASSED tests/test_units.py::test_expurgation_des_journaux
PASSED tests/test_units.py::test_normalisation_numero_de_serie
PASSED tests/test_units.py::test_pdf_minimal
44 passed in 37.14s
```

Couverture des exigences de test : unités et conversions (test_units), contraintes de stock et journal immuable,
cohérence grand livre ↔ soldes après chaque parcours (`assert_ledger_matches_balances`), exemplaires sérialisés
(positions uniques, séries dupliquées), concurrence (4 réservations simultanées sur 50 unités → 2 acceptées / 2 refusées,
jamais plus de 40 réservées ; 3 réservations simultanées d'exemplaires → jamais plus que le parc), requêtes dupliquées
(séquentielles et simultanées), réceptions partielles, transferts (transit, écarts, perte, retrouvé), permissions
(périmètre dépôt, rôles, CSRF, MFA, verrouillage, OIDC, administrateur sans pouvoir d'approbation), corrections liées,
maintenance (clôture ≠ aptitude, décision attribuée), inventaires (aveugle, recomptage, mouvement pendant le comptage,
seuils d'approbation), documents (types vérifiés sur le contenu, versions, accès restreint), rapports et traitement
en arrière-plan, **sauvegarde puis restauration** (pg_dump → base neuve → pg_restore → comparaison des comptes et soldes,
déclencheurs d'immuabilité restaurés).

## 2. Scénario de démonstration — `python -m seed.demo --reset`

Rejoué via l'API réelle (35 étapes journalisées, `docs/demo-log.json`). Base obtenue : 139 mouvements, 149 événements
d'audit (136 réussis, 8 refus d'accès, 5 refus de règles), 7 documents versionnés.

| Étape | Résultat | Données |
|---|---|---|
| 0 | Stock d'ouverture réceptionné, contrôlé et mis en stock dans les deux dépôts fictifs. |  |
| pré-9 | GEN-DÉMO-024 prêté au Centre de Formation Charlie (échéance 15/11). | {"allocation": "DOT-2026-00001"} |
| 1 | Garde-fou : saisie de 2,5 cartons refusée (un conditionnement se saisit en entier). | {"status": 422, "code": "donnees_invalides"} |
| 1 | Réception REC-2026-00003 : 120 vestes reçues physiquement, toutes « non contrôlées » (bloquées). |  |
| cas limite | Réservation de vestes non contrôlées refusée : le stock en attente de contrôle n'est pas disponible. | {"status": 409, "code": "stock_insuffisant"} |
| cas limite | Contrôle par l'agent ayant reçu la livraison refusé (séparation des tâches). | {"status": 403, "code": "separation_des_taches"} |
| 2 | Contrôle : 112 acceptées, 8 rejetées (quarantaine) — statut PARTIALLY_ACCEPTED. |  |
| 3 | Mise en stock de 112 vestes ; correction liée MVT-2026-000105, MVT-2026-000106 ; réception clôturée. |  |
| cas limite | Requête dupliquée (même clé d'idempotence) : réponse rejouée, aucune seconde demande créée. | {"status": 201, "replayed": "true", "same_reference": true} |
| 4 | Demande DEM-2026-00003 : 40 vestes, revue par le responsable de dépôt. |  |
| cas limite | Approbation tentée par un profil Consultation : refusée. | {"status": 403, "code": "acces_refuse"} |
| cas limite | Action fondée sur une version obsolète refusée (contrôle de concurrence). | {"status": 409, "code": "version_obsolete"} |
| 5 | Demande approuvée puis réservée : 40 vestes réservées (non remises). |  |
| 6 | Remise partielle DOT-2026-00002 : 25 vestes remises, reliquat toujours réservé — statut PARTIALLY_ISSUED. |  |
| cas limite | Deux réservations simultanées des 2 seuls groupes du Dépôt Sud : une seule aboutit, aucune double allocation. | {"results": {"DEM-2026-00005": 409, "DEM-2026-00004": 200}} |
| 7 | Transfert TRF-2026-00001 expédié : 30 vestes en transit, absentes des deux dépôts. | {"transit_DS": 30.0, "physique_DS": 0.0, "physique_DN": 65.0} |
| cas limite | Réception du transfert par un agent du dépôt expéditeur refusée (dépôt destinataire seulement). | {"status": 403, "code": "acces_refuse"} |
| 8 | Réception au Dépôt Sud : 27 bonnes, 1 endommagée (quarantaine), écart de 2 à traiter. | {"discrepancy": 2.0} |
| cas limite | Passation en perte par le responsable de dépôt refusée : approbation requise. | {"status": 403, "code": "acces_refuse"} |
| 8 | Transfert rapproché (RECONCILED) : perte de 2 approuvée et justifiée. |  |
| 9 | Retour RET-2026-00001 de GEN-DÉMO-024 : en quarantaine, ordre OTM-2026-00001 signalé. |  |
| 10 | Maintenance OTM-2026-00001 : 3.5 h, coût total 283.5 € (fictif) — statut TO_INSPECT. |  |
| cas limite | Clôture de l'ordre sans contrôle refusée (contrôle manquant). | {"status": 409, "code": "controle_manquant"} |
| cas limite | Remise à disposition sans contrôle refusée. | {"status": 409, "code": "controle_manquant"} |
| 11 | Ordre clôturé : l'équipement reste « AWAITING_INSPECTION » tant qu'aucune décision n'est prise. |  |
| cas limite | Décision de remise à disposition par un profil maintenance refusée (rôle non habilité). | {"status": 403, "code": "acces_refuse"} |
| 11 | Décision DRD-2026-00001 : GEN-DÉMO-024 remis à disposition par le responsable de dépôt (prochain contrôle 2027-05-19). |  |
| 12 | Inventaire INV-2026-00001 ouvert (à l'aveugle : quantités théoriques masquées au compteur = True). |  |
| cas limite | Ajustement important (-8 tables) refusé au responsable de dépôt : approbateur requis. | {"status": 403, "code": "acces_refuse"} |
| 12 | Inventaire clôturé : écarts M -1 et tables -8 ajustés après recomptage et approbation ; le déplacement de 5 tables pendant le comptage a été pris en compte. |  |
| état final | Travaux en cours : prêt de radio échu, défaut signalé, groupe en transit, réception à contrôler, demande à approuver. |  |
| 13 | Traçabilité GEN-DÉMO-024 : 15 événements — En stock à l'emplacement B-01 du Dépôt Nord — Site des Tilleuls (fictif), état technique : apte, sous la garde du Dépôt Nord — Site des Tilleuls (fictif). |  |
| cas limite | Lecture du journal d'audit par un profil Consultation refusée. | {"status": 403} |
| cas limite | Consultation du Dépôt Sud par un profil limité au Dépôt Nord refusée. | {"status": 403} |
| 14 | Exports produits en arrière-plan et conservés comme documents versionnés. | {"traceability": "DONE", "stock": "DONE"} |

## 3. Sauvegarde et restauration par scripts

`scripts/backup.sh` sur la base de démonstration puis `scripts/restore.sh` vers une base vide `intendance_restauree` :
empreintes vérifiées (`objects.tar.gz: OK`), 139 mouvements restaurés, 0 solde incohérent, objets documentaires restaurés.

## 4. Interface

- `npx tsc --noEmit` : aucune erreur. `next build` : 22 routes compilées.
- Application lancée (uvicorn + `next start`) et parcourue avec Chromium : connexion, tableau de bord, toutes les
  entrées de navigation, fiches réception / transfert / maintenance / équipement ; **aucune erreur console** ;
  largeur mobile 390 px sans défilement horizontal. Captures : `docs/captures/`.

## 5. Limites constatées honnêtement

- Pile Docker non démarrée ici (pas de démon) ; images non tirées.
- Code 128 : table et somme de contrôle vérifiées par test, **lecture par un scanner physique non testée**.
- Lecture caméra dans le navigateur : dépend de l'API expérimentale `BarcodeDetector` (non testée ici) ; la saisie
  clavier / lecteur USB est opérationnelle.
- Pas de tests automatisés de l'interface (contrôle visuel et parcours manuels scriptés uniquement).
