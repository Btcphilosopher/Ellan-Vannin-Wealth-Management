# API INTENDANCE — référence

Documentation interactive générée par FastAPI : **`/v1/docs`** (Swagger UI) et **`/v1/redoc`** ; schéma OpenAPI complet : `docs/openapi.json`
(également servi sur `/v1/openapi.json`).

## Conventions

| Sujet | Règle |
|---|---|
| Authentification | `POST /v1/auth/login` → cookie de session `HttpOnly; SameSite=Strict` (+ `Secure` en production) et jeton CSRF ; ou `Authorization: Bearer <jeton>` pour un client d'API. MFA (TOTP) : `POST /v1/auth/mfa`. |
| CSRF | Avec le cookie, toute requête non sûre exige l'en-tête `X-CSRF-Token` (valeur du cookie `intendance_csrf`). |
| Idempotence | En-tête `Idempotency-Key` sur les `POST`. Même clé + même contenu → réponse d'origine rejouée (`Idempotent-Replayed: true`) ; contenu différent → 422 ; requête identique encore en cours → 409. Seules les réponses 2xx sont mémorisées (48 h). |
| Concurrence | Les actions métier exigent `version` (version connue de l'enregistrement) ; 409 `version_obsolete` sinon. Les soldes sont verrouillés (`SELECT … FOR UPDATE`) et protégés par des contraintes `CHECK`. |
| Transitions | Les changements d'état passent exclusivement par des actions métier (`/submit`, `/physical-receipt`, `/inspection`, `/approval`, `/dispatch`, …) ; aucun champ `status` n'est modifiable librement. |
| Pagination | `page` (≥ 1), `page_size` (≤ 200) → `{items, total, page, page_size}`. |
| Erreurs | `{code, message, details, request_id}` ; 401 non authentifié, 403 accès refusé / séparation des tâches, 404, 409 conflit métier, 422 données invalides. Chaque réponse porte `X-Request-ID`. |
| Dates | `occurred_at` = horloge métier (configurable pour la démonstration) ; `recorded_at` = heure réelle d'enregistrement. |
| Quantités | Toujours exprimées en unité de base de l'article ; les saisies en conditionnement (`unit`) ne sont acceptées que pour les conversions déclarées. |

## Points d'entrée demandés par le cahier des charges

| Demandé | Implémenté |
|---|---|
| `GET /v1/dashboard` | ✔ |
| `GET /v1/items`, `POST /v1/items` | ✔ |
| `GET /v1/stock` | ✔ (+ `/v1/stock/positions`) |
| `GET /v1/assets/{asset_id}`, `GET /v1/assets/{asset_id}/history` | ✔ |
| `POST /v1/receipts`, `POST /v1/receipts/{id}/inspection` | ✔ (+ `/submit`, `/physical-receipt`, `/putaway`, `/close`) |
| `POST /v1/requests`, `POST /v1/requests/{id}/approval`, `POST /v1/allocations` | ✔ (+ `/review`, `/reservation`, `/preparation`, `/close`) |
| `POST /v1/transfers`, `/{id}/dispatch`, `/{id}/receipt` | ✔ (+ `/approval`, `/reservation`, `/reconciliation`) |
| `POST /v1/stocktakes` | ✔ (+ `/start`, `/counts`, `/review`, `/adjustments`, `/close`) |
| `POST /v1/maintenance-orders` | ✔ (+ `/assessment`, `/planning`, `/start`, `/labour`, `/parts`, `/completion`, `/closure`) |
| `GET /v1/audit-events` | ✔ |

## Toutes les routes (101)

| Méthode | Chemin | Module | Description |
|---|---|---|---|
| `GET` | `/v1/health` | Système |  |
| `POST` | `/v1/auth/login` | Authentification |  |
| `POST` | `/v1/auth/mfa` | Authentification |  |
| `POST` | `/v1/auth/logout` | Authentification |  |
| `GET` | `/v1/auth/me` | Authentification |  |
| `GET` | `/v1/dashboard` | Tableau de bord |  |
| `GET` | `/v1/families` | Catalogue |  |
| `GET` | `/v1/units` | Catalogue |  |
| `GET` | `/v1/items` | Catalogue |  |
| `POST` | `/v1/items` | Catalogue |  |
| `GET` | `/v1/items/{item_id}` | Catalogue |  |
| `PATCH` | `/v1/items/{item_id}` | Catalogue |  |
| `GET` | `/v1/depots` | Stocks et traçabilité |  |
| `GET` | `/v1/depots/{depot_id}/locations` | Stocks et traçabilité |  |
| `GET` | `/v1/stock` | Stocks et traçabilité | Synthèse des stocks : physique · réservé · disponible · en transit · bloqué. |
| `GET` | `/v1/stock/positions` | Stocks et traçabilité | Détail des positions de stock (emplacement × article × variante × lot × statut). |
| `GET` | `/v1/movements` | Stocks et traçabilité |  |
| `POST` | `/v1/stock/relocations` | Stocks et traçabilité | Mise en emplacement / déplacement interne de stock utilisable non réservé. |
| `POST` | `/v1/movements/{movement_id}/correction` | Stocks et traçabilité | Corrige un mouvement par des mouvements liés (contre-passation + éventuelle écriture rectifiée). |
| `GET` | `/v1/assets` | Stocks et traçabilité |  |
| `GET` | `/v1/assets/{asset_id}` | Stocks et traçabilité |  |
| `GET` | `/v1/assets/{asset_id}/history` | Stocks et traçabilité | Traçabilité : réception → emplacements → affectations → retours → maintenance → état actuel. |
| `POST` | `/v1/inspections/stock` | Stocks et traçabilité | Contrôle d'une quantité bloquée (retours, quarantaine) : requalification attribuée. |
| `GET` | `/v1/receipts` | Réceptions |  |
| `POST` | `/v1/receipts` | Réceptions |  |
| `GET` | `/v1/receipts/{receipt_id}` | Réceptions |  |
| `POST` | `/v1/receipts/{receipt_id}/submit` | Réceptions |  |
| `POST` | `/v1/receipts/{receipt_id}/physical-receipt` | Réceptions | Enregistre les quantités réellement reçues. Tout entre en « non contrôlé » (bloqué) au quai de réception. |
| `POST` | `/v1/receipts/{receipt_id}/inspection` | Réceptions | Contrôle : acceptation totale ou partielle. Seules les quantités acceptées deviennent disponibles. |
| `POST` | `/v1/receipts/{receipt_id}/putaway` | Réceptions |  |
| `POST` | `/v1/receipts/{receipt_id}/close` | Réceptions |  |
| `GET` | `/v1/requests` | Demandes et dotations |  |
| `POST` | `/v1/requests` | Demandes et dotations |  |
| `GET` | `/v1/requests/{request_id}` | Demandes et dotations |  |
| `POST` | `/v1/requests/{request_id}/submit` | Demandes et dotations |  |
| `POST` | `/v1/requests/{request_id}/review` | Demandes et dotations |  |
| `POST` | `/v1/requests/{request_id}/approval` | Demandes et dotations |  |
| `POST` | `/v1/requests/{request_id}/reservation` | Demandes et dotations | Réserve le stock disponible (contrôlé, utilisable, non réservé). Verrouillage des soldes : pas de double allocation. |
| `POST` | `/v1/requests/{request_id}/preparation` | Demandes et dotations |  |
| `POST` | `/v1/requests/{request_id}/close` | Demandes et dotations | Clôture : libère les reliquats réservés non remis. |
| `POST` | `/v1/allocations` | Demandes et dotations | Remise effective, partielle autorisée, avec justificatif. Consomme les réservations de la demande. |
| `GET` | `/v1/allocations` | Demandes et dotations |  |
| `GET` | `/v1/allocations/{allocation_id}` | Demandes et dotations |  |
| `POST` | `/v1/allocation-lines/{line_id}/extension` | Demandes et dotations | Prolongation autorisée d'un prêt (nombre et durée plafonnés par paramètres). |
| `POST` | `/v1/allocation-lines/{line_id}/consumption` | Demandes et dotations | Déclare consommée une quantité remise (la remise seule n'est pas une consommation). |
| `POST` | `/v1/returns` | Demandes et dotations | Retour d'un matériel remis : entre bloqué (contrôle de retour ou quarantaine) — jamais directement disponible. |
| `GET` | `/v1/transfers` | Transferts |  |
| `POST` | `/v1/transfers` | Transferts |  |
| `GET` | `/v1/transfers/{transfer_id}` | Transferts |  |
| `POST` | `/v1/transfers/{transfer_id}/approval` | Transferts |  |
| `POST` | `/v1/transfers/{transfer_id}/reservation` | Transferts |  |
| `POST` | `/v1/transfers/{transfer_id}/dispatch` | Transferts | Expédition : le stock quitte le dépôt d'origine et passe « en transit » (aucun des deux dépôts). |
| `POST` | `/v1/transfers/{transfer_id}/receipt` | Transferts | Réception au dépôt destinataire : quantités bonnes, endommagées ; l'écart restant est conservé à traiter. |
| `POST` | `/v1/transfers/{transfer_id}/reconciliation` | Transferts | Rapprochement : chaque écart restant est soit retrouvé (entrée tardive), soit passé en perte avec justification approuvée. |
| `GET` | `/v1/stocktakes` | Inventaires physiques |  |
| `POST` | `/v1/stocktakes` | Inventaires physiques |  |
| `GET` | `/v1/stocktakes/{stocktake_id}` | Inventaires physiques |  |
| `POST` | `/v1/stocktakes/{stocktake_id}/start` | Inventaires physiques | Ouvre le comptage : instantané des positions du périmètre (tous statuts confondus). |
| `POST` | `/v1/stocktakes/{stocktake_id}/counts` | Inventaires physiques | Saisie de comptage (à l'aveugle si configuré). Le premier comptage n'est jamais appliqué automatiquement. |
| `POST` | `/v1/stocktakes/{stocktake_id}/review` | Inventaires physiques |  |
| `POST` | `/v1/stocktakes/{stocktake_id}/adjustments` | Inventaires physiques | Approbation justifiée des ajustements. Écarts importants : approbateur, distinct des compteurs de la ligne. |
| `POST` | `/v1/stocktakes/{stocktake_id}/close` | Inventaires physiques |  |
| `GET` | `/v1/maintenance-orders` | Maintenance |  |
| `POST` | `/v1/maintenance-orders` | Maintenance |  |
| `GET` | `/v1/maintenance-orders/{order_id}` | Maintenance |  |
| `POST` | `/v1/maintenance-orders/{order_id}/assessment` | Maintenance |  |
| `POST` | `/v1/maintenance-orders/{order_id}/planning` | Maintenance |  |
| `POST` | `/v1/maintenance-orders/{order_id}/start` | Maintenance |  |
| `POST` | `/v1/maintenance-orders/{order_id}/labour` | Maintenance |  |
| `POST` | `/v1/maintenance-orders/{order_id}/parts` | Maintenance | Pièces consommées : mouvement de consommation depuis un stock utilisable non réservé. |
| `POST` | `/v1/maintenance-orders/{order_id}/completion` | Maintenance |  |
| `POST` | `/v1/maintenance-orders/{order_id}/closure` | Maintenance | Clôture administrative. L'équipement reste « en attente de décision » : aucune aptitude automatique. |
| `POST` | `/v1/inspections/asset` | Maintenance |  |
| `POST` | `/v1/assets/{asset_id}/release-decision` | Maintenance |  |
| `GET` | `/v1/providers` | Maintenance |  |
| `GET` | `/v1/documents` | Documents |  |
| `POST` | `/v1/documents` | Documents |  |
| `GET` | `/v1/documents/kinds` | Documents |  |
| `GET` | `/v1/documents/{document_id}` | Documents |  |
| `POST` | `/v1/documents/{document_id}/versions` | Documents |  |
| `GET` | `/v1/documents/{document_id}/versions/{version_no}/content` | Documents |  |
| `GET` | `/v1/scan/{code}` | Étiquettes et scan |  |
| `GET` | `/v1/labels/assets/{asset_id}.svg` | Étiquettes et scan |  |
| `GET` | `/v1/labels/locations/{location_id}.svg` | Étiquettes et scan |  |
| `GET` | `/v1/reports` | Rapports |  |
| `GET` | `/v1/reports/{kind}/download` | Rapports | Export immédiat (synchrone). |
| `POST` | `/v1/reports/exports` | Rapports | Export en arrière-plan : le fichier produit est conservé comme document versionné. |
| `GET` | `/v1/reports/exports/{job_id}` | Rapports |  |
| `GET` | `/v1/audit-events` | Audit | Journal d'audit (acteur, action, objet, date, motif, identifiant de requête). Lecture réservée aux auditeurs. |
| `GET` | `/v1/organizations` | Administration |  |
| `GET` | `/v1/admin/roles` | Administration |  |
| `GET` | `/v1/admin/users` | Administration |  |
| `POST` | `/v1/admin/users` | Administration |  |
| `POST` | `/v1/admin/users/{user_id}/memberships` | Administration |  |
| `DELETE` | `/v1/admin/users/{user_id}/memberships/{membership_id}` | Administration |  |
| `POST` | `/v1/admin/users/{user_id}/mfa` | Administration | Enrôlement MFA (adaptateur configuré). Le secret n'est affiché qu'une fois. |
| `POST` | `/v1/admin/users/{user_id}/deactivate` | Administration |  |
| `GET` | `/v1/admin/settings` | Administration |  |
| `PATCH` | `/v1/admin/settings/{key}` | Administration |  |
| `GET` | `/v1/admin/clock` | Administration |  |
| `POST` | `/v1/admin/clock` | Administration | Horloge de démonstration : fixer, avancer ou repasser en heure réelle. |
