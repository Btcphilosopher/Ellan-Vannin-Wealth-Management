# État des fonctionnalités

Légende : **Opérationnel** = implémenté, exécuté et testé ici · **Simulé** = fonctionne avec des données ou adaptateurs
fictifs · **Intégré (non exécuté)** = configuration livrée mais non lancée dans cet environnement · **Reporté** = non livré.

## Opérationnel
| Domaine | Détail |
|---|---|
| Catalogue | articles, familles, variantes, unités de base, conditionnements et conversions autorisées, suivi quantité/lot/série, exigences de contrôle, documents, état actif, modification versionnée |
| Réceptions et contrôles | cycle complet, quantités attendue/reçue/acceptée/rejetée/en attente, lots, numéros de série, état constaté, écarts motivés, contrôles partiels successifs, quarantaine, mise en stock, clôture |
| Inventaire et mouvements | journal immuable (déclencheurs), 16 types de mouvements, corrections liées, soldes transactionnels verrouillés, contraintes CHECK, physique/réservé/disponible/en transit/bloqué |
| Demandes et dotations | demande → revue → approbation → réservation → préparation → remise(s) partielle(s) → clôture ; justificatif ; prêts, échéances, prolongations plafonnées, retours, consommation déclarée |
| Transferts | parcours complet, transit hors des deux dépôts, réception par le dépôt destinataire seulement, endommagé/écart/perte approuvée/retrouvé, exemplaires sérialisés |
| Inventaires physiques | campagnes, périmètres, comptage à l'aveugle, recomptages, règle des mouvements pendant le comptage, seuils et approbations justifiées, historique des comptages |
| Maintenance | échéances, défauts, ordres de travail, prestataires, temps, coûts, pièces consommées, contrôles, clôture sans aptitude, décision de remise à disposition attribuée, réforme |
| Tableau de bord | indicateurs calculés en base, état des stocks par famille, actions prioritaires cliquables, traçabilité d'un équipement, derniers mouvements |
| Traçabilité | fiche équipement : réception → emplacements → affectations → retours → maintenance → état actuel, phrase explicable (où, quel état, sous quelle garde) |
| Documents | versions, auteur, date, empreinte, niveaux d'accès, contrôle des types sur le contenu, stockage objet local protégé |
| Étiquettes et scan | étiquettes internes Code 128 (SVG), recherche par étiquette/série/lot/code, saisie clavier et lecteur USB |
| Permissions et audit | 7 rôles, périmètre organisation/dépôt, séparation des tâches configurable, audit complet y compris refus, identifiant de requête |
| API | 101 opérations, validation Pydantic, pagination, idempotence, contrôle des versions, actions métier explicites, OpenAPI |
| Sécurité | sessions serveur, CSRF, MFA TOTP par adaptateur, verrouillage, en-têtes, journaux expurgés, secrets par fichiers |
| Rapports | 7 rapports CSV/PDF, export immédiat ou en arrière-plan (worker) conservé comme document |
| Résilience | scripts de sauvegarde/restauration exécutés ; test automatisé de restauration |
| Horloge de démonstration | heure métier figée/avancée, auditée |

## Simulé
| Élément | Détail |
|---|---|
| Organisations, personnes, fournisseurs, prestataires, matériels | entièrement fictifs |
| Valeurs et coûts | montants indicatifs fictifs |
| MFA | TOTP réel, mais secret de démonstration publié dans le README pour le compte `admin` |
| Transporteur | simple libellé (aucune intégration) |

## Intégré (livré, non exécuté ici)
| Élément | Détail |
|---|---|
| Docker Compose | PostgreSQL, MinIO, API, worker, interface, Caddy ; validé par `docker compose config`, non démarré (pas de démon Docker) |
| Stockage S3/MinIO | adaptateur `S3Storage` (chiffrement côté serveur demandé) ; seul l'adaptateur local a été exécuté |
| TLS | Caddy `tls internal` + HSTS ; `INTENDANCE_DATABASE_SSLMODE` pour PostgreSQL |
| Caméra | lecture par `BarcodeDetector` si le navigateur le propose |

## Reporté
| Élément | Raison / piste |
|---|---|
| Fournisseur d'identité OIDC réel | interface d'adaptateur présente ; aucun système réel n'est connecté (exigence du concept) |
| Brouillons hors connexion | non proposés ; toute réservation exige le serveur |
| Notifications (courriel, messagerie) | alertes visibles uniquement au tableau de bord |
| Retour fournisseur des quantités rejetées | elles restent en quarantaine ; réforme possible par contrôle de stock |
| Chaînage cryptographique de l'audit | immuabilité par déclencheurs ; chaînage de hachés à ajouter pour la preuve d'intégrité externe |
| Tests automatisés de l'interface (Playwright) | parcours vérifiés par captures scriptées seulement |
| Internationalisation, multi-devises, gestion fine des péremptions (FEFO utilisé pour la réservation seulement) | hors périmètre du prototype |
| Homologation de sécurité | **prototype non apte au traitement d'informations classifiées** |
