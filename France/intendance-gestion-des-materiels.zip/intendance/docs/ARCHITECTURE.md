# Architecture

## Vue d'ensemble

```
Navigateur ──HTTPS──► Caddy (TLS) ──► Next.js (interface, /v1/* relayé) ──► FastAPI (monolithe modulaire)
                                                                              │        │
                                                          PostgreSQL 16 ◄─────┘        └──► Stockage objet (MinIO/S3 ou disque 0600)
                                                                ▲
                                                 Worker (python -m app.worker) : exports, purges
```

- **Monolithe modulaire** : un seul processus API, des modules séparés (`app/modules/*`) avec leurs modèles,
  règles et routes : `catalog`, `inventory`, `receipts`, `requests` (demandes, dotations, prêts, retours),
  `transfers`, `stocktakes`, `maintenance`, `documents`, `audit`, `auth`, `org` (organisations, rôles, paramètres),
  `dashboard`, `reports`, `scan`, `admin`.
- **Un seul point d'écriture du stock** : `app/modules/inventory/service.py` (`post_movement`, `reserve_stock`,
  `consume_reservation`, `release_reservation`). Aucun module ne modifie un solde directement.
- **Transactions** : chaque requête métier s'exécute dans une transaction ; journal, soldes, exemplaires et audit sont
  validés ensemble (`ctx.commit()`), ou rien n'est écrit.
- **Interface** : Next.js App Router, composants clients ; l'API est appelée en même origine (réécriture `/v1/*`),
  ce qui permet des cookies `SameSite=Strict` sans CORS côté navigateur.

## Modèle de données (principales tables)

| Concept | Table | Remarques |
|---|---|---|
| Organisation | `organizations` | support, bénéficiaire, fournisseur, prestataire ; mode d'authentification (LOCAL/OIDC) |
| Utilisateur | `users` | mot de passe Argon2id, secret TOTP, verrouillage |
| Rôle | `roles` | 7 rôles du cahier des charges |
| Appartenance | `memberships` | utilisateur × organisation × (dépôt optionnel) × rôle |
| Dépôt / Emplacement | `depots`, `locations` | types : quai, stockage, quarantaine, atelier, expédition ; étiquette interne |
| Article / Variante | `items`, `item_variants` | code, famille, unité de base, suivi (quantité/lot/série), exigences de contrôle |
| Conditionnement | `item_packagings` | seules conversions autorisées : `1 <unité> = facteur × unité de base` |
| Lot | `lots` | numéro, péremption |
| Exemplaire sérialisé | `assets` | **une seule colonne d'emplacement** ; cycle de vie, état technique, garde distincts |
| Position de stock | `stock_balances` | emplacement × article × variante × lot × statut ; `quantity`, `reserved` |
| Mouvement de stock | `stock_movements` | journal immuable, attribué, horodaté (métier + réel), origine, motif, correction liée |
| Réservation | `reservations` | sur un solde (et un exemplaire), pour une ligne de demande **ou** de transfert |
| Réception / ligne | `receipts`, `receipt_lines` | attendu, reçu, accepté, rejeté, en attente (calculé), mis en stock |
| Demande / ligne | `supply_requests`, `request_lines` | demandé, approuvé, remis ; prêt avec échéance |
| Dotation (remise) | `allocations`, `allocation_lines` | justificatif, remis à, retourné, consommé, prolongations |
| Retour | `returns` | état constaté, ordre de maintenance éventuel |
| Transfert / ligne | `transfers`, `transfer_lines` | expédié, reçu, endommagé, perte ; lots et exemplaires expédiés |
| Inventaire | `stocktakes`, `stocktake_lines`, `stock_counts` | instantané, comptages successifs, écart, décision |
| Ordre de maintenance | `maintenance_orders`, `maintenance_labour`, `maintenance_parts` | temps, coûts, pièces consommées |
| Inspection | `inspections` | réception, retour, avant remise à disposition, stock |
| Décision | `release_decisions` | remise à disposition / maintien inapte / réforme, attribuée |
| Document | `documents`, `document_versions` | version, auteur, date, empreinte SHA-256, niveau d'accès |
| Audit | `audit_events` | acteur, action, résultat, objet, date, motif, identifiant de requête, IP |
| Technique | `idempotency_records`, `jobs`, `user_sessions`, `settings`, `reference_counters` | |

Identifiants : UUID stables + références lisibles (`REC-2026-00003`, `MVT-2026-000104`…) générées atomiquement.
Concurrence : colonne `version` (verrou optimiste SQLAlchemy) sur les agrégats ; verrous pessimistes sur les soldes.

### Contraintes de base de données (dernier rempart)

- `stock_balances` : `quantity ≥ 0`, `reserved ≥ 0`, `reserved ≤ quantity` (disponible jamais négatif),
  réservation uniquement sur du stock `USABLE`.
- `assets` : cohérence cycle de vie / emplacement (en stock ⇔ un emplacement ; remis, en transit, manquant ou
  réformé ⇔ aucun emplacement) ; un exemplaire réservé est forcément utilisable et apte ; série unique par article.
- `reservations` : rattachée à une seule origine ; consommé + libéré ≤ réservé.
- Lignes : bornes accepté + rejeté ≤ reçu, mis en stock ≤ accepté, remis ≤ approuvé ≤ demandé, reçu + endommagé + perte ≤ expédié.
- Déclencheurs `intendance_forbid_mutation` : `UPDATE`/`DELETE`/`TRUNCATE` refusés sur `stock_movements` et
  `audit_events` (sauf opération d'archivage explicite `SET LOCAL intendance.allow_journal_maintenance = 'on'`).

## Sécurité

| Exigence | Mise en œuvre |
|---|---|
| Sessions sécurisées | jeton aléatoire 256 bits, seule l'empreinte SHA-256 est stockée ; cookie `HttpOnly`, `SameSite=Strict`, `Secure` (production) ; expiration absolue (8 h) et d'inactivité (60 min) ; révocation à la déconnexion |
| CSRF | double jeton (cookie lisible + en-tête `X-CSRF-Token`) exigé pour les requêtes non sûres authentifiées par cookie |
| Authentification organisationnelle | adaptateur `LOCAL` opérationnel ; organisation en mode `OIDC` → refus explicite (adaptateur à brancher) |
| MFA via adaptateur | interface `MFAAdapter` ; adaptateur TOTP RFC 6238 (vecteur de test RFC vérifié) ; obligatoire pour les rôles configurés |
| Permissions côté serveur | matrice `PERMISSIONS` (app/core/context.py), contrôle par organisation et dépôt sur chaque route ; aucun rôle « super-utilisateur » (l'administrateur n'approuve ni ne déplace de stock) |
| Séparation des tâches | règles configurables (`settings`) : réception ≠ contrôle, auteur ≠ approbateur, demandeur ≠ approbateur de transfert, compteur ≠ approbateur d'ajustement, contrôleur ≠ décideur de remise à disposition, auteur ≠ correcteur (option) |
| Audit | toutes les actions, ainsi que les refus d'accès (`DENIED`) et de règles (`REFUSED`) journalisés hors transaction, avec `request_id` |
| Secrets | variables d'environnement ou fichiers `INTENDANCE_*_FILE` (secrets Docker) ; refus de démarrer en production sans secret fort |
| Connexions chiffrées | Caddy TLS en frontal, HSTS ; `INTENDANCE_DATABASE_SSLMODE` pour PostgreSQL ; réseau Docker `back` interne |
| Fichiers contrôlés | liste blanche (PDF, PNG, JPEG, TXT, CSV) vérifiée **sur le contenu**, taille plafonnée, clés de stockage aléatoires, empreinte vérifiée au téléchargement, `Content-Disposition: attachment`, CSP `sandbox` |
| Journaux expurgés | format JSON, filtre d'expurgation (mots de passe, jetons, cookies, en-têtes `Authorization`) |
| En-têtes | `X-Content-Type-Options`, `X-Frame-Options: DENY`, `Referrer-Policy`, `Cache-Control: no-store`, CSP côté interface |
| Sauvegardes | `scripts/backup.sh` (pg_dump + objets + SHA256SUMS), `scripts/restore.sh` (base vide + contrôles) ; restauration testée automatiquement |
| Brouillons hors connexion | **non proposés** : toute réservation passe par le serveur (aucune allocation locale) |

## Traitements en arrière-plan

File `jobs` en base, prise en charge par `SELECT … FOR UPDATE SKIP LOCKED`, reprises bornées avec délai croissant :
exports de rapports (CSV/PDF conservés comme documents versionnés) et purge horaire des sessions expirées et des
clés d'idempotence.

## Horloge de démonstration

`app/core/clock.py` : heure métier figée (`INTENDANCE_DEMO_CLOCK` ou paramètre `demo_clock` modifiable par
l'administrateur, chaque changement étant audité). Toutes les dates métier (mouvements, échéances, contrôles,
alertes) en dépendent ; les horodatages techniques restent en heure réelle.
