# Règles métier

## Catalogue et unités
- Chaque article a **une unité de base** (PCE, PAIRE, JEU, KG, L, M). Les quantités sont **toujours stockées en unité de base**.
- Un conditionnement (CARTON, BIDON, PALETTE, SACHET) n'est accepté que s'il est **déclaré pour l'article** avec son facteur ;
  il se saisit en nombre entier. Une conversion entre dimensions différentes (kg ↔ pièces, litres ↔ pièces) est refusée à la création.
- Les unités de comptage n'acceptent pas de décimales ; les litres, kilogrammes et mètres oui.
- Suivi : **quantité**, **lot** (numéro obligatoire en réception et pour tout mouvement) ou **numéro de série** (pièce, quantité 1 par mouvement).

## Statuts de stock et quantités affichées
| Statut | Signification | Disponible ? |
|---|---|---|
| `USABLE` | contrôlé, utilisable | oui, moins le réservé |
| `PENDING_INSPECTION` | reçu ou retourné, non contrôlé | **non** (bloqué) |
| `QUARANTINE` | rejeté, endommagé, défaut signalé | **non** (bloqué) |
| `MAINTENANCE` | en atelier | **non** (bloqué) |

Physique = tous statuts présents au dépôt · Réservé = réservé non remis · Disponible = `USABLE` − réservé ·
Bloqué = statuts non utilisables · En transit = expédié vers le dépôt, **compté dans aucun des deux dépôts**.

## Journal des mouvements
Types : réception, mise en emplacement, déplacement, changement de statut, quarantaine, réservation, libération, remise,
retour, expédition, réception de transfert, consommation, réforme, ajustement, perte, correction.
Chaque mouvement est attribué (acteur, identifiant de requête), horodaté (date métier et date d'enregistrement), rattaché à son
origine. **Une erreur se corrige par une contre-passation liée** (`corrects_movement_id`) et, si besoin, une écriture rectifiée ;
le mouvement d'origine n'est jamais modifié (déclencheur PostgreSQL). Les corrections directes sont limitées aux mouvements
d'emplacement ; les autres écarts passent par l'action métier (contrôle, retour, ajustement d'inventaire approuvé, perte de transfert).

## Réceptions
Brouillon → soumise → reçue physiquement → contrôle (éventuellement en plusieurs fois) → acceptée totalement / partiellement /
rejetée → clôturée.
- Toute quantité reçue entre au **quai, statut non contrôlé** ; elle n'est ni réservable ni remettable.
- Écart avec l'attendu : motif obligatoire. Quantités distinctes : attendue, reçue, acceptée, rejetée, **en attente = reçue − acceptée − rejetée**.
- Le contrôleur est distinct de l'agent ayant reçu (paramètre). Les rejets partent en quarantaine.
- Articles sérialisés : un numéro distinct par exemplaire, unique par article (normalisation accents/casse) ; rejets désignés par numéro.
- Clôture impossible tant qu'une quantité est en attente de contrôle.

## Demandes, réservations, remises, prêts
Demande → revue (responsable de dépôt) → approbation (approbateur ≠ auteur) → réservation → préparation → remise(s) → clôture.
- La réservation ne porte que sur du stock `USABLE` contrôlé ; elle verrouille les soldes (`FOR UPDATE`) et, pour les exemplaires,
  saute les exemplaires verrouillés (`SKIP LOCKED`) : **aucune double allocation**, aucune disponibilité négative.
- **Une réservation n'est pas une remise** : le physique reste au dépôt. **Une remise n'est pas une consommation** : la quantité
  reste détenue par le bénéficiaire (garde = organisation + responsable) jusqu'au retour ou à la déclaration de consommation
  (consommables uniquement).
- Remises partielles autorisées ; chacune exige un justificatif de remise et consomme des réservations existantes.
- Clôture : les reliquats réservés sont libérés par des mouvements de libération.
- Prêts : échéance obligatoire, prolongations plafonnées (nombre et durée paramétrés), retour obligatoire.
- Retour : entre au quai en **non contrôlé** (bon état) ou en **quarantaine** (endommagé/incomplet) ; un défaut signalé ouvre un
  ordre de maintenance.

## Transferts
Demandé → approuvé (approbateur ≠ demandeur) → réservé → expédié / en transit → réceptionné → rapproché.
- À l'expédition, le stock sort du dépôt d'origine ; il n'apparaît dans aucun dépôt (indicateur « en transit » du destinataire).
- Seul un utilisateur habilité **du dépôt destinataire** confirme la réception ; quantités bonnes, endommagées (quarantaine) et
  écart restant sont conservées séparément.
- Rapprochement : chaque écart est soit **retrouvé** (entrée tardive), soit **passé en perte** avec justification par un approbateur.

## Inventaires physiques
- Campagne sur un périmètre (emplacements, familles), **à l'aveugle** par défaut (quantités théoriques masquées aux compteurs).
- **Mouvements pendant le comptage** : non gelés. Un instantané est pris à l'ouverture (quantités + numéro de séquence du journal).
  Quantité théorique d'un comptage = instantané + mouvements nets postérieurs à l'instantané et dont la date métier est
  antérieure ou égale à l'heure physique de comptage déclarée.
- Le premier comptage n'est **jamais appliqué automatiquement** : tout écart impose un recomptage ; deux comptages concordants
  (ou trois tours) confirment l'écart.
- Ajustement : décision ligne par ligne, **justification obligatoire** ; au-delà du seuil (5 unités ou 500 € fictifs, paramétrables)
  un approbateur est requis ; l'approbateur ne peut pas avoir compté la ligne. Un refus ne crée aucune écriture.
- Les écarts sur articles sérialisés se traitent par l'action métier (recherche, perte, réforme), pas par ajustement.

## Maintenance et remise à disposition
Signalé → évalué → planifié → en intervention (atelier) → à contrôler → clôturé.
- Signaler un défaut bloque l'exemplaire (quarantaine, inapte).
- Temps, coûts, prestataires fictifs, pièces consommées (mouvements de consommation sur stock utilisable).
- La clôture exige qu'un contrôle ait été enregistré, mais **ne rend pas l'équipement apte**.
- **Décision de remise à disposition** explicite, attribuée au responsable de dépôt, fondée sur un contrôle **conforme**,
  postérieur à la dernière intervention, réalisé par une autre personne ; elle replace l'exemplaire en stockage, le déclare
  apte et recalcule la prochaine échéance. Autres décisions : maintien inapte, réforme.

## Scan
Un scan (étiquette `ITD-…`, `LOC-…`, code article, numéro de série ou de lot) **identifie un enregistrement** dans le périmètre de
l'utilisateur ; il ne prouve ni la présence physique, ni l'état, ni la réalisation d'un contrôle.
