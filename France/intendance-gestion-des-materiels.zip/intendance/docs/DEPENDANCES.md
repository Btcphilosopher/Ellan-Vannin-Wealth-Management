# Dépendances, versions et licences

Vérification effectuée le **28/11/2026** à partir des **métadonnées officielles publiées sur les registres** (PyPI via
`pip index versions` / `pip show` — champ `License-Expression` ; npm via `npm view <paquet> version license`).
Les versions retenues sont les dernières stables publiées à cette date, sauf mention contraire.

## Backend (Python 3.13 testé)

| Paquet | Version | Licence | Usage |
|---|---|---|---|
| fastapi | 0.165.0 | MIT | API HTTP |
| uvicorn | 0.55.0 | BSD-3-Clause | serveur ASGI |
| SQLAlchemy | 2.1.9 | MIT | ORM, transactions, verrous |
| alembic | 1.20.1 | MIT | migrations |
| psycopg[binary] | 3.3.9 | **LGPL-3.0-only** | pilote PostgreSQL (utilisé comme bibliothèque non modifiée ; compatible avec un usage propriétaire sous réserve des obligations LGPL) |
| pydantic | 2.14.4 | MIT | validation |
| pydantic-settings | 2.16.3 | MIT | configuration |
| python-multipart | 0.0.34 | Apache-2.0 | téléversement de fichiers |
| argon2-cffi | 25.1.0 | MIT | hachage des mots de passe |
| boto3 | 1.44.13 | Apache-2.0 | stockage objet S3 / MinIO |
| pytest (dev) | 9.2.0 | MIT | tests |
| httpx (dev) | 0.29.0 | BSD-3-Clause | client de test |

Choix délibérés sans dépendance : TOTP (RFC 6238), génération PDF, codes-barres Code 128 (SVG), file de traitements.

## Interface

| Paquet | Version | Licence |
|---|---|---|
| next | 16.4.6 | MIT |
| react / react-dom | 19.3.1 | MIT |
| typescript (dev) | 5.9.3 | Apache-2.0 — la 7.0.2 existe mais n'a pas été retenue (nouveau compilateur, compatibilité Next.js non vérifiée) |
| @types/react, @types/react-dom, @types/node (dev) | 19.3.3, 19.3.0, 22.20.7 | MIT |

## Images de conteneurs (Docker Compose)

| Image | Licence | Remarque |
|---|---|---|
| postgres:16-alpine | PostgreSQL License | version testée localement : 16.15 |
| minio/minio (RELEASE.2025-04-22) | **AGPL-3.0** | stockage objet de démonstration ; pour un déploiement réel, vérifier la compatibilité AGPL ou remplacer par un service S3 de l'organisation (l'adaptateur `S3Storage` est générique) |
| caddy:2.10-alpine | Apache-2.0 | terminaison TLS |
| python:3.13-slim, node:22-alpine | PSF / MIT | images de base |

Les étiquettes d'images n'ont **pas** pu être tirées dans l'environnement de développement (pas de démon Docker) ;
vérifier leur disponibilité avant déploiement.
