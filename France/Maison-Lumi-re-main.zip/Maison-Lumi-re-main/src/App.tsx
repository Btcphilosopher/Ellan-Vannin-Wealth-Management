import React, { useState, useEffect } from 'react';
import { 
  Flower2, 
  Menu, 
  X, 
  ArrowRight, 
  Sofa, 
  Ruler, 
  Compass, 
  Sparkles, 
  MapPin, 
  Phone, 
  Mail, 
  Instagram, 
  Heart, 
  MessageCircle, 
  ChevronRight, 
  ChevronLeft,
  Calendar,
  Send,
  User,
  Activity,
  Award
} from 'lucide-react';
import { SERVICES, PROJECTS, INSTAGRAM_POSTS } from './data';
import { Project, InstagramPost } from './types';

export default function App() {
  // Navigation states
  const [isScrolled, setIsScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  // Modal / Interaction states
  const [bookingModalOpen, setBookingModalOpen] = useState(false);
  const [selectedProject, setSelectedProject] = useState<Project | null>(null);
  const [selectedInstaPost, setSelectedInstaPost] = useState<InstagramPost | null>(null);
  
  // Filter state
  const [activeCategory, setActiveCategory] = useState<'all' | 'residential' | 'hotel'>('all');

  // Interactive like system for Instagram
  const [likedPostIds, setLikedPostIds] = useState<Record<string, boolean>>({});
  const [instaLikesCount, setInstaLikesCount] = useState<Record<string, number>>(
    INSTAGRAM_POSTS.reduce((acc, post) => ({ ...acc, [post.id]: post.likes }), {})
  );

  // Form states
  const [bookingForm, setBookingForm] = useState({
    name: '',
    email: '',
    phone: '',
    projectType: 'Appartement Haussmannien',
    budget: '50k - 100k€',
    message: '',
    timePreference: 'morning'
  });
  const [bookingSubmitted, setBookingSubmitted] = useState(false);
  const [bookingLoading, setBookingLoading] = useState(false);

  const [contactEmail, setContactEmail] = useState('');
  const [contactSubmitted, setContactSubmitted] = useState(false);

  const [contactFormCustom, setContactFormCustom] = useState({
    name: '',
    email: '',
    message: ''
  });
  const [contactFormSubmitted, setContactFormSubmitted] = useState(false);

  // Detect scroll to style header
  useEffect(() => {
    const handleScroll = () => {
      if (window.scrollY > 40) {
        setIsScrolled(true);
      } else {
        setIsScrolled(false);
      }
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  // Filter projects based on active filter tab
  const filteredProjects = PROJECTS.filter(project => {
    if (activeCategory === 'all') return true;
    return project.category === activeCategory;
  });

  // Handle slide/carousel next/prev in the Quick View Project Modal
  const handleNextProject = () => {
    if (!selectedProject) return;
    const currentIndex = PROJECTS.findIndex(p => p.id === selectedProject.id);
    const nextIndex = (currentIndex + 1) % PROJECTS.length;
    setSelectedProject(PROJECTS[nextIndex]);
  };

  const handlePrevProject = () => {
    if (!selectedProject) return;
    const currentIndex = PROJECTS.findIndex(p => p.id === selectedProject.id);
    const prevIndex = (currentIndex - 1 + PROJECTS.length) % PROJECTS.length;
    setSelectedProject(PROJECTS[prevIndex]);
  };

  // Toggle Like on Instagram photos
  const handleToggleLike = (postId: string, e: React.MouseEvent) => {
    e.stopPropagation();
    const isLiked = likedPostIds[postId];
    setLikedPostIds(prev => ({ ...prev, [postId]: !isLiked }));
    setInstaLikesCount(prev => ({
      ...prev,
      [postId]: isLiked ? prev[postId] - 1 : prev[postId] + 1
    }));
  };

  // Submit book/appointment request
  const handleBookingSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!bookingForm.name || !bookingForm.email) return;
    setBookingLoading(true);
    setTimeout(() => {
      setBookingLoading(false);
      setBookingSubmitted(true);
    }, 1200);
  };

  // Submit contact form
  const handleContactSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!contactFormCustom.name || !contactFormCustom.email || !contactFormCustom.message) return;
    setContactFormSubmitted(true);
    setTimeout(() => {
      // Clear
      setContactFormCustom({ name: '', email: '', message: '' });
    }, 3000);
  };

  // Reset booking form
  const resetBookingForm = () => {
    setBookingForm({
      name: '',
      email: '',
      phone: '',
      projectType: 'Appartement Haussmannien',
      budget: '50k - 100k€',
      message: '',
      timePreference: 'morning'
    });
    setBookingSubmitted(false);
  };

  return (
    <div className="relative min-h-screen bg-brand-warm-bg text-brand-text font-sans selection:bg-brand-lavender selection:text-brand-plum-dark">
      
      {/* BACKGROUND TOP-RIGHT AMBIENT LAVENDER GLOW */}
      <div 
        id="ambient-gradient-glow"
        className="absolute top-0 right-0 w-full md:w-[65%] h-[800px] bg-gradient-to-b md:bg-gradient-to-bl from-[rgba(195,180,209,0.35)] via-[rgba(244,239,235,0.7)] to-transparent rounded-bl-[150px] md:rounded-bl-[350px] pointer-events-none -z-10"
      />

      {/* HEADER SECTION */}
      <header 
        id="navbar-site"
        className={`fixed top-0 left-0 right-0 z-40 transition-all duration-300 ${
          isScrolled 
            ? 'bg-brand-warm-bg/90 backdrop-blur-md shadow-sm border-b border-brand-plum-light/50 py-3' 
            : 'bg-transparent py-5'
        }`}
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between">
            
            {/* LOGO BLOCK */}
            <a href="#" className="flex items-center gap-3 group">
              <div className="relative flex items-center justify-center w-10 h-10 rounded-full border border-brand-plum/30 bg-brand-warm-bg/50 group-hover:border-brand-plum transition-all duration-500">
                <Flower2 className="w-5 h-5 text-brand-text-muted group-hover:text-brand-plum group-hover:rotate-45 transition-all duration-700" />
                <div className="absolute inset-0.5 rounded-full border border-dashed border-brand-lavender/30 group-hover:scale-105 transition-transform duration-500" />
              </div>
              <div className="flex flex-col">
                <span className="font-serif text-lg leading-none tracking-[0.14em] text-brand-plum font-semibold">
                  MAISON LUMIÈRE
                </span>
                <span className="font-sans text-[9px] uppercase tracking-[0.25em] text-brand-text-muted mt-0.5 font-medium">
                  DESIGN INTÉRIEUR
                </span>
              </div>
            </a>

            {/* DESKTOP NAVIGATION LINkS */}
            <nav id="desktop-nav" className="hidden md:flex items-center gap-8">
              <a href="#propos" className="font-sans text-[11px] font-semibold tracking-[0.2em] text-brand-text-muted hover:text-brand-plum transition-colors uppercase">
                À propos
              </a>
              <a href="#services" className="font-sans text-[11px] font-semibold tracking-[0.2em] text-brand-text-muted hover:text-brand-plum transition-colors uppercase">
                Services
              </a>
              <a href="#projets" className="font-sans text-[11px] font-semibold tracking-[0.2em] text-brand-text-muted hover:text-brand-plum transition-colors uppercase">
                Projets
              </a>
              <a href="#art-de-vivre" className="font-sans text-[11px] font-semibold tracking-[0.2em] text-brand-text-muted hover:text-brand-plum transition-colors uppercase">
                Journal
              </a>
              <a href="#contact" className="font-sans text-[11px] font-semibold tracking-[0.2em] text-brand-text-muted hover:text-brand-plum transition-colors uppercase">
                Contact
              </a>
            </nav>

            {/* CTA BUTTON */}
            <div className="hidden md:block">
              <button
                id="btn-nav-book"
                onClick={() => { resetBookingForm(); setBookingModalOpen(true); }}
                className="font-serif text-[11px] tracking-[0.15em] text-brand-plum uppercase border border-brand-plum/60 px-6 py-2.5 hover:bg-brand-plum hover:text-white transition-all duration-300"
              >
                PRENDRE RENDEZ-VOUS
              </button>
            </div>

            {/* MOBILE MENU TOGGLE */}
            <div className="flex md:hidden items-center justify-between">
              <button
                id="btn-mobile-toggle"
                onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
                className="p-2 text-brand-plum hover:text-brand-plum-dark"
                aria-label="Toggle navigation menu"
              >
                {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
              </button>
            </div>

          </div>
        </div>
      </header>

      {/* MOBILE DRAWER NAVIGATION OVERLAY */}
      {mobileMenuOpen && (
        <div id="mobile-drawer" className="fixed inset-0 top-[60px] bg-brand-warm-bg z-30 flex flex-col justify-between p-6 transition-all duration-300 md:hidden animate-fade-in">
          <nav className="flex flex-col gap-6 pt-8">
            <a 
              href="#propos" 
              onClick={() => setMobileMenuOpen(false)}
              className="font-serif text-2xl tracking-wider text-brand-plum border-b border-brand-plum-light pb-2"
            >
              À propos
            </a>
            <a 
              href="#services" 
              onClick={() => setMobileMenuOpen(false)}
              className="font-serif text-2xl tracking-wider text-brand-plum border-b border-brand-plum-light pb-2"
            >
              Services
            </a>
            <a 
              href="#projets" 
              onClick={() => setMobileMenuOpen(false)}
              className="font-serif text-2xl tracking-wider text-brand-plum border-b border-brand-plum-light pb-2"
            >
              Projets récents
            </a>
            <a 
              href="#art-de-vivre" 
              onClick={() => setMobileMenuOpen(false)}
              className="font-serif text-2xl tracking-wider text-brand-plum border-b border-brand-plum-light pb-2"
            >
              L’Art du Détail
            </a>
            <a 
              href="#contact" 
              onClick={() => setMobileMenuOpen(false)}
              className="font-serif text-2xl tracking-wider text-brand-plum border-b border-brand-plum-light pb-2"
            >
              Inquiries & Contact
            </a>
          </nav>
          
          <div className="mb-10 flex flex-col gap-4">
            <button
              id="btn-mobile-book"
              onClick={() => {
                setMobileMenuOpen(false);
                resetBookingForm();
                setBookingModalOpen(true);
              }}
              className="w-full font-serif text-[13px] tracking-[0.15em] text-center text-white bg-brand-plum uppercase py-3.5 hover:bg-brand-plum-dark transition-all duration-300 shadow-md"
            >
              PRENDRE RENDEZ-VOUS
            </button>
            <p className="text-center text-xs text-brand-text-muted uppercase tracking-widest font-mono">
              +33 1 42 00 00 00
            </p>
          </div>
        </div>
      )}

      {/* HERO SECTION */}
      <section 
        id="hero-header"
        className="relative pt-[120px] pb-[70px] md:pt-[190px] md:pb-[110px]"
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-[75%] md:max-w-[65%] lg:max-w-[55%] xl:max-w-[52%]">
            
            {/* SUBTITLE ACCENT WITH DELICATE SPARKLE */}
            <div className="flex items-center gap-2 mb-4 animate-pulse">
              <Sparkles className="w-4 h-4 text-brand-lavender" />
              <span className="font-sans text-[11px] font-semibold text-brand-plum tracking-[0.2em] uppercase">
                HAUTE COUTURE INTERIORS
              </span>
            </div>

            {/* MAIN STATEMENT HEADINGS */}
            <h1 
              id="hero-title"
              className="font-serif text-4xl sm:text-5xl md:text-6xl lg:text-7.5xl leading-[1.12] text-brand-plum tracking-[0.012em] font-light mb-6 uppercase fade-in-up md:w-[130%]"
            >
              Créateurs <br />
              <span className="italic font-normal">d’espaces de vie</span> <br />
              raffinés
            </h1>

            {/* SUB-HEAD PARAGRAPH */}
            <p className="font-sans text-sm md:text-base leading-relaxed text-brand-text-muted mb-8 max-w-md font-light">
              Maison Lumière conçoit des intérieurs élégants et intemporels, pensés pour votre style de vie. L’élégance française mariée à l’exigence moderne.
            </p>

            {/* CTA BUTTON */}
            <div className="flex flex-col sm:flex-row items-start gap-4">
              <a 
                id="btn-hero-discover"
                href="#projets"
                className="group flex items-center justify-between gap-6 font-serif text-[12px] tracking-[0.16em] text-white bg-brand-plum hover:bg-brand-plum-dark px-7 py-4 transition-all duration-300 shadow-md hover:shadow-lg uppercase"
              >
                <span>Découvrir nos projets</span>
                <ArrowRight className="w-4 h-4 group-hover:translate-x-1.5 transition-transform duration-300" />
              </a>
              <a
                href="#services"
                className="font-sans text-[11px] font-semibold tracking-[0.2em] text-brand-plum uppercase py-4 px-2 hover:opacity-80 transition-opacity border-b border-brand-plum-light"
              >
                Notre Approche
              </a>
            </div>

          </div>
        </div>
      </section>

      {/* CORE SERVICES 4-COLUMN CARDS SECTION */}
      <section 
        id="services"
        className="py-12 border-y border-brand-plum-light/50 bg-brand-warm-bg/40 relative z-10"
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 divide-y sm:divide-y-0 sm:divide-x divide-brand-plum-light/80">
            
            {/* SERVICE COLUMN 1 */}
            <div className="p-6 md:p-8 flex flex-col items-center text-center group hover:bg-white/40 transition-colors duration-500 rounded-lg">
              <div className="mb-4 text-brand-plum group-hover:scale-110 transition-transform duration-500">
                <Ruler className="w-8 h-8 stroke-[1.2]" />
              </div>
              <h3 className="font-sans text-[12px] tracking-[0.15em] font-semibold text-brand-plum mb-3 uppercase">
                CONCEPTION SUR-MESURE
              </h3>
              <p className="font-sans text-xs text-brand-text-muted leading-relaxed font-light">
                Des intérieurs uniques, pensés pour vous selon votre mode de vie.
              </p>
            </div>

            {/* SERVICE COLUMN 2 */}
            <div className="p-6 md:p-8 flex flex-col items-center text-center group hover:bg-white/40 transition-colors duration-500 rounded-lg">
              <div className="mb-4 text-brand-plum group-hover:scale-110 transition-transform duration-500">
                <Compass className="w-8 h-8 stroke-[1.2]" />
              </div>
              <h3 className="font-sans text-[12px] tracking-[0.15em] font-semibold text-brand-plum mb-3 uppercase">
                ACCOMPAGNEMENT COMPLET
              </h3>
              <p className="font-sans text-xs text-brand-text-muted leading-relaxed font-light">
                De la conception à la réalisation, nous vous guidons à chaque étape.
              </p>
            </div>

            {/* SERVICE COLUMN 3 */}
            <div className="p-6 md:p-8 flex flex-col items-center text-center group hover:bg-white/40 transition-colors duration-500 rounded-lg">
              <div className="mb-4 text-brand-plum group-hover:scale-110 transition-transform duration-500">
                <Sofa className="w-8 h-8 stroke-[1.2]" />
              </div>
              <h3 className="font-sans text-[12px] tracking-[0.15em] font-semibold text-brand-plum mb-3 uppercase">
                MATÉRIAUX D'EXCEPTION
              </h3>
              <p className="font-sans text-xs text-brand-text-muted leading-relaxed font-light">
                Des matières nobles sélectionnées avec soin pour sublimer vos espaces.
              </p>
            </div>

            {/* SERVICE COLUMN 4 */}
            <div className="p-6 md:p-8 flex flex-col items-center text-center group hover:bg-white/40 transition-colors duration-500 rounded-lg">
              <div className="mb-4 text-brand-plum group-hover:scale-110 transition-transform duration-500">
                <Flower2 className="w-8 h-8 stroke-[1.2]" />
              </div>
              <h3 className="font-sans text-[12px] tracking-[0.15em] font-semibold text-brand-plum mb-3 uppercase">
                ART DE VIVRE
              </h3>
              <p className="font-sans text-xs text-brand-text-muted leading-relaxed font-light">
                Un équilibre subtil entre esthétique, confort et fonctionnalité.
              </p>
            </div>

          </div>
        </div>
      </section>

      {/* DETAILED SERVICES ACCORDION & QUOTES */}
      <section id="propos" className="py-16 md:py-24 bg-gradient-to-b from-brand-warm-bg to-brand-warm-bg">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
            
            <div className="lg:col-span-5">
              <span className="font-mono text-xs text-brand-lavender uppercase tracking-widest block mb-2">NOTRE PHILOSOPHIE</span>
              <h2 className="font-serif text-3xl md:text-4xl lg:text-5xl text-brand-plum leading-tight mb-6 tracking-wide uppercase">
                L’ÉQUILIBRE SUBTIL ENTRE <br />
                <span className="italic font-normal text-brand-plum-dark">LUMINO-SCÉNOGRAPHIE</span> <br />
                ET MATÈRE NOBLE
              </h2>
              <p className="font-sans text-sm text-brand-text-muted leading-relaxed mb-6 font-light">
                À l’image des grands maîtres, nous appréhendons la lumière comme un matériau de construction à part entière. Nos agencements cherchent à dompter l’éclat naturel des saisons, structurant les volumes pour révéler subtilement l’éclat soyeux des moquettes, le brossage velouté du marbre violet or, et les veinures profondes du chêne brut.
              </p>
              <div className="space-y-4">
                <div className="flex items-start gap-3">
                  <div className="w-5 h-5 rounded-full bg-brand-plum-light flex items-center justify-center text-brand-plum mt-1">
                    <Award className="w-3.5 h-3.5 text-brand-plum-dark" />
                  </div>
                  <div>
                    <h4 className="font-sans text-xs font-semibold uppercase tracking-wider text-brand-plum">L’Excellence de l’Artisanat Français</h4>
                    <p className="font-sans text-xs text-brand-text-muted font-light">Nos compagnons menuisiers, doreurs et marbriers perpétuent les gestes nobles.</p>
                  </div>
                </div>
                <div className="flex items-start gap-3">
                  <div className="w-5 h-5 rounded-full bg-brand-plum-light flex items-center justify-center text-brand-plum mt-1">
                    <Activity className="w-3.5 h-3.5 text-brand-plum-dark" />
                  </div>
                  <div>
                    <h4 className="font-sans text-xs font-semibold uppercase tracking-wider text-brand-plum">Design Responsable & Durable</h4>
                    <p className="font-sans text-xs text-brand-text-muted font-light">Des bois certifiés locaux, des finitions d'origine naturelle dénuées de solvants.</p>
                  </div>
                </div>
              </div>
            </div>

            <div className="lg:col-span-7 grid grid-cols-1 sm:grid-cols-2 gap-6">
              {SERVICES.map((s) => (
                <div 
                  key={s.id}
                  className="bg-brand-warm-beige/30 hover:bg-white p-8 rounded-lg border border-brand-plum-light/50 transition-all duration-300 hover:shadow-lg group"
                >
                  <span className="font-serif text-3xl italic text-brand-lavender group-hover:text-brand-plum transition-colors duration-300">
                    {s.number}
                  </span>
                  <h3 className="font-serif text-lg tracking-wider text-brand-plum font-semibold uppercase mt-3 mb-2">
                    {s.title}
                  </h3>
                  <p className="font-sans text-xs text-brand-text-muted leading-relaxed font-light mb-3">
                    {s.description}
                  </p>
                  <hr className="border-brand-plum-light my-3 group-hover:border-brand-lavender/60 transition-colors" />
                  <p className="font-sans text-[11px] text-brand-text-muted/80 leading-relaxed font-light italic">
                    {s.details}
                  </p>
                </div>
              ))}
            </div>

          </div>
        </div>
      </section>

      {/* RECENT PROJECTS SECTION */}
      <section 
        id="projets"
        className="py-16 md:py-24 bg-brand-warm-beige/20 border-t border-brand-plum-light/40 relative"
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          
          {/* PROJECTS HEADER ROW */}
          <div className="flex flex-col md:flex-row md:items-end justify-between mb-10 gap-4">
            <div>
              <span className="font-mono text-[10px] uppercase text-brand-lavender tracking-[0.25em] font-bold block mb-2">
                RÉALISATIONS
              </span>
              <h2 className="font-serif text-2xl sm:text-3xl md:text-4xl text-brand-plum tracking-wider uppercase">
                Projets récents
              </h2>
            </div>

            {/* TAB FILTERS */}
            <div className="flex flex-wrap items-center gap-1.5 md:gap-3 bg-brand-warm-beige/60 p-1 rounded-full border border-brand-plum-light/60">
              <button 
                onClick={() => setActiveCategory('all')}
                className={`font-sans text-[10px] tracking-widest font-semibold uppercase px-4 py-2 rounded-full transition-all duration-300 ${
                  activeCategory === 'all' 
                    ? 'bg-brand-plum text-white shadow-sm' 
                    : 'text-brand-text-muted hover:text-brand-plum'
                }`}
              >
                Tout
              </button>
              <button 
                onClick={() => setActiveCategory('residential')}
                className={`font-sans text-[10px] tracking-widest font-semibold uppercase px-4 py-2 rounded-full transition-all duration-300 ${
                  activeCategory === 'residential' 
                    ? 'bg-brand-plum text-white shadow-sm' 
                    : 'text-brand-text-muted hover:text-brand-plum'
                }`}
              >
                Résidentiel
              </button>
              <button 
                onClick={() => setActiveCategory('hotel')}
                className={`font-sans text-[10px] tracking-widest font-semibold uppercase px-4 py-2 rounded-full transition-all duration-300 ${
                  activeCategory === 'hotel' 
                    ? 'bg-brand-plum text-white shadow-sm' 
                    : 'text-brand-text-muted hover:text-brand-plum'
                }`}
              >
                Hôtelier
              </button>
            </div>

            <a 
              href="#contact"
              className="hidden md:flex items-center gap-2 font-sans text-xs tracking-widest text-brand-plum uppercase hover:opacity-80 transition-opacity font-semibold"
            >
              <span>VOIR TOUS LES PROJETS</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </a>
          </div>

          {/* DYNAMIC CARD GRID */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {filteredProjects.map((project) => (
              <div 
                key={project.id}
                id={`project-card-${project.id}`}
                onClick={() => setSelectedProject(project)}
                className="group cursor-pointer flex flex-col h-full bg-white md:bg-transparent md:hover:bg-white rounded-lg p-3 md:p-4 border border-transparent md:hover:border-brand-plum-light/50 md:hover:shadow-xl transition-all duration-500 animate-fade-in"
              >
                {/* PHOTO CONTAINER */}
                <div className="relative overflow-hidden aspect-[4/3] rounded bg-brand-warm-beige mb-4 shadow-sm">
                  {/* HOVER OVERLAY EFFECT */}
                  <div className="absolute inset-0 bg-brand-plum/10 opacity-0 group-hover:opacity-100 transition-opacity duration-500 z-10" />
                  
                  <img 
                    src={project.image} 
                    alt={project.title}
                    referrerPolicy="no-referrer"
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700"
                  />
                  
                  {/* CATEGORY TAG FLOATING */}
                  <span className="absolute top-3 left-3 bg-brand-warm-bg/95 backdrop-blur-sm text-[8.5px] uppercase tracking-[0.2em] px-2.5 py-1 text-brand-plum font-semibold rounded-sm z-20 shadow-sm border border-brand-plum-light/30">
                    {project.categoryLabel}
                  </span>
                </div>

                {/* PROJECT WRITING */}
                <div className="flex flex-col justify-between flex-grow">
                  <div>
                    <h3 className="font-serif text-lg tracking-wider text-brand-plum group-hover:text-brand-plum-dark transition-colors uppercase mb-1">
                      {project.title}
                    </h3>
                    <p className="font-sans text-xs text-brand-text-muted uppercase tracking-widest font-light">
                      {project.location}
                    </p>
                    <p className="font-sans text-[11px] text-brand-text-muted/70 mt-2 line-clamp-2 leading-relaxed">
                      {project.description}
                    </p>
                  </div>
                  
                  <div className="pt-4 mt-4 border-t border-brand-plum-light/40 flex items-center justify-between text-brand-plum text-[11px] font-semibold tracking-widest uppercase">
                    <span>Voir le projet</span>
                    <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform" />
                  </div>
                </div>
              </div>
            ))}
          </div>

        </div>
      </section>

      {/* DETAIL BANNER SECTION (The editorial split row) */}
      <section 
        id="banner-detail"
        className="py-16 md:py-24 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8"
      >
        <div className="grid grid-cols-1 lg:grid-cols-12 bg-zinc-900 overflow-hidden shadow-2xl rounded-2xl">
          
          {/* IMAGE COLUMN */}
          <div className="relative h-[250px] sm:h-[350px] lg:h-auto lg:col-span-5 bg-brand-warm-beige">
            <img 
              src="/src/assets/images/art_detail_shot_1780915828182.png" 
              alt="L'art du détail Maison Lumière"
              referrerPolicy="no-referrer" 
              className="absolute inset-0 w-full h-full object-cover filter brightness-[0.9] saturate-[0.85]"
            />
            {/* Soft mauve atmospheric glow from the photo blending to the right card */}
            <div className="absolute inset-0 bg-gradient-to-r from-transparent via-brand-plum-dark/10 to-brand-plum-dark/40" />
          </div>

          {/* BRAND VERBIAGE COLUMN ON MAUVE GRID */}
          <div className="lg:col-span-7 bg-brand-plum-dark p-8 sm:p-12 md:p-16 flex flex-col justify-center text-white relative">
            
            <div className="absolute top-0 right-0 w-64 h-64 bg-radial-gradient from-brand-plum/20 to-transparent pointer-events-none rounded-full" />
            
            <span className="font-mono text-[9px] uppercase tracking-[0.3em] text-brand-lavender block mb-3">
              PERSPECTIVE & EXIGENCE
            </span>
            
            <h2 className="font-serif text-2xl sm:text-3.5xl lg:text-4xl leading-snug tracking-wider uppercase mb-5">
              L’Art du détail, <br />
              <span className="italic font-normal">L’exigence du beau</span>
            </h2>
            
            <p className="font-sans text-xs sm:text-sm leading-relaxed text-brand-plum-light/80 font-light mb-8 max-w-lg">
              Nous croyons que chaque intérieur raconte une histoire. Notre mission : orchestrer la lumière, marier des textures de lin épais et de bois sculptés pour concevoir des oasis hautement personnalisées, durables et inspirantes, où chaque recoin a sa propre poésie.
            </p>
            
            <div className="flex flex-col sm:flex-row gap-4 items-start">
              <button
                id="btn-detail-inquiry"
                onClick={() => { resetBookingForm(); setBookingModalOpen(true); }}
                className="group inline-flex items-center gap-4 font-serif text-[11px] tracking-widest uppercase text-brand-plum-dark bg-brand-warm-bg hover:bg-white px-6 py-3.5 transition-all duration-300 font-semibold"
              >
                <span>Prendre Conseil</span>
                <ArrowRight className="w-3.5 h-3.5 text-brand-plum group-hover:translate-x-1 transition-transform" />
              </button>
              
              <a 
                href="#services"
                className="font-sans text-[11.5px] uppercase tracking-widest text-brand-lavender hover:text-white py-3 px-2 transition-colors font-medium"
              >
                En Savoir Plus
              </a>
            </div>

          </div>

        </div>
      </section>

      {/* INSTAGRAM GRID WITH STATISTICS & LIGHTBOX INTERACTION */}
      <section 
        id="art-de-vivre"
        className="py-12 border-t border-brand-plum-light/30 bg-brand-warm-beige/10"
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          
          {/* INSTAGRAM GRID HEADER */}
          <div className="flex items-center justify-between mb-8">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-full bg-brand-plum-light/40">
                <Instagram className="w-4 h-4 text-brand-plum" />
              </div>
              <span className="font-sans text-[10px] font-semibold uppercase tracking-[0.2em] text-brand-plum">
                suivez-nous sur instagram
              </span>
            </div>
            <a 
              href="https://instagram.com" 
              target="_blank" 
              rel="noreferrer" 
              className="font-mono text-[10px] tracking-widest text-brand-text-muted hover:text-brand-plum transition-all"
            >
              @MAISONLUMIERE.DESIGN
            </a>
          </div>

          {/* THE GRID (8 IMAGES) */}
          <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-8 gap-3">
            {INSTAGRAM_POSTS.map((post, idx) => {
              const hasLiked = likedPostIds[post.id] || false;
              const likes = instaLikesCount[post.id] ?? post.likes;
              
              return (
                <div 
                  key={`${post.id}-${idx}`}
                  onClick={() => setSelectedInstaPost(post)}
                  className="group relative aspect-square overflow-hidden rounded bg-brand-warm-beige cursor-pointer shadow-sm hover:shadow-md transition-all"
                >
                  <img 
                    src={post.image} 
                    alt={`Instagram grid element ${idx + 1}`}
                    referrerPolicy="no-referrer"
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                  />
                  
                  {/* HOVER INTERACTIVE ACCENT */}
                  <div className="absolute inset-0 bg-brand-plum-dark/60 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex flex-col justify-center items-center gap-3 text-white">
                    <div className="flex items-center gap-1">
                      <button 
                        onClick={(e) => handleToggleLike(post.id, e)}
                        className="p-1 hover:scale-125 transition-transform active:scale-95"
                      >
                        <Heart className={`w-4 h-4 ${hasLiked ? 'fill-red-400 text-red-400' : 'text-white'}`} />
                      </button>
                      <span className="font-mono text-[11px] font-medium">{likes}</span>
                    </div>
                    <div className="flex items-center gap-1">
                      <MessageCircle className="w-3.5 h-3.5" />
                      <span className="font-mono text-[10px]">{post.comments}</span>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>

        </div>
      </section>

      {/* NEWSLETTER INLINED SIGNUP & FULL INQUIRY FORM */}
      <section 
        id="contact"
        className="py-16 md:py-24 bg-brand-warm-beige/30 border-t border-brand-plum-light/50 relative overflow-hidden"
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-12">
            
            {/* DETAILS COLUMN */}
            <div className="lg:col-span-5 flex flex-col justify-between">
              <div>
                <span className="font-mono text-[10px] uppercase text-brand-lavender tracking-[0.25em] font-bold block mb-2">
                  CONTACTS & ACCÈS
                </span>
                <h2 className="font-serif text-3xl md:text-4xl text-brand-plum leading-tight uppercase mb-6">
                  Une idée de projet ? <br />
                  <span className="italic font-normal">Parlons-en ensemble.</span>
                </h2>
                <p className="font-sans text-xs sm:text-sm text-brand-text-muted leading-relaxed font-light mb-8">
                  Que ce soit pour une simple rénovation de salon ou une étude complète d’un complexe hôtelier, notre cabinet saura vous accompagner pour sublimer vos espaces. Nos bureaux sont ouverts sur rendez-vous.
                </p>

                {/* ADRESS & INFO CARDS */}
                <div className="space-y-4">
                  <div className="flex items-center gap-4">
                    <div className="p-2.5 rounded-full bg-brand-plum-light/50 text-brand-plum">
                      <MapPin className="w-4 h-4" />
                    </div>
                    <div>
                      <h4 className="font-sans text-[11px] font-semibold text-brand-plum uppercase">Atelier Principal</h4>
                      <p className="font-sans text-[11.5px] text-brand-text-muted font-light">18 Rue de la Paix, 75002 Paris</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-4">
                    <div className="p-2.5 rounded-full bg-brand-plum-light/50 text-brand-plum">
                      <Phone className="w-4 h-4" />
                    </div>
                    <div>
                      <h4 className="font-sans text-[11px] font-semibold text-brand-plum uppercase">Téléphone</h4>
                      <p className="font-sans text-[11.5px] text-brand-text-muted font-light">+33 1 42 00 00 00</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-4">
                    <div className="p-2.5 rounded-full bg-brand-plum-light/50 text-brand-plum">
                      <Mail className="w-4 h-4" />
                    </div>
                    <div>
                      <h4 className="font-sans text-[11px] font-semibold text-brand-plum uppercase">Secrétariat</h4>
                      <p className="font-sans text-[11.5px] text-brand-text-muted font-light">bonjour@maisonlumiere.fr</p>
                    </div>
                  </div>
                </div>
              </div>

              {/* REALISTIC NEWSLETTER INLINED WITH TOAST FEEDBACK */}
              <div className="mt-12 bg-white/60 p-6 rounded-lg border border-brand-plum-light/50 max-w-sm">
                <h4 className="font-serif text-sm uppercase text-brand-plum font-semibold tracking-wider mb-2">Notre Journal d'inspiration</h4>
                <p className="font-sans text-[11px] text-brand-text-muted leading-relaxed mb-4">Rejoignez 4,000+ passionnés de design et recevez trimestriellement nos dossiers tendances.</p>
                
                {contactSubmitted ? (
                  <div className="bg-brand-plum-light text-brand-plum text-xs px-3 py-2 rounded font-medium text-center animate-pulse">
                    Merci ! Votre inscription est validée. ✨
                  </div>
                ) : (
                  <form onSubmit={(e) => { e.preventDefault(); if (contactEmail) setContactSubmitted(true); }} className="flex gap-2">
                    <input 
                      type="email" 
                      placeholder="Votre adresse email" 
                      value={contactEmail}
                      onChange={(e) => setContactEmail(e.target.value)}
                      required
                      className="flex-grow text-xs px-3 py-2 rounded border border-brand-plum-light/80 bg-white placeholder:text-brand-text-muted/50 focus:outline-none focus:border-brand-plum text-brand-text"
                    />
                    <button 
                      type="submit" 
                      className="bg-brand-plum hover:bg-brand-plum-dark text-white text-[11px] font-semibold tracking-wider uppercase px-4 rounded transition-colors"
                    >
                      S'abonner
                    </button>
                  </form>
                )}
              </div>

            </div>

            {/* INTERACTIVE FORM COLUMN */}
            <div className="lg:col-span-7 bg-white p-8 sm:p-10 rounded-xl border border-brand-plum-light/60 shadow-xl">
              <h3 className="font-serif text-xl tracking-wider text-brand-plum uppercase mb-2">Écrivez-nous un message</h3>
              <p className="font-sans text-xs text-brand-text-muted font-light mb-6">Nous vous recontactons sous 24 heures pour échanger autour de vos envies de rénovation.</p>

              {contactFormSubmitted ? (
                <div className="text-center py-12">
                  <div className="w-12 h-12 bg-green-100 text-green-700 rounded-full flex items-center justify-center mx-auto mb-4 scale-110">
                    <Send className="w-6 h-6 animate-bounce" />
                  </div>
                  <h4 className="font-serif text-lg text-brand-plum uppercase tracking-wider mb-2">Message envoyé avec succès</h4>
                  <p className="font-sans text-xs text-brand-text-muted max-w-sm mx-auto leading-relaxed">
                    Un architecte conseil de l’agence Maison Lumière étudiera votre demande et vous appellera très prochainement.
                  </p>
                  <button
                    onClick={() => setContactFormSubmitted(false)}
                    className="mt-6 font-sans text-[10px] tracking-widest text-brand-plum uppercase border-b border-brand-plum pb-1 font-semibold hover:opacity-85 transition-opacity"
                  >
                    Envoyer un autre message
                  </button>
                </div>
              ) : (
                <form onSubmit={handleContactSubmit} className="space-y-4">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-[10px] font-semibold uppercase text-brand-plum tracking-wider mb-1">Votre Nom complet</label>
                      <input 
                        type="text" 
                        required
                        value={contactFormCustom.name}
                        onChange={(e) => setContactFormCustom({...contactFormCustom, name: e.target.value})}
                        placeholder="Ex: Jean Dupont"
                        className="w-full text-xs px-3 py-2.5 rounded border border-brand-plum-light/80 text-brand-text placeholder:text-brand-text-muted/40 bg-zinc-50 focus:bg-white focus:outline-none focus:border-brand-plum"
                      />
                    </div>
                    <div>
                      <label className="block text-[10px] font-semibold uppercase text-brand-plum tracking-wider mb-1">Votre Email</label>
                      <input 
                        type="email" 
                        required
                        value={contactFormCustom.email}
                        onChange={(e) => setContactFormCustom({...contactFormCustom, email: e.target.value})}
                        placeholder="Ex: jean@mail.com"
                        className="w-full text-xs px-3 py-2.5 rounded border border-brand-plum-light/80 text-brand-text placeholder:text-brand-text-muted/40 bg-zinc-50 focus:bg-white focus:outline-none focus:border-brand-plum"
                      />
                    </div>
                  </div>
                  
                  <div>
                    <label className="block text-[10px] font-semibold uppercase text-brand-plum tracking-wider mb-1">Dites-nous en plus sur votre projet</label>
                    <textarea 
                      rows={4} 
                      required
                      value={contactFormCustom.message}
                      onChange={(e) => setContactFormCustom({...contactFormCustom, message: e.target.value})}
                      placeholder="Indiquez par exemple la surface, la localisation géographique et le type de rénovation envisagé (Appartement, commerce, boutique...)"
                      className="w-full text-xs px-3 py-2.5 rounded border border-brand-plum-light/80 text-brand-text placeholder:text-brand-text-muted/40 bg-zinc-50 focus:bg-white focus:outline-none focus:border-brand-plum resize-none"
                    />
                  </div>

                  <div className="pt-2">
                    <button 
                      type="submit" 
                      className="w-full bg-brand-plum hover:bg-brand-plum-dark text-white font-serif text-[11px] tracking-widest uppercase py-3.5 transition-colors shadow-md rounded"
                    >
                      Envoyer ma Demande d'Étude
                    </button>
                  </div>
                </form>
              )}
            </div>

          </div>
        </div>
      </section>

      {/* BRAND FOOTER */}
      <footer 
        id="footer-main"
        className="bg-brand-warm-bg border-t border-brand-plum-light/60 py-12 md:py-16 text-xs text-brand-text-muted relative z-10"
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-12 gap-10">
            
            {/* BRANDING */}
            <div className="lg:col-span-4 flex flex-col justify-between">
              <div>
                <div className="flex items-center gap-3 mb-4">
                  <div className="flex items-center justify-center w-8 h-8 rounded-full border border-brand-plum/30">
                    <Flower2 className="w-4 h-4 text-brand-plum" />
                  </div>
                  <span className="font-serif text-base font-semibold uppercase tracking-[0.15em] text-brand-plum">
                    MAISON LUMIÈRE
                  </span>
                </div>
                <p className="font-sans text-[11px] font-light leading-relaxed max-w-xs">
                  Agence d’architecture d’intérieur et de scénographie d’art. Nous concevons à vos côtés les espaces nobles et mémorables de demain.
                </p>
              </div>

              {/* SOCIAL MEDIA BADGES */}
              <div className="flex items-center gap-4 mt-6">
                <a href="https://instagram.com" target="_blank" rel="noreferrer" className="p-2 border border-brand-plum-light hover:border-brand-plum rounded-full text-brand-plum/70 hover:text-brand-plum hover:bg-white transition-all">
                  <Instagram className="w-4 h-4" />
                </a>
                <a href="https://pinterest.com" target="_blank" rel="noreferrer" className="p-2 border border-brand-plum-light hover:border-brand-plum rounded-full text-brand-plum/70 hover:text-brand-plum hover:bg-white transition-all">
                  {/* Using custom simple text/letter or visual circle for pinterest as requested using standard react icon */}
                  <svg className="w-4 h-4 fill-current" viewBox="0 0 24 24">
                    <path d="M12 0C5.37 0 0 5.37 0 12c0 5.08 3.16 9.4 7.63 11.13-.1-.95-.2-2.4.04-3.44.22-.94 1.4-5.96 1.4-5.96s-.36-.72-.36-1.78c0-1.66.96-2.9 2.16-2.9 1.02 0 1.51.77 1.51 1.68 0 1.03-.65 2.56-.99 3.98-.28 1.19.6 2.16 1.77 2.16 2.12 0 3.76-2.24 3.76-5.48 0-2.87-2.06-4.88-5.01-4.88-3.41 0-5.42 2.56-5.42 5.21 0 1.03.4 2.14.9 2.74.1.12.11.23.08.35-.09.37-.29 1.18-.33 1.34-.05.22-.17.27-.39.17-1.46-.68-2.37-2.82-2.37-4.54 0-3.7 2.69-7.1 7.75-7.1 4.07 0 7.23 2.9 7.23 6.77 0 4.04-2.55 7.3-6.08 7.3-1.19 0-2.31-.62-2.69-1.35l-.73 2.79c-.26 1.01-1 2.27-1.49 3.08C8.54 23.77 10.2 24 12 24c6.63 0 12-5.37 12-12S18.63 0 12 0z"/>
                  </svg>
                </a>
                <a href="https://linkedin.com" target="_blank" rel="noreferrer" className="p-2 border border-brand-plum-light hover:border-brand-plum rounded-full text-brand-plum/70 hover:text-brand-plum hover:bg-white transition-all">
                  <svg className="w-4 h-4 fill-current" viewBox="0 0 24 24">
                    <path d="M19 0h-14c-2.761 0-5 2.239-5 5v14c0 2.761 2.239 5 5 5h14c2.762 0 5-2.239 5-5v-14c0-2.761-2.238-5-5-5zm-11 19h-3v-11h3v11zm-1.5-12.268c-.966 0-1.75-.779-1.75-1.75s.784-1.75 1.75-1.75 1.75.779 1.75 1.75-.784 1.75-1.75 1.75zm13.5 12.268h-3v-5.604c0-3.368-4-3.113-4 0v5.604h-3v-11h3v1.765c1.396-2.586 7-2.777 7 2.476v6.759z"/>
                  </svg>
                </a>
              </div>
            </div>

            {/* LINKS COLUMNS */}
            <div className="sm:col-span-1 lg:col-span-2">
              <h4 className="font-sans text-[10px] uppercase tracking-widest text-brand-plum font-semibold mb-4">
                L'Agence
              </h4>
              <ul className="space-y-2.5 text-[11px] font-light">
                <li><a href="#propos" className="hover:text-brand-plum transition-colors">À Propos</a></li>
                <li><a href="#propos" className="hover:text-brand-plum transition-colors">Notre Approche</a></li>
                <li><a href="#propos" className="hover:text-brand-plum transition-colors">L'Équipe d’Art</a></li>
                <li><a href="#contact" className="hover:text-brand-plum transition-colors">Carrières</a></li>
              </ul>
            </div>

            <div className="sm:col-span-1 lg:col-span-2">
              <h4 className="font-sans text-[10px] uppercase tracking-widest text-brand-plum font-semibold mb-4">
                Services
              </h4>
              <ul className="space-y-2.5 text-[11px] font-light">
                <li><a href="#services" className="hover:text-brand-plum transition-colors">Sur-Mesure</a></li>
                <li><a href="#projets" className="hover:text-brand-plum transition-colors">Réalisations</a></li>
                <li><a href="#art-de-vivre" className="hover:text-brand-plum transition-colors">Le Journal</a></li>
                <li><a href="#contact" className="hover:text-brand-plum transition-colors">Presse</a></li>
              </ul>
            </div>

            <div className="sm:col-span-1 lg:col-span-2">
              <h4 className="font-sans text-[10px] uppercase tracking-widest text-brand-plum font-semibold mb-4">
                Légal
              </h4>
              <ul className="space-y-2.5 text-[11px] font-light">
                <li><a href="#" className="hover:text-brand-plum transition-colors">Mentions Légales</a></li>
                <li><a href="#" className="hover:text-brand-plum transition-colors">Politique RGPD</a></li>
                <li><a href="#" className="hover:text-brand-plum transition-colors">CGV de l’Agence</a></li>
                <li><a href="#" className="hover:text-brand-plum transition-colors">Cookies</a></li>
              </ul>
            </div>

            {/* QUICK CONTACTS */}
            <div className="sm:col-span-1 lg:col-span-2">
              <h4 className="font-sans text-[10px] uppercase tracking-widest text-brand-plum font-semibold mb-4">
                Contact
              </h4>
              <p className="font-sans text-[11px] leading-relaxed font-light mb-3">
                Inquiries: <br />
                <a href="mailto:bonjour@maisonlumiere.fr" className="font-semibold text-brand-plum hover:underline">
                  bonjour@maisonlumiere.fr
                </a>
              </p>
              <p className="font-sans text-[11px] leading-relaxed font-light">
                Call Secrétariat:<br />
                <span className="font-semibold text-brand-plum">+33 1 42 00 00 00</span>
              </p>
            </div>

          </div>

          <hr className="border-brand-plum-light/50 my-8 md:my-10" />

          {/* REAL COPYRIGHT */}
          <div className="flex flex-col sm:flex-row items-center justify-between gap-4 text-[10.5px] uppercase tracking-widest text-brand-text-muted/70">
            <span>© 2026 MAISON LUMIÈRE - TOUS DROITS RÉSERVÉS</span>
            <span>CRAFTED IN PARIS & MILAN</span>
          </div>

        </div>
      </footer>


      {/* INTERACTIVE COMPONENT 1: THE APPOINTMENT SCHEDULER MODAL */}
      {bookingModalOpen && (
        <div 
          id="booking-overlay"
          className="fixed inset-0 bg-brand-plum/60 backdrop-blur-sm z-50 flex items-center justify-center p-4 overflow-y-auto animate-fade-in"
          onClick={() => setBookingModalOpen(false)}
        >
          <div 
            className="relative bg-brand-warm-bg w-full max-w-lg rounded-xl overflow-hidden shadow-2xl border border-brand-plum-light/60 animate-fade-in-up"
            onClick={(e) => e.stopPropagation()}
          >
            {/* CLOSE BUTTON */}
            <button 
              onClick={() => setBookingModalOpen(false)}
              className="absolute top-4 right-4 p-1.5 rounded-full bg-white/80 hover:bg-white text-brand-plum hover:scale-105 transition-all"
            >
              <X className="w-4 h-4" />
            </button>

            {/* DECORATIVE LINE ACCENT */}
            <div className="h-1 bg-gradient-to-r from-brand-plum via-brand-lavender to-brand-plum" />

            <div className="p-6 sm:p-8">
              
              {bookingSubmitted ? (
                <div className="text-center py-10">
                  <div className="w-16 h-16 bg-brand-plum-light text-brand-plum rounded-full flex items-center justify-center mx-auto mb-6 scale-110">
                    <Calendar className="w-8 h-8 animate-pulse" />
                  </div>
                  <h3 className="font-serif text-2xl text-brand-plum uppercase tracking-wider mb-3">Demande enregistrée</h3>
                  <p className="font-sans text-xs text-brand-text-muted leading-relaxed max-w-sm mx-auto mb-8 font-light">
                    Votre demande de rendez-vous pour un projet de type <strong className="text-brand-plum-dark">{bookingForm.projectType}</strong> (Budget : {bookingForm.budget}) a bien été prise en compte par le cabinet.
                  </p>
                  <p className="font-sans text-xs font-semibold text-brand-text mb-6">
                    Nous vous appellerons le matin par téléphone au <span className="text-brand-plum">{bookingForm.phone || 'numéro renseigné'}</span>.
                  </p>
                  <button 
                    onClick={() => setBookingModalOpen(false)}
                    className="bg-brand-plum hover:bg-brand-plum-dark text-white font-serif text-[11px] tracking-widest uppercase px-6 py-3 transition-colors rounded shadow-md"
                  >
                    FERMER LE MODULE
                  </button>
                </div>
              ) : (
                <>
                  <div className="mb-6">
                    <span className="font-mono text-[9px] uppercase tracking-widest text-brand-lavender font-bold">PROJET SUR-MESURE</span>
                    <h3 className="font-serif text-2xl text-brand-plum uppercase tracking-wider">Demander une Consultation</h3>
                    <p className="font-sans text-xs text-brand-text-muted font-light mt-1">Prenons le temps d’imaginer vos futurs espaces de vie.</p>
                  </div>

                  <form onSubmit={handleBookingSubmit} className="space-y-4">
                    
                    {/* Name */}
                    <div>
                      <label className="block text-[10px] font-semibold uppercase tracking-wider text-brand-plum mb-1">Nom complet</label>
                      <input 
                        type="text" 
                        required 
                        value={bookingForm.name}
                        onChange={(e) => setBookingForm({...bookingForm, name: e.target.value})}
                        placeholder="Ex: Alexandre de Beauvau"
                        className="w-full text-xs px-3 py-2.5 rounded border border-brand-plum-light bg-white focus:outline-none focus:border-brand-plum text-brand-text"
                      />
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      {/* Email */}
                      <div>
                        <label className="block text-[10px] font-semibold uppercase tracking-wider text-brand-plum mb-1">Email</label>
                        <input 
                          type="email" 
                          required 
                          value={bookingForm.email}
                          onChange={(e) => setBookingForm({...bookingForm, email: e.target.value})}
                          placeholder="Ex: alexandre@luxury.fr"
                          className="w-full text-xs px-3 py-2.5 rounded border border-brand-plum-light bg-white focus:outline-none focus:border-brand-plum text-brand-text"
                        />
                      </div>
                      
                      {/* Tel */}
                      <div>
                        <label className="block text-[10px] font-semibold uppercase tracking-wider text-brand-plum mb-1">Téléphone</label>
                        <input 
                          type="tel" 
                          required
                          value={bookingForm.phone}
                          onChange={(e) => setBookingForm({...bookingForm, phone: e.target.value})}
                          placeholder="Ex: +33 6 12 34 56 78"
                          className="w-full text-xs px-3 py-2.5 rounded border border-brand-plum-light bg-white focus:outline-none focus:border-brand-plum text-brand-text"
                        />
                      </div>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      {/* Project type select */}
                      <div>
                        <label className="block text-[10px] font-semibold uppercase tracking-wider text-brand-plum mb-1">Type de Bien</label>
                        <select 
                          value={bookingForm.projectType}
                          onChange={(e) => setBookingForm({...bookingForm, projectType: e.target.value})}
                          className="w-full text-xs px-3 py-2.5 rounded border border-brand-plum-light bg-white focus:outline-none focus:border-brand-plum text-brand-text"
                        >
                          <option value="Appartement Haussmannien">Appartement Haussmannien</option>
                          <option value="Maison Contemporaine">Maison Contemporaine</option>
                          <option value="Hôtel Particulier">Hôtel Particulier</option>
                          <option value="Commerce de prestige">Commerce / Boutique de luxe</option>
                          <option value="Autre">Autre projet / Conseil</option>
                        </select>
                      </div>

                      {/* Estimated budget selection */}
                      <div>
                        <label className="block text-[10px] font-semibold uppercase tracking-wider text-brand-plum mb-1">Budget prévisionnel</label>
                        <select 
                          value={bookingForm.budget}
                          onChange={(e) => setBookingForm({...bookingForm, budget: e.target.value})}
                          className="w-full text-xs px-3 py-2.5 rounded border border-brand-plum-light bg-white focus:outline-none focus:border-brand-plum text-brand-text"
                        >
                          <option value="Moins de 50k€">Moins de 50,000 €</option>
                          <option value="50k - 100k€">50,000 € - 100,000 €</option>
                          <option value="100k - 250k€">100,000 € - 250,000 €</option>
                          <option value="Plus de 250k€">Plus de 250,000 €</option>
                        </select>
                      </div>
                    </div>

                    {/* Preferences */}
                    <div className="bg-brand-warm-beige/40 p-3 rounded border border-brand-plum-light/50">
                      <span className="block text-[9px] font-semibold uppercase tracking-wider text-brand-plum mb-2">Moment idéal pour être rappelé(e)</span>
                      <div className="flex gap-4">
                        <label className="flex items-center gap-2 text-xs text-brand-text cursor-pointer">
                          <input 
                            type="radio" 
                            name="timePref" 
                            checked={bookingForm.timePreference === 'morning'}
                            onChange={() => setBookingForm({...bookingForm, timePreference: 'morning'})}
                            className="text-brand-plum focus:ring-brand-plum" 
                          />
                          <span>En matinée (9h - 12h)</span>
                        </label>
                        <label className="flex items-center gap-2 text-xs text-brand-text cursor-pointer">
                          <input 
                            type="radio" 
                            name="timePref"
                            checked={bookingForm.timePreference === 'afternoon'}
                            onChange={() => setBookingForm({...bookingForm, timePreference: 'afternoon'})}
                            className="text-brand-plum focus:ring-brand-plum" 
                          />
                          <span>L'après-midi (14h - 18h)</span>
                        </label>
                      </div>
                    </div>

                    {/* Message */}
                    <div>
                      <label className="block text-[10px] font-semibold uppercase tracking-wider text-brand-plum mb-1">Votre message ou souhaits d’aménagement</label>
                      <textarea 
                        rows={3} 
                        value={bookingForm.message}
                        onChange={(e) => setBookingForm({...bookingForm, message: e.target.value})}
                        placeholder="Ex: Souhaite décloisonner la salle à manger et intégrer une suite parentale avec dressing."
                        className="w-full text-xs px-3 py-2 bg-white rounded border border-brand-plum-light focus:outline-none focus:border-brand-plum text-brand-text resize-none"
                      />
                    </div>

                    <button 
                      type="submit" 
                      disabled={bookingLoading}
                      className="w-full bg-brand-plum hover:bg-brand-plum-dark text-white font-serif text-[11px] tracking-widest uppercase py-3.5 transition-colors shadow-md rounded disabled:opacity-50 flex items-center justify-center gap-2 font-semibold"
                    >
                      {bookingLoading ? (
                        <>
                          <svg className="animate-spin h-4 w-4 text-white" fill="none" viewBox="0 0 24 24">
                            <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
                            <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z" />
                          </svg>
                          <span>ENREGISTREMENT...</span>
                        </>
                      ) : (
                        <span>PLANIFIER LE RENDEZ-VOUS</span>
                      )}
                    </button>

                  </form>
                </>
              )}

            </div>
          </div>
        </div>
      )}


      {/* INTERACTIVE COMPONENT 2: PROJECTS CAROUSEL QUICK-VIEW DETAILS MODAL */}
      {selectedProject && (
        <div 
          id="project-overlay"
          className="fixed inset-0 bg-brand-plum/70 backdrop-blur-md z-50 flex items-center justify-center p-4 overflow-y-auto animate-fade-in"
          onClick={() => setSelectedProject(null)}
        >
          <div 
            className="relative bg-brand-warm-bg w-full max-w-4xl rounded-2xl overflow-hidden shadow-2xl border border-brand-plum-light/50 animate-fade-in-up"
            onClick={(e) => e.stopPropagation()}
          >
            {/* Carousel navigation buttons inside modal */}
            <button 
              onClick={handlePrevProject}
              className="absolute left-4 top-1/2 -translate-y-1/2 z-20 p-2.5 rounded-full bg-white/90 hover:bg-white text-brand-plum hover:scale-110 transition-all shadow-md"
              aria-label="Projet précédent"
            >
              <ChevronLeft className="w-5 h-5" />
            </button>
            <button 
              onClick={handleNextProject}
              className="absolute right-4 top-1/2 -translate-y-1/2 z-20 p-2.5 rounded-full bg-white/90 hover:bg-white text-brand-plum hover:scale-110 transition-all shadow-md"
              aria-label="Projet suivant"
            >
              <ChevronRight className="w-5 h-5" />
            </button>

            {/* Close Button top-right */}
            <button 
              onClick={() => setSelectedProject(null)}
              className="absolute top-4 right-4 z-20 p-2 rounded-full bg-black/40 hover:bg-black/60 text-white transition-all hover:scale-105"
            >
              <X className="w-4 h-4" />
            </button>

            <div className="grid grid-cols-1 lg:grid-cols-12">
              
              {/* IMAGE HEADER */}
              <div className="relative h-[250px] sm:h-[350px] lg:h-[500px] lg:col-span-6 bg-brand-warm-beige">
                <img 
                  src={selectedProject.image} 
                  alt={selectedProject.title}
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/50 via-transparent to-transparent pointer-events-none" />
                <span className="absolute bottom-4 left-4 bg-white/90 backdrop-blur-sm text-[9px] uppercase tracking-widest px-3 py-1 text-brand-plum font-semibold rounded-sm">
                  {selectedProject.categoryLabel}
                </span>
              </div>

              {/* STATS & SUMMARY COLUMN */}
              <div className="p-6 sm:p-8 lg:p-10 lg:col-span-6 flex flex-col justify-between h-auto lg:h-[500px] overflow-y-auto">
                <div>
                  <span className="font-mono text-[9px] uppercase tracking-[0.25em] text-brand-lavender font-bold block mb-1">FICHE TECHNIQUE</span>
                  <h3 className="font-serif text-xl sm:text-2xl text-brand-plum uppercase tracking-wider mb-4 border-b border-brand-plum-light pb-2">
                    {selectedProject.title}
                  </h3>

                  {/* SPECIFICATION CHIPS */}
                  <div className="grid grid-cols-3 gap-3 bg-brand-warm-beige/50 p-4 rounded-lg mb-6 text-center border border-brand-plum-light/50">
                    <div>
                      <span className="block text-[8.5px] uppercase tracking-widest text-brand-text-muted/80 mb-0.5">LOCALISATION</span>
                      <strong className="font-sans text-xs text-brand-plum-dark font-semibold">{selectedProject.location}</strong>
                    </div>
                    <div>
                      <span className="block text-[8.5px] uppercase tracking-widest text-brand-text-muted/80 mb-0.5">SURFACE</span>
                      <strong className="font-sans text-xs text-brand-plum-dark font-semibold">{selectedProject.area}</strong>
                    </div>
                    <div>
                      <span className="block text-[8.5px] uppercase tracking-widest text-brand-text-muted/80 mb-0.5 font-light">LIVRAISON</span>
                      <strong className="font-sans text-xs text-brand-plum-dark font-semibold">{selectedProject.year}</strong>
                    </div>
                  </div>

                  {/* DETAILED ANALYSIS */}
                  <h4 className="font-sans text-[10px] uppercase tracking-wider text-brand-plum font-semibold mb-2">Histoire & Concept</h4>
                  <p className="font-sans text-xs leading-relaxed text-brand-text-muted font-light mb-6">
                    {selectedProject.description}
                  </p>

                  {/* BULLET INSPIRATION POINTS */}
                  <h4 className="font-sans text-[10px] uppercase tracking-wider text-brand-plum font-semibold mb-2">Interventions clés d’aménagement:</h4>
                  <ul className="space-y-2 text-xs text-brand-text font-light pl-1">
                    {selectedProject.details.map((detail, index) => (
                      <li key={index} className="flex items-start gap-2">
                        <span className="inline-block w-1.5 h-1.5 rounded-full bg-brand-lavender mt-1.5 shrink-0" />
                        <span>{detail}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                {/* MODAL INTERACTIONS FOOTER */}
                <div className="mt-8 pt-4 border-t border-brand-plum-light/55 flex gap-4">
                  <button
                    onClick={() => {
                      setSelectedProject(null);
                      resetBookingForm();
                      setBookingForm(prev => ({
                        ...prev,
                        projectType: selectedProject.title,
                        message: `Bonjour, j’ai vu votre réalisation "${selectedProject.title}" à ${selectedProject.location} et je souhaite avoir un aperçu ou un conseil similaire...`
                      }));
                      setBookingModalOpen(true);
                    }}
                    className="flex-grow text-center text-white bg-brand-plum hover:bg-brand-plum-dark font-serif text-[10px] tracking-widest uppercase py-3 transition-colors shadow"
                  >
                    PRENDRE CONSEIL SUR CE STYLE
                  </button>
                  <button 
                    onClick={() => setSelectedProject(null)}
                    className="px-4 py-3 border border-brand-plum-light text-brand-text-muted hover:text-brand-plum text-[10px] tracking-widest uppercase font-sans hover:bg-white transition-all font-semibold"
                  >
                    Fermer
                  </button>
                </div>

              </div>

            </div>
          </div>
        </div>
      )}


      {/* INTERACTIVE COMPONENT 3: INSTAGRAM POST LIGHTBOX */}
      {selectedInstaPost && (
        <div 
          id="insta-overlay"
          className="fixed inset-0 bg-black/80 backdrop-blur-md z-50 flex items-center justify-center p-4"
          onClick={() => setSelectedInstaPost(null)}
        >
          <div 
            className="relative bg-brand-warm-bg w-full max-w-2xl rounded-xl overflow-hidden shadow-2xl border border-brand-plum-light/50 flex flex-col md:flex-row max-h-[90vh] md:h-[450px]"
            onClick={(e) => e.stopPropagation()}
          >
            {/* CLOSE ACTION BUTTON */}
            <button 
              onClick={() => setSelectedInstaPost(null)}
              className="absolute top-3 right-3 z-30 p-1.5 rounded-full bg-black/60 hover:bg-black text-white hover:scale-105 transition-all"
            >
              <X className="w-4 h-4" />
            </button>

            {/* ART WORK ILLUSTRATION COLUMN */}
            <div className="w-full md:w-1/2 h-[250px] md:h-full bg-zinc-900 flex-shrink-0 relative">
              <img 
                src={selectedInstaPost.image} 
                alt="Instagram Close-up View" 
                referrerPolicy="no-referrer"
                className="w-full h-full object-cover"
              />
            </div>

            {/* COMMENTS & INTERPRETATION COLUMN */}
            <div className="w-full md:w-1/2 p-6 flex flex-col justify-between overflow-y-auto h-full">
              <div>
                
                {/* ACCOUNT PROFILE TITLE ROW */}
                <div className="flex items-center gap-2 mb-4 pb-3 border-b border-brand-plum-light">
                  <div className="w-7 h-7 rounded-full border border-brand-plum/40 bg-brand-lavender/30 flex items-center justify-center">
                    <Flower2 className="w-3.5 h-3.5 text-brand-plum" />
                  </div>
                  <div>
                    <h4 className="font-serif text-xs font-semibold tracking-wider text-brand-plum uppercase leading-none">MAISON LUMIÈRE</h4>
                    <span className="text-[9px] text-brand-text-muted font-mono">Paris, France</span>
                  </div>
                </div>

                {/* POST CAPTION */}
                <div className="font-sans text-xs leading-relaxed text-brand-text mb-6">
                  {selectedInstaPost.caption}
                </div>

                {/* RECENT MOCK FEEDBACK COMMENTS */}
                <div className="space-y-3 mt-4">
                  <span className="block font-sans text-[9px] uppercase tracking-wider text-brand-text-muted/80 font-bold mb-2">Commentaires</span>
                  <div className="text-[11px] leading-relaxed">
                    <strong className="text-brand-plum uppercase tracking-wider mr-1 text-[10px]">sophie.m</strong> Une pure merveille ! Ce travail sur le marbre est divin. ❤️
                  </div>
                  <div className="text-[11px] leading-relaxed">
                    <strong className="text-brand-plum uppercase tracking-wider mr-1 text-[10px]">interiors_mag</strong> Minimalist perfection. We love the neutral palettes.
                  </div>
                </div>

              </div>

              {/* POST ENGAGEMENT CONTROLS ROOT */}
              <div className="pt-4 border-t border-brand-plum-light mt-6">
                <div className="flex items-center justify-between text-brand-plum mb-3">
                  <div className="flex items-center gap-4">
                    
                    {/* LIKE TOGGLE */}
                    <button 
                      onClick={(e) => handleToggleLike(selectedInstaPost.id, e)}
                      className="flex items-center gap-1.5 p-1 hover:scale-105 active:scale-95 transition-all text-xs"
                    >
                      <Heart className={`w-4 h-4 ${likedPostIds[selectedInstaPost.id] ? 'fill-red-400 text-red-400' : 'text-brand-plum'}`} />
                      <strong className="font-mono">{instaLikesCount[selectedInstaPost.id] ?? selectedInstaPost.likes} j'aime</strong>
                    </button>
                    
                    {/* COMMENT COUNTER ICON */}
                    <div className="flex items-center gap-1 text-xs">
                      <MessageCircle className="w-4 h-4" />
                      <span className="font-mono">{selectedInstaPost.comments}</span>
                    </div>

                  </div>

                  <span className="text-[9.5px] font-mono text-brand-text-muted">IL Y A 3 JOURS</span>
                </div>

                {/* BOOK CONSULT ACTION BUTTON */}
                <button
                  onClick={() => {
                    setSelectedInstaPost(null);
                    resetBookingForm();
                    setBookingForm(prev => ({
                      ...prev,
                      message: `Bonjour, je suis très sensible au visuel Instagram "${selectedInstaPost.caption.substring(0, 40)}..." et j’aimerais échanger pour adapter des finitions similaires dans ma future rénovation.`
                    }));
                    setBookingModalOpen(true);
                  }}
                  className="w-full text-center bg-brand-plum-light text-brand-plum hover:bg-brand-plum hover:text-white font-serif text-[9px] tracking-widest uppercase py-2 transition-all font-semibold rounded"
                >
                  S'INSPIRER DE CE VOLUMES
                </button>
              </div>

            </div>

          </div>
        </div>
      )}

    </div>
  );
}
