export interface Project {
  id: string;
  title: string;
  category: 'residential' | 'hotel' | 'commercial';
  categoryLabel: string;
  location: string;
  image: string;
  year: string;
  area: string;
  description: string;
  details: string[];
}

export interface Service {
  id: string;
  title: string;
  description: string;
  details: string;
  number: string;
}

export interface InstagramPost {
  id: string;
  image: string;
  likes: number;
  comments: number;
  caption: string;
}
