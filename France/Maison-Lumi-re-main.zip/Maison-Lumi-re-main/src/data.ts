import { Project, Service, InstagramPost } from './types';

export const SERVICES: Service[] = [
  {
    id: 's1',
    number: '01',
    title: 'CONCEPTION SUR-MESURE',
    description: 'Des intérieurs uniques, pensés pour vous.',
    details: 'De l’esquisse initiale aux plans techniques détaillés, nous concevons des plans d’aménagement 2D et 3D optimisés pour sublimer chaque m² selon votre mode de vie.'
  },
  {
    id: 's2',
    number: '02',
    title: 'ACCOMPAGNEMENT COMPLET',
    description: 'De la conception à la réalisation, nous vous guidons à chaque étape.',
    details: 'Nous gérons l’intégralité de votre projet : choix des artisans, suivi esthétique du chantier, respect des délais, et gestion budgétaire pour un projet clé en main serein.'
  },
  {
    id: 's3',
    number: '03',
    title: "MATÉRIAUX D'EXCEPTION",
    description: 'Des matières nobles sélectionnées avec soin pour sublimer vos espaces.',
    details: 'Marbres rares, bois précieux, textiles haute couture et finitions en laiton brossé. Nous collaborons avec des artisans d’art pour façonner des détails remarquables.'
  },
  {
    id: 's4',
    number: '04',
    title: 'ART DE VIVRE',
    description: 'Un équilibre subtil entre esthétique et fonctionnalité.',
    details: 'Car un bel espace se doit d’être agréable à habiter. Nous soignons l’éclairage, l’isolation acoustique, la fluidité de circulation et l’harmonie générale des sens.'
  }
];

export const PROJECTS: Project[] = [
  {
    id: 'p1',
    title: 'APPARTEMENT HAUSSMANNIEN',
    category: 'residential',
    categoryLabel: 'Résidentiel',
    location: 'Paris 8e',
    image: '/src/assets/images/haussmann_apt_1780915771286.png',
    year: '2024',
    area: '145 m²',
    description: 'Rénovation complète d’un appartement Haussmannien classique dans le 8ème arrondissement. Nous avons conservé le charme d’époque avec les moulures d’origine tout en y apportant une touche contemporaine luxueuse.',
    details: [
      'Restauration minutieuse des moulures parisiennes à la feuille d’or',
      'Création d’une verrière sur-mesure reliant la cuisine au salon double',
      'Sélection de mobilier de créateurs italiens aux teintes mauve et écru',
      'Salle de bain habillée d’un marbre de Carrare blanc d’exception'
    ]
  },
  {
    id: 'p2',
    title: 'MAISON CONTEMPORAINE',
    category: 'residential',
    categoryLabel: 'Résidentiel',
    location: 'Biarritz',
    image: '/src/assets/images/contemporary_house_1780915790169.png',
    year: '2025',
    area: '310 m²',
    description: 'Une villa contemporaine d’exception face à l’océan. Les pièces ont été orchestrées pour maximiser la vue imprenable tout en proposant des textures chaleureuses de bois clair, de lin et de béton ciré.',
    details: [
      'Grand séjour traversant baigné de lumière naturelle',
      'Table de salle à manger majestueuse en chêne brut sculptée sur place',
      'Aménagement d’une cuisine d’architecte minimaliste noire mate et bois foncés',
      'Chambres d’amis avec terrasses privatives et fauteuils de lin violet'
    ]
  },
  {
    id: 'p3',
    title: 'HÔTEL PARTICULIER',
    category: 'hotel',
    categoryLabel: 'Hôtelier',
    location: 'Bordeaux',
    image: '/src/assets/images/hotel_particulier_1780915808005.png',
    year: '2025',
    area: '480 m²',
    description: 'Transformation d’une demeure bourgeoise du XVIIIe siècle en un hôtel de charme à la française. L’alliance de papiers peints damassés dorés, de velours violet profond et de dorures crée un havre d’intimité absolue.',
    details: [
      'Conception de 6 suites hôtelières thématiques d’époque',
      'Remplacement des cheminées d’époque par des poêles discrets en céramique',
      'Têtes de lit monumentales rembourrées en velours haute couture',
      'Éclairage d’ambiance scénographié avec variateurs intelligents'
    ]
  }
];

export const INSTAGRAM_POSTS: InstagramPost[] = [
  {
    id: 'i1',
    image: '/src/assets/images/insta_detail_molding_1780915847411.png',
    likes: 1240,
    comments: 42,
    caption: 'L’élégance intemporelle des moulures restaurées à la main. Chaque détail compte. ✨ #MaisonLumiere #ParisianStyle #InteriorDetails'
  },
  {
    id: 'i2',
    image: '/src/assets/images/insta_detail_textile_1780915862129.png',
    likes: 890,
    comments: 18,
    caption: 'Sélection de matières précieuses pour notre futur projet parisien. Soies drapées, lin brut et nuances de prune divine. 🧵 #DesignTextile #LuxuryFabrics'
  },
  {
    id: 'i3',
    image: '/src/assets/images/insta_detail_faucet_1780915878383.png',
    likes: 1542,
    comments: 67,
    caption: 'Laiton brossé & veines violacées du marbre Calacatta. L’art culinaire ou le raffinement de la salle de bain. 💫 #KitchenBath #LuxuryDetails #MarbleLove'
  },
  {
    id: 'i4',
    image: '/src/assets/images/insta_detail_chair_1780915894895.png',
    likes: 2104,
    comments: 53,
    caption: 'Un coin de lecture propice à la sérénité. Bouclé crème, table minérale et ombres portées. 🛋️ #BoucleChair #CozyCorner #MutedColors'
  },
  // We double them to form an elegant grid of 8 cards in our grid, but update statistics & captions for variation
  {
    id: 'i5',
    image: '/src/assets/images/insta_detail_molding_1780915847411.png',
    likes: 934,
    comments: 12,
    caption: 'Jeux d’ombres et de moulures sous la douce lumière matinale. #QuietLuxury #ClassicDesign'
  },
  {
    id: 'i6',
    image: '/src/assets/images/insta_detail_textile_1780915862129.png',
    likes: 1105,
    comments: 29,
    caption: 'Chaudes nuances de lavande et reflets d’argenterie d’art pour nos décors. #MaisonLumiere #TextureDesign'
  },
  {
    id: 'i7',
    image: '/src/assets/images/insta_detail_faucet_1780915878383.png',
    likes: 1378,
    comments: 34,
    caption: 'Des finitions dorées d’une pureté absolue. Matériaux nobles d’exception. #BathroomDesign #LuxuryLiving'
  },
  {
    id: 'i8',
    image: '/src/assets/images/insta_detail_chair_1780915894895.png',
    likes: 1729,
    comments: 48,
    caption: 'L’équilibre des lignes et des matières dans nos intérieurs sur-mesure. #DesignInspiration #OrganicTextures'
  }
];
