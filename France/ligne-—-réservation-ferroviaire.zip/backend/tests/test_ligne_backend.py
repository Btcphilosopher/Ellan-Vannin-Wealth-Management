import unittest
from datetime import datetime, timedelta, timezone

from backend.app.domain import BookingRecord, PassengerComposition
from backend.app.providers import (
    HorizonHandoffAdapter,
    LigneDirectDemoAdapter,
    is_allowlisted_seller_url,
)
from backend.app.storage import ObjectStorageClient
from backend.app.timezone_utils import (
    compute_elapsed_minutes,
    format_local_hhmm,
    zoned_wall_time_to_utc,
)
from backend.app.workers import reconcile_pending_bookings


class TestLigneBackend(unittest.TestCase):
    def test_station_identity_isolation(self) -> None:
        adapter = LigneDirectDemoAdapter()
        ply = adapter.search_offers("FRPLY", "FRLPD", "2027-06-18", PassengerComposition(adults=1))
        self.assertEqual(len(ply), 2)
        self.assertEqual([x["offer"].total_known_cents for x in ply], [4900, 5900])

        pmo = adapter.search_offers("FRPMO", "FRLPD", "2027-06-18", PassengerComposition(adults=1))
        self.assertEqual(pmo, [])

    def test_iana_dst_and_cross_timezone(self) -> None:
        # Spring forward in Paris (2027-03-28): 22:45 -> 06:15+1 is 390 minutes
        dep = zoned_wall_time_to_utc("2027-03-27", "22:45", "Europe/Paris", day_offset=0)
        arr = zoned_wall_time_to_utc("2027-03-27", "06:15", "Europe/Paris", day_offset=1)
        self.assertEqual(compute_elapsed_minutes(dep, arr), 390)

        # Cross-timezone Paris (CET) -> London (GMT)
        p_dep = zoned_wall_time_to_utc("2027-01-15", "10:13", "Europe/Paris")
        l_arr = zoned_wall_time_to_utc("2027-01-15", "11:30", "Europe/London")
        self.assertEqual(compute_elapsed_minutes(p_dep, l_arr), 137)
        self.assertEqual(format_local_hhmm(l_arr, "Europe/London"), "11:30")

    def test_offer_expiry_revalidation(self) -> None:
        adapter = LigneDirectDemoAdapter()
        offers = adapter.search_offers("FRPLY", "FRLPD", "2027-06-18", PassengerComposition(adults=1))
        offer = offers[0]["offer"]
        self.assertEqual(adapter.revalidate_offer(offer)["status"], "unchanged")

        offer.expires_at = (datetime.now(timezone.utc) - timedelta(minutes=5)).isoformat()
        self.assertEqual(adapter.revalidate_offer(offer)["status"], "expired")

    def test_seller_redirect_allowlist(self) -> None:
        handoff = HorizonHandoffAdapter()
        self.assertFalse(handoff.capabilities()["integrated_booking"])
        self.assertTrue(handoff.capabilities()["seller_handoff"])
        self.assertTrue(is_allowlisted_seller_url("https://horizon-rail-demo.ligne.example/handoff?offer=1"))
        self.assertFalse(is_allowlisted_seller_url("https://malicious.example/redirect"))
        self.assertFalse(is_allowlisted_seller_url("javascript:alert(1)"))

    def test_reconciliation_worker_resolves_uncertain_booking(self) -> None:
        rec = BookingRecord(
            booking_id="bkg_py_1",
            user_id="usr_1",
            booking_reference="LG-777001",
            provider_order_ref="ORD-LD-777001",
            provider_id="rail_direct_demo",
            booking_mode="integrated_demo",
            state="reconciliation_required",
            total_paid_cents=4900,
        )
        summary = reconcile_pending_bookings([rec])
        self.assertEqual(summary["checked"], 1)
        self.assertEqual(summary["resolved"], 1)
        self.assertEqual(rec.state, "ticket_issued")
        self.assertTrue(rec.ticket_issued)

    def test_object_storage_path_confinement(self) -> None:
        client = ObjectStorageClient()
        key = client.store_document("tickets/demo-test.txt", b"SPECIMEN")
        self.assertEqual(client.read_document(key), b"SPECIMEN")


if __name__ == "__main__":
    unittest.main()
