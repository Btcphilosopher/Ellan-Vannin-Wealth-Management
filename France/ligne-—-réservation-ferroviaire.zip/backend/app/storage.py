import os
from pathlib import Path
from typing import Optional


class ObjectStorageClient:
    """Stores authorised specimen tickets and payment receipts in S3/MinIO or local fallback."""

    def __init__(self) -> None:
        self.endpoint = os.environ.get("OBJECT_STORAGE_ENDPOINT", "").strip()
        self.local_root = Path(".ligne-data/objects")

    def store_document(self, object_key: str, content: bytes) -> str:
        safe_key = object_key.lstrip("/").replace("..", "")
        self.local_root.mkdir(parents=True, exist_ok=True)
        target = (self.local_root / safe_key).resolve()
        if not str(target).startswith(str(self.local_root.resolve()) + os.sep):
            raise ValueError("Invalid object key")
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(content)
        return safe_key

    def read_document(self, object_key: str) -> Optional[bytes]:
        safe_key = object_key.lstrip("/").replace("..", "")
        target = (self.local_root / safe_key).resolve()
        if not str(target).startswith(str(self.local_root.resolve()) + os.sep):
            return None
        if not target.exists():
            return None
        return target.read_bytes()
