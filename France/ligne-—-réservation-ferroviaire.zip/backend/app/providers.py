from abc import ABC, abstractmethod
from datetime import datetime, timedelta, timezone
from typing import Dict, List, Optional
from urllib.parse import urlencode, urlparse
import uuid

from .domain import (
    FareOffer,
    PassengerComposition,
    PriceComponent,
    StationNode,
    StructuredCondition,
)
from .timezone_utils import compute_elapsed_minutes, format_local_hhmm, zoned_wall_time_to_utc

ALLOWED_SELLER_ORIGINS = {
    "https://horizon-rail-demo.ligne.example",
    "https://billets-demo.ligne.example",
}

STATIONS: Dict[str, StationNode] = {
    "FRPLY": StationNode("FRPLY", "Paris Gare de Lyon", "Paris", "FR", "individual_station", "Europe/Paris"),
    "FRPMO": StationNode("FRPMO", "Paris Montparnasse", "Paris", "FR", "individual_station", "Europe/Paris"),
    "FRPNO": StationNode("FRPNO", "Paris Gare du Nord", "Paris", "FR", "individual_station", "Europe/Paris"),
    "FRPES": StationNode("FRPES", "Paris Gare de l'Est", "Paris", "FR", "individual_station", "Europe/Paris"),
    "FRPAR_ALL": StationNode(
        "FRPAR_ALL",
        "Paris (toutes gares)",
        "Paris",
        "FR",
        "city_group",
        "Europe/Paris",
        ["FRPLY", "FRPMO", "FRPNO", "FRPES"],
    ),
    "FRLPD": StationNode("FRLPD", "Lyon Part-Dieu", "Lyon", "FR", "individual_station", "Europe/Paris"),
    "FRBDX": StationNode("FRBDX", "Bordeaux Saint-Jean", "Bordeaux", "FR", "individual_station", "Europe/Paris"),
    "FRMRS": StationNode("FRMRS", "Marseille Saint-Charles", "Marseille", "FR", "individual_station", "Europe/Paris"),
    "FRXSB": StationNode("FRXSB", "Strasbourg", "Strasbourg", "FR", "individual_station", "Europe/Paris"),
    "GBSTP": StationNode("GBSTP", "Londres Saint-Pancras International", "Londres", "GB", "individual_station", "Europe/London"),
}


def is_allowlisted_seller_url(url: str) -> bool:
    parsed = urlparse(url)
    if parsed.scheme != "https" or not parsed.netloc:
        return False
    origin = f"{parsed.scheme}://{parsed.netloc}"
    return origin in ALLOWED_SELLER_ORIGINS


def expand_station_ids(station_id: str) -> set:
    st = STATIONS.get(station_id)
    if not st:
        return set()
    if st.kind == "city_group" and st.child_station_ids:
        return set(st.child_station_ids)
    return {st.id}


class RailProviderAdapter(ABC):
    provider_id: str
    provider_name: str

    @abstractmethod
    def capabilities(self) -> Dict[str, bool]:
        raise NotImplementedError

    @abstractmethod
    def search_offers(
        self,
        from_station_id: str,
        to_station_id: str,
        travel_date: str,
        pax: PassengerComposition,
        travel_class: str = "2",
    ) -> List[Dict]:
        raise NotImplementedError

    @abstractmethod
    def revalidate_offer(self, offer: FareOffer) -> Dict:
        raise NotImplementedError


class LigneDirectDemoAdapter(RailProviderAdapter):
    provider_id = "rail_direct_demo"
    provider_name = "Ligne Direct Démo"

    def capabilities(self) -> Dict[str, bool]:
        return {
            "station_lookup": True,
            "journey_search": True,
            "fare_search": True,
            "offer_revalidation": True,
            "integrated_booking": True,
            "booking_status_lookup": True,
            "ticket_retrieval": True,
            "cancellation_refund": True,
            "seller_handoff": False,
        }

    def search_offers(
        self,
        from_station_id: str,
        to_station_id: str,
        travel_date: str,
        pax: PassengerComposition,
        travel_class: str = "2",
    ) -> List[Dict]:
        origins = expand_station_ids(from_station_id)
        dests = expand_station_ids(to_station_id)
        if "FRPLY" not in origins or "FRLPD" not in dests:
            return []

        now = datetime.now(timezone.utc)
        exp = now + timedelta(minutes=15)
        total_pax = pax.adults + pax.youths + pax.seniors
        fixtures = [
            ("LD 6601", "08:00", "10:00", 4900 if travel_class == "2" else 7900, "Tarif Standard", "with_fee", 1900),
            ("LD 6605", "09:30", "11:30", 5900 if travel_class == "2" else 8900, "Tarif Flexible", "allowed", 0),
        ]
        results = []
        for train, dep_t, arr_t, unit_cents, product, cond_status, fee_cents in fixtures:
            dep_utc = zoned_wall_time_to_utc(travel_date, dep_t, "Europe/Paris")
            arr_utc = zoned_wall_time_to_utc(travel_date, arr_t, "Europe/Paris")
            total_cents = unit_cents * total_pax
            j_ref = f"JRN-{train.replace(' ', '')}-{travel_date.replace('-', '')}"
            offer = FareOffer(
                offer_id=f"OFR-{uuid.uuid4().hex[:8].upper()}",
                provider_id=self.provider_id,
                provider_name=self.provider_name,
                booking_mode="integrated_demo",
                journey_reference=j_ref,
                passenger_composition=pax,
                discount_cards_applied=[],
                travel_class="1" if travel_class == "1" else "2",
                ticket_product=product,
                included_services=["Bagage inclus", "Prise électrique"],
                train_binding="train_specific",
                route_or_operator_restrictions=f"Valable sur {train}",
                change_conditions=StructuredCondition(
                    status=cond_status,  # type: ignore[arg-type]
                    summary=f"Conditions échange ({cond_status})",
                    fee_cents=fee_cents,
                ),
                refund_conditions=StructuredCondition(
                    status=cond_status,  # type: ignore[arg-type]
                    summary=f"Conditions remboursement ({cond_status})",
                    fee_cents=fee_cents,
                ),
                mandatory_price_components=[
                    PriceComponent("RAIL_FARE", "Billet ferroviaire", total_cents, True)
                ],
                currency="EUR",
                quoted_at=now.isoformat(),
                expires_at=exp.isoformat(),
                total_known_cents=total_cents,
                has_unknown_mandatory_fees=False,
            )
            results.append(
                {
                    "journey_reference": j_ref,
                    "departure_local": format_local_hhmm(dep_utc, "Europe/Paris"),
                    "arrival_local": format_local_hhmm(arr_utc, "Europe/Paris"),
                    "duration_minutes": compute_elapsed_minutes(dep_utc, arr_utc),
                    "offer": offer,
                }
            )
        return results

    def revalidate_offer(self, offer: FareOffer) -> Dict:
        if offer.is_expired():
            return {"status": "expired", "offer": offer}
        return {"status": "unchanged", "offer": offer}

    def lookup_booking_status(self, provider_order_ref: str) -> str:
        if provider_order_ref.startswith("ORD-"):
            return "confirmed"
        return "failed"


class HorizonHandoffAdapter(RailProviderAdapter):
    provider_id = "horizon_handoff"
    provider_name = "Horizon Distribution"

    def capabilities(self) -> Dict[str, bool]:
        return {
            "station_lookup": True,
            "journey_search": True,
            "fare_search": True,
            "offer_revalidation": True,
            "integrated_booking": False,
            "booking_status_lookup": False,
            "ticket_retrieval": False,
            "cancellation_refund": False,
            "seller_handoff": True,
        }

    def search_offers(
        self,
        from_station_id: str,
        to_station_id: str,
        travel_date: str,
        pax: PassengerComposition,
        travel_class: str = "2",
    ) -> List[Dict]:
        return []

    def revalidate_offer(self, offer: FareOffer) -> Dict:
        return {"status": "unchanged", "offer": offer}

    def build_handoff_url(self, offer: FareOffer) -> str:
        qs = urlencode({"offer": offer.offer_id, "journey": offer.journey_reference})
        url = f"https://horizon-rail-demo.ligne.example/handoff?{qs}"
        if not is_allowlisted_seller_url(url):
            raise ValueError("Seller redirect URL is not allowlisted")
        return url
