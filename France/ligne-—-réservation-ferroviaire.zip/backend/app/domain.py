from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Dict, List, Literal, Optional

StationKind = Literal["individual_station", "city_group", "transport_hub"]
BookingMode = Literal["integrated_demo", "seller_handoff"]
BookingState = Literal[
    "offer_selected",
    "revalidation_pending",
    "reservation_pending",
    "reservation_held",
    "payment_pending",
    "payment_confirmed",
    "booking_confirmation_pending",
    "booking_confirmed",
    "ticket_issuance_pending",
    "ticket_issued",
    "failed",
    "reconciliation_required",
]


@dataclass
class StationNode:
    id: str
    name: str
    city: str
    country: str
    kind: StationKind
    iana_timezone: str
    child_station_ids: List[str] = field(default_factory=list)


@dataclass
class PassengerComposition:
    adults: int = 1
    youths: int = 0
    seniors: int = 0


@dataclass
class PriceComponent:
    code: str
    label: str
    amount_cents: Optional[int]
    mandatory: bool
    unknown_amount: bool = False


@dataclass
class StructuredCondition:
    status: Literal["allowed", "with_fee", "non_modifiable", "unknown"]
    summary: str
    fee_cents: Optional[int] = None


@dataclass
class FareOffer:
    offer_id: str
    provider_id: str
    provider_name: str
    booking_mode: BookingMode
    journey_reference: str
    passenger_composition: PassengerComposition
    discount_cards_applied: List[str]
    travel_class: Literal["1", "2"]
    ticket_product: str
    included_services: List[str]
    train_binding: Literal["train_specific", "day_flexible", "unknown"]
    route_or_operator_restrictions: str
    change_conditions: StructuredCondition
    refund_conditions: StructuredCondition
    mandatory_price_components: List[PriceComponent]
    currency: str
    quoted_at: str
    expires_at: str
    total_known_cents: int
    has_unknown_mandatory_fees: bool = False

    def is_expired(self, now: Optional[datetime] = None) -> bool:
        ref = now or datetime.now(timezone.utc)
        exp = datetime.fromisoformat(self.expires_at.replace("Z", "+00:00"))
        return exp < ref


@dataclass
class BookingRecord:
    booking_id: str
    user_id: str
    booking_reference: str
    provider_order_ref: str
    provider_id: str
    booking_mode: BookingMode
    state: BookingState
    total_paid_cents: int
    currency: str = "EUR"
    state_history: List[Dict[str, str]] = field(default_factory=list)
    ticket_issued: bool = False
    is_simulated_ticket: bool = True
    watermark_text: str = "DÉMONSTRATION — NON VALABLE POUR VOYAGER"
