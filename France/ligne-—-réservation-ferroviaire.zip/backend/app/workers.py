from datetime import datetime, timezone
from typing import Dict, List

from .domain import BookingRecord
from .providers import LigneDirectDemoAdapter


def reconcile_pending_bookings(bookings: List[BookingRecord]) -> Dict[str, int]:
    """Queries provider by stable provider_order_ref without duplicating orders."""
    adapter = LigneDirectDemoAdapter()
    checked = 0
    resolved = 0

    for bkg in bookings:
        if bkg.state not in ("reconciliation_required", "booking_confirmation_pending"):
            continue
        checked += 1
        outcome = adapter.lookup_booking_status(bkg.provider_order_ref)
        now = datetime.now(timezone.utc).isoformat()
        if outcome == "confirmed":
            bkg.state = "booking_confirmed"
            bkg.state_history.append(
                {
                    "state": "booking_confirmed",
                    "timestamp": now,
                    "note": f"Confirmé via {bkg.provider_order_ref}",
                }
            )
            bkg.state = "ticket_issued"
            bkg.ticket_issued = True
            bkg.state_history.append(
                {
                    "state": "ticket_issued",
                    "timestamp": now,
                    "note": "Billet spécimen émis après réconciliation",
                }
            )
            resolved += 1

    return {"checked": checked, "resolved": resolved}


if __name__ == "__main__":
    print("LIGNE reconciliation worker prêt.")
