from dataclasses import asdict
from datetime import datetime, timezone
from typing import Dict, Optional
import uuid

from fastapi import FastAPI, Header, HTTPException
from pydantic import BaseModel

from .domain import BookingRecord, PassengerComposition
from .providers import STATIONS, HorizonHandoffAdapter, LigneDirectDemoAdapter
from .storage import ObjectStorageClient
from .workers import reconcile_pending_bookings

app = FastAPI(
    title="LIGNE — Réservation ferroviaire API",
    version="0.1.0",
    description="API backend Python/FastAPI du prototype indépendant LIGNE.",
)

direct_adapter = LigneDirectDemoAdapter()
handoff_adapter = HorizonHandoffAdapter()
storage = ObjectStorageClient()

BOOKINGS_DB: Dict[str, BookingRecord] = {}
IDEMPOTENCY_DB: Dict[str, Dict] = {}


class CheckoutPayload(BaseModel):
    user_id: str
    from_station_id: str
    to_station_id: str
    travel_date: str
    total_cents: int
    simulate_uncertain_outcome: bool = False


@app.get("/health")
def health() -> Dict[str, str]:
    return {"status": "ok", "service": "ligne-fastapi"}


@app.get("/stations")
def list_stations(q: str = "") -> Dict:
    ql = q.strip().lower()
    items = [
        asdict(st)
        for st in STATIONS.values()
        if not ql or ql in st.name.lower() or ql in st.city.lower() or ql in st.id.lower()
    ]
    return {"stations": items}


@app.get("/journeys/search")
def search_journeys(
    from_id: str = "FRPLY",
    to_id: str = "FRLPD",
    out_date: str = "2027-06-18",
    adults: int = 1,
    youths: int = 0,
    seniors: int = 0,
    travel_class: str = "2",
) -> Dict:
    if from_id == to_id:
        raise HTTPException(status_code=400, detail="Les gares doivent être distinctes.")
    pax = PassengerComposition(adults=adults, youths=youths, seniors=seniors)
    offers = direct_adapter.search_offers(from_id, to_id, out_date, pax, travel_class)
    return {
        "results": [
            {**row, "offer": asdict(row["offer"])}
            for row in offers
        ],
        "providers": {
            direct_adapter.provider_id: direct_adapter.capabilities(),
            handoff_adapter.provider_id: handoff_adapter.capabilities(),
        },
    }


@app.post("/bookings/checkout")
def checkout_booking(
    payload: CheckoutPayload,
    idempotency_key: Optional[str] = Header(default=None),
) -> Dict:
    if not idempotency_key:
        raise HTTPException(status_code=400, detail="Idempotency-Key requis.")
    if idempotency_key in IDEMPOTENCY_DB:
        return IDEMPOTENCY_DB[idempotency_key]

    booking_id = f"bkg_{uuid.uuid4().hex[:8]}"
    booking_ref = f"LG-{uuid.uuid4().hex[:6].upper()}"
    order_ref = f"ORD-LD-{booking_ref[3:]}"
    now = datetime.now(timezone.utc).isoformat()

    state = "reconciliation_required" if payload.simulate_uncertain_outcome else "ticket_issued"
    record = BookingRecord(
        booking_id=booking_id,
        user_id=payload.user_id,
        booking_reference=booking_ref,
        provider_order_ref=order_ref,
        provider_id="rail_direct_demo",
        booking_mode="integrated_demo",
        state=state,  # type: ignore[arg-type]
        total_paid_cents=payload.total_cents,
        state_history=[
            {"state": "payment_confirmed", "timestamp": now, "note": "Paiement simulé validé"},
            {"state": state, "timestamp": now, "note": "Traitement fournisseur"},
        ],
        ticket_issued=(state == "ticket_issued"),
    )
    BOOKINGS_DB[booking_id] = record
    if record.ticket_issued:
        storage.store_document(
            f"tickets/{booking_id}.txt",
            f"DÉMONSTRATION — NON VALABLE POUR VOYAGER\nDossier {booking_ref}".encode("utf-8"),
        )
    resp = {"booking": asdict(record)}
    IDEMPOTENCY_DB[idempotency_key] = resp
    return resp


@app.post("/reconciliation/run")
def run_reconciliation() -> Dict[str, int]:
    return reconcile_pending_bookings(list(BOOKINGS_DB.values()))
