from datetime import datetime, timedelta, timezone
from zoneinfo import ZoneInfo


def zoned_wall_time_to_utc(
    date_str: str,
    time_str: str,
    iana_tz: str,
    day_offset: int = 0,
) -> datetime:
    year, month, day = [int(x) for x in date_str.split("-")]
    hour, minute = [int(x) for x in time_str.split(":")]
    base_date = datetime(year, month, day, hour, minute, tzinfo=ZoneInfo(iana_tz))
    if day_offset:
        # Preserve wall-clock local time on the destination day across DST transitions
        target_day = datetime(year, month, day) + timedelta(days=day_offset)
        base_date = datetime(
            target_day.year,
            target_day.month,
            target_day.day,
            hour,
            minute,
            tzinfo=ZoneInfo(iana_tz),
        )
    return base_date.astimezone(timezone.utc)


def format_local_hhmm(utc_dt: datetime, iana_tz: str) -> str:
    local_dt = utc_dt.astimezone(ZoneInfo(iana_tz))
    return local_dt.strftime("%H:%M")


def compute_elapsed_minutes(dep_utc: datetime, arr_utc: datetime) -> int:
    return max(1, int((arr_utc - dep_utc).total_seconds() // 60))
