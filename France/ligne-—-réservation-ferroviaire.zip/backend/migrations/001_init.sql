-- LIGNE PostgreSQL Schema Migration 001
-- Separates scheduled services, journey itineraries, fare offers, seat reservations,
-- bookings, payments, idempotency keys, issued tickets, refunds, and audit logs.

CREATE TABLE IF NOT EXISTS stations (
  id VARCHAR(32) PRIMARY KEY,
  name VARCHAR(160) NOT NULL,
  city VARCHAR(120) NOT NULL,
  country_code CHAR(2) NOT NULL,
  kind VARCHAR(32) NOT NULL CHECK (kind IN ('individual_station', 'city_group', 'transport_hub')),
  iana_timezone VARCHAR(64) NOT NULL,
  child_station_ids TEXT[] DEFAULT '{}',
  accessibility_level VARCHAR(32) NOT NULL DEFAULT 'unknown',
  accessibility_summary TEXT NOT NULL DEFAULT '',
  accessibility_source VARCHAR(160) NOT NULL DEFAULT 'Non renseigné',
  accessibility_updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS scheduled_services (
  service_id VARCHAR(64) PRIMARY KEY,
  train_number VARCHAR(32) NOT NULL,
  operator_name VARCHAR(120) NOT NULL,
  service_category VARCHAR(64) NOT NULL,
  origin_station_id VARCHAR(32) NOT NULL REFERENCES stations(id),
  destination_station_id VARCHAR(32) NOT NULL REFERENCES stations(id),
  departure_local_time TIME NOT NULL,
  arrival_local_time TIME NOT NULL,
  day_offset INTEGER NOT NULL DEFAULT 0
);

CREATE TABLE IF NOT EXISTS journey_itineraries (
  journey_reference VARCHAR(96) PRIMARY KEY,
  origin_station_id VARCHAR(32) NOT NULL REFERENCES stations(id),
  destination_station_id VARCHAR(32) NOT NULL REFERENCES stations(id),
  departure_utc TIMESTAMPTZ NOT NULL,
  arrival_utc TIMESTAMPTZ NOT NULL,
  total_duration_minutes INTEGER NOT NULL,
  changes_count INTEGER NOT NULL DEFAULT 0,
  segments_json JSONB NOT NULL,
  disruption_json JSONB NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS fare_offers (
  offer_id VARCHAR(96) PRIMARY KEY,
  provider_id VARCHAR(64) NOT NULL,
  booking_mode VARCHAR(32) NOT NULL CHECK (booking_mode IN ('integrated_demo', 'seller_handoff')),
  journey_reference VARCHAR(96) NOT NULL,
  passenger_composition JSONB NOT NULL,
  discount_cards_applied TEXT[] DEFAULT '{}',
  travel_class CHAR(1) NOT NULL CHECK (travel_class IN ('1', '2')),
  ticket_product VARCHAR(120) NOT NULL,
  included_services TEXT[] DEFAULT '{}',
  train_binding VARCHAR(32) NOT NULL,
  route_or_operator_restrictions TEXT NOT NULL,
  change_conditions JSONB NOT NULL,
  refund_conditions JSONB NOT NULL,
  mandatory_price_components JSONB NOT NULL,
  total_known_cents INTEGER NOT NULL,
  has_unknown_mandatory_fees BOOLEAN NOT NULL DEFAULT FALSE,
  currency CHAR(3) NOT NULL DEFAULT 'EUR',
  quoted_at TIMESTAMPTZ NOT NULL,
  expires_at TIMESTAMPTZ NOT NULL
);

CREATE TABLE IF NOT EXISTS users (
  user_id VARCHAR(64) PRIMARY KEY,
  email VARCHAR(255) UNIQUE NOT NULL,
  display_name VARCHAR(120) NOT NULL,
  role VARCHAR(24) NOT NULL CHECK (role IN ('traveler', 'admin')),
  password_hash TEXT NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS bookings (
  booking_id VARCHAR(64) PRIMARY KEY,
  user_id VARCHAR(64) NOT NULL REFERENCES users(user_id),
  booking_reference VARCHAR(32) UNIQUE NOT NULL,
  provider_order_ref VARCHAR(64) UNIQUE NOT NULL,
  provider_id VARCHAR(64) NOT NULL,
  booking_mode VARCHAR(32) NOT NULL,
  state VARCHAR(48) NOT NULL,
  state_history JSONB NOT NULL,
  outward_itinerary JSONB NOT NULL,
  outward_offer JSONB NOT NULL,
  return_itinerary JSONB,
  return_offer JSONB,
  passengers JSONB NOT NULL,
  contact_email VARCHAR(255) NOT NULL,
  total_paid_cents INTEGER NOT NULL,
  currency CHAR(3) NOT NULL DEFAULT 'EUR',
  cancellation_status VARCHAR(32) NOT NULL DEFAULT 'active',
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS seat_reservations (
  reservation_id VARCHAR(64) PRIMARY KEY,
  booking_id VARCHAR(64) NOT NULL REFERENCES bookings(booking_id) ON DELETE CASCADE,
  provider_id VARCHAR(64) NOT NULL,
  journey_reference VARCHAR(96) NOT NULL,
  coach VARCHAR(32) NOT NULL,
  seat_numbers TEXT[] NOT NULL,
  held_until TIMESTAMPTZ NOT NULL,
  status VARCHAR(24) NOT NULL
);

CREATE TABLE IF NOT EXISTS idempotency_keys (
  idempotency_key VARCHAR(128) PRIMARY KEY,
  booking_id VARCHAR(64) REFERENCES bookings(booking_id),
  response_payload JSONB NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS payments (
  payment_id VARCHAR(64) PRIMARY KEY,
  idempotency_key VARCHAR(128) UNIQUE NOT NULL,
  booking_id VARCHAR(64) NOT NULL REFERENCES bookings(booking_id),
  amount_cents INTEGER NOT NULL,
  currency CHAR(3) NOT NULL DEFAULT 'EUR',
  method_label VARCHAR(80) NOT NULL,
  masked_reference VARCHAR(32) NOT NULL,
  state VARCHAR(24) NOT NULL,
  provider_event_ids TEXT[] DEFAULT '{}',
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS issued_tickets (
  ticket_id VARCHAR(64) PRIMARY KEY,
  booking_id VARCHAR(64) NOT NULL REFERENCES bookings(booking_id),
  is_simulated BOOLEAN NOT NULL DEFAULT TRUE,
  watermark_text VARCHAR(160) NOT NULL,
  ticket_number VARCHAR(64) NOT NULL,
  object_storage_key VARCHAR(255),
  issued_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS refund_records (
  refund_id VARCHAR(64) PRIMARY KEY,
  booking_id VARCHAR(64) NOT NULL REFERENCES bookings(booking_id),
  payment_id VARCHAR(64) NOT NULL REFERENCES payments(payment_id),
  requested_amount_cents INTEGER NOT NULL,
  penalty_cents INTEGER NOT NULL,
  net_refund_cents INTEGER NOT NULL,
  reason TEXT NOT NULL,
  state VARCHAR(24) NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS saved_itineraries (
  saved_id VARCHAR(64) PRIMARY KEY,
  user_id VARCHAR(64) NOT NULL REFERENCES users(user_id),
  label VARCHAR(160) NOT NULL,
  itinerary_json JSONB NOT NULL,
  quoted_cents INTEGER NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS support_cases (
  case_id VARCHAR(64) PRIMARY KEY,
  booking_id VARCHAR(64) REFERENCES bookings(booking_id),
  user_email VARCHAR(255) NOT NULL,
  category VARCHAR(32) NOT NULL,
  summary TEXT NOT NULL,
  status VARCHAR(24) NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS audit_logs (
  audit_id VARCHAR(64) PRIMARY KEY,
  actor VARCHAR(160) NOT NULL,
  action VARCHAR(80) NOT NULL,
  target_type VARCHAR(48) NOT NULL,
  target_id VARCHAR(96) NOT NULL,
  detail TEXT NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
