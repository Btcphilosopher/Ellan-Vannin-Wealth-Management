# LIGNE — Réservation ferroviaire (Prototype indépendant)

Application de recherche de trajets ferroviaires, comparaison de conditions tarifaires et réservation de démonstration en français.

> **Avertissement :** LIGNE est un prototype indépendant utilisant des transporteurs fictifs (*Ligne Direct Démo*, *Horizon Distribution*), des horaires illustratifs et des billets spécimens portant la mention **DÉMONSTRATION — NON VALABLE POUR VOYAGER**. Aucune intégration commerciale SNCF ou tierce n’est fabriquée.

## Architecture & Capacités

| Composant | État | Rôle |
| --- | --- | --- |
| Frontend Angular 21 (Standalone, Signals, RxJS, CDK, Tailwind + tokens SCSS) | Implémenté | Page d’accueil, recherche par gare exacte, comparaison, checkout, Mes voyages, Aide, Admin |
| Serveur SSR Express (`src/server.ts`) + API `/api/*` | Implémenté | Moteur autoritaire actif en aperçu sur port 3000 (recherche, revalidation, idempotence, réconciliation) |
| Backend Python FastAPI (`backend/app/`) | Implémenté | Service REST & OpenAPI (`/docs`) miroir prêt pour déploiement conteneurisé |
| Schéma PostgreSQL (`backend/migrations/001_init.sql`) | Implémenté | Séparation stricte : services, itinéraires, offres, réservations de places, dossiers, paiements, billets, remboursements |
| Adaptateurs fournisseurs (`rail_direct_demo`, `horizon_handoff`) | Simulé (fictif) | Mode réservation intégrée démo vs mode redirection vendeur avec liste blanche |
| Worker de réconciliation & stockage objet (`MinIO` / local) | Implémenté / Simulé | Résolution par référence stable (`provider_order_ref`) et stockage des reçus/spécimens |
| Intégration transporteurs commerciaux / PSP production | Différé | Nécessite agréments ferroviaires, contrats distributeurs et conformité DSP2/RGPD avant mise en production |

## Lancement rapide

### 1. Mode aperçu / développement Node + Angular SSR
```bash
npm install
npm run dev
```
L’application est accessible sur `http://localhost:3000`.

### 2. Mode conteneurisé complet (PostgreSQL + FastAPI + Worker + MinIO + Angular)
```bash
docker compose up --build
```
- Frontend : `http://localhost:3000`
- Documentation OpenAPI FastAPI : `http://localhost:8000/docs`
- Console MinIO : `http://localhost:9001`

## Tests automatisés

```bash
# Tests frontend & backend TypeScript (Vitest)
npm test

# Tests backend Python
python3 -m unittest discover -s backend/tests -p "test_*.py"

# Vérification build & lint Angular
npm run lint && npm run build
```
