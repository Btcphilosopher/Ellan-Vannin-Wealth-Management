import {
  AngularNodeAppEngine,
  createNodeRequestHandler,
  isMainModule,
  writeResponseToNodeResponse,
} from '@angular/ssr/node';
import express from 'express';
import { join } from 'node:path';
import { createApiRouter } from './server/api';
import { startReconciliationWorker } from './server/worker';

const browserDistFolder = join(import.meta.dirname, '../browser');
const assetsFolder = join(process.cwd(), 'src/assets');

const app = express();
const angularApp = new AngularNodeAppEngine();

// Start background reconciliation worker
startReconciliationWorker();

// Mount authoritative LIGNE REST API
app.use('/api', createApiRouter());

// Serve generated editorial image assets in both dev & production SSR
app.use(
  '/src/assets',
  express.static(assetsFolder, {
    maxAge: '1d',
    index: false,
  }),
);

// Serve static files from /browser
app.use(
  express.static(browserDistFolder, {
    maxAge: '1y',
    index: false,
    redirect: false,
  }),
);

// Handle all other requests by rendering the Angular application
app.use((req, res, next) => {
  angularApp
    .handle(req)
    .then((response) => (response ? writeResponseToNodeResponse(response, res) : next()))
    .catch(next);
});

if (isMainModule(import.meta.url) || process.env['pm_id']) {
  const port = process.env['PORT'] || 4000;
  app.listen(port, (error) => {
    if (error) {
      throw error;
    }
    console.log(`Node Express server listening on http://localhost:${port}`);
  });
}

export const reqHandler = createNodeRequestHandler(app);
