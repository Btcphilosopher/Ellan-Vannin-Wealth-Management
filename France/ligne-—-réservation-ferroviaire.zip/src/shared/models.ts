export type StationKind = 'individual_station' | 'city_group' | 'transport_hub';

export type AccessibilityLevel = 'accessible' | 'partial' | 'assistance_required' | 'unknown';

export interface AccessibilityInfo {
  level: AccessibilityLevel;
  step_free_platforms: boolean | null;
  assistance_desk: boolean | null;
  summary: string;
  source: string;
  updated_at: string;
}

export interface StationNode {
  id: string;
  name: string;
  city: string;
  country: string;
  kind: StationKind;
  iana_timezone: string;
  child_station_ids?: string[];
  aliases: string[];
  accessibility: AccessibilityInfo;
}

export type TimetableState = 'scheduled' | 'estimated' | 'actual' | 'cancelled' | 'unknown';

export interface DisruptionInfo {
  state: TimetableState;
  delay_minutes: number | null;
  message: string;
  source: string;
  updated_at: string;
}

export interface ScheduledService {
  service_id: string;
  train_number: string;
  operator_name: string;
  service_category: string;
  origin_station_id: string;
  destination_station_id: string;
  departure_local_time: string;
  arrival_local_time: string;
  day_offset: number;
  stops_count: number;
}

export interface JourneySegment {
  segment_id: string;
  service_id: string;
  train_number: string;
  operator_name: string;
  service_category: string;
  origin_station: StationNode;
  destination_station: StationNode;
  departure_iso: string;
  arrival_iso: string;
  departure_local_label: string;
  arrival_local_label: string;
  departure_tz: string;
  arrival_tz: string;
  day_offset: number;
  duration_minutes: number;
  disruption: DisruptionInfo;
}

export interface JourneyItinerary {
  journey_reference: string;
  origin_station: StationNode;
  destination_station: StationNode;
  departure_iso: string;
  arrival_iso: string;
  departure_local_label: string;
  arrival_local_label: string;
  departure_tz: string;
  arrival_tz: string;
  day_offset: number;
  total_duration_minutes: number;
  changes_count: number;
  operators: string[];
  segments: JourneySegment[];
  disruption_summary: DisruptionInfo;
}

export type TravelClass = '1' | '2';

export type DiscountCardId =
  | 'CARTE_AVANTAGE_ADULTE'
  | 'CARTE_AVANTAGE_JEUNE'
  | 'CARTE_AVANTAGE_SENIOR'
  | 'CARTE_LIBERTE';

export interface PassengerComposition {
  adults: number;
  youths: number;
  seniors: number;
}

export interface PriceComponent {
  code: string;
  label: string;
  amount_cents: number | null;
  mandatory: boolean;
  unknown_amount?: boolean;
}

export type BookingMode = 'integrated_demo' | 'seller_handoff';

export type FlexibilityConditionStatus = 'allowed' | 'with_fee' | 'non_modifiable' | 'unknown';

export interface StructuredCondition {
  status: FlexibilityConditionStatus;
  summary: string;
  fee_cents: number | null;
  deadline_description: string | null;
}

export interface FareOffer {
  offer_id: string;
  provider_id: string;
  provider_name: string;
  booking_mode: BookingMode;
  journey_reference: string;
  passenger_composition: PassengerComposition;
  discount_cards_applied: DiscountCardId[];
  travel_class: TravelClass;
  ticket_product: string;
  included_services: string[];
  train_binding: 'train_specific' | 'day_flexible' | 'unknown';
  route_or_operator_restrictions: string;
  change_conditions: StructuredCondition;
  refund_conditions: StructuredCondition;
  mandatory_price_components: PriceComponent[];
  base_fare_cents: number;
  discount_cents: number;
  total_known_cents: number;
  has_unknown_mandatory_fees: boolean;
  currency: 'EUR';
  quoted_at: string;
  expires_at: string;
  required_passenger_fields: ('first_name' | 'last_name' | 'birth_date' | 'discount_card_number')[];
  available_seats: number | null;
}

export interface JourneySearchResultItem {
  itinerary: JourneyItinerary;
  offers: FareOffer[];
  lowest_known_offer_id: string | null;
}

export interface ProviderSearchNotice {
  provider_id: string;
  provider_name: string;
  status: 'ok' | 'timeout' | 'error' | 'unsupported';
  message: string;
  responded_at: string;
}

export interface JourneySearchResponse {
  search_id: string;
  query: {
    from_station_id: string;
    to_station_id: string;
    trip_type: 'oneway' | 'roundtrip';
    outward_date: string;
    outward_time: string;
    return_date?: string;
    return_time?: string;
    adults: number;
    youths: number;
    seniors: number;
    travel_class: TravelClass;
    discount_cards: DiscountCardId[];
  };
  from_station: StationNode;
  to_station: StationNode;
  outward_results: JourneySearchResultItem[];
  return_results: JourneySearchResultItem[];
  provider_notices: ProviderSearchNotice[];
  partial_results: boolean;
  generated_at: string;
}

export type BookingState =
  | 'offer_selected'
  | 'revalidation_pending'
  | 'reservation_pending'
  | 'reservation_held'
  | 'payment_pending'
  | 'payment_confirmed'
  | 'booking_confirmation_pending'
  | 'booking_confirmed'
  | 'ticket_issuance_pending'
  | 'ticket_issued'
  | 'failed'
  | 'reconciliation_required';

export type PaymentState = 'pending' | 'confirmed' | 'failed' | 'refunded';

export interface SeatReservation {
  reservation_id: string;
  provider_id: string;
  journey_reference: string;
  coach: string;
  seat_numbers: string[];
  held_until: string;
  status: 'held' | 'confirmed' | 'released' | 'failed';
}

export interface PaymentRecord {
  payment_id: string;
  idempotency_key: string;
  booking_id: string;
  amount_cents: number;
  currency: 'EUR';
  method_label: string;
  masked_reference: string;
  state: PaymentState;
  provider_event_ids: string[];
  created_at: string;
  updated_at: string;
}

export interface IssuedTicket {
  ticket_id: string;
  booking_id: string;
  is_simulated: boolean;
  watermark_text: string;
  ticket_number: string;
  passenger_names: string[];
  travel_class: TravelClass;
  ticket_product: string;
  issued_at: string;
  document_url: string;
}

export type RefundState = 'requested' | 'under_review' | 'approved' | 'credited' | 'rejected';

export interface RefundRecord {
  refund_id: string;
  booking_id: string;
  payment_id: string;
  requested_amount_cents: number;
  penalty_cents: number;
  net_refund_cents: number;
  reason: string;
  state: RefundState;
  created_at: string;
  updated_at: string;
}

export interface AssistanceRequest {
  request_id: string;
  station_id: string;
  station_name: string;
  assistance_type: string;
  notes: string;
  status: 'requested_unconfirmed' | 'confirmed' | 'unavailable';
  created_at: string;
}

export interface PassengerDetailInput {
  first_name: string;
  last_name: string;
  birth_date?: string;
  category: 'adult' | 'youth' | 'senior';
  discount_card_id?: DiscountCardId | '';
  discount_card_number?: string;
}

export interface OptionalExtraSelection {
  code: string;
  label: string;
  amount_cents: number;
}

export interface BookingRecord {
  booking_id: string;
  user_id: string;
  booking_reference: string;
  provider_order_ref: string;
  provider_id: string;
  provider_name: string;
  booking_mode: BookingMode;
  state: BookingState;
  state_history: { state: BookingState; timestamp: string; note: string }[];
  outward_itinerary: JourneyItinerary;
  outward_offer: FareOffer;
  return_itinerary: JourneyItinerary | null;
  return_offer: FareOffer | null;
  passengers: PassengerDetailInput[];
  contact_email: string;
  contact_phone: string;
  optional_extras: OptionalExtraSelection[];
  base_total_cents: number;
  mandatory_fees_cents: number;
  discount_total_cents: number;
  extras_total_cents: number;
  total_paid_cents: number;
  currency: 'EUR';
  seat_reservations: SeatReservation[];
  payment: PaymentRecord | null;
  tickets: IssuedTicket[];
  refunds: RefundRecord[];
  assistance_requests: AssistanceRequest[];
  cancellation_status: 'active' | 'exchange_requested' | 'cancelled';
  created_at: string;
  updated_at: string;
}

export interface SavedItinerary {
  saved_id: string;
  user_id: string;
  label: string;
  from_station: StationNode;
  to_station: StationNode;
  outward_itinerary: JourneyItinerary;
  quoted_cents: number;
  created_at: string;
}

export interface RevalidationResult {
  offer_id: string;
  status: 'unchanged' | 'price_changed' | 'expired' | 'unavailable';
  previous_total_cents: number;
  new_total_cents: number;
  message: string;
  offer: FareOffer;
  revalidated_at: string;
}

export interface ProviderCapabilities {
  station_lookup: boolean;
  journey_search: boolean;
  fare_search: boolean;
  offer_revalidation: boolean;
  integrated_booking: boolean;
  booking_status_lookup: boolean;
  ticket_retrieval: boolean;
  cancellation_refund: boolean;
  seller_handoff: boolean;
}

export interface ProviderHealth {
  provider_id: string;
  provider_name: string;
  booking_mode: BookingMode;
  status: 'healthy' | 'degraded' | 'timeout_simulated';
  avg_latency_ms: number;
  last_checked_at: string;
  capabilities: ProviderCapabilities;
}

export interface SimulationFlags {
  timeout_provider_id: string | null;
  partial_results_mode: boolean;
  force_expired_offer: boolean;
  force_price_change_cents: number;
  force_unavailable_inventory: boolean;
  simulate_duplicate_payment_event: boolean;
  force_uncertain_booking_outcome: boolean;
}

export interface SupportCase {
  case_id: string;
  booking_id: string;
  booking_reference: string;
  user_email: string;
  category: 'exchange' | 'refund' | 'reconciliation' | 'assistance' | 'other';
  summary: string;
  status: 'open' | 'investigating' | 'resolved';
  created_at: string;
  updated_at: string;
}

export interface AuditEntry {
  audit_id: string;
  actor: string;
  action: string;
  target_type: string;
  target_id: string;
  detail: string;
  timestamp: string;
}

export interface UserSession {
  user_id: string;
  email: string;
  display_name: string;
  role: 'traveler' | 'admin';
}
