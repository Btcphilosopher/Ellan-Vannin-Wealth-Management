import {ChangeDetectionStrategy, Component, inject, signal} from '@angular/core';
import {RouterLink, RouterLinkActive} from '@angular/router';
import {MatIconModule} from '@angular/material/icon';
import {AuthStore} from '../services/auth-store';
import {I18nStore} from '../services/i18n';

@Component({
  selector: 'app-header-bar',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [RouterLink, RouterLinkActive, MatIconModule],
  template: `
    <header class="bg-[#FAF8F5]/95 backdrop-blur-sm border-b border-[#E3E6EC] sticky top-0 z-40">
      <div class="max-w-[1200px] mx-auto px-4 sm:px-6 h-16 flex items-center justify-between gap-4 sm:gap-8">
        <!-- Zone 1: Brand wordmark -->
        <a
          routerLink="/"
          class="flex items-center gap-2.5 text-[#0E1F3B] whitespace-nowrap shrink-0 ligne-focus rounded-md py-1"
          aria-label="LIGNE — Accueil réservation ferroviaire"
        >
          <svg width="30" height="16" viewBox="0 0 36 18" fill="none" aria-hidden="true">
            <path d="M2 14.5C9.5 11.5 19.5 7 34 3.5" stroke="#0F54D4" stroke-width="2.6" stroke-linecap="round" />
            <path d="M8 16C14.5 13.5 23 10.5 33.5 8.5" stroke="#2D74F5" stroke-width="1.8" stroke-linecap="round" />
          </svg>
          <span class="text-xl font-bold tracking-[0.08em] text-[#0E1F3B]">LIGNE</span>
        </a>

        <!-- Zone 2: 4 single-line nav links -->
        <nav class="hidden md:flex items-center gap-7 text-[15px] font-medium text-[#2A3B59]" aria-label="Navigation principale">
          <a
            routerLink="/"
            routerLinkActive="text-[#0E1F3B] font-semibold border-b-2 border-[#D63D2E]"
            [routerLinkActiveOptions]="{exact: true}"
            class="py-1.5 whitespace-nowrap shrink-0 hover:text-[#0E1F3B] transition-colors border-b-2 border-transparent ligne-focus"
          >
            {{ i18n.locale() === 'fr' ? 'Réserver' : 'Book' }}
          </a>
          <a
            routerLink="/destinations"
            routerLinkActive="text-[#0E1F3B] font-semibold border-b-2 border-[#D63D2E]"
            class="py-1.5 whitespace-nowrap shrink-0 hover:text-[#0E1F3B] transition-colors border-b-2 border-transparent ligne-focus"
          >
            Destinations
          </a>
          <a
            routerLink="/mes-voyages"
            routerLinkActive="text-[#0E1F3B] font-semibold border-b-2 border-[#D63D2E]"
            class="py-1.5 whitespace-nowrap shrink-0 hover:text-[#0E1F3B] transition-colors border-b-2 border-transparent ligne-focus"
          >
            {{ i18n.locale() === 'fr' ? 'Mes voyages' : 'My trips' }}
          </a>
          <a
            routerLink="/aide"
            routerLinkActive="text-[#0E1F3B] font-semibold border-b-2 border-[#D63D2E]"
            class="py-1.5 whitespace-nowrap shrink-0 hover:text-[#0E1F3B] transition-colors border-b-2 border-transparent ligne-focus"
          >
            {{ i18n.locale() === 'fr' ? 'Aide' : 'Help' }}
          </a>
        </nav>

        <!-- Zone 3: Language & Account control -->
        <div class="flex items-center gap-3 shrink-0">
          <div class="relative hidden sm:block">
            <button
              type="button"
              (click)="toggleLangMenu()"
              class="flex items-center gap-1 px-2.5 py-1.5 text-sm font-medium text-[#0E1F3B] hover:bg-[#F3F1EC] rounded-lg transition-colors whitespace-nowrap shrink-0 ligne-focus"
              [attr.aria-expanded]="langOpen()"
              aria-label="Choisir la langue"
            >
              <span>{{ i18n.locale() === 'fr' ? 'Français' : 'English' }}</span>
              <mat-icon class="!text-[18px] !w-[18px] !h-[18px] text-[#4B5A73]">expand_more</mat-icon>
            </button>
            @if (langOpen()) {
              <div class="absolute right-0 mt-1.5 w-36 bg-white border border-[#E3E6EC] rounded-xl shadow-md py-1 z-50">
                <button
                  type="button"
                  (click)="selectLocale('fr')"
                  class="w-full text-left px-3 py-2 text-sm hover:bg-[#FAF8F5] flex items-center justify-between"
                >
                  <span>Français</span>
                  @if (i18n.locale() === 'fr') {
                    <mat-icon class="!text-[16px] !w-[16px] !h-[16px] text-[#0F54D4]">check</mat-icon>
                  }
                </button>
                <button
                  type="button"
                  (click)="selectLocale('en')"
                  class="w-full text-left px-3 py-2 text-sm hover:bg-[#FAF8F5] flex items-center justify-between"
                >
                  <span>English</span>
                  @if (i18n.locale() === 'en') {
                    <mat-icon class="!text-[16px] !w-[16px] !h-[16px] text-[#0F54D4]">check</mat-icon>
                  }
                </button>
              </div>
            }
          </div>

          @if (auth.user(); as currentUser) {
            <div class="relative">
              <button
                type="button"
                (click)="toggleUserMenu()"
                class="flex items-center gap-2 px-3.5 py-2 text-sm font-medium text-[#0E1F3B] bg-white border border-[#CDD3DE] rounded-xl hover:bg-[#FAF8F5] transition-colors whitespace-nowrap shrink-0 ligne-focus"
                [attr.aria-expanded]="userMenuOpen()"
              >
                <mat-icon class="!text-[18px] !w-[18px] !h-[18px] text-[#0F54D4]">person_outline</mat-icon>
                <span class="max-w-[130px] truncate">{{ currentUser.display_name }}</span>
                <mat-icon class="!text-[18px] !w-[18px] !h-[18px] text-[#4B5A73]">expand_more</mat-icon>
              </button>
              @if (userMenuOpen()) {
                <div class="absolute right-0 mt-1.5 w-56 bg-white border border-[#E3E6EC] rounded-xl shadow-md py-1.5 z-50">
                  <div class="px-3.5 py-2 border-b border-[#E3E6EC]">
                    <p class="text-xs text-[#4B5A73] truncate">{{ currentUser.email }}</p>
                  </div>
                  <a
                    routerLink="/mes-voyages"
                    (click)="userMenuOpen.set(false)"
                    class="flex items-center gap-2 px-3.5 py-2 text-sm text-[#0E1F3B] hover:bg-[#FAF8F5]"
                  >
                    <mat-icon class="!text-[18px] !w-[18px] !h-[18px] text-[#4B5A73]">confirmation_number</mat-icon>
                    <span>Mes voyages</span>
                  </a>
                  <a
                    routerLink="/admin"
                    (click)="userMenuOpen.set(false)"
                    class="flex items-center gap-2 px-3.5 py-2 text-sm text-[#0E1F3B] hover:bg-[#FAF8F5]"
                  >
                    <mat-icon class="!text-[18px] !w-[18px] !h-[18px] text-[#4B5A73]">admin_panel_settings</mat-icon>
                    <span>Administration</span>
                  </a>
                  <button
                    type="button"
                    (click)="logout()"
                    class="w-full text-left flex items-center gap-2 px-3.5 py-2 text-sm text-[#B42318] hover:bg-[#FAF8F5] border-t border-[#E3E6EC] mt-1"
                  >
                    <mat-icon class="!text-[18px] !w-[18px] !h-[18px]">logout</mat-icon>
                    <span>Se déconnecter</span>
                  </button>
                </div>
              }
            </div>
          } @else {
            <button
              type="button"
              (click)="auth.openModal()"
              class="flex items-center gap-2 px-4 py-2 text-sm font-medium text-[#0E1F3B] bg-white border border-[#CDD3DE] rounded-xl hover:bg-[#F3F1EC] transition-colors whitespace-nowrap shrink-0 ligne-focus"
            >
              <mat-icon class="!text-[18px] !w-[18px] !h-[18px] text-[#0E1F3B]">person_outline</mat-icon>
              <span>{{ i18n.locale() === 'fr' ? 'Se connecter' : 'Sign in' }}</span>
            </button>
          }

          <button
            type="button"
            (click)="mobileOpen.set(!mobileOpen())"
            class="md:hidden p-2 rounded-lg border border-[#E3E6EC] bg-white text-[#0E1F3B] ligne-focus"
            aria-label="Menu mobile"
          >
            <mat-icon class="!text-[20px] !w-[20px] !h-[20px]">{{ mobileOpen() ? 'close' : 'menu' }}</mat-icon>
          </button>
        </div>
      </div>

      @if (mobileOpen()) {
        <nav class="md:hidden border-t border-[#E3E6EC] bg-white px-4 py-3 flex flex-col gap-1" aria-label="Menu mobile">
          <a routerLink="/" (click)="mobileOpen.set(false)" class="px-3 py-2.5 rounded-lg text-sm font-medium text-[#0E1F3B] hover:bg-[#FAF8F5]">Réserver</a>
          <a routerLink="/destinations" (click)="mobileOpen.set(false)" class="px-3 py-2.5 rounded-lg text-sm font-medium text-[#0E1F3B] hover:bg-[#FAF8F5]">Destinations</a>
          <a routerLink="/mes-voyages" (click)="mobileOpen.set(false)" class="px-3 py-2.5 rounded-lg text-sm font-medium text-[#0E1F3B] hover:bg-[#FAF8F5]">Mes voyages</a>
          <a routerLink="/aide" (click)="mobileOpen.set(false)" class="px-3 py-2.5 rounded-lg text-sm font-medium text-[#0E1F3B] hover:bg-[#FAF8F5]">Aide</a>
          <a routerLink="/admin" (click)="mobileOpen.set(false)" class="px-3 py-2.5 rounded-lg text-sm font-medium text-[#4B5A73] hover:bg-[#FAF8F5]">Administration</a>
        </nav>
      }
    </header>
  `,
})
export class HeaderBar {
  readonly auth = inject(AuthStore);
  readonly i18n = inject(I18nStore);

  readonly langOpen = signal(false);
  readonly userMenuOpen = signal(false);
  readonly mobileOpen = signal(false);

  toggleLangMenu(): void {
    this.langOpen.update((v) => !v);
    this.userMenuOpen.set(false);
  }

  toggleUserMenu(): void {
    this.userMenuOpen.update((v) => !v);
    this.langOpen.set(false);
  }

  selectLocale(locale: 'fr' | 'en'): void {
    this.i18n.setLocale(locale);
    this.langOpen.set(false);
  }

  async logout(): Promise<void> {
    this.userMenuOpen.set(false);
    await this.auth.logout();
  }
}
