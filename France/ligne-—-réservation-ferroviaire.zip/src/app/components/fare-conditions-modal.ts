import {ChangeDetectionStrategy, Component, input, output} from '@angular/core';
import {A11yModule} from '@angular/cdk/a11y';
import {MatIconModule} from '@angular/material/icon';
import type {FareOffer, JourneyItinerary} from '../../shared/models';
import {
  formatConditionStatusFr,
  formatDurationFr,
  formatEuroCents,
  formatTimetableStateFr,
} from '../shared/formatters';

@Component({
  selector: 'app-fare-conditions-modal',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [A11yModule, MatIconModule],
  template: `
    @if (offer(); as activeOffer) {
      <div
        class="fixed inset-0 z-50 flex items-center justify-center bg-[#0E1F3B]/55 backdrop-blur-[2px] p-4"
        role="dialog"
        aria-modal="true"
        aria-labelledby="fare-modal-title"
      >
        <div
          cdkTrapFocus
          [cdkTrapFocusAutoCapture]="true"
          class="w-full max-w-2xl max-h-[90vh] overflow-y-auto bg-white border border-[#E3E6EC] rounded-2xl shadow-xl p-6 sm:p-7"
        >
          <div class="flex items-start justify-between gap-4 pb-4 border-b border-[#E3E6EC]">
            <div>
              <p class="text-xs font-medium text-[#4B5A73]">
                {{ activeOffer.provider_name }} · {{ activeOffer.offer_id }}
              </p>
              <h2 id="fare-modal-title" class="font-serif-display text-2xl font-semibold text-[#0E1F3B] mt-1">
                Conditions du billet — {{ activeOffer.ticket_product }}
              </h2>
            </div>
            <button
              type="button"
              (click)="closed.emit()"
              class="p-1.5 rounded-lg text-[#4B5A73] hover:bg-[#FAF8F5] hover:text-[#0E1F3B] ligne-focus"
              aria-label="Fermer les conditions du billet"
            >
              <mat-icon>close</mat-icon>
            </button>
          </div>

          @if (itinerary(); as itin) {
            <div class="mt-4 p-4 rounded-xl bg-[#FAF8F5] border border-[#E3E6EC] flex flex-wrap items-center justify-between gap-3">
              <div>
                <p class="text-sm font-semibold text-[#0E1F3B]">
                  {{ itin.origin_station.name }} ({{ itin.departure_local_label }}) →
                  {{ itin.destination_station.name }} ({{ itin.arrival_local_label }})
                </p>
                <p class="text-xs text-[#4B5A73] mt-0.5">
                  {{ itin.changes_count === 0 ? 'Direct' : itin.changes_count + ' correspondance(s)' }}
                  · {{ formatDuration(itin.total_duration_minutes) }}
                  · {{ itin.operators.join(' + ') }}
                </p>
              </div>
              <div class="text-right">
                <p class="text-lg font-bold text-[#0E1F3B] tabular-nums">
                  {{ formatPrice(activeOffer.total_known_cents) }}
                </p>
                <p class="text-xs text-[#4B5A73]">
                  {{ activeOffer.travel_class === '1' ? '1re classe' : '2de classe' }}
                </p>
              </div>
            </div>
          }

          <div class="mt-5 grid sm:grid-cols-2 gap-4">
            <div class="p-4 rounded-xl border border-[#E3E6EC]">
              <h3 class="text-sm font-semibold text-[#0E1F3B] mb-1.5">Conditions d’échange</h3>
              <p class="text-xs font-medium text-[#0F54D4] mb-1">
                {{ conditionLabel(activeOffer.change_conditions.status) }}
              </p>
              <p class="text-sm text-[#334155]">{{ activeOffer.change_conditions.summary }}</p>
            </div>
            <div class="p-4 rounded-xl border border-[#E3E6EC]">
              <h3 class="text-sm font-semibold text-[#0E1F3B] mb-1.5">Conditions de remboursement</h3>
              <p class="text-xs font-medium text-[#0F54D4] mb-1">
                {{ conditionLabel(activeOffer.refund_conditions.status) }}
              </p>
              <p class="text-sm text-[#334155]">{{ activeOffer.refund_conditions.summary }}</p>
            </div>
          </div>

          <div class="mt-4 p-4 rounded-xl border border-[#E3E6EC] space-y-2.5">
            <h3 class="text-sm font-semibold text-[#0E1F3B]">Détail structuré de l’offre</h3>
            <div class="grid sm:grid-cols-2 gap-y-2 gap-x-6 text-sm">
              <div>
                <span class="text-[#4B5A73]">Mode de réservation :</span>
                <span class="font-medium text-[#0E1F3B] ml-1">
                  {{
                    activeOffer.booking_mode === 'integrated_demo'
                      ? 'Réservation intégrée (démonstration)'
                      : 'Redirection vendeur partenaire'
                  }}
                </span>
              </div>
              <div>
                <span class="text-[#4B5A73]">Validité train :</span>
                <span class="font-medium text-[#0E1F3B] ml-1">
                  @switch (activeOffer.train_binding) {
                    @case ('train_specific') { Billet valable sur ce train précis }
                    @case ('day_flexible') { Valable sur la journée }
                    @default { Inconnu (non précisé) }
                  }
                </span>
              </div>
              <div class="sm:col-span-2">
                <span class="text-[#4B5A73]">Restrictions :</span>
                <span class="text-[#0E1F3B] ml-1">{{ activeOffer.route_or_operator_restrictions }}</span>
              </div>
            </div>

            <div class="pt-2 border-t border-[#E3E6EC]">
              <p class="text-xs font-semibold text-[#0E1F3B] mb-1.5">Composantes tarifaires obligatoires</p>
              <ul class="space-y-1 text-sm">
                @for (comp of activeOffer.mandatory_price_components; track comp.code) {
                  <li class="flex items-center justify-between">
                    <span class="text-[#334155]">{{ comp.label }}</span>
                    <span class="font-medium tabular-nums text-[#0E1F3B]">
                      {{ comp.unknown_amount ? 'Montant inconnu' : formatPrice(comp.amount_cents) }}
                    </span>
                  </li>
                }
              </ul>
              @if (activeOffer.has_unknown_mandatory_fees) {
                <p class="mt-2 text-xs text-[#9A3412] bg-[#FFF7ED] border border-[#FED7AA] rounded-lg px-3 py-2">
                  Des frais obligatoires du transporteur ne sont pas connus à ce stade : ce tarif n’est donc jamais classé « Le moins cher ».
                </p>
              }
            </div>

            <div class="pt-2 border-t border-[#E3E6EC]">
              <p class="text-xs font-semibold text-[#0E1F3B] mb-1">Services inclus</p>
              <p class="text-sm text-[#334155]">{{ activeOffer.included_services.join(' · ') }}</p>
            </div>
          </div>

          @if (itinerary(); as itin) {
            <div class="mt-4 p-4 rounded-xl border border-[#E3E6EC] space-y-2 text-xs text-[#4B5A73]">
              <p class="font-semibold text-[#0E1F3B] text-sm">Information horaires & accessibilité</p>
              <p>
                Circulation : <strong class="text-[#0E1F3B]">{{ timetableLabel(itin) }}</strong>
                — {{ itin.disruption_summary.message }} (Source : {{ itin.disruption_summary.source }})
              </p>
              <p>
                Accessibilité départ ({{ itin.origin_station.name }}) : {{ itin.origin_station.accessibility.summary }}
                (Source : {{ itin.origin_station.accessibility.source }})
              </p>
              <p>
                Devis établi à {{ formatTime(activeOffer.quoted_at) }} · Valable jusqu’à {{ formatTime(activeOffer.expires_at) }}
              </p>
            </div>
          }

          <div class="mt-5 flex justify-end gap-3">
            <button
              type="button"
              (click)="closed.emit()"
              class="px-5 py-2.5 rounded-xl bg-[#0F54D4] hover:bg-[#0B44B0] text-white text-sm font-semibold transition-colors ligne-focus"
            >
              Compris
            </button>
          </div>
        </div>
      </div>
    }
  `,
})
export class FareConditionsModal {
  readonly offer = input<FareOffer | null>(null);
  readonly itinerary = input<JourneyItinerary | null>(null);
  readonly closed = output<void>();

  formatPrice(cents: number | null): string {
    return formatEuroCents(cents);
  }

  formatDuration(minutes: number): string {
    return formatDurationFr(minutes);
  }

  conditionLabel(status: FareOffer['change_conditions']['status']): string {
    return formatConditionStatusFr(status);
  }

  timetableLabel(itin: JourneyItinerary): string {
    return formatTimetableStateFr(
      itin.disruption_summary.state,
      itin.disruption_summary.delay_minutes,
    );
  }

  formatTime(iso: string): string {
    return new Intl.DateTimeFormat('fr-FR', {
      hour: '2-digit',
      minute: '2-digit',
      timeZone: 'Europe/Paris',
    }).format(new Date(iso));
  }
}
