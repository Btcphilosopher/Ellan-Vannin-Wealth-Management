import {ChangeDetectionStrategy, Component, inject, signal} from '@angular/core';
import {FormControl, FormGroup, ReactiveFormsModule, Validators} from '@angular/forms';
import {RouterLink} from '@angular/router';
import {A11yModule} from '@angular/cdk/a11y';
import {MatIconModule} from '@angular/material/icon';
import {AuthStore} from '../services/auth-store';

@Component({
  selector: 'app-auth-modal',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [ReactiveFormsModule, RouterLink, A11yModule, MatIconModule],
  template: `
    @if (auth.modalOpen()) {
      <div
        class="fixed inset-0 z-50 flex items-center justify-center bg-[#0E1F3B]/50 backdrop-blur-[2px] p-4"
        role="dialog"
        aria-modal="true"
        aria-labelledby="auth-modal-title"
      >
        <div
          cdkTrapFocus
          [cdkTrapFocusAutoCapture]="true"
          class="w-full max-w-md bg-white border border-[#E3E6EC] rounded-2xl shadow-xl p-6 sm:p-7"
        >
          <div class="flex items-start justify-between gap-4 mb-4">
            <div>
              <h2 id="auth-modal-title" class="font-serif-display text-2xl font-semibold text-[#0E1F3B]">
                {{ mode() === 'login' ? 'Connexion voyageur' : 'Créer un compte' }}
              </h2>
              <p class="text-sm text-[#4B5A73] mt-1">
                Retrouvez vos billets spécimens et demandes de remboursement dans Mes voyages.
              </p>
            </div>
            <button
              type="button"
              (click)="auth.closeModal()"
              class="p-1.5 rounded-lg text-[#4B5A73] hover:bg-[#FAF8F5] hover:text-[#0E1F3B] ligne-focus"
              aria-label="Fermer la fenêtre de connexion"
            >
              <mat-icon>close</mat-icon>
            </button>
          </div>

          <button
            type="button"
            (click)="signInDemoTraveler()"
            [disabled]="busy()"
            class="w-full flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl bg-[#EEF4FF] text-[#0F54D4] border border-[#C7DAFC] font-semibold text-sm hover:bg-[#E1ECFF] transition-colors mb-5 disabled:opacity-60 ligne-focus"
          >
            <mat-icon class="!text-[18px] !w-[18px] !h-[18px]">bolt</mat-icon>
            <span>Continuer avec le compte démo (Camille Laurent)</span>
          </button>

          <div class="flex items-center gap-3 mb-4 text-xs text-[#64748B]">
            <div class="flex-1 h-px bg-[#E3E6EC]"></div>
            <span>ou avec votre adresse e-mail</span>
            <div class="flex-1 h-px bg-[#E3E6EC]"></div>
          </div>

          <form [formGroup]="form" (ngSubmit)="submit()" class="space-y-3.5">
            @if (mode() === 'register') {
              <div>
                <label for="auth-name" class="block text-xs font-medium text-[#0E1F3B] mb-1">Nom complet</label>
                <input
                  id="auth-name"
                  type="text"
                  formControlName="displayName"
                  placeholder="Camille Laurent"
                  class="w-full px-3.5 py-2.5 text-sm rounded-xl border border-[#CDD3DE] focus:border-[#0F54D4] focus:outline-none"
                />
              </div>
            }

            <div>
              <label for="auth-email" class="block text-xs font-medium text-[#0E1F3B] mb-1">Adresse e-mail</label>
              <input
                id="auth-email"
                type="email"
                formControlName="email"
                placeholder="nom@exemple.fr"
                class="w-full px-3.5 py-2.5 text-sm rounded-xl border border-[#CDD3DE] focus:border-[#0F54D4] focus:outline-none"
              />
            </div>

            <div>
              <label for="auth-password" class="block text-xs font-medium text-[#0E1F3B] mb-1">
                Mot de passe (8 caractères min.)
              </label>
              <input
                id="auth-password"
                type="password"
                formControlName="password"
                placeholder="••••••••"
                class="w-full px-3.5 py-2.5 text-sm rounded-xl border border-[#CDD3DE] focus:border-[#0F54D4] focus:outline-none"
              />
            </div>

            @if (errorMsg()) {
              <p class="text-xs text-[#B42318] bg-[#FDECEA] border border-[#F5C2BE] rounded-lg px-3 py-2" role="alert">
                {{ errorMsg() }}
              </p>
            }

            <button
              type="submit"
              [disabled]="busy()"
              class="w-full flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl bg-[#0F54D4] hover:bg-[#0B44B0] text-white font-semibold text-sm transition-colors disabled:opacity-60 ligne-focus"
            >
              <mat-icon class="!text-[18px] !w-[18px] !h-[18px]">login</mat-icon>
              <span>{{ mode() === 'login' ? 'Se connecter' : 'Créer mon compte' }}</span>
            </button>
          </form>

          <div class="mt-5 pt-4 border-t border-[#E3E6EC] flex items-center justify-between text-xs text-[#4B5A73]">
            <button
              type="button"
              (click)="toggleMode()"
              class="text-[#0F54D4] font-medium hover:underline ligne-focus"
            >
              {{ mode() === 'login' ? 'Nouveau sur LIGNE ? Créer un compte' : 'Déjà inscrit ? Se connecter' }}
            </button>
            <a
              routerLink="/admin"
              (click)="auth.closeModal()"
              class="text-[#4B5A73] hover:text-[#0E1F3B] underline"
            >
              Accès Administration
            </a>
          </div>
        </div>
      </div>
    }
  `,
})
export class AuthModal {
  readonly auth = inject(AuthStore);
  readonly mode = signal<'login' | 'register'>('login');
  readonly busy = signal(false);
  readonly errorMsg = signal<string | null>(null);

  readonly form = new FormGroup({
    displayName: new FormControl('', {nonNullable: true}),
    email: new FormControl('', {nonNullable: true, validators: [Validators.required, Validators.email]}),
    password: new FormControl('', {nonNullable: true, validators: [Validators.required, Validators.minLength(8)]}),
  });

  toggleMode(): void {
    this.errorMsg.set(null);
    this.mode.update((m) => (m === 'login' ? 'register' : 'login'));
  }

  async signInDemoTraveler(): Promise<void> {
    this.busy.set(true);
    this.errorMsg.set(null);
    try {
      await this.auth.loginDemoTraveler();
    } catch {
      this.errorMsg.set('Impossible de charger le compte de démonstration.');
    } finally {
      this.busy.set(false);
    }
  }

  async submit(): Promise<void> {
    if (this.form.invalid) {
      this.errorMsg.set('Veuillez saisir un e-mail valide et un mot de passe d’au moins 8 caractères.');
      return;
    }
    this.busy.set(true);
    this.errorMsg.set(null);
    const {email, password, displayName} = this.form.getRawValue();
    try {
      if (this.mode() === 'login') {
        await this.auth.login(email, password);
      } else {
        await this.auth.register(email, password, displayName);
      }
    } catch (err: unknown) {
      const msg =
        (err as {error?: {error?: string}})?.error?.error ||
        'Échec de l’authentification. Vérifiez vos identifiants.';
      this.errorMsg.set(msg);
    } finally {
      this.busy.set(false);
    }
  }
}
