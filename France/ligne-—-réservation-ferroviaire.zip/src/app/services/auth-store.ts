import {computed, inject, Injectable, PLATFORM_ID, signal} from '@angular/core';
import {isPlatformBrowser} from '@angular/common';
import {HttpClient} from '@angular/common/http';
import {firstValueFrom} from 'rxjs';
import type {UserSession} from '../../shared/models';

@Injectable({providedIn: 'root'})
export class AuthStore {
  private readonly http = inject(HttpClient);
  private readonly platformId = inject(PLATFORM_ID);

  private readonly tokenSignal = signal<string | null>(null);
  readonly user = signal<UserSession | null>(null);
  readonly initialized = signal(false);
  readonly modalOpen = signal(false);

  readonly isAuthenticated = computed(() => this.user() !== null);
  readonly isAdmin = computed(() => this.user()?.role === 'admin');

  getToken(): string | null {
    return this.tokenSignal();
  }

  setSession(user: UserSession | null, token?: string | null): void {
    this.user.set(user);
    if (token !== undefined) {
      this.tokenSignal.set(token);
    }
  }

  openModal(): void {
    this.modalOpen.set(true);
  }

  closeModal(): void {
    this.modalOpen.set(false);
  }

  async refreshSession(): Promise<void> {
    if (!isPlatformBrowser(this.platformId)) {
      this.initialized.set(true);
      return;
    }
    try {
      const res = await firstValueFrom(
        this.http.get<{user: UserSession | null}>('/api/auth/me'),
      );
      this.user.set(res.user);
    } catch {
      this.user.set(null);
    } finally {
      this.initialized.set(true);
    }
  }

  async loginDemoTraveler(): Promise<UserSession> {
    const res = await firstValueFrom(
      this.http.post<{user: UserSession; token: string}>('/api/auth/demo-traveler', {}),
    );
    this.user.set(res.user);
    this.tokenSignal.set(res.token);
    this.modalOpen.set(false);
    return res.user;
  }

  async login(email: string, password: string): Promise<UserSession> {
    const res = await firstValueFrom(
      this.http.post<{user: UserSession; token: string}>('/api/auth/login', {
        email,
        password,
      }),
    );
    this.user.set(res.user);
    this.tokenSignal.set(res.token);
    this.modalOpen.set(false);
    return res.user;
  }

  async register(email: string, password: string, displayName: string): Promise<UserSession> {
    const res = await firstValueFrom(
      this.http.post<{user: UserSession; token: string}>('/api/auth/register', {
        email,
        password,
        display_name: displayName,
      }),
    );
    this.user.set(res.user);
    this.tokenSignal.set(res.token);
    this.modalOpen.set(false);
    return res.user;
  }

  async logout(): Promise<void> {
    try {
      await firstValueFrom(this.http.post('/api/auth/logout', {}));
    } finally {
      this.user.set(null);
      this.tokenSignal.set(null);
    }
  }
}
