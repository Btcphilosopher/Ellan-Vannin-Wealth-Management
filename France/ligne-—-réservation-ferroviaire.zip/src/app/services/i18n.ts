import {Injectable, signal} from '@angular/core';

export type SupportedLocale = 'fr' | 'en';

@Injectable({providedIn: 'root'})
export class I18nStore {
  readonly locale = signal<SupportedLocale>('fr');

  setLocale(next: SupportedLocale): void {
    this.locale.set(next);
  }
}
