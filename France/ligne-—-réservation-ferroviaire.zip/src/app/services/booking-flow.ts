import {computed, Injectable, signal} from '@angular/core';
import type {FareOffer, JourneyItinerary} from '../../shared/models';

export interface SelectedLeg {
  itinerary: JourneyItinerary;
  offer: FareOffer;
}

@Injectable({providedIn: 'root'})
export class BookingFlow {
  readonly tripType = signal<'oneway' | 'roundtrip'>('roundtrip');
  readonly outward = signal<SelectedLeg | null>(null);
  readonly returnLeg = signal<SelectedLeg | null>(null);
  readonly handoffNotice = signal<{
    seller_name: string;
    redirect_url: string;
    offer: FareOffer;
    itinerary: JourneyItinerary;
    notice: string;
  } | null>(null);

  readonly totalSelectedCents = computed(() => {
    const outCents = this.outward()?.offer.total_known_cents ?? 0;
    const retCents = this.returnLeg()?.offer.total_known_cents ?? 0;
    return outCents + retCents;
  });

  startSelection(tripType: 'oneway' | 'roundtrip'): void {
    this.tripType.set(tripType);
    this.outward.set(null);
    this.returnLeg.set(null);
    this.handoffNotice.set(null);
  }

  selectOutward(itinerary: JourneyItinerary, offer: FareOffer): void {
    this.outward.set({itinerary, offer});
    this.returnLeg.set(null);
    this.handoffNotice.set(null);
  }

  selectReturn(itinerary: JourneyItinerary, offer: FareOffer): void {
    this.returnLeg.set({itinerary, offer});
  }

  clear(): void {
    this.outward.set(null);
    this.returnLeg.set(null);
    this.handoffNotice.set(null);
  }
}
