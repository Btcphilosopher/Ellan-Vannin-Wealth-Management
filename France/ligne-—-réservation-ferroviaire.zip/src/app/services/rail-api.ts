import {inject, Injectable} from '@angular/core';
import {HttpClient, HttpParams} from '@angular/common/http';
import {Observable} from 'rxjs';
import type {
  BookingRecord,
  DiscountCardId,
  FareOffer,
  JourneyItinerary,
  JourneySearchResponse,
  OptionalExtraSelection,
  PassengerDetailInput,
  RevalidationResult,
  SavedItinerary,
  SimulationFlags,
  StationNode,
  TravelClass,
  UserSession,
} from '../../shared/models';

export interface SearchParamsPayload {
  from: string;
  to: string;
  trip: 'oneway' | 'roundtrip';
  out: string;
  out_time?: string;
  ret?: string;
  ret_time?: string;
  adults: number;
  youths: number;
  seniors: number;
  class: TravelClass;
  cards: DiscountCardId[];
}

@Injectable({providedIn: 'root'})
export class RailApi {
  private readonly http = inject(HttpClient);

  searchStations(query: string): Observable<{stations: StationNode[]}> {
    const params = new HttpParams().set('q', query);
    return this.http.get<{stations: StationNode[]}>('/api/stations', {params});
  }

  searchJourneys(payload: SearchParamsPayload): Observable<JourneySearchResponse> {
    let params = new HttpParams()
      .set('from', payload.from)
      .set('to', payload.to)
      .set('trip', payload.trip)
      .set('out', payload.out)
      .set('adults', String(payload.adults))
      .set('youths', String(payload.youths))
      .set('seniors', String(payload.seniors))
      .set('class', payload.class);

    if (payload.out_time) params = params.set('out_time', payload.out_time);
    if (payload.trip === 'roundtrip' && payload.ret) {
      params = params.set('ret', payload.ret);
      if (payload.ret_time) params = params.set('ret_time', payload.ret_time);
    }
    if (payload.cards.length > 0) {
      params = params.set('cards', payload.cards.join(','));
    }

    return this.http.get<JourneySearchResponse>('/api/journeys/search', {params});
  }

  revalidateOffers(
    outwardOffer: FareOffer,
    returnOffer: FareOffer | null,
  ): Observable<{outward: RevalidationResult; return: RevalidationResult | null}> {
    return this.http.post<{outward: RevalidationResult; return: RevalidationResult | null}>(
      '/api/offers/revalidate',
      {
        outward_offer: outwardOffer,
        return_offer: returnOffer,
      },
    );
  }

  prepareSellerHandoff(offer: FareOffer): Observable<{
    revalidation: RevalidationResult;
    seller_name: string;
    redirect_url: string;
    notice: string;
  }> {
    return this.http.post<{
      revalidation: RevalidationResult;
      seller_name: string;
      redirect_url: string;
      notice: string;
    }>('/api/handoff/prepare', {offer});
  }

  checkoutBooking(
    idempotencyKey: string,
    payload: {
      outward_itinerary: JourneyItinerary;
      outward_offer: FareOffer;
      return_itinerary: JourneyItinerary | null;
      return_offer: FareOffer | null;
      passengers: PassengerDetailInput[];
      contact_email: string;
      contact_phone: string;
      optional_extras: OptionalExtraSelection[];
      payment_method_label: string;
      accept_price_change: boolean;
      accepted_conditions: boolean;
    },
  ): Observable<{booking: BookingRecord; user: UserSession; token: string | null}> {
    return this.http.post<{booking: BookingRecord; user: UserSession; token: string | null}>(
      '/api/bookings/checkout',
      payload,
      {
        headers: {'Idempotency-Key': idempotencyKey},
      },
    );
  }

  triggerDuplicateWebhookDemo(eventId: string, bookingId: string): Observable<{
    deduplicated: boolean;
    message: string;
  }> {
    return this.http.post<{deduplicated: boolean; message: string}>(
      '/api/payments/webhook-demo',
      {event_id: eventId, booking_id: bookingId},
    );
  }

  getMyBookings(): Observable<{bookings: BookingRecord[]}> {
    return this.http.get<{bookings: BookingRecord[]}>('/api/bookings');
  }

  cancelBooking(id: string, reason: string): Observable<{booking: BookingRecord}> {
    return this.http.post<{booking: BookingRecord}>(`/api/bookings/${id}/cancel`, {reason});
  }

  requestExchange(
    id: string,
    desiredDate: string,
    note: string,
  ): Observable<{booking: BookingRecord}> {
    return this.http.post<{booking: BookingRecord}>(`/api/bookings/${id}/exchange`, {
      desired_date: desiredDate,
      note,
    });
  }

  requestAssistance(
    id: string,
    stationId: string,
    assistanceType: string,
    notes: string,
  ): Observable<{booking: BookingRecord}> {
    return this.http.post<{booking: BookingRecord}>(`/api/bookings/${id}/assistance`, {
      station_id: stationId,
      assistance_type: assistanceType,
      notes,
    });
  }

  getSavedItineraries(): Observable<{saved_itineraries: SavedItinerary[]}> {
    return this.http.get<{saved_itineraries: SavedItinerary[]}>('/api/saved-itineraries');
  }

  saveItinerary(
    label: string,
    outwardItinerary: JourneyItinerary,
    quotedCents: number,
  ): Observable<{saved_itinerary: SavedItinerary}> {
    return this.http.post<{saved_itinerary: SavedItinerary}>('/api/saved-itineraries', {
      label,
      outward_itinerary: outwardItinerary,
      quoted_cents: quotedCents,
    });
  }

  deleteSavedItinerary(id: string): Observable<{ok: boolean}> {
    return this.http.delete<{ok: boolean}>(`/api/saved-itineraries/${id}`);
  }

  getSimulationFlags(): Observable<{simulation: SimulationFlags}> {
    return this.http.get<{simulation: SimulationFlags}>('/api/demo/simulation');
  }

  updateSimulationFlags(flags: Partial<SimulationFlags>): Observable<{simulation: SimulationFlags}> {
    return this.http.post<{simulation: SimulationFlags}>('/api/demo/simulation', flags);
  }

  triggerReconciliation(): Observable<{checked: number; resolved: number; details: string[]}> {
    return this.http.post<{checked: number; resolved: number; details: string[]}>(
      '/api/demo/reconcile',
      {},
    );
  }
}
