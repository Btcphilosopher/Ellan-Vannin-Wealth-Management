import {HttpInterceptorFn} from '@angular/common/http';
import {inject} from '@angular/core';
import {AuthStore} from './auth-store';

export const authInterceptor: HttpInterceptorFn = (req, next) => {
  const auth = inject(AuthStore);
  const token = auth.getToken();

  let headers = req.headers.set('X-Requested-With', 'XMLHttpRequest');
  if (token && !headers.has('Authorization')) {
    headers = headers.set('Authorization', `Bearer ${token}`);
  }

  return next(req.clone({headers}));
};
