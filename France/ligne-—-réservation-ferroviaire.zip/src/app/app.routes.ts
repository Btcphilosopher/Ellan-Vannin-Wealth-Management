import {Routes} from '@angular/router';

export const routes: Routes = [
  {
    path: '',
    loadComponent: () => import('./pages/home-page').then((m) => m.HomePage),
    title: 'LIGNE — Réservation ferroviaire',
  },
  {
    path: 'destinations',
    loadComponent: () => import('./pages/destinations-page').then((m) => m.DestinationsPage),
    title: 'Destinations — LIGNE',
  },
  {
    path: 'reservation',
    loadComponent: () => import('./pages/checkout-page').then((m) => m.CheckoutPage),
    title: 'Finaliser votre réservation — LIGNE',
  },
  {
    path: 'mes-voyages',
    loadComponent: () => import('./pages/trips-page').then((m) => m.TripsPage),
    title: 'Mes voyages — LIGNE',
  },
  {
    path: 'aide',
    loadComponent: () => import('./pages/help-page').then((m) => m.HelpPage),
    title: 'Aide et scénarios — LIGNE',
  },
  {
    path: 'admin',
    loadComponent: () => import('./pages/admin-page').then((m) => m.AdminPage),
    title: 'Administration — LIGNE',
  },
  {
    path: '**',
    redirectTo: '',
  },
];
