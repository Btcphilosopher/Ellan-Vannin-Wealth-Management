import {
  ChangeDetectionStrategy,
  Component,
  inject,
  OnInit,
  PLATFORM_ID,
  signal,
} from '@angular/core';
import {isPlatformBrowser} from '@angular/common';
import {HttpClient} from '@angular/common/http';
import {FormControl, FormGroup, ReactiveFormsModule, Validators} from '@angular/forms';
import {MatIconModule} from '@angular/material/icon';
import {firstValueFrom} from 'rxjs';
import type {
  AuditEntry,
  BookingRecord,
  ProviderHealth,
  SupportCase,
  UserSession,
} from '../../shared/models';
import {AuthStore} from '../services/auth-store';
import {
  formatBookingStateFr,
  formatEuroCents,
  formatRefundStateFr,
} from '../shared/formatters';

interface AdminFixtureRow {
  template_id: string;
  provider_id: string;
  origin: string;
  destination: string;
  departure: string;
  product: string;
  default_second_class_cents: number;
  override_cents: number | null;
  unavailable: boolean;
}

interface AdminOverviewResponse {
  providers: ProviderHealth[];
  fixtures: AdminFixtureRow[];
  bookings: BookingRecord[];
  support_cases: SupportCase[];
  audit_logs: AuditEntry[];
  stations_count: number;
}

@Component({
  selector: 'app-admin-page',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [ReactiveFormsModule, MatIconModule],
  template: `
    <main class="min-h-screen bg-[#FAF8F5] py-10">
      <div class="max-w-[1200px] mx-auto px-4 sm:px-6 space-y-6">
        <div class="flex flex-wrap items-end justify-between gap-4">
          <div>
            <h1 class="font-serif-display text-3xl font-semibold text-[#0E1F3B]">
              Console d’administration LIGNE
            </h1>
            <div class="w-12 h-[2.5px] bg-[#D63D2E] mt-2"></div>
            <p class="mt-2 text-sm text-[#4B5A73]">
              Supervision des fournisseurs, référentiel tarifaire, réconciliation paiements, remboursements, SAV et journal d’audit.
            </p>
          </div>
          @if (auth.isAdmin()) {
            <button
              type="button"
              (click)="loadOverview()"
              class="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl border border-[#CDD3DE] bg-white hover:bg-[#FAF8F5] text-xs font-semibold text-[#0E1F3B]"
            >
              <mat-icon class="!text-[16px] !w-[16px] !h-[16px]">refresh</mat-icon>
              <span>Actualiser</span>
            </button>
          }
        </div>

        @if (!auth.isAdmin()) {
          <div class="max-w-md bg-white border border-[#E3E6EC] rounded-2xl p-6 sm:p-7 space-y-4">
            @if (needsBootstrap()) {
              <div>
                <h2 class="font-serif-display text-xl font-semibold text-[#0E1F3B]">
                  Initialisation de l’accès administrateur
                </h2>
                <p class="text-xs text-[#4B5A73] mt-1">
                  Aucun code administrateur n’est encore configuré. Définissez le mot de passe d’administration initial (8 caractères minimum) pour verrouiller cet espace.
                </p>
              </div>
            } @else {
              <div>
                <h2 class="font-serif-display text-xl font-semibold text-[#0E1F3B]">
                  Connexion administrateur
                </h2>
                <p class="text-xs text-[#4B5A73] mt-1">
                  Saisissez le mot de passe administrateur configuré pour accéder aux outils protégés.
                </p>
              </div>
            }

            <form [formGroup]="adminForm" (ngSubmit)="submitAdminAuth()" class="space-y-3">
              <div>
                <label for="admin-passcode" class="block text-xs font-medium text-[#0E1F3B] mb-1">
                  Mot de passe administrateur
                </label>
                <input
                  id="admin-passcode"
                  type="password"
                  formControlName="passcode"
                  placeholder="••••••••"
                  class="w-full px-3.5 py-2.5 text-sm border border-[#CDD3DE] rounded-xl focus:border-[#0F54D4] focus:outline-none"
                />
              </div>

              @if (authError()) {
                <p class="text-xs text-[#B42318] bg-[#FDECEA] border border-[#F5C2BE] rounded-lg px-3 py-2" role="alert">
                  {{ authError() }}
                </p>
              }

              <button
                type="submit"
                class="w-full px-4 py-2.5 rounded-xl bg-[#0F54D4] hover:bg-[#0B44B0] text-white text-sm font-semibold"
              >
                {{ needsBootstrap() ? 'Créer et activer l’accès admin' : 'Déverrouiller la console' }}
              </button>
            </form>
          </div>
        } @else if (overview(); as data) {
          <!-- Admin Tabs -->
          <div class="flex flex-wrap gap-2">
            @for (tab of tabs; track tab.id) {
              <button
                type="button"
                (click)="activeTab.set(tab.id)"
                [class]="
                  activeTab() === tab.id
                    ? 'px-4 py-2 rounded-xl text-xs font-semibold bg-[#0E1F3B] text-white'
                    : 'px-4 py-2 rounded-xl text-xs font-medium bg-white border border-[#E3E6EC] text-[#2A3B59]'
                "
              >
                {{ tab.label }}
              </button>
            }
          </div>

          @if (actionMsg()) {
            <p class="text-xs text-[#0F54D4] bg-[#EEF4FF] border border-[#C7DAFC] rounded-xl px-4 py-2.5">
              {{ actionMsg() }}
            </p>
          }

          <!-- Tab 1: Provider Health -->
          @if (activeTab() === 'providers') {
            <div class="grid grid-cols-1 md:grid-cols-2 gap-5">
              @for (p of data.providers; track p.provider_id) {
                <div class="bg-white border border-[#E3E6EC] rounded-2xl p-5 space-y-3">
                  <div class="flex items-center justify-between">
                    <h2 class="text-base font-semibold text-[#0E1F3B]">{{ p.provider_name }}</h2>
                    <span class="text-xs font-semibold text-[#0F54D4]">
                      {{ p.status === 'healthy' ? 'Opérationnel' : 'Timeout simulé' }} · {{ p.avg_latency_ms }} ms
                    </span>
                  </div>
                  <p class="text-xs text-[#4B5A73]">
                    Mode : {{ p.booking_mode === 'integrated_demo' ? 'Réservation intégrée' : 'Redirection vendeur' }}
                  </p>
                  <div class="text-xs text-[#334155] space-y-1 pt-2 border-t border-[#E3E6EC]">
                    <p>Recherche trajets : {{ p.capabilities.journey_search ? 'Oui' : 'Non' }}</p>
                    <p>Revalidation tarif : {{ p.capabilities.offer_revalidation ? 'Oui' : 'Non' }}</p>
                    <p>Réservation directe : {{ p.capabilities.integrated_booking ? 'Oui' : 'Non' }}</p>
                    <p>Émission billet : {{ p.capabilities.ticket_retrieval ? 'Oui' : 'Non' }}</p>
                  </div>
                </div>
              }
            </div>
          }

          <!-- Tab 2: Fixtures -->
          @if (activeTab() === 'fixtures') {
            <div class="bg-white border border-[#E3E6EC] rounded-2xl p-5 overflow-x-auto">
              <table class="w-full text-left border-collapse text-xs">
                <thead>
                  <tr class="border-b border-[#E3E6EC] text-[#4B5A73]">
                    <th class="py-2 pr-3">ID Modèle</th>
                    <th class="py-2 pr-3">Corridor</th>
                    <th class="py-2 pr-3">Départ</th>
                    <th class="py-2 pr-3">Produit</th>
                    <th class="py-2 pr-3">Prix défaut</th>
                    <th class="py-2 pr-3">Actions</th>
                  </tr>
                </thead>
                <tbody class="divide-y divide-[#E3E6EC]">
                  @for (fx of data.fixtures; track fx.template_id) {
                    <tr>
                      <td class="py-2.5 pr-3 font-mono-tabular font-semibold">{{ fx.template_id }}</td>
                      <td class="py-2.5 pr-3">{{ fx.origin }} → {{ fx.destination }}</td>
                      <td class="py-2.5 pr-3 tabular-nums">{{ fx.departure }}</td>
                      <td class="py-2.5 pr-3">{{ fx.product }}</td>
                      <td class="py-2.5 pr-3 tabular-nums">
                        {{ formatPrice(fx.override_cents ?? fx.default_second_class_cents) }}
                        @if (fx.unavailable) {
                          <span class="text-[#B42318] ml-1">(Épuisé)</span>
                        }
                      </td>
                      <td class="py-2.5 flex items-center gap-2">
                        <button
                          type="button"
                          (click)="toggleFixtureUnavailable(fx)"
                          class="px-2.5 py-1 rounded-lg border border-[#CDD3DE] hover:bg-[#FAF8F5]"
                        >
                          {{ fx.unavailable ? 'Rendre disponible' : 'Marquer épuisé' }}
                        </button>
                      </td>
                    </tr>
                  }
                </tbody>
              </table>
            </div>
          }

          <!-- Tab 3: Booking Investigations & Reconciliation -->
          @if (activeTab() === 'bookings') {
            <div class="bg-white border border-[#E3E6EC] rounded-2xl p-5 space-y-4">
              <div class="flex flex-wrap items-center justify-between gap-3">
                <h2 class="text-base font-semibold text-[#0E1F3B]">
                  Dossiers de réservation & réconciliation paiements
                </h2>
                <button
                  type="button"
                  (click)="runReconciliation()"
                  class="px-4 py-2 rounded-xl bg-[#0F54D4] text-white text-xs font-semibold"
                >
                  Exécuter le worker de réconciliation
                </button>
              </div>

              <div class="space-y-3">
                @for (b of data.bookings; track b.booking_id) {
                  <div class="p-4 rounded-xl border border-[#E3E6EC] text-xs flex flex-wrap items-center justify-between gap-3">
                    <div>
                      <p class="font-semibold text-[#0E1F3B]">
                        {{ b.booking_reference }} · {{ b.outward_itinerary.origin_station.id }} → {{ b.outward_itinerary.destination_station.id }}
                        · <span class="text-[#0F54D4]">{{ stateLabel(b.state) }}</span>
                      </p>
                      <p class="text-[#4B5A73] mt-0.5">
                        Contact : {{ b.contact_email }} · Ordre : {{ b.provider_order_ref }}
                        · Total : {{ formatPrice(b.total_paid_cents) }}
                      </p>
                    </div>
                    <span class="font-mono-tabular text-[11px] text-[#64748B]">
                      Idem : {{ b.payment?.idempotency_key ?? 'N/A' }}
                    </span>
                  </div>
                }
              </div>
            </div>
          }

          <!-- Tab 4: Refunds & Support Cases -->
          @if (activeTab() === 'refunds') {
            <div class="grid grid-cols-1 lg:grid-cols-2 gap-5">
              <div class="bg-white border border-[#E3E6EC] rounded-2xl p-5 space-y-3">
                <h2 class="text-base font-semibold text-[#0E1F3B]">Remboursements</h2>
                @for (b of data.bookings; track b.booking_id) {
                  @for (ref of b.refunds; track ref.refund_id) {
                    <div class="p-3.5 rounded-xl border border-[#E3E6EC] text-xs space-y-2">
                      <div class="flex justify-between">
                        <span class="font-mono-tabular font-semibold">{{ ref.refund_id }} ({{ b.booking_reference }})</span>
                        <span class="font-semibold text-[#0F54D4]">{{ refundLabel(ref.state) }}</span>
                      </div>
                      <p class="text-[#4B5A73]">Net : {{ formatPrice(ref.net_refund_cents) }} · {{ ref.reason }}</p>
                      @if (ref.state !== 'credited') {
                        <div class="flex gap-2">
                          <button
                            type="button"
                            (click)="advanceRefund(ref.refund_id, 'approved')"
                            class="px-2.5 py-1 rounded-lg border border-[#CDD3DE]"
                          >
                            Approuver
                          </button>
                          <button
                            type="button"
                            (click)="advanceRefund(ref.refund_id, 'credited')"
                            class="px-2.5 py-1 rounded-lg bg-[#0F54D4] text-white"
                          >
                            Marquer crédité
                          </button>
                        </div>
                      }
                    </div>
                  }
                }
              </div>

              <div class="bg-white border border-[#E3E6EC] rounded-2xl p-5 space-y-3">
                <h2 class="text-base font-semibold text-[#0E1F3B]">Dossiers SAV</h2>
                @for (c of data.support_cases; track c.case_id) {
                  <div class="p-3.5 rounded-xl border border-[#E3E6EC] text-xs space-y-1.5">
                    <div class="flex justify-between">
                      <span class="font-semibold text-[#0E1F3B]">{{ c.case_id }} · {{ c.booking_reference }}</span>
                      <span class="text-[#0F54D4] font-semibold">{{ c.status }}</span>
                    </div>
                    <p class="text-[#334155]">{{ c.summary }}</p>
                    @if (c.status !== 'resolved') {
                      <button
                        type="button"
                        (click)="resolveCase(c.case_id)"
                        class="px-2.5 py-1 rounded-lg border border-[#CDD3DE]"
                      >
                        Marquer résolu
                      </button>
                    }
                  </div>
                }
              </div>
            </div>
          }

          <!-- Tab 5: Audit History -->
          @if (activeTab() === 'audit') {
            <div class="bg-white border border-[#E3E6EC] rounded-2xl p-5 space-y-2.5">
              <h2 class="text-base font-semibold text-[#0E1F3B]">Journal d’audit chronologique</h2>
              <div class="divide-y divide-[#E3E6EC] text-xs">
                @for (entry of data.audit_logs; track entry.audit_id) {
                  <div class="py-2.5 flex flex-wrap items-center justify-between gap-2">
                    <div>
                      <span class="font-mono-tabular font-semibold text-[#0E1F3B]">{{ entry.action }}</span>
                      <span class="text-[#4B5A73] ml-2">{{ entry.detail }}</span>
                    </div>
                    <span class="text-[#64748B]">{{ entry.actor }} · {{ entry.timestamp }}</span>
                  </div>
                }
              </div>
            </div>
          }
        }
      </div>
    </main>
  `,
})
export class AdminPage implements OnInit {
  private readonly http = inject(HttpClient);
  private readonly platformId = inject(PLATFORM_ID);
  readonly auth = inject(AuthStore);

  readonly needsBootstrap = signal(false);
  readonly authError = signal<string | null>(null);
  readonly overview = signal<AdminOverviewResponse | null>(null);
  readonly activeTab = signal<'providers' | 'fixtures' | 'bookings' | 'refunds' | 'audit'>('providers');
  readonly actionMsg = signal<string | null>(null);

  readonly tabs: {id: 'providers' | 'fixtures' | 'bookings' | 'refunds' | 'audit'; label: string}[] = [
    {id: 'providers', label: 'Santé fournisseurs'},
    {id: 'fixtures', label: 'Offres & Référentiel'},
    {id: 'bookings', label: 'Enquêtes & Réconciliation'},
    {id: 'refunds', label: 'Remboursements & SAV'},
    {id: 'audit', label: 'Journal d’audit'},
  ];

  readonly adminForm = new FormGroup({
    passcode: new FormControl('', {nonNullable: true, validators: [Validators.required, Validators.minLength(8)]}),
  });

  ngOnInit(): void {
    if (!isPlatformBrowser(this.platformId)) return;
    if (this.auth.isAdmin()) {
      void this.loadOverview();
      return;
    }
    this.http
      .get<{needs_bootstrap: boolean}>('/api/admin/status')
      .subscribe({
        next: (r) => this.needsBootstrap.set(r.needs_bootstrap),
      });
  }

  async submitAdminAuth(): Promise<void> {
    this.authError.set(null);
    if (this.adminForm.invalid) {
      this.authError.set('Saisissez au moins 8 caractères.');
      return;
    }
    const passcode = this.adminForm.controls.passcode.value;
    try {
      const endpoint = this.needsBootstrap() ? '/api/admin/bootstrap' : '/api/admin/login';
      const res = await firstValueFrom(
        this.http.post<{user: UserSession; token: string}>(endpoint, {passcode}),
      );
      this.auth.setSession(res.user, res.token);
      await this.loadOverview();
    } catch (err: unknown) {
      this.authError.set(
        (err as {error?: {error?: string}})?.error?.error || 'Accès refusé.',
      );
    }
  }

  async loadOverview(): Promise<void> {
    const res = await firstValueFrom(
      this.http.get<AdminOverviewResponse>('/api/admin/overview'),
    );
    this.overview.set(res);
  }

  async toggleFixtureUnavailable(fx: AdminFixtureRow): Promise<void> {
    await firstValueFrom(
      this.http.post('/api/admin/fixtures/update', {
        template_id: fx.template_id,
        override_cents: fx.override_cents,
        unavailable: !fx.unavailable,
      }),
    );
    this.actionMsg.set(`Disponibilité mise à jour pour ${fx.template_id}.`);
    await this.loadOverview();
  }

  async runReconciliation(): Promise<void> {
    const res = await firstValueFrom(
      this.http.post<{checked: number; resolved: number}>('/api/admin/reconciliation/run', {}),
    );
    this.actionMsg.set(`Réconciliation : ${res.checked} vérifié(s), ${res.resolved} résolu(s).`);
    await this.loadOverview();
  }

  async advanceRefund(refundId: string, nextState: 'approved' | 'credited'): Promise<void> {
    await firstValueFrom(
      this.http.post(`/api/admin/refunds/${refundId}/advance`, {next_state: nextState}),
    );
    this.actionMsg.set(`Remboursement ${refundId} mis à jour.`);
    await this.loadOverview();
  }

  async resolveCase(caseId: string): Promise<void> {
    await firstValueFrom(
      this.http.post(`/api/admin/cases/${caseId}/update`, {status: 'resolved'}),
    );
    this.actionMsg.set(`Dossier ${caseId} résolu.`);
    await this.loadOverview();
  }

  formatPrice(cents: number): string {
    return formatEuroCents(cents);
  }

  stateLabel(state: BookingRecord['state']): string {
    return formatBookingStateFr(state);
  }

  refundLabel(state: BookingRecord['refunds'][number]['state']): string {
    return formatRefundStateFr(state);
  }
}
