import {
  ChangeDetectionStrategy,
  Component,
  computed,
  effect,
  inject,
  OnInit,
  PLATFORM_ID,
  signal,
} from '@angular/core';
import {isPlatformBrowser} from '@angular/common';
import {FormControl, FormGroup, ReactiveFormsModule} from '@angular/forms';
import {Router, RouterLink} from '@angular/router';
import {MatIconModule} from '@angular/material/icon';
import {firstValueFrom} from 'rxjs';
import type {BookingRecord, SavedItinerary} from '../../shared/models';
import {AuthStore} from '../services/auth-store';
import {RailApi} from '../services/rail-api';
import {
  formatBookingStateFr,
  formatDateShortFr,
  formatDurationFr,
  formatEuroCents,
  formatRefundStateFr,
} from '../shared/formatters';

@Component({
  selector: 'app-trips-page',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [ReactiveFormsModule, RouterLink, MatIconModule],
  template: `
    <main class="min-h-screen bg-[#FAF8F5] py-10">
      <div class="max-w-[1120px] mx-auto px-4 sm:px-6">
        <div class="flex flex-wrap items-end justify-between gap-4 mb-6">
          <div>
            <h1 class="font-serif-display text-3xl sm:text-4xl font-semibold text-[#0E1F3B]">
              Mes voyages
            </h1>
            <div class="w-12 h-[2.5px] bg-[#D63D2E] mt-2"></div>
            <p class="mt-2.5 text-sm text-[#4B5A73]">
              Retrouvez vos dossiers de réservation, documents spécimens, demandes d’échange ou de remboursement et itinéraires enregistrés.
            </p>
          </div>

          <a
            routerLink="/"
            class="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-[#0F54D4] hover:bg-[#0B44B0] text-white text-sm font-semibold"
          >
            <mat-icon class="!text-[18px] !w-[18px] !h-[18px]">add</mat-icon>
            <span>Nouveau trajet</span>
          </a>
        </div>

        @if (!auth.isAuthenticated()) {
          <div class="bg-white border border-[#E3E6EC] rounded-2xl p-8 max-w-xl">
            <h2 class="font-serif-display text-2xl font-semibold text-[#0E1F3B]">
              Connectez-vous pour accéder à vos dossiers
            </h2>
            <p class="text-sm text-[#4B5A73] mt-2 leading-relaxed">
              Par sécurité, chaque réservation est strictement isolée par compte utilisateur. Utilisez votre compte ou accédez directement au profil voyageur de démonstration.
            </p>
            <div class="mt-5 flex flex-wrap gap-3">
              <button
                type="button"
                (click)="signInDemo()"
                class="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-[#0F54D4] hover:bg-[#0B44B0] text-white text-sm font-semibold"
              >
                <mat-icon class="!text-[18px] !w-[18px] !h-[18px]">bolt</mat-icon>
                <span>Accéder au compte démo (Camille Laurent)</span>
              </button>
              <button
                type="button"
                (click)="auth.openModal()"
                class="px-5 py-2.5 rounded-xl border border-[#CDD3DE] bg-white hover:bg-[#FAF8F5] text-sm font-semibold text-[#0E1F3B]"
              >
                Connexion par e-mail
              </button>
            </div>
          </div>
        } @else {
          <!-- Section Tabs -->
          <div class="flex flex-wrap items-center gap-2 mb-6">
            <button
              type="button"
              (click)="activeTab.set('upcoming')"
              [class]="
                activeTab() === 'upcoming'
                  ? 'px-4 py-2 rounded-xl text-sm font-semibold bg-[#0E1F3B] text-white'
                  : 'px-4 py-2 rounded-xl text-sm font-medium bg-white border border-[#E3E6EC] text-[#2A3B59]'
              "
            >
              Voyages à venir ({{ upcomingBookings().length }})
            </button>
            <button
              type="button"
              (click)="activeTab.set('past')"
              [class]="
                activeTab() === 'past'
                  ? 'px-4 py-2 rounded-xl text-sm font-semibold bg-[#0E1F3B] text-white'
                  : 'px-4 py-2 rounded-xl text-sm font-medium bg-white border border-[#E3E6EC] text-[#2A3B59]'
              "
            >
              Voyages passés ({{ pastBookings().length }})
            </button>
            <button
              type="button"
              (click)="activeTab.set('saved')"
              [class]="
                activeTab() === 'saved'
                  ? 'px-4 py-2 rounded-xl text-sm font-semibold bg-[#0E1F3B] text-white'
                  : 'px-4 py-2 rounded-xl text-sm font-medium bg-white border border-[#E3E6EC] text-[#2A3B59]'
              "
            >
              Itinéraires enregistrés ({{ savedItineraries().length }})
            </button>
          </div>

          @if (loading()) {
            <div class="h-40 rounded-2xl bg-white border border-[#E3E6EC] animate-pulse"></div>
          } @else if (activeTab() === 'saved') {
            <div class="space-y-4">
              <div class="p-4 rounded-xl bg-[#EEF4FF] border border-[#C7DAFC] text-xs text-[#0E1F3B]">
                Les itinéraires enregistrés sont des repères de comparaison. Ils ne constituent ni une place réservée ni un billet acheté.
              </div>
              @if (savedItineraries().length === 0) {
                <div class="bg-white border border-[#E3E6EC] rounded-2xl p-8 text-center text-sm text-[#4B5A73]">
                  Aucun itinéraire enregistré pour le moment.
                </div>
              } @else {
                @for (sav of savedItineraries(); track sav.saved_id) {
                  <div class="bg-white border border-[#E3E6EC] rounded-2xl p-5 flex flex-wrap items-center justify-between gap-4">
                    <div>
                      <p class="text-xs text-[#4B5A73]">Itinéraire enregistré · non acheté</p>
                      <h3 class="text-base font-semibold text-[#0E1F3B] mt-0.5">{{ sav.label }}</h3>
                      <p class="text-xs text-[#4B5A73] mt-0.5">
                        {{ sav.outward_itinerary.departure_local_label }} → {{ sav.outward_itinerary.arrival_local_label }}
                        · Tarif indicatif au moment de la sauvegarde : {{ formatPrice(sav.quoted_cents) }}
                      </p>
                    </div>
                    <div class="flex items-center gap-2">
                      <button
                        type="button"
                        (click)="reSearchSaved(sav)"
                        class="px-4 py-2 rounded-xl bg-[#0F54D4] text-white text-xs font-semibold"
                      >
                        Actualiser le tarif
                      </button>
                      <button
                        type="button"
                        (click)="deleteSaved(sav.saved_id)"
                        class="px-3 py-2 rounded-xl border border-[#CDD3DE] text-xs text-[#B42318]"
                      >
                        Supprimer
                      </button>
                    </div>
                  </div>
                }
              }
            </div>
          } @else {
            @let list = activeTab() === 'upcoming' ? upcomingBookings() : pastBookings();
            @if (list.length === 0) {
              <div class="bg-white border border-[#E3E6EC] rounded-2xl p-8 text-center text-sm text-[#4B5A73]">
                Aucun voyage dans cette catégorie.
              </div>
            } @else {
              <div class="space-y-6">
                @for (bkg of list; track bkg.booking_id) {
                  <article class="bg-white border border-[#E3E6EC] rounded-2xl overflow-hidden">
                    <!-- Specimen Notice Banner -->
                    <div class="bg-[#FDECEA] border-b border-[#F5C2BE] px-5 py-2.5 flex flex-wrap items-center justify-between gap-2">
                      <span class="text-xs font-bold tracking-wide text-[#B42318]">
                        DÉMONSTRATION — NON VALABLE POUR VOYAGER
                      </span>
                      <span class="font-mono-tabular text-xs text-[#0E1F3B] font-semibold">
                        Dossier {{ bkg.booking_reference }} · {{ stateLabel(bkg.state) }}
                      </span>
                    </div>

                    <div class="p-5 sm:p-6 space-y-5">
                      <!-- Route & Price Header -->
                      <div class="flex flex-wrap items-start justify-between gap-4">
                        <div>
                          <p class="text-xs text-[#4B5A73]">
                            {{ bkg.provider_name }} · {{ formatDate(bkg.outward_itinerary.departure_iso.slice(0, 10)) }}
                          </p>
                          <h2 class="font-serif-display text-2xl font-semibold text-[#0E1F3B] mt-0.5">
                            {{ bkg.outward_itinerary.origin_station.name }} ({{ bkg.outward_itinerary.departure_local_label }})
                            → {{ bkg.outward_itinerary.destination_station.name }} ({{ bkg.outward_itinerary.arrival_local_label }})
                          </h2>
                          @if (bkg.return_itinerary; as ret) {
                            <p class="text-sm font-medium text-[#2A3B59] mt-1">
                              Retour : {{ ret.origin_station.name }} ({{ ret.departure_local_label }}) →
                              {{ ret.destination_station.name }} ({{ ret.arrival_local_label }})
                            </p>
                          }
                          <p class="text-xs text-[#4B5A73] mt-1">
                            {{ formatDuration(bkg.outward_itinerary.total_duration_minutes) }}
                            · {{ bkg.outward_offer.travel_class === '1' ? '1re classe' : '2de classe' }}
                            · {{ bkg.outward_offer.ticket_product }}
                          </p>
                        </div>

                        <div class="text-right">
                          <p class="text-xl font-bold text-[#0E1F3B] tabular-nums">
                            {{ formatPrice(bkg.total_paid_cents) }}
                          </p>
                          <p class="text-xs text-[#4B5A73]">
                            @if (bkg.cancellation_status === 'cancelled') {
                              Annulation demandée
                            } @else if (bkg.cancellation_status === 'exchange_requested') {
                              Échange demandé
                            } @else {
                              Réservation active
                            }
                          </p>
                        </div>
                      </div>

                      <!-- Passengers, Seats & Non-functional Sample Graphic -->
                      <div class="grid grid-cols-1 md:grid-cols-12 gap-5 pt-4 border-t border-[#E3E6EC]">
                        <div class="md:col-span-8 space-y-3 text-sm">
                          <div>
                            <p class="text-xs font-semibold text-[#0E1F3B]">Voyageurs & placement</p>
                            <p class="text-xs text-[#334155] mt-1">
                              {{ passengerNames(bkg) }}
                              @if (bkg.seat_reservations.length > 0) {
                                <span>
                                  · {{ bkg.seat_reservations[0].coach }} ({{ bkg.seat_reservations[0].seat_numbers.join(', ') }})
                                </span>
                              }
                            </p>
                          </div>

                          <div>
                            <p class="text-xs font-semibold text-[#0E1F3B]">Conditions tarifaires retenues</p>
                            <p class="text-xs text-[#4B5A73] mt-0.5">
                              Échange : {{ bkg.outward_offer.change_conditions.summary }}
                            </p>
                            <p class="text-xs text-[#4B5A73]">
                              Remboursement : {{ bkg.outward_offer.refund_conditions.summary }}
                            </p>
                          </div>

                          @if (bkg.payment) {
                            <div class="text-xs text-[#4B5A73]">
                              Reçu paiement : <span class="font-mono-tabular">{{ bkg.payment.payment_id }}</span>
                              · {{ bkg.payment.method_label }} ({{ bkg.payment.masked_reference }})
                              · Clé : <span class="font-mono-tabular">{{ bkg.payment.idempotency_key }}</span>
                            </div>
                          }
                        </div>

                        <!-- Visibly non-functional sample ticket graphic (NO operational barcode) -->
                        <div class="md:col-span-4 flex flex-col items-center justify-center p-4 rounded-xl border border-dashed border-[#CDD3DE] bg-[#FAF8F5] text-center">
                          <svg width="116" height="68" viewBox="0 0 116 68" fill="none" aria-label="Graphique spécimen non valable pour voyager">
                            <rect x="2" y="2" width="112" height="64" rx="8" stroke="#94A3B8" stroke-dasharray="4 4" fill="#FFFFFF" />
                            <line x1="16" y1="16" x2="100" y2="52" stroke="#D63D2E" stroke-width="1.5" stroke-dasharray="3 3" />
                            <line x1="100" y1="16" x2="16" y2="52" stroke="#D63D2E" stroke-width="1.5" stroke-dasharray="3 3" />
                            <text x="58" y="38" text-anchor="middle" fill="#0E1F3B" font-size="10" font-weight="700" font-family="monospace">
                              SPÉCIMEN
                            </text>
                          </svg>
                          <p class="text-[11px] font-semibold text-[#B42318] mt-2">
                            Spécimen visuel sans code-barres opérationnel
                          </p>
                          @if (bkg.tickets.length > 0) {
                            <a
                              [href]="bkg.tickets[0].document_url"
                              target="_blank"
                              rel="noopener"
                              class="mt-2 inline-flex items-center gap-1 text-xs font-semibold text-[#0F54D4] hover:underline"
                            >
                              <mat-icon class="!text-[15px] !w-[15px] !h-[15px]">download</mat-icon>
                              <span>Télécharger le document spécimen</span>
                            </a>
                          }
                        </div>
                      </div>

                      <!-- Reconciliation Notice if pending -->
                      @if (bkg.state === 'reconciliation_required') {
                        <div class="p-4 rounded-xl bg-[#FFF7ED] border border-[#FED7AA] text-xs text-[#9A3412] flex flex-wrap items-center justify-between gap-3">
                          <span>
                            Paiement confirmé, confirmation transporteur en attente de réconciliation ({{ bkg.provider_order_ref }}).
                          </span>
                          <button
                            type="button"
                            (click)="runReconciliation()"
                            class="px-3.5 py-1.5 rounded-lg bg-[#9A3412] text-white font-semibold"
                          >
                            Réconcilier maintenant
                          </button>
                        </div>
                      }

                      <!-- Refund Progress Tracker -->
                      @if (bkg.refunds.length > 0) {
                        <div class="p-4 rounded-xl bg-[#FAF8F5] border border-[#E3E6EC] space-y-2">
                          <p class="text-xs font-semibold text-[#0E1F3B]">Suivi des remboursements simulés</p>
                          @for (ref of bkg.refunds; track ref.refund_id) {
                            <div class="flex flex-wrap items-center justify-between gap-2 text-xs">
                              <span>
                                <strong class="font-mono-tabular">{{ ref.refund_id }}</strong> ·
                                Net remboursé : <strong class="tabular-nums">{{ formatPrice(ref.net_refund_cents) }}</strong>
                                (retenue {{ formatPrice(ref.penalty_cents) }})
                              </span>
                              <span class="font-semibold text-[#0F54D4]">{{ refundStateLabel(ref.state) }}</span>
                            </div>
                          }
                        </div>
                      }

                      <!-- Assistance Requests (kept separate from confirmed assistance) -->
                      @if (bkg.assistance_requests.length > 0) {
                        <div class="p-4 rounded-xl bg-[#FAF8F5] border border-[#E3E6EC] space-y-1.5 text-xs">
                          <p class="font-semibold text-[#0E1F3B]">Demandes d’assistance en gare</p>
                          @for (ast of bkg.assistance_requests; track ast.request_id) {
                            <p class="text-[#334155]">
                              {{ ast.station_name }} · {{ ast.assistance_type }} —
                              <strong>
                                {{
                                  ast.status === 'confirmed'
                                    ? 'Assistance confirmée'
                                    : 'Demande enregistrée (non confirmée par le pôle gare)'
                                }}
                              </strong>
                            </p>
                          }
                        </div>
                      }

                      <!-- Action Buttons -->
                      <div class="flex flex-wrap items-center gap-3 pt-2 border-t border-[#E3E6EC]">
                        @if (bkg.cancellation_status !== 'cancelled') {
                          <button
                            type="button"
                            (click)="openExchange(bkg.booking_id)"
                            class="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl border border-[#CDD3DE] bg-white hover:bg-[#FAF8F5] text-xs font-semibold text-[#0E1F3B]"
                          >
                            <mat-icon class="!text-[16px] !w-[16px] !h-[16px]">swap_horiz</mat-icon>
                            <span>Demander un échange</span>
                          </button>
                          <button
                            type="button"
                            (click)="requestCancellation(bkg)"
                            class="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl border border-[#F5C2BE] bg-[#FDECEA] hover:bg-[#FADBD8] text-xs font-semibold text-[#B42318]"
                          >
                            <mat-icon class="!text-[16px] !w-[16px] !h-[16px]">cancel</mat-icon>
                            <span>Demander l’annulation & remboursement</span>
                          </button>
                        }
                        <button
                          type="button"
                          (click)="requestAssistance(bkg)"
                          class="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl border border-[#CDD3DE] bg-white hover:bg-[#FAF8F5] text-xs font-medium text-[#2A3B59]"
                        >
                          <mat-icon class="!text-[16px] !w-[16px] !h-[16px]">accessible</mat-icon>
                          <span>Demander une assistance en gare</span>
                        </button>
                      </div>

                      @if (exchangeBookingId() === bkg.booking_id) {
                        <form [formGroup]="exchangeForm" (ngSubmit)="submitExchange(bkg.booking_id)" class="p-4 rounded-xl bg-[#FAF8F5] border border-[#E3E6EC] flex flex-wrap items-end gap-3">
                          <div>
                            <label [for]="'ex-date-' + bkg.booking_id" class="block text-xs font-medium text-[#0E1F3B] mb-1">Nouvelle date souhaitée</label>
                            <input
                              [id]="'ex-date-' + bkg.booking_id"
                              type="date"
                              formControlName="desiredDate"
                              class="px-3 py-1.5 text-xs bg-white border border-[#CDD3DE] rounded-lg"
                            />
                          </div>
                          <div class="flex-1 min-w-[200px]">
                            <label [for]="'ex-note-' + bkg.booking_id" class="block text-xs font-medium text-[#0E1F3B] mb-1">Précision horaire</label>
                            <input
                              [id]="'ex-note-' + bkg.booking_id"
                              type="text"
                              formControlName="note"
                              placeholder="Ex. départ vers 14h00"
                              class="w-full px-3 py-1.5 text-xs bg-white border border-[#CDD3DE] rounded-lg"
                            />
                          </div>
                          <button
                            type="submit"
                            class="px-4 py-2 rounded-lg bg-[#0F54D4] text-white text-xs font-semibold"
                          >
                            Envoyer la demande
                          </button>
                        </form>
                      }
                    </div>
                  </article>
                }
              </div>
            }
          }
        }
      </div>
    </main>
  `,
})
export class TripsPage implements OnInit {
  private readonly railApi = inject(RailApi);
  private readonly router = inject(Router);
  private readonly platformId = inject(PLATFORM_ID);
  readonly auth = inject(AuthStore);

  readonly loading = signal(false);
  readonly bookings = signal<BookingRecord[]>([]);
  readonly savedItineraries = signal<SavedItinerary[]>([]);
  readonly activeTab = signal<'upcoming' | 'past' | 'saved'>('upcoming');
  readonly exchangeBookingId = signal<string | null>(null);

  readonly exchangeForm = new FormGroup({
    desiredDate: new FormControl('2027-06-19', {nonNullable: true}),
    note: new FormControl('', {nonNullable: true}),
  });

  readonly upcomingBookings = computed(() =>
    this.bookings().filter((b) => b.outward_itinerary.departure_iso >= '2026-11-28T00:00:00Z'),
  );

  readonly pastBookings = computed(() =>
    this.bookings().filter((b) => b.outward_itinerary.departure_iso < '2026-11-28T00:00:00Z'),
  );

  constructor() {
    effect(() => {
      if (this.auth.isAuthenticated() && isPlatformBrowser(this.platformId)) {
        void this.loadAll();
      }
    });
  }

  ngOnInit(): void {
    if (isPlatformBrowser(this.platformId) && this.auth.isAuthenticated()) {
      void this.loadAll();
    }
  }

  async signInDemo(): Promise<void> {
    await this.auth.loginDemoTraveler();
    await this.loadAll();
  }

  async loadAll(): Promise<void> {
    this.loading.set(true);
    try {
      const [bRes, sRes] = await Promise.all([
        firstValueFrom(this.railApi.getMyBookings()),
        firstValueFrom(this.railApi.getSavedItineraries()),
      ]);
      this.bookings.set(bRes.bookings);
      this.savedItineraries.set(sRes.saved_itineraries);
    } finally {
      this.loading.set(false);
    }
  }

  async requestCancellation(bkg: BookingRecord): Promise<void> {
    await firstValueFrom(
      this.railApi.cancelBooking(bkg.booking_id, 'Annulation demandée depuis Mes voyages'),
    );
    await this.loadAll();
  }

  openExchange(bookingId: string): void {
    this.exchangeBookingId.update((cur) => (cur === bookingId ? null : bookingId));
  }

  async submitExchange(bookingId: string): Promise<void> {
    const raw = this.exchangeForm.getRawValue();
    await firstValueFrom(
      this.railApi.requestExchange(bookingId, raw.desiredDate, raw.note),
    );
    this.exchangeBookingId.set(null);
    await this.loadAll();
  }

  async requestAssistance(bkg: BookingRecord): Promise<void> {
    await firstValueFrom(
      this.railApi.requestAssistance(
        bkg.booking_id,
        bkg.outward_itinerary.origin_station.id,
        'Accompagnement quai / mobilité',
        'Demande enregistrée par le voyageur (en attente de confirmation).',
      ),
    );
    await this.loadAll();
  }

  async runReconciliation(): Promise<void> {
    await firstValueFrom(this.railApi.triggerReconciliation());
    await this.loadAll();
  }

  reSearchSaved(sav: SavedItinerary): void {
    void this.router.navigate(['/'], {
      queryParams: {
        from: sav.from_station.id,
        to: sav.to_station.id,
        trip: 'oneway',
        out: sav.outward_itinerary.departure_iso.slice(0, 10),
      },
    });
  }

  async deleteSaved(id: string): Promise<void> {
    await firstValueFrom(this.railApi.deleteSavedItinerary(id));
    await this.loadAll();
  }

  passengerNames(bkg: BookingRecord): string {
    return bkg.passengers.map((p) => `${p.first_name} ${p.last_name}`).join(', ');
  }

  formatPrice(cents: number): string {
    return formatEuroCents(cents);
  }

  formatDuration(min: number): string {
    return formatDurationFr(min);
  }

  formatDate(d: string): string {
    return formatDateShortFr(d);
  }

  stateLabel(state: BookingRecord['state']): string {
    return formatBookingStateFr(state);
  }

  refundStateLabel(state: BookingRecord['refunds'][number]['state']): string {
    return formatRefundStateFr(state);
  }
}
