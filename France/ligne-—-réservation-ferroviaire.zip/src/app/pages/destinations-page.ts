import {ChangeDetectionStrategy, Component, inject, OnInit, PLATFORM_ID, signal} from '@angular/core';
import {isPlatformBrowser} from '@angular/common';
import {Router, RouterLink} from '@angular/router';
import {MatIconModule} from '@angular/material/icon';
import type {StationNode} from '../../shared/models';
import {RailApi} from '../services/rail-api';
import {formatStationKindFr} from '../shared/formatters';

interface CorridorCard {
  title: string;
  fromId: string;
  toId: string;
  duration: string;
  fromPrice: string;
  imageUrl?: string;
  description: string;
}

@Component({
  selector: 'app-destinations-page',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [RouterLink, MatIconModule],
  template: `
    <main class="min-h-screen bg-[#FAF8F5] py-10 sm:py-12">
      <div class="max-w-[1200px] mx-auto px-4 sm:px-6">
        <div class="max-w-2xl">
          <h1 class="font-serif-display text-3xl sm:text-4xl font-semibold text-[#0E1F3B]">
            Destinations et référentiel des gares
          </h1>
          <div class="w-12 h-[2.5px] bg-[#D63D2E] mt-2"></div>
          <p class="mt-3 text-sm sm:text-base text-[#2A3B59] leading-relaxed">
            Explorez les liaisons de démonstration au départ de Paris et consultez les attributs exacts de chaque gare (identifiant stable, fuseau horaire IANA et accessibilité documentée).
          </p>
        </div>

        <!-- Featured visual corridors -->
        <div class="mt-8 grid grid-cols-1 md:grid-cols-3 gap-6">
          @for (corridor of corridors; track corridor.toId) {
            <article class="bg-white border border-[#E3E6EC] rounded-2xl overflow-hidden flex flex-col">
              @if (corridor.imageUrl) {
                <div class="aspect-[16/9] bg-[#E8ECF2] overflow-hidden">
                  <img
                    [src]="corridor.imageUrl"
                    [alt]="corridor.title"
                    referrerpolicy="no-referrer"
                    class="w-full h-full object-cover"
                  />
                </div>
              }
              <div class="p-5 flex-1 flex flex-col justify-between gap-4">
                <div>
                  <p class="text-xs font-medium text-[#4B5A73]">
                    {{ corridor.duration }} · {{ corridor.fromPrice }}
                  </p>
                  <h2 class="font-serif-display text-xl font-semibold text-[#0E1F3B] mt-1">
                    {{ corridor.title }}
                  </h2>
                  <p class="text-sm text-[#334155] mt-2 leading-relaxed">
                    {{ corridor.description }}
                  </p>
                </div>
                <button
                  type="button"
                  (click)="searchCorridor(corridor.fromId, corridor.toId)"
                  class="w-full flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl bg-[#0F54D4] hover:bg-[#0B44B0] text-white text-sm font-semibold transition-colors ligne-focus"
                >
                  <mat-icon class="!text-[18px] !w-[18px] !h-[18px]">search</mat-icon>
                  <span>Rechercher ce trajet</span>
                </button>
              </div>
            </article>
          }
        </div>

        <!-- Cross-timezone & hub examples -->
        <div class="mt-10 bg-white border border-[#E3E6EC] rounded-2xl p-6">
          <div class="flex flex-wrap items-center justify-between gap-4 mb-5">
            <div>
              <h2 class="font-serif-display text-2xl font-semibold text-[#0E1F3B]">
                Gares, groupes de gares et pôles d’échanges
              </h2>
              <p class="text-xs text-[#4B5A73] mt-1">
                LIGNE ne remplace jamais silencieusement une gare parisienne par une autre : Paris Gare de Lyon (FRPLY) reste distincte de Paris Montparnasse (FRPMO).
              </p>
            </div>
            <button
              type="button"
              (click)="searchCorridor('FRPNO', 'GBSTP')"
              class="px-4 py-2 rounded-xl border border-[#0F54D4] text-[#0F54D4] hover:bg-[#EEF4FF] text-xs font-semibold transition-colors"
            >
              Tester Paris Nord → Londres (fuseaux IANA)
            </button>
          </div>

          <div class="overflow-x-auto">
            <table class="w-full text-left border-collapse text-sm">
              <thead>
                <tr class="border-b border-[#E3E6EC] text-xs text-[#4B5A73]">
                  <th class="py-2.5 pr-4 font-semibold">Code</th>
                  <th class="py-2.5 pr-4 font-semibold">Nom</th>
                  <th class="py-2.5 pr-4 font-semibold">Type</th>
                  <th class="py-2.5 pr-4 font-semibold">Fuseau IANA</th>
                  <th class="py-2.5 font-semibold">Accessibilité & Source</th>
                </tr>
              </thead>
              <tbody class="divide-y divide-[#E3E6EC]">
                @for (st of stations(); track st.id) {
                  <tr>
                    <td class="py-3 pr-4 font-mono-tabular text-xs font-semibold text-[#0E1F3B]">{{ st.id }}</td>
                    <td class="py-3 pr-4 font-medium text-[#0E1F3B]">{{ st.name }}</td>
                    <td class="py-3 pr-4 text-xs text-[#4B5A73]">{{ kindLabel(st.kind) }}</td>
                    <td class="py-3 pr-4 font-mono-tabular text-xs text-[#2A3B59]">{{ st.iana_timezone }}</td>
                    <td class="py-3 text-xs text-[#334155]">
                      <span>{{ st.accessibility.summary }}</span>
                      <span class="block text-[11px] text-[#64748B] mt-0.5">
                        Source : {{ st.accessibility.source }}
                      </span>
                    </td>
                  </tr>
                }
              </tbody>
            </table>
          </div>
        </div>

        <div class="mt-6 text-xs text-[#4B5A73] flex justify-between items-center">
          <a routerLink="/" class="text-[#0F54D4] hover:underline font-medium">← Retour à la recherche</a>
          <span>Données de démonstration indépendantes</span>
        </div>
      </div>
    </main>
  `,
})
export class DestinationsPage implements OnInit {
  private readonly railApi = inject(RailApi);
  private readonly router = inject(Router);
  private readonly platformId = inject(PLATFORM_ID);

  readonly stations = signal<StationNode[]>([]);

  readonly corridors: CorridorCard[] = [
    {
      title: 'Paris Montparnasse → Bordeaux Saint-Jean',
      fromId: 'FRPMO',
      toId: 'FRBDX',
      duration: '2 h 04 direct',
      fromPrice: 'Dès 54 €',
      imageUrl: '/src/assets/images/dest_bordeaux_1795859312912.jpg',
      description: 'Liaison grande vitesse Atlantique au départ exclusif de Paris Montparnasse.',
    },
    {
      title: 'Paris Gare de Lyon → Marseille Saint-Charles',
      fromId: 'FRPLY',
      toId: 'FRMRS',
      duration: '3 h 08 direct',
      fromPrice: 'Dès 62 €',
      imageUrl: '/src/assets/images/dest_marseille_1795859313524.jpg',
      description: 'Liaison Méditerranée directe vers le terminus Saint-Charles.',
    },
    {
      title: "Paris Gare de l'Est → Strasbourg",
      fromId: 'FRPES',
      toId: 'FRXSB',
      duration: '1 h 46 direct',
      fromPrice: 'Dès 45 €',
      imageUrl: '/src/assets/images/dest_strasbourg_1795859313333.jpg',
      description: "Liaison Est Grande Vitesse depuis Paris Gare de l'Est.",
    },
  ];

  ngOnInit(): void {
    if (!isPlatformBrowser(this.platformId)) return;
    this.railApi.searchStations('').subscribe({
      next: (r) => this.stations.set(r.stations),
    });
  }

  kindLabel(kind: StationNode['kind']): string {
    return formatStationKindFr(kind);
  }

  searchCorridor(fromId: string, toId: string): void {
    void this.router.navigate(['/'], {
      queryParams: {
        from: fromId,
        to: toId,
        trip: 'roundtrip',
        out: '2027-06-18',
        ret: '2027-06-21',
        adults: 1,
        class: '2',
      },
    });
  }
}
