import {
  ChangeDetectionStrategy,
  Component,
  inject,
  OnInit,
  PLATFORM_ID,
  signal,
} from '@angular/core';
import {isPlatformBrowser} from '@angular/common';
import {RouterLink} from '@angular/router';
import {MatIconModule} from '@angular/material/icon';
import {firstValueFrom} from 'rxjs';
import type {SimulationFlags} from '../../shared/models';
import {RailApi} from '../services/rail-api';

@Component({
  selector: 'app-help-page',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [RouterLink, MatIconModule],
  template: `
    <main class="min-h-screen bg-[#FAF8F5] py-10">
      <div class="max-w-[1120px] mx-auto px-4 sm:px-6 space-y-8">
        <div>
          <h1 class="font-serif-display text-3xl sm:text-4xl font-semibold text-[#0E1F3B]">
            Aide, transparence tarifaire & scénarios de démonstration
          </h1>
          <div class="w-12 h-[2.5px] bg-[#D63D2E] mt-2"></div>
          <p class="mt-3 text-sm text-[#2A3B59] max-w-2xl leading-relaxed">
            LIGNE est un prototype indépendant de réservation ferroviaire. Cette page détaille les règles métier garanties par le moteur et permet d’activer les scénarios d’incidents pour les tester en conditions réelles.
          </p>
        </div>

        <!-- Core Guarantees -->
        <div class="grid grid-cols-1 md:grid-cols-3 gap-5">
          <div class="bg-white border border-[#E3E6EC] rounded-2xl p-5">
            <h2 class="text-base font-semibold text-[#0E1F3B]">Deux modes de réservation</h2>
            <p class="text-xs text-[#4B5A73] mt-2 leading-relaxed">
              Le fournisseur <strong>Ligne Direct Démo</strong> gère la réservation intégrée complète. Le fournisseur <strong>Horizon Distribution</strong> redirige vers un vendeur autorisé sans simuler d’émission de billet.
            </p>
          </div>
          <div class="bg-white border border-[#E3E6EC] rounded-2xl p-5">
            <h2 class="text-base font-semibold text-[#0E1F3B]">Identité des gares & fuseaux IANA</h2>
            <p class="text-xs text-[#4B5A73] mt-2 leading-relaxed">
              Paris Gare de Lyon (FRPLY) et Paris Montparnasse (FRPMO) restent distinctes. Les trajets de nuit (+1 j), changements d’heure et liaisons transmanche (Europe/Paris ↔ Europe/London) calculent les durées exactes en UTC.
            </p>
          </div>
          <div class="bg-white border border-[#E3E6EC] rounded-2xl p-5">
            <h2 class="text-base font-semibold text-[#0E1F3B]">Paiement & réconciliation sûre</h2>
            <p class="text-xs text-[#4B5A73] mt-2 leading-relaxed">
              Chaque paiement utilise une clé d’idempotence. Si la confirmation fournisseur tarde après encaissement, l’état passe en <em>Réconciliation requise</em> et un worker vérifie la référence stable sans créer de doublon.
            </p>
          </div>
        </div>

        <!-- Interactive Failure & Edge-case Simulator -->
        <section class="bg-white border border-[#E3E6EC] rounded-2xl p-6 space-y-5">
          <div class="flex flex-wrap items-center justify-between gap-4 border-b border-[#E3E6EC] pb-4">
            <div>
              <h2 class="font-serif-display text-2xl font-semibold text-[#0E1F3B]">
                Console des scénarios d’incidents (démonstration)
              </h2>
              <p class="text-xs text-[#4B5A73] mt-1">
                Activez un scénario puis lancez une recherche ou une réservation pour observer le comportement exact du système.
              </p>
            </div>
            <button
              type="button"
              (click)="resetAll()"
              class="px-4 py-2 rounded-xl border border-[#CDD3DE] bg-[#FAF8F5] hover:bg-[#F3F1EC] text-xs font-semibold text-[#0E1F3B]"
            >
              Tout réinitialiser (nominal)
            </button>
          </div>

          @if (flags(); as f) {
            <div class="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
              <label class="flex items-start justify-between gap-3 p-4 rounded-xl border border-[#E3E6EC] cursor-pointer hover:bg-[#FAF8F5]">
                <div>
                  <p class="font-semibold text-[#0E1F3B]">Résultats partiels (timeout Horizon)</p>
                  <p class="text-xs text-[#4B5A73] mt-0.5">
                    Simule un dépassement de délai sur Horizon Distribution : Ligne Direct répond, un bandeau signale les résultats partiels.
                  </p>
                </div>
                <input
                  type="checkbox"
                  [checked]="f.partial_results_mode"
                  (change)="toggleFlag('partial_results_mode', !f.partial_results_mode)"
                  class="mt-1"
                />
              </label>

              <label class="flex items-start justify-between gap-3 p-4 rounded-xl border border-[#E3E6EC] cursor-pointer hover:bg-[#FAF8F5]">
                <div>
                  <p class="font-semibold text-[#0E1F3B]">Timeout complet Ligne Direct</p>
                  <p class="text-xs text-[#4B5A73] mt-0.5">
                    Simule l’indisponibilité temporaire du fournisseur principal lors de la recherche.
                  </p>
                </div>
                <input
                  type="checkbox"
                  [checked]="f.timeout_provider_id === 'rail_direct_demo'"
                  (change)="toggleTimeoutDirect(f.timeout_provider_id !== 'rail_direct_demo')"
                  class="mt-1"
                />
              </label>

              <label class="flex items-start justify-between gap-3 p-4 rounded-xl border border-[#E3E6EC] cursor-pointer hover:bg-[#FAF8F5]">
                <div>
                  <p class="font-semibold text-[#0E1F3B]">Offre expirée à la revalidation</p>
                  <p class="text-xs text-[#4B5A73] mt-0.5">
                    Force le statut « devis expiré » puis génère un nouveau devis actualisé à la revalidation.
                  </p>
                </div>
                <input
                  type="checkbox"
                  [checked]="f.force_expired_offer"
                  (change)="toggleFlag('force_expired_offer', !f.force_expired_offer)"
                  class="mt-1"
                />
              </label>

              <label class="flex items-start justify-between gap-3 p-4 rounded-xl border border-[#E3E6EC] cursor-pointer hover:bg-[#FAF8F5]">
                <div>
                  <p class="font-semibold text-[#0E1F3B]">Prix modifié (+12 € à la revalidation)</p>
                  <p class="text-xs text-[#4B5A73] mt-0.5">
                    Exige l’acceptation explicite de l’écart tarifaire par le voyageur avant de payer.
                  </p>
                </div>
                <input
                  type="checkbox"
                  [checked]="f.force_price_change_cents > 0"
                  (change)="togglePriceChange(f.force_price_change_cents === 0)"
                  class="mt-1"
                />
              </label>

              <label class="flex items-start justify-between gap-3 p-4 rounded-xl border border-[#E3E6EC] cursor-pointer hover:bg-[#FAF8F5]">
                <div>
                  <p class="font-semibold text-[#0E1F3B]">Inventaire épuisé</p>
                  <p class="text-xs text-[#4B5A73] mt-0.5">
                    Refuse la réservation lors de la revalidation / du placement faute de places disponibles.
                  </p>
                </div>
                <input
                  type="checkbox"
                  [checked]="f.force_unavailable_inventory"
                  (change)="toggleFlag('force_unavailable_inventory', !f.force_unavailable_inventory)"
                  class="mt-1"
                />
              </label>

              <label class="flex items-start justify-between gap-3 p-4 rounded-xl border border-[#E3E6EC] cursor-pointer hover:bg-[#FAF8F5]">
                <div>
                  <p class="font-semibold text-[#0E1F3B]">Événement paiement dupliqué</p>
                  <p class="text-xs text-[#4B5A73] mt-0.5">
                    Simule la réception en double d’un webhook paiement, neutralisé par idempotence.
                  </p>
                </div>
                <input
                  type="checkbox"
                  [checked]="f.simulate_duplicate_payment_event"
                  (change)="toggleFlag('simulate_duplicate_payment_event', !f.simulate_duplicate_payment_event)"
                  class="mt-1"
                />
              </label>

              <label class="flex items-start justify-between gap-3 p-4 rounded-xl border border-[#E3E6EC] cursor-pointer hover:bg-[#FAF8F5] md:col-span-2">
                <div>
                  <p class="font-semibold text-[#0E1F3B]">Confirmation fournisseur incertaine après paiement</p>
                  <p class="text-xs text-[#4B5A73] mt-0.5">
                    Le paiement réussit mais le transporteur ne répond pas : le dossier passe en « Réconciliation requise » sans perdre le paiement, puis est résolu par le worker.
                  </p>
                </div>
                <input
                  type="checkbox"
                  [checked]="f.force_uncertain_booking_outcome"
                  (change)="toggleFlag('force_uncertain_booking_outcome', !f.force_uncertain_booking_outcome)"
                  class="mt-1"
                />
              </label>
            </div>
          }

          <div class="flex flex-wrap items-center gap-3 pt-2">
            <a
              routerLink="/"
              class="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-[#0F54D4] text-white text-xs font-semibold"
            >
              <mat-icon class="!text-[17px] !w-[17px] !h-[17px]">search</mat-icon>
              <span>Tester sur Paris → Lyon</span>
            </a>
            <button
              type="button"
              (click)="triggerReconcile()"
              class="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl border border-[#CDD3DE] bg-white hover:bg-[#FAF8F5] text-xs font-semibold text-[#0E1F3B]"
            >
              <mat-icon class="!text-[17px] !w-[17px] !h-[17px]">sync</mat-icon>
              <span>Déclencher un cycle de réconciliation</span>
            </button>
          </div>

          @if (statusNotice()) {
            <p class="text-xs text-[#0F54D4] bg-[#EEF4FF] border border-[#C7DAFC] rounded-xl px-3.5 py-2.5">
              {{ statusNotice() }}
            </p>
          }
        </section>
      </div>
    </main>
  `,
})
export class HelpPage implements OnInit {
  private readonly railApi = inject(RailApi);
  private readonly platformId = inject(PLATFORM_ID);

  readonly flags = signal<SimulationFlags | null>(null);
  readonly statusNotice = signal<string | null>(null);

  ngOnInit(): void {
    if (!isPlatformBrowser(this.platformId)) return;
    this.railApi.getSimulationFlags().subscribe({
      next: (r) => this.flags.set(r.simulation),
    });
  }

  async toggleFlag(key: keyof SimulationFlags, value: boolean): Promise<void> {
    const res = await firstValueFrom(this.railApi.updateSimulationFlags({[key]: value}));
    this.flags.set(res.simulation);
    this.statusNotice.set('Paramètre de simulation enregistré.');
  }

  async toggleTimeoutDirect(active: boolean): Promise<void> {
    const res = await firstValueFrom(
      this.railApi.updateSimulationFlags({
        timeout_provider_id: active ? 'rail_direct_demo' : null,
      }),
    );
    this.flags.set(res.simulation);
    this.statusNotice.set('Simulation timeout Ligne Direct mise à jour.');
  }

  async togglePriceChange(active: boolean): Promise<void> {
    const res = await firstValueFrom(
      this.railApi.updateSimulationFlags({
        force_price_change_cents: active ? 1200 : 0,
      }),
    );
    this.flags.set(res.simulation);
    this.statusNotice.set('Simulation écart tarifaire mise à jour.');
  }

  async resetAll(): Promise<void> {
    const res = await firstValueFrom(
      this.railApi.updateSimulationFlags({
        timeout_provider_id: null,
        partial_results_mode: false,
        force_expired_offer: false,
        force_price_change_cents: 0,
        force_unavailable_inventory: false,
        simulate_duplicate_payment_event: false,
        force_uncertain_booking_outcome: false,
      }),
    );
    this.flags.set(res.simulation);
    this.statusNotice.set('Tous les scénarios d’incidents ont été réinitialisés.');
  }

  async triggerReconcile(): Promise<void> {
    const res = await firstValueFrom(this.railApi.triggerReconciliation());
    this.statusNotice.set(
      `Réconciliation exécutée : ${res.checked} dossier(s) vérifié(s), ${res.resolved} résolu(s).`,
    );
  }
}
