import {
  ChangeDetectionStrategy,
  Component,
  computed,
  inject,
  OnInit,
  PLATFORM_ID,
  signal,
} from '@angular/core';
import {isPlatformBrowser} from '@angular/common';
import {FormArray, FormControl, FormGroup, ReactiveFormsModule, Validators} from '@angular/forms';
import {RouterLink} from '@angular/router';
import {MatIconModule} from '@angular/material/icon';
import {firstValueFrom} from 'rxjs';
import type {
  BookingRecord,
  OptionalExtraSelection,
  PassengerDetailInput,
  RevalidationResult,
} from '../../shared/models';
import {AuthStore} from '../services/auth-store';
import {BookingFlow} from '../services/booking-flow';
import {RailApi} from '../services/rail-api';
import {
  formatBookingStateFr,
  formatConditionStatusFr,
  formatDurationFr,
  formatEuroCents,
} from '../shared/formatters';

const AVAILABLE_EXTRAS: OptionalExtraSelection[] = [
  {code: 'QUIET_COACH', label: 'Préférence voiture calme (démo)', amount_cents: 0},
  {code: 'BICYCLE_SPACE', label: 'Emplacement vélo non démonté', amount_cents: 1000},
  {code: 'SMS_ALERT', label: 'Suivi perturbations par SMS (démo)', amount_cents: 150},
];

@Component({
  selector: 'app-checkout-page',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [ReactiveFormsModule, RouterLink, MatIconModule],
  template: `
    <main class="min-h-screen bg-[#FAF8F5] py-8 sm:py-10">
      <div class="max-w-[1120px] mx-auto px-4 sm:px-6">
        @if (!bookingFlow.outward()) {
          <div class="bg-white border border-[#E3E6EC] rounded-2xl p-8 text-center max-w-xl mx-auto">
            <h1 class="font-serif-display text-2xl font-semibold text-[#0E1F3B]">
              Aucune offre sélectionnée
            </h1>
            <p class="text-sm text-[#4B5A73] mt-2">
              Recherchez d’abord un trajet entre deux gares pour comparer les tarifs et accéder au récapitulatif.
            </p>
            <a
              routerLink="/"
              class="mt-5 inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-[#0F54D4] text-white text-sm font-semibold"
            >
              <mat-icon class="!text-[18px] !w-[18px] !h-[18px]">search</mat-icon>
              <span>Rechercher un train</span>
            </a>
          </div>
        } @else {
          @let outLeg = bookingFlow.outward()!;
          @let retLeg = bookingFlow.returnLeg();

          <!-- Mode 1: SELLER HANDOFF -->
          @if (outLeg.offer.booking_mode === 'seller_handoff') {
            <div class="max-w-2xl mx-auto bg-white border border-[#E3E6EC] rounded-2xl p-6 sm:p-8 space-y-5">
              <div class="flex items-start justify-between gap-4">
                <div>
                  <p class="text-xs font-semibold text-[#0F54D4]">Mode : Redirection vers vendeur partenaire</p>
                  <h1 class="font-serif-display text-3xl font-semibold text-[#0E1F3B] mt-1">
                    Transfert vers {{ outLeg.offer.provider_name }}
                  </h1>
                </div>
                <a routerLink="/" class="text-xs font-medium text-[#4B5A73] hover:text-[#0E1F3B]">
                  ← Modifier
                </a>
              </div>

              <div class="p-4 rounded-xl bg-[#FFF7ED] border border-[#FED7AA] text-sm text-[#9A3412]">
                <strong>Information importante :</strong> LIGNE agit ici en comparateur et ne vend ni n’émet ce billet. L’achat final s’effectue exclusivement sur le site du vendeur autorisé.
              </div>

              <div class="p-4 rounded-xl bg-[#FAF8F5] border border-[#E3E6EC] space-y-1.5 text-sm">
                <p class="font-semibold text-[#0E1F3B]">
                  {{ outLeg.itinerary.origin_station.name }} ({{ outLeg.itinerary.departure_local_label }}) →
                  {{ outLeg.itinerary.destination_station.name }} ({{ outLeg.itinerary.arrival_local_label }})
                </p>
                <p class="text-xs text-[#4B5A73]">
                  {{ outLeg.offer.ticket_product }} · {{ formatPrice(outLeg.offer.total_known_cents) }}
                  @if (outLeg.offer.has_unknown_mandatory_fees) {
                    <span>(+ frais éventuels du vendeur)</span>
                  }
                </p>
              </div>

              @if (handoffPreparing()) {
                <p class="text-sm text-[#4B5A73]">Revalidation du devis auprès de {{ outLeg.offer.provider_name }}...</p>
              } @else if (handoffResult(); as hr) {
                <div class="p-4 rounded-xl border border-[#C7DAFC] bg-[#EEF4FF] space-y-2 text-sm">
                  <p class="font-semibold text-[#0E1F3B]">Devis revalidé</p>
                  <p class="text-xs text-[#2A3B59]">{{ hr.revalidation.message }}</p>
                  <p class="text-xs font-mono-tabular text-[#4B5A73] break-all">
                    Destination vérifiée (liste blanche) : {{ hr.redirect_url }}
                  </p>
                </div>

                @if (handoffConfirmed()) {
                  <div class="p-4 rounded-xl border border-[#BBF7D0] bg-[#F0FDF4] text-sm text-[#166534]">
                    Redirection simulée enregistrée vers <strong>{{ hr.seller_name }}</strong>. Aucun billet fictif LIGNE n’a été généré pour cette offre partenaire.
                  </div>
                } @else {
                  <button
                    type="button"
                    (click)="handoffConfirmed.set(true)"
                    class="w-full flex items-center justify-center gap-2 px-5 py-3 rounded-xl bg-[#0F54D4] hover:bg-[#0B44B0] text-white text-sm font-semibold transition-colors"
                  >
                    <mat-icon class="!text-[18px] !w-[18px] !h-[18px]">open_in_new</mat-icon>
                    <span>Continuer vers {{ hr.seller_name }} (simulation)</span>
                  </button>
                }
              }
            </div>
          } @else {
            <!-- Mode 2: INTEGRATED DEMONSTRATION BOOKING -->
            <div class="mb-6 flex flex-wrap items-center justify-between gap-4">
              <div>
                <a routerLink="/" class="text-xs font-medium text-[#0F54D4] hover:underline">
                  ← Retour aux résultats
                </a>
                <h1 class="font-serif-display text-3xl font-semibold text-[#0E1F3B] mt-1">
                  Finaliser votre réservation de démonstration
                </h1>
                <p class="text-xs text-[#4B5A73] mt-0.5">
                  Mode : Réservation intégrée simulée · Aucune carte bancaire réelle débitée
                </p>
              </div>
              <div class="text-xs text-[#4B5A73] font-mono-tabular">
                Clé d’idempotence : {{ idempotencyKey() }}
              </div>
            </div>

            <!-- Booking Lifecycle Banner -->
            @if (completedBooking(); as bkg) {
              <section class="bg-white border border-[#E3E6EC] rounded-2xl p-6 sm:p-8 space-y-6">
                <div class="flex flex-wrap items-start justify-between gap-4 pb-5 border-b border-[#E3E6EC]">
                  <div>
                    <p class="text-xs font-semibold text-[#0F54D4]">
                      Référence dossier : {{ bkg.booking_reference }} · Ordre fournisseur : {{ bkg.provider_order_ref }}
                    </p>
                    <h2 class="font-serif-display text-2xl sm:text-3xl font-semibold text-[#0E1F3B] mt-1">
                      {{ stateLabel(bkg.state) }}
                    </h2>
                  </div>
                  <div class="text-right">
                    <p class="text-xs text-[#4B5A73]">Montant payé (simulé)</p>
                    <p class="text-2xl font-bold text-[#0E1F3B] tabular-nums">
                      {{ formatPrice(bkg.total_paid_cents) }}
                    </p>
                  </div>
                </div>

                @if (bkg.state === 'reconciliation_required') {
                  <div class="p-4 rounded-xl bg-[#FFF7ED] border border-[#FED7AA] text-sm text-[#9A3412] space-y-2">
                    <p class="font-semibold">
                      Paiement confirmé, confirmation transporteur en attente de réconciliation
                    </p>
                    <p class="text-xs">
                      Votre paiement n’a pas été perdu et aucune seconde réservation en double ne sera créée. Le worker de réconciliation interroge le fournisseur avec la référence stable <span class="font-mono-tabular">{{ bkg.provider_order_ref }}</span>.
                    </p>
                    <button
                      type="button"
                      (click)="runManualReconciliation()"
                      class="px-4 py-2 rounded-lg bg-[#9A3412] text-white text-xs font-semibold"
                    >
                      Exécuter la réconciliation maintenant
                    </button>
                  </div>
                }

                <!-- Timeline of separated states -->
                <div>
                  <h3 class="text-sm font-semibold text-[#0E1F3B] mb-3">
                    Journal des états séparés de la transaction
                  </h3>
                  <ol class="space-y-2 border-l border-[#E3E6EC] pl-4">
                    @for (step of bkg.state_history; track $index) {
                      <li class="text-xs">
                        <span class="font-semibold text-[#0E1F3B]">{{ stateLabel(step.state) }}</span>
                        <span class="text-[#64748B] ml-2">{{ step.note }}</span>
                      </li>
                    }
                  </ol>
                </div>

                @if (bkg.seat_reservations.length > 0) {
                  <div class="p-4 rounded-xl bg-[#FAF8F5] border border-[#E3E6EC] text-sm">
                    <p class="font-semibold text-[#0E1F3B]">Placement attribué</p>
                    @for (res of bkg.seat_reservations; track res.reservation_id) {
                      <p class="text-xs text-[#334155] mt-1">
                        {{ res.coach }} · {{ res.seat_numbers.join(', ') }}
                      </p>
                    }
                  </div>
                }

                <div class="flex flex-wrap items-center gap-3 pt-2">
                  <a
                    routerLink="/mes-voyages"
                    class="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-[#0F54D4] hover:bg-[#0B44B0] text-white text-sm font-semibold"
                  >
                    <mat-icon class="!text-[18px] !w-[18px] !h-[18px]">confirmation_number</mat-icon>
                    <span>Voir mon billet spécimen dans Mes voyages</span>
                  </a>
                  <button
                    type="button"
                    (click)="testDuplicateWebhook(bkg)"
                    class="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl border border-[#CDD3DE] bg-white hover:bg-[#FAF8F5] text-xs font-semibold text-[#0E1F3B]"
                  >
                    <mat-icon class="!text-[17px] !w-[17px] !h-[17px]">sync</mat-icon>
                    <span>Tester un événement paiement dupliqué</span>
                  </button>
                </div>

                @if (duplicateEventMessage()) {
                  <p class="text-xs text-[#0F54D4] bg-[#EEF4FF] border border-[#C7DAFC] rounded-xl px-3.5 py-2.5">
                    {{ duplicateEventMessage() }}
                  </p>
                }
              </section>
            } @else {
              <div class="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
                <!-- Checkout Form -->
                <form
                  [formGroup]="checkoutForm"
                  (ngSubmit)="submitCheckout()"
                  class="lg:col-span-8 space-y-6"
                >
                  <!-- Step 1: Quote Revalidation Box -->
                  <div class="bg-white border border-[#E3E6EC] rounded-2xl p-5 sm:p-6">
                    <div class="flex flex-wrap items-center justify-between gap-3">
                      <div>
                        <h2 class="text-base font-semibold text-[#0E1F3B]">
                          1. Vérification en temps réel du devis (revalidation)
                        </h2>
                        <p class="text-xs text-[#4B5A73] mt-0.5">
                          LIGNE revalide le tarif et la disponibilité auprès de {{ outLeg.offer.provider_name }} avant tout paiement.
                        </p>
                      </div>
                      <button
                        type="button"
                        (click)="runRevalidation()"
                        [disabled]="revalidating()"
                        class="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl border border-[#CDD3DE] bg-[#FAF8F5] hover:bg-[#F3F1EC] text-xs font-semibold text-[#0E1F3B]"
                      >
                        <mat-icon class="!text-[16px] !w-[16px] !h-[16px]">refresh</mat-icon>
                        <span>{{ revalidating() ? 'Vérification...' : 'Revalider le tarif' }}</span>
                      </button>
                    </div>

                    @if (outReval(); as r) {
                      <div
                        [class]="
                          r.status === 'unavailable'
                            ? 'mt-3 p-3.5 rounded-xl bg-[#FDECEA] border border-[#F5C2BE] text-xs text-[#B42318]'
                            : r.status === 'price_changed' || r.status === 'expired'
                              ? 'mt-3 p-3.5 rounded-xl bg-[#FFF7ED] border border-[#FED7AA] text-xs text-[#9A3412]'
                              : 'mt-3 p-3.5 rounded-xl bg-[#F0FDF4] border border-[#BBF7D0] text-xs text-[#166534]'
                        "
                      >
                        <p class="font-semibold">{{ r.message }}</p>
                        @if (r.status === 'price_changed') {
                          <label class="mt-2 flex items-center gap-2 font-medium text-[#0E1F3B] cursor-pointer">
                            <input
                              type="checkbox"
                              formControlName="acceptPriceChange"
                              class="rounded border-[#CDD3DE]"
                            />
                            <span>
                              J’accepte le nouveau tarif vérifié de {{ formatPrice(r.new_total_cents) }} (au lieu de {{ formatPrice(r.previous_total_cents) }}).
                            </span>
                          </label>
                        }
                      </div>
                    }
                  </div>

                  <!-- Step 2: Passenger Details (only fields required by provider) -->
                  <div class="bg-white border border-[#E3E6EC] rounded-2xl p-5 sm:p-6 space-y-4">
                    <div class="flex items-center justify-between">
                      <h2 class="text-base font-semibold text-[#0E1F3B]">
                        2. Voyageurs (champs exigés par le fournisseur uniquement)
                      </h2>
                      @if (!auth.isAuthenticated()) {
                        <button
                          type="button"
                          (click)="auth.openModal()"
                          class="text-xs font-semibold text-[#0F54D4] hover:underline"
                        >
                          Se connecter
                        </button>
                      }
                    </div>

                    <div formArrayName="passengers" class="space-y-4">
                      @for (paxCtrl of passengerControls.controls; track $index; let i = $index) {
                        <div [formGroupName]="i" class="p-4 rounded-xl bg-[#FAF8F5] border border-[#E3E6EC] space-y-3">
                          <p class="text-xs font-semibold text-[#0E1F3B]">
                            Voyageur {{ i + 1 }} ({{ paxCategoryLabel(paxCtrl.controls.category.value) }})
                          </p>
                          <div class="grid sm:grid-cols-2 gap-3">
                            <div>
                              <label [for]="'pax-first-' + i" class="block text-xs text-[#4B5A73] mb-1">Prénom *</label>
                              <input
                                [id]="'pax-first-' + i"
                                type="text"
                                formControlName="first_name"
                                placeholder="Camille"
                                class="w-full px-3 py-2 text-sm bg-white border border-[#CDD3DE] rounded-xl focus:border-[#0F54D4] focus:outline-none"
                              />
                            </div>
                            <div>
                              <label [for]="'pax-last-' + i" class="block text-xs text-[#4B5A73] mb-1">Nom *</label>
                              <input
                                [id]="'pax-last-' + i"
                                type="text"
                                formControlName="last_name"
                                placeholder="Laurent"
                                class="w-full px-3 py-2 text-sm bg-white border border-[#CDD3DE] rounded-xl focus:border-[#0F54D4] focus:outline-none"
                              />
                            </div>
                          </div>

                          @if (requiresBirthDate()) {
                            <div class="grid sm:grid-cols-2 gap-3">
                              <div>
                                <label [for]="'pax-birth-' + i" class="block text-xs text-[#4B5A73] mb-1">Date de naissance (tarif jeune/senior ou carte) *</label>
                                <input
                                  [id]="'pax-birth-' + i"
                                  type="date"
                                  formControlName="birth_date"
                                  class="w-full px-3 py-2 text-sm bg-white border border-[#CDD3DE] rounded-xl focus:border-[#0F54D4] focus:outline-none"
                                />
                              </div>
                              @if (requiresCardNumber()) {
                                <div>
                                  <label [for]="'pax-card-' + i" class="block text-xs text-[#4B5A73] mb-1">Numéro de carte de réduction *</label>
                                  <input
                                    [id]="'pax-card-' + i"
                                    type="text"
                                    formControlName="discount_card_number"
                                    placeholder="2909-0123-4567"
                                    class="w-full px-3 py-2 text-sm bg-white border border-[#CDD3DE] rounded-xl focus:border-[#0F54D4] focus:outline-none"
                                  />
                                </div>
                              }
                            </div>
                          }
                        </div>
                      }
                    </div>

                    <div class="grid sm:grid-cols-2 gap-3 pt-2">
                      <div>
                        <label for="contact-email" class="block text-xs font-medium text-[#0E1F3B] mb-1">
                          E-mail de confirmation *
                        </label>
                        <input
                          id="contact-email"
                          type="email"
                          formControlName="contactEmail"
                          placeholder="camille.laurent@exemple.fr"
                          class="w-full px-3.5 py-2.5 text-sm bg-white border border-[#CDD3DE] rounded-xl focus:border-[#0F54D4] focus:outline-none"
                        />
                      </div>
                      <div>
                        <label for="contact-phone" class="block text-xs font-medium text-[#0E1F3B] mb-1">
                          Téléphone mobile (facultatif)
                        </label>
                        <input
                          id="contact-phone"
                          type="tel"
                          formControlName="contactPhone"
                          placeholder="+33 6 12 34 56 78"
                          class="w-full px-3.5 py-2.5 text-sm bg-white border border-[#CDD3DE] rounded-xl focus:border-[#0F54D4] focus:outline-none"
                        />
                      </div>
                    </div>
                  </div>

                  <!-- Step 3: Optional Extras (NEVER preselected) -->
                  <div class="bg-white border border-[#E3E6EC] rounded-2xl p-5 sm:p-6 space-y-3">
                    <h2 class="text-base font-semibold text-[#0E1F3B]">
                      3. Options facultatives (aucune option pré-cochée)
                    </h2>
                    <div class="space-y-2">
                      @for (extra of availableExtras; track extra.code) {
                        <label class="flex items-center justify-between p-3 rounded-xl border border-[#E3E6EC] hover:bg-[#FAF8F5] cursor-pointer">
                          <span class="flex items-center gap-2.5 text-sm text-[#0E1F3B]">
                            <input
                              type="checkbox"
                              [checked]="isExtraSelected(extra.code)"
                              (change)="toggleExtra(extra)"
                              class="rounded border-[#CDD3DE] text-[#0F54D4]"
                            />
                            <span>{{ extra.label }}</span>
                          </span>
                          <span class="text-sm font-semibold tabular-nums text-[#0E1F3B]">
                            {{ extra.amount_cents === 0 ? 'Gratuit' : '+ ' + formatPrice(extra.amount_cents) }}
                          </span>
                        </label>
                      }
                    </div>
                  </div>

                  <!-- Step 4: Simulated Payment Method (no raw card fields stored) & Explicit Consent -->
                  <div class="bg-white border border-[#E3E6EC] rounded-2xl p-5 sm:p-6 space-y-4">
                    <h2 class="text-base font-semibold text-[#0E1F3B]">
                      4. Paiement simulé et confirmation d’achat
                    </h2>
                    <p class="text-xs text-[#4B5A73]">
                      LIGNE ne stocke jamais de numéro de carte complet. Ce simulateur utilise un jeton de démonstration.
                    </p>

                    <div class="grid sm:grid-cols-2 gap-3">
                      <label class="flex items-center gap-2.5 p-3.5 rounded-xl border border-[#CDD3DE] cursor-pointer">
                        <input
                          type="radio"
                          formControlName="paymentMethod"
                          value="Carte de démonstration"
                          class="text-[#0F54D4]"
                        />
                        <span class="text-sm font-medium text-[#0E1F3B]">
                          Carte de démonstration •••• 4242
                        </span>
                      </label>
                      <label class="flex items-center gap-2.5 p-3.5 rounded-xl border border-[#CDD3DE] cursor-pointer">
                        <input
                          type="radio"
                          formControlName="paymentMethod"
                          value="Portefeuille instantané démo"
                          class="text-[#0F54D4]"
                        />
                        <span class="text-sm font-medium text-[#0E1F3B]">
                          Portefeuille instantané démo
                        </span>
                      </label>
                    </div>

                    <label class="flex items-start gap-2.5 text-xs text-[#2A3B59] cursor-pointer pt-1">
                      <input
                        type="checkbox"
                        formControlName="acceptedConditions"
                        class="mt-0.5 rounded border-[#CDD3DE] text-[#0F54D4]"
                      />
                      <span>
                        J’ai pris connaissance des conditions d’échange ({{ conditionStatus(outLeg.offer.change_conditions.status) }}) et de remboursement ({{ conditionStatus(outLeg.offer.refund_conditions.status) }}), et je confirme cette réservation de démonstration.
                      </span>
                    </label>

                    @if (checkoutError()) {
                      <p class="text-xs text-[#B42318] bg-[#FDECEA] border border-[#F5C2BE] rounded-xl px-3.5 py-2.5" role="alert">
                        {{ checkoutError() }}
                      </p>
                    }

                    <button
                      type="submit"
                      [disabled]="submitting()"
                      class="w-full flex items-center justify-center gap-2 px-5 py-3.5 rounded-xl bg-[#0F54D4] hover:bg-[#0B44B0] text-white text-sm font-semibold transition-colors disabled:opacity-60 ligne-focus"
                    >
                      <mat-icon class="!text-[18px] !w-[18px] !h-[18px]">lock</mat-icon>
                      <span>
                        {{
                          submitting()
                            ? 'Traitement de la réservation...'
                            : 'Confirmer et payer (simulé) · ' + formatPrice(totalPayableCents())
                        }}
                      </span>
                    </button>
                  </div>
                </form>

                <!-- Right Itemised Summary Sidebar -->
                <aside class="lg:col-span-4 bg-white border border-[#E3E6EC] rounded-2xl p-6 space-y-4 sticky top-24">
                  <h2 class="font-serif-display text-xl font-semibold text-[#0E1F3B]">
                    Récapitulatif détaillé
                  </h2>

                  <div class="pb-3 border-b border-[#E3E6EC] text-xs space-y-1">
                    <p class="font-semibold text-[#0E1F3B]">
                      Aller · {{ outLeg.itinerary.origin_station.name }} → {{ outLeg.itinerary.destination_station.name }}
                    </p>
                    <p class="text-[#4B5A73]">
                      {{ outLeg.itinerary.departure_local_label }} → {{ outLeg.itinerary.arrival_local_label }}
                      · {{ formatDuration(outLeg.itinerary.total_duration_minutes) }}
                    </p>
                    <p class="text-[#4B5A73]">
                      {{ outLeg.offer.ticket_product }} · {{ outLeg.offer.travel_class === '1' ? '1re classe' : '2de classe' }}
                    </p>
                  </div>

                  @if (retLeg) {
                    <div class="pb-3 border-b border-[#E3E6EC] text-xs space-y-1">
                      <p class="font-semibold text-[#0E1F3B]">
                        Retour · {{ retLeg.itinerary.origin_station.name }} → {{ retLeg.itinerary.destination_station.name }}
                      </p>
                      <p class="text-[#4B5A73]">
                        {{ retLeg.itinerary.departure_local_label }} → {{ retLeg.itinerary.arrival_local_label }}
                        · {{ formatDuration(retLeg.itinerary.total_duration_minutes) }}
                      </p>
                      <p class="text-[#4B5A73]">
                        {{ retLeg.offer.ticket_product }} · {{ retLeg.offer.travel_class === '1' ? '1re classe' : '2de classe' }}
                      </p>
                    </div>
                  }

                  <div class="space-y-2 text-sm">
                    <div class="flex justify-between text-[#334155]">
                      <span>Tarif de base</span>
                      <span class="tabular-nums">{{ formatPrice(baseFareTotalCents()) }}</span>
                    </div>
                    @if (discountTotalCents() > 0) {
                      <div class="flex justify-between text-[#166534]">
                        <span>Réductions appliquées</span>
                        <span class="tabular-nums">− {{ formatPrice(discountTotalCents()) }}</span>
                      </div>
                    }
                    <div class="flex justify-between text-[#334155]">
                      <span>Frais obligatoires</span>
                      <span class="tabular-nums">0 €</span>
                    </div>
                    @if (extrasTotalCents() > 0) {
                      <div class="flex justify-between text-[#334155]">
                        <span>Options facultatives</span>
                        <span class="tabular-nums">{{ formatPrice(extrasTotalCents()) }}</span>
                      </div>
                    }
                    <div class="pt-3 border-t border-[#E3E6EC] flex justify-between items-baseline font-bold text-[#0E1F3B]">
                      <span>Total à payer (TTC)</span>
                      <span class="text-xl tabular-nums">{{ formatPrice(totalPayableCents()) }}</span>
                    </div>
                  </div>
                </aside>
              </div>
            }
          }
        }
      </div>
    </main>
  `,
})
export class CheckoutPage implements OnInit {
  private readonly railApi = inject(RailApi);
  private readonly platformId = inject(PLATFORM_ID);
  readonly auth = inject(AuthStore);
  readonly bookingFlow = inject(BookingFlow);

  readonly availableExtras = AVAILABLE_EXTRAS;
  readonly selectedExtras = signal<OptionalExtraSelection[]>([]);
  readonly idempotencyKey = signal(`idem-${Math.random().toString(36).slice(2, 10)}`);

  readonly revalidating = signal(false);
  readonly outReval = signal<RevalidationResult | null>(null);
  readonly retReval = signal<RevalidationResult | null>(null);

  readonly handoffPreparing = signal(false);
  readonly handoffResult = signal<{
    revalidation: RevalidationResult;
    seller_name: string;
    redirect_url: string;
    notice: string;
  } | null>(null);
  readonly handoffConfirmed = signal(false);

  readonly submitting = signal(false);
  readonly checkoutError = signal<string | null>(null);
  readonly completedBooking = signal<BookingRecord | null>(null);
  readonly duplicateEventMessage = signal<string | null>(null);

  readonly checkoutForm = new FormGroup({
    passengers: new FormArray<
      FormGroup<{
        first_name: FormControl<string>;
        last_name: FormControl<string>;
        birth_date: FormControl<string>;
        category: FormControl<'adult' | 'youth' | 'senior'>;
        discount_card_number: FormControl<string>;
      }>
    >([]),
    contactEmail: new FormControl('voyageur@ligne.demo', {
      nonNullable: true,
      validators: [Validators.required, Validators.email],
    }),
    contactPhone: new FormControl('+33 6 12 34 56 78', {nonNullable: true}),
    paymentMethod: new FormControl('Carte de démonstration', {nonNullable: true}),
    acceptPriceChange: new FormControl(false, {nonNullable: true}),
    acceptedConditions: new FormControl(false, {nonNullable: true}),
  });

  get passengerControls() {
    return this.checkoutForm.controls.passengers;
  }

  readonly baseFareTotalCents = computed(() => {
    const out = this.outReval()?.offer ?? this.bookingFlow.outward()?.offer;
    const ret = this.retReval()?.offer ?? this.bookingFlow.returnLeg()?.offer;
    return (out?.base_fare_cents ?? 0) + (ret?.base_fare_cents ?? 0);
  });

  readonly discountTotalCents = computed(() => {
    const out = this.outReval()?.offer ?? this.bookingFlow.outward()?.offer;
    const ret = this.retReval()?.offer ?? this.bookingFlow.returnLeg()?.offer;
    return (out?.discount_cents ?? 0) + (ret?.discount_cents ?? 0);
  });

  readonly extrasTotalCents = computed(() =>
    this.selectedExtras().reduce((sum, e) => sum + e.amount_cents, 0),
  );

  readonly totalPayableCents = computed(() => {
    const out = this.outReval()?.offer ?? this.bookingFlow.outward()?.offer;
    const ret = this.retReval()?.offer ?? this.bookingFlow.returnLeg()?.offer;
    return (
      (out?.total_known_cents ?? 0) +
      (ret?.total_known_cents ?? 0) +
      this.extrasTotalCents()
    );
  });

  ngOnInit(): void {
    if (!isPlatformBrowser(this.platformId)) return;
    const out = this.bookingFlow.outward();
    if (!out) return;

    if (out.offer.booking_mode === 'seller_handoff') {
      this.handoffPreparing.set(true);
      this.railApi.prepareSellerHandoff(out.offer).subscribe({
        next: (res) => {
          this.handoffResult.set(res);
          this.handoffPreparing.set(false);
        },
        error: () => this.handoffPreparing.set(false),
      });
      return;
    }

    const comp = out.offer.passenger_composition;
    const pushPax = (category: 'adult' | 'youth' | 'senior', idx: number) => {
      this.passengerControls.push(
        new FormGroup({
          first_name: new FormControl(idx === 0 ? 'Camille' : '', {
            nonNullable: true,
            validators: [Validators.required],
          }),
          last_name: new FormControl(idx === 0 ? 'Laurent' : '', {
            nonNullable: true,
            validators: [Validators.required],
          }),
          birth_date: new FormControl('', {nonNullable: true}),
          category: new FormControl(category, {nonNullable: true}),
          discount_card_number: new FormControl('', {nonNullable: true}),
        }),
      );
    };

    let idx = 0;
    for (let i = 0; i < comp.adults; i++) pushPax('adult', idx++);
    for (let i = 0; i < comp.youths; i++) pushPax('youth', idx++);
    for (let i = 0; i < comp.seniors; i++) pushPax('senior', idx++);

    if (this.auth.user()?.email) {
      this.checkoutForm.controls.contactEmail.setValue(this.auth.user()!.email);
    }

    void this.runRevalidation();
  }

  requiresBirthDate(): boolean {
    const out = this.bookingFlow.outward()?.offer;
    return Boolean(out?.required_passenger_fields.includes('birth_date'));
  }

  requiresCardNumber(): boolean {
    const out = this.bookingFlow.outward()?.offer;
    return Boolean(out?.required_passenger_fields.includes('discount_card_number'));
  }

  paxCategoryLabel(cat: 'adult' | 'youth' | 'senior'): string {
    return cat === 'adult' ? 'Adulte' : cat === 'youth' ? 'Jeune' : 'Senior';
  }

  isExtraSelected(code: string): boolean {
    return this.selectedExtras().some((e) => e.code === code);
  }

  toggleExtra(extra: OptionalExtraSelection): void {
    this.selectedExtras.update((list) =>
      list.some((e) => e.code === extra.code)
        ? list.filter((e) => e.code !== extra.code)
        : [...list, extra],
    );
  }

  async runRevalidation(): Promise<void> {
    const out = this.bookingFlow.outward()?.offer;
    if (!out) return;
    const ret = this.bookingFlow.returnLeg()?.offer ?? null;
    this.revalidating.set(true);
    try {
      const res = await firstValueFrom(this.railApi.revalidateOffers(out, ret));
      this.outReval.set(res.outward);
      this.retReval.set(res.return);
    } catch {
      this.checkoutError.set('Impossible de revalider le tarif actuellement.');
    } finally {
      this.revalidating.set(false);
    }
  }

  async submitCheckout(): Promise<void> {
    this.checkoutError.set(null);
    if (this.checkoutForm.invalid) {
      this.checkoutError.set('Renseignez les coordonnées obligatoires des voyageurs et votre e-mail.');
      return;
    }
    const raw = this.checkoutForm.getRawValue();
    if (!raw.acceptedConditions) {
      this.checkoutError.set('Veuillez accepter les conditions du billet avant de confirmer.');
      return;
    }

    const out = this.bookingFlow.outward()!;
    const ret = this.bookingFlow.returnLeg();
    const passengers: PassengerDetailInput[] = raw.passengers.map((p) => ({
      first_name: p.first_name.trim(),
      last_name: p.last_name.trim(),
      birth_date: p.birth_date || undefined,
      category: p.category,
      discount_card_number: p.discount_card_number || undefined,
    }));

    this.submitting.set(true);
    try {
      const res = await firstValueFrom(
        this.railApi.checkoutBooking(this.idempotencyKey(), {
          outward_itinerary: out.itinerary,
          outward_offer: this.outReval()?.offer ?? out.offer,
          return_itinerary: ret?.itinerary ?? null,
          return_offer: this.retReval()?.offer ?? ret?.offer ?? null,
          passengers,
          contact_email: raw.contactEmail,
          contact_phone: raw.contactPhone,
          optional_extras: this.selectedExtras(),
          payment_method_label: raw.paymentMethod,
          accept_price_change: raw.acceptPriceChange,
          accepted_conditions: raw.acceptedConditions,
        }),
      );

      if (res.token) {
        this.auth.setSession(res.user, res.token);
      }
      this.completedBooking.set(res.booking);
    } catch (err: unknown) {
      const payload = (err as {error?: {code?: string; error?: string; revalidation?: RevalidationResult}})?.error;
      if (payload?.revalidation) {
        this.outReval.set(payload.revalidation);
      }
      this.checkoutError.set(payload?.error || 'Erreur lors de la finalisation.');
    } finally {
      this.submitting.set(false);
    }
  }

  async runManualReconciliation(): Promise<void> {
    const bkg = this.completedBooking();
    if (!bkg) return;
    await firstValueFrom(this.railApi.triggerReconciliation());
    const refreshed = await firstValueFrom(this.railApi.getMyBookings());
    const found = refreshed.bookings.find((b) => b.booking_id === bkg.booking_id);
    if (found) this.completedBooking.set(found);
  }

  async testDuplicateWebhook(bkg: BookingRecord): Promise<void> {
    const evtId = bkg.payment?.provider_event_ids[0] ?? 'evt_demo';
    const res = await firstValueFrom(
      this.railApi.triggerDuplicateWebhookDemo(evtId, bkg.booking_id),
    );
    this.duplicateEventMessage.set(res.message);
  }

  formatPrice(cents: number): string {
    return formatEuroCents(cents);
  }

  formatDuration(min: number): string {
    return formatDurationFr(min);
  }

  stateLabel(state: BookingRecord['state']): string {
    return formatBookingStateFr(state);
  }

  conditionStatus(status: 'allowed' | 'with_fee' | 'non_modifiable' | 'unknown'): string {
    return formatConditionStatusFr(status);
  }
}
