import {
  ChangeDetectionStrategy,
  Component,
  computed,
  DestroyRef,
  inject,
  OnInit,
  PLATFORM_ID,
  signal,
} from '@angular/core';
import {isPlatformBrowser} from '@angular/common';
import {takeUntilDestroyed} from '@angular/core/rxjs-interop';
import {FormControl, FormGroup, ReactiveFormsModule} from '@angular/forms';
import {ActivatedRoute, Router, RouterLink} from '@angular/router';
import {MatIconModule} from '@angular/material/icon';
import {
  catchError,
  debounceTime,
  distinctUntilChanged,
  of,
  Subject,
  switchMap,
} from 'rxjs';
import type {
  DiscountCardId,
  FareOffer,
  JourneyItinerary,
  JourneySearchResponse,
  JourneySearchResultItem,
  StationNode,
  TravelClass,
} from '../../shared/models';
import {FareConditionsModal} from '../components/fare-conditions-modal';
import {AuthStore} from '../services/auth-store';
import {BookingFlow} from '../services/booking-flow';
import {RailApi, type SearchParamsPayload} from '../services/rail-api';
import {
  formatDateHeadingFr,
  formatDateShortFr,
  formatDurationFr,
  formatEuroCents,
  formatPassengerSummaryFr,
  formatStationKindFr,
  formatTimetableStateFr,
} from '../shared/formatters';

interface DiscountCardOption {
  id: DiscountCardId;
  label: string;
}

const DISCOUNT_CARD_OPTIONS: DiscountCardOption[] = [
  {id: 'CARTE_AVANTAGE_ADULTE', label: 'Carte Avantage Adulte'},
  {id: 'CARTE_AVANTAGE_JEUNE', label: 'Carte Avantage Jeune'},
  {id: 'CARTE_AVANTAGE_SENIOR', label: 'Carte Avantage Senior'},
  {id: 'CARTE_LIBERTE', label: 'Carte Liberté'},
];

@Component({
  selector: 'app-home-page',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [ReactiveFormsModule, RouterLink, MatIconModule, FareConditionsModal],
  template: `
    <main class="min-h-screen bg-[#FAF8F5]">
      <!-- HERO & FLOATING SEARCH PANEL -->
      <section class="relative">
        <div class="relative h-[320px] sm:h-[360px] lg:h-[390px] overflow-hidden bg-[#EAF0F8]">
          <img
            src="/src/assets/images/hero_french_tgv_1795859313882.jpg"
            alt="Train à grande vitesse traversant un viaduc dans la campagne française"
            referrerpolicy="no-referrer"
            class="absolute inset-0 w-full h-full object-cover object-center"
          />
          <div
            class="absolute inset-0 bg-gradient-to-r from-[#FAF8F5] via-[#FAF8F5]/85 to-transparent sm:w-3/4"
          ></div>
          <div
            class="absolute inset-x-0 bottom-0 h-28 bg-gradient-to-t from-[#FAF8F5] to-transparent"
          ></div>

          <div class="relative max-w-[1200px] mx-auto px-4 sm:px-6 pt-10 sm:pt-14">
            <h1
              class="font-serif-display text-[36px] sm:text-[48px] lg:text-[54px] font-semibold leading-[1.08] tracking-[-0.02em] text-[#0E1F3B] max-w-xl [text-wrap:balance]"
            >
              La France, à portée de train.
            </h1>
            <p class="mt-3.5 text-base sm:text-lg text-[#2A3B59] max-w-md leading-relaxed">
              Comparez vos trajets. Choisissez votre billet.<br />Partez sereinement.
            </p>
          </div>
        </div>

        <!-- Floating Search Panel -->
        <div class="relative max-w-[1200px] mx-auto px-4 sm:px-6 -mt-20 sm:-mt-24 z-20">
          <form
            [formGroup]="searchForm"
            (ngSubmit)="submitSearch()"
            class="bg-white/95 backdrop-blur-sm border border-[#E3E6EC] rounded-2xl shadow-md p-4 sm:p-5"
          >
            <!-- Top controls: Trip type + Passengers / Class / Discount cards -->
            <div class="flex flex-wrap items-center gap-3 pb-3.5 mb-3.5 border-b border-[#E3E6EC]">
              <div
                class="inline-flex items-center p-0.5 rounded-xl bg-[#F3F1EC] border border-[#E3E6EC]"
                role="group"
                aria-label="Type de trajet"
              >
                <button
                  type="button"
                  (click)="setTripType('roundtrip')"
                  [class]="
                    tripType() === 'roundtrip'
                      ? 'px-3.5 py-1.5 rounded-[10px] text-xs sm:text-sm font-semibold bg-[#0F54D4] text-white whitespace-nowrap shrink-0 transition-colors'
                      : 'px-3.5 py-1.5 rounded-[10px] text-xs sm:text-sm font-medium text-[#2A3B59] hover:text-[#0E1F3B] whitespace-nowrap shrink-0 transition-colors'
                  "
                >
                  Aller-retour
                </button>
                <button
                  type="button"
                  (click)="setTripType('oneway')"
                  [class]="
                    tripType() === 'oneway'
                      ? 'px-3.5 py-1.5 rounded-[10px] text-xs sm:text-sm font-semibold bg-[#0F54D4] text-white whitespace-nowrap shrink-0 transition-colors'
                      : 'px-3.5 py-1.5 rounded-[10px] text-xs sm:text-sm font-medium text-[#2A3B59] hover:text-[#0E1F3B] whitespace-nowrap shrink-0 transition-colors'
                  "
                >
                  Aller simple
                </button>
              </div>

              <div class="hidden sm:block h-5 w-px bg-[#E3E6EC]" aria-hidden="true"></div>

              <!-- Passengers, Class & Discount Cards Popover -->
              <div class="relative">
                <button
                  type="button"
                  (click)="paxPopoverOpen.set(!paxPopoverOpen())"
                  class="flex items-center gap-2 px-3.5 py-1.5 rounded-xl border border-[#CDD3DE] bg-white hover:bg-[#FAF8F5] text-xs sm:text-sm font-medium text-[#0E1F3B] whitespace-nowrap shrink-0 transition-colors ligne-focus"
                  [attr.aria-expanded]="paxPopoverOpen()"
                >
                  <mat-icon class="!text-[18px] !w-[18px] !h-[18px] text-[#4B5A73]">person_outline</mat-icon>
                  <span>{{ passengerSummaryLabel() }}</span>
                  @if (selectedCards().length > 0) {
                    <span class="text-[#0F54D4] font-semibold">· {{ selectedCards().length }} carte(s)</span>
                  }
                  <mat-icon class="!text-[18px] !w-[18px] !h-[18px] text-[#4B5A73]">expand_more</mat-icon>
                </button>

                @if (paxPopoverOpen()) {
                  <div
                    class="absolute left-0 mt-2 w-80 bg-white border border-[#E3E6EC] rounded-2xl shadow-xl p-4 z-40 space-y-4"
                    role="region"
                    aria-label="Voyageurs, classe et cartes de réduction"
                  >
                    <div class="space-y-2.5">
                      <p class="text-xs font-semibold text-[#0E1F3B]">Voyageurs</p>
                      <div class="flex items-center justify-between text-sm">
                        <span>Adultes (26–59 ans)</span>
                        <div class="flex items-center gap-2">
                          <button
                            type="button"
                            (click)="adjustPax('adults', -1)"
                            class="w-7 h-7 rounded-lg border border-[#CDD3DE] flex items-center justify-center hover:bg-[#FAF8F5]"
                            aria-label="Retirer un adulte"
                          >
                            −
                          </button>
                          <span class="w-5 text-center font-semibold tabular-nums">{{ adults() }}</span>
                          <button
                            type="button"
                            (click)="adjustPax('adults', 1)"
                            class="w-7 h-7 rounded-lg border border-[#CDD3DE] flex items-center justify-center hover:bg-[#FAF8F5]"
                            aria-label="Ajouter un adulte"
                          >
                            +
                          </button>
                        </div>
                      </div>
                      <div class="flex items-center justify-between text-sm">
                        <span>Jeunes (12–25 ans)</span>
                        <div class="flex items-center gap-2">
                          <button
                            type="button"
                            (click)="adjustPax('youths', -1)"
                            class="w-7 h-7 rounded-lg border border-[#CDD3DE] flex items-center justify-center hover:bg-[#FAF8F5]"
                            aria-label="Retirer un jeune"
                          >
                            −
                          </button>
                          <span class="w-5 text-center font-semibold tabular-nums">{{ youths() }}</span>
                          <button
                            type="button"
                            (click)="adjustPax('youths', 1)"
                            class="w-7 h-7 rounded-lg border border-[#CDD3DE] flex items-center justify-center hover:bg-[#FAF8F5]"
                            aria-label="Ajouter un jeune"
                          >
                            +
                          </button>
                        </div>
                      </div>
                      <div class="flex items-center justify-between text-sm">
                        <span>Seniors (60+ ans)</span>
                        <div class="flex items-center gap-2">
                          <button
                            type="button"
                            (click)="adjustPax('seniors', -1)"
                            class="w-7 h-7 rounded-lg border border-[#CDD3DE] flex items-center justify-center hover:bg-[#FAF8F5]"
                            aria-label="Retirer un senior"
                          >
                            −
                          </button>
                          <span class="w-5 text-center font-semibold tabular-nums">{{ seniors() }}</span>
                          <button
                            type="button"
                            (click)="adjustPax('seniors', 1)"
                            class="w-7 h-7 rounded-lg border border-[#CDD3DE] flex items-center justify-center hover:bg-[#FAF8F5]"
                            aria-label="Ajouter un senior"
                          >
                            +
                          </button>
                        </div>
                      </div>
                    </div>

                    <div class="pt-3 border-t border-[#E3E6EC]">
                      <p class="text-xs font-semibold text-[#0E1F3B] mb-2">Classe de voyage</p>
                      <div class="grid grid-cols-2 gap-2">
                        <button
                          type="button"
                          (click)="travelClass.set('2')"
                          [class]="
                            travelClass() === '2'
                              ? 'py-2 rounded-xl text-xs font-semibold bg-[#0F54D4] text-white'
                              : 'py-2 rounded-xl text-xs font-medium border border-[#CDD3DE] text-[#0E1F3B]'
                          "
                        >
                          2de classe
                        </button>
                        <button
                          type="button"
                          (click)="travelClass.set('1')"
                          [class]="
                            travelClass() === '1'
                              ? 'py-2 rounded-xl text-xs font-semibold bg-[#0F54D4] text-white'
                              : 'py-2 rounded-xl text-xs font-medium border border-[#CDD3DE] text-[#0E1F3B]'
                          "
                        >
                          1re classe
                        </button>
                      </div>
                    </div>

                    <div class="pt-3 border-t border-[#E3E6EC] space-y-2">
                      <p class="text-xs font-semibold text-[#0E1F3B]">Cartes de réduction</p>
                      @for (card of discountCardOptions; track card.id) {
                        <label class="flex items-center gap-2 text-xs text-[#2A3B59] cursor-pointer">
                          <input
                            type="checkbox"
                            [checked]="selectedCards().includes(card.id)"
                            (change)="toggleDiscountCard(card.id)"
                            class="rounded border-[#CDD3DE] text-[#0F54D4]"
                          />
                          <span>{{ card.label }}</span>
                        </label>
                      }
                    </div>

                    <div class="flex justify-end pt-2">
                      <button
                        type="button"
                        (click)="paxPopoverOpen.set(false)"
                        class="px-3.5 py-1.5 rounded-lg bg-[#0E1F3B] text-white text-xs font-semibold"
                      >
                        Valider
                      </button>
                    </div>
                  </div>
                }
              </div>

              <span class="ml-auto text-xs text-[#4B5A73] hidden lg:inline">
                Prototype indépendant · Identifiants de gares exacts respectés
              </span>
            </div>

            <!-- Main search input row -->
            <div class="grid grid-cols-1 lg:grid-cols-12 gap-2.5 items-stretch">
              <!-- Origin station -->
              <div class="lg:col-span-3 relative">
                <label for="from-station" class="sr-only">Gare de départ</label>
                <div class="relative flex items-center">
                  <mat-icon class="absolute left-3 !text-[18px] !w-[18px] !h-[18px] text-[#4B5A73] pointer-events-none">
                    location_on
                  </mat-icon>
                  <input
                    id="from-station"
                    type="text"
                    formControlName="fromLabel"
                    (focus)="openOriginSuggestions()"
                    (keydown)="handleStationKeydown($event, 'origin')"
                    autocomplete="off"
                    placeholder="Gare de départ"
                    class="w-full pl-9 pr-3 py-2.5 text-sm font-medium text-[#0E1F3B] bg-white border border-[#CDD3DE] rounded-xl focus:border-[#0F54D4] focus:outline-none"
                    role="combobox"
                    aria-controls="origin-station-listbox"
                    [attr.aria-expanded]="originDropdownOpen()"
                  />
                </div>
                @if (originDropdownOpen() && originSuggestions().length > 0) {
                  <ul
                    id="origin-station-listbox"
                    class="absolute left-0 right-0 mt-1.5 bg-white border border-[#E3E6EC] rounded-xl shadow-lg py-1 z-50 max-h-64 overflow-y-auto"
                    role="listbox"
                  >
                    @for (st of originSuggestions(); track st.id; let idx = $index) {
                      <li>
                        <button
                          type="button"
                          (click)="selectStation('origin', st)"
                          [class]="
                            activeOriginIdx() === idx
                              ? 'w-full text-left px-3 py-2 bg-[#EEF4FF] text-[#0E1F3B] flex items-center justify-between gap-2'
                              : 'w-full text-left px-3 py-2 hover:bg-[#FAF8F5] text-[#0E1F3B] flex items-center justify-between gap-2'
                          "
                        >
                          <div class="min-w-0">
                            <p class="text-sm font-medium truncate">{{ st.name }}</p>
                            <p class="text-[11px] text-[#4B5A73]">
                              {{ kindLabel(st.kind) }} · {{ st.iana_timezone }}
                            </p>
                          </div>
                          <span class="font-mono-tabular text-[11px] text-[#64748B] shrink-0">{{ st.id }}</span>
                        </button>
                      </li>
                    }
                  </ul>
                }
              </div>

              <!-- Swap button -->
              <div class="lg:col-span-1 flex items-center justify-center">
                <button
                  type="button"
                  (click)="swapStations()"
                  class="w-10 h-10 rounded-xl border border-[#CDD3DE] bg-[#FAF8F5] hover:bg-[#F3F1EC] text-[#0E1F3B] flex items-center justify-center transition-colors ligne-focus"
                  aria-label="Inverser la gare de départ et la gare d’arrivée"
                >
                  <mat-icon class="!text-[19px] !w-[19px] !h-[19px]">swap_horiz</mat-icon>
                </button>
              </div>

              <!-- Destination station -->
              <div class="lg:col-span-3 relative">
                <label for="to-station" class="sr-only">Gare d’arrivée</label>
                <div class="relative flex items-center">
                  <mat-icon class="absolute left-3 !text-[18px] !w-[18px] !h-[18px] text-[#4B5A73] pointer-events-none">
                    location_on
                  </mat-icon>
                  <input
                    id="to-station"
                    type="text"
                    formControlName="toLabel"
                    (focus)="openDestSuggestions()"
                    (keydown)="handleStationKeydown($event, 'dest')"
                    autocomplete="off"
                    placeholder="Gare d’arrivée"
                    class="w-full pl-9 pr-3 py-2.5 text-sm font-medium text-[#0E1F3B] bg-white border border-[#CDD3DE] rounded-xl focus:border-[#0F54D4] focus:outline-none"
                    role="combobox"
                    aria-controls="dest-station-listbox"
                    [attr.aria-expanded]="destDropdownOpen()"
                  />
                </div>
                @if (destDropdownOpen() && destSuggestions().length > 0) {
                  <ul
                    id="dest-station-listbox"
                    class="absolute left-0 right-0 mt-1.5 bg-white border border-[#E3E6EC] rounded-xl shadow-lg py-1 z-50 max-h-64 overflow-y-auto"
                    role="listbox"
                  >
                    @for (st of destSuggestions(); track st.id; let idx = $index) {
                      <li>
                        <button
                          type="button"
                          (click)="selectStation('dest', st)"
                          [class]="
                            activeDestIdx() === idx
                              ? 'w-full text-left px-3 py-2 bg-[#EEF4FF] text-[#0E1F3B] flex items-center justify-between gap-2'
                              : 'w-full text-left px-3 py-2 hover:bg-[#FAF8F5] text-[#0E1F3B] flex items-center justify-between gap-2'
                          "
                        >
                          <div class="min-w-0">
                            <p class="text-sm font-medium truncate">{{ st.name }}</p>
                            <p class="text-[11px] text-[#4B5A73]">
                              {{ kindLabel(st.kind) }} · {{ st.iana_timezone }}
                            </p>
                          </div>
                          <span class="font-mono-tabular text-[11px] text-[#64748B] shrink-0">{{ st.id }}</span>
                        </button>
                      </li>
                    }
                  </ul>
                }
              </div>

              <!-- Outward date & optional time -->
              <div class="lg:col-span-2 flex gap-1.5">
                <div class="flex-1">
                  <label for="out-date" class="sr-only">Date aller</label>
                  <input
                    id="out-date"
                    type="date"
                    formControlName="outwardDate"
                    min="2026-01-01"
                    max="2028-12-31"
                    class="w-full px-2.5 py-2.5 text-sm font-medium text-[#0E1F3B] bg-white border border-[#CDD3DE] rounded-xl focus:border-[#0F54D4] focus:outline-none"
                  />
                </div>
                <div class="w-20">
                  <label for="out-time" class="sr-only">Heure aller</label>
                  <select
                    id="out-time"
                    formControlName="outwardTime"
                    class="w-full px-1.5 py-2.5 text-xs font-medium text-[#0E1F3B] bg-white border border-[#CDD3DE] rounded-xl focus:border-[#0F54D4] focus:outline-none"
                  >
                    <option value="00:00">Dès 00h</option>
                    <option value="06:00">Dès 06h</option>
                    <option value="09:00">Dès 09h</option>
                    <option value="12:00">Dès 12h</option>
                    <option value="17:00">Dès 17h</option>
                  </select>
                </div>
              </div>

              <!-- Return date (only for roundtrip) -->
              @if (tripType() === 'roundtrip') {
                <div class="lg:col-span-2 flex gap-1.5">
                  <div class="flex-1">
                    <label for="ret-date" class="sr-only">Date retour</label>
                    <input
                      id="ret-date"
                      type="date"
                      formControlName="returnDate"
                      min="2026-01-01"
                      max="2028-12-31"
                      class="w-full px-2.5 py-2.5 text-sm font-medium text-[#0E1F3B] bg-white border border-[#CDD3DE] rounded-xl focus:border-[#0F54D4] focus:outline-none"
                    />
                  </div>
                  <div class="w-20">
                    <label for="ret-time" class="sr-only">Heure retour</label>
                    <select
                      id="ret-time"
                      formControlName="returnTime"
                      class="w-full px-1.5 py-2.5 text-xs font-medium text-[#0E1F3B] bg-white border border-[#CDD3DE] rounded-xl focus:border-[#0F54D4] focus:outline-none"
                    >
                      <option value="00:00">Dès 00h</option>
                      <option value="12:00">Dès 12h</option>
                      <option value="16:00">Dès 16h</option>
                      <option value="18:00">Dès 18h</option>
                    </select>
                  </div>
                </div>
              } @else {
                <div class="lg:col-span-2 flex items-center px-3 py-2.5 rounded-xl bg-[#FAF8F5] border border-dashed border-[#CDD3DE] text-xs text-[#64748B]">
                  Trajet aller simple
                </div>
              }

              <!-- Search CTA -->
              <div class="lg:col-span-1">
                <button
                  type="submit"
                  class="w-full h-full min-h-[44px] px-3 py-2.5 rounded-xl bg-[#0F54D4] hover:bg-[#0B44B0] text-white text-sm font-semibold flex items-center justify-center gap-1.5 transition-colors whitespace-nowrap shrink-0 ligne-focus"
                >
                  <mat-icon class="!text-[18px] !w-[18px] !h-[18px]">search</mat-icon>
                  <span class="lg:hidden xl:inline">Rechercher</span>
                </button>
              </div>
            </div>

            @if (validationError()) {
              <p class="mt-2.5 text-xs text-[#B42318]" role="alert">{{ validationError() }}</p>
            }
          </form>
        </div>
      </section>

      <!-- RESULTS & SIDEBAR -->
      <section class="max-w-[1200px] mx-auto px-4 sm:px-6 pt-9 pb-12" aria-live="polite">
        <div class="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          <!-- Left Results Column -->
          <div class="lg:col-span-8">
            @if (selectingReturn() && bookingFlow.outward(); as outLeg) {
              <div class="mb-4 p-4 rounded-xl bg-[#EEF4FF] border border-[#C7DAFC] flex flex-wrap items-center justify-between gap-3">
                <div>
                  <p class="text-xs font-semibold text-[#0F54D4]">Étape 1 validée · Votre aller</p>
                  <p class="text-sm font-semibold text-[#0E1F3B]">
                    {{ outLeg.itinerary.origin_station.name }} ({{ outLeg.itinerary.departure_local_label }}) →
                    {{ outLeg.itinerary.destination_station.name }} ({{ outLeg.itinerary.arrival_local_label }})
                    · {{ formatPrice(outLeg.offer.total_known_cents) }}
                  </p>
                </div>
                <button
                  type="button"
                  (click)="resetToOutwardStep()"
                  class="text-xs font-semibold text-[#0F54D4] hover:underline"
                >
                  Modifier l’aller
                </button>
              </div>
            }

            <div class="flex flex-wrap items-baseline justify-between gap-3">
              <div>
                <h2 class="font-serif-display text-[28px] sm:text-[32px] font-semibold text-[#0E1F3B] tracking-[-0.01em]">
                  @if (searchResponse(); as res) {
                    @if (selectingReturn()) {
                      Votre retour : {{ res.to_station.city }} → {{ res.from_station.city }}
                    } @else {
                      Votre aller : {{ res.from_station.city }} → {{ res.to_station.city }}
                    }
                  } @else {
                    Votre aller : Paris → Lyon
                  }
                </h2>
                <p class="text-sm text-[#4B5A73] mt-0.5">
                  {{ activeDateHeading() }} · {{ passengerHeading() }}
                </p>
              </div>

              <button
                type="button"
                (click)="filtersOpen.set(!filtersOpen())"
                class="flex items-center gap-1.5 px-3 py-1.5 rounded-xl border border-[#CDD3DE] bg-white text-xs font-semibold text-[#0E1F3B] hover:bg-[#FAF8F5] lg:hidden"
              >
                <mat-icon class="!text-[16px] !w-[16px] !h-[16px]">tune</mat-icon>
                <span>Filtres</span>
              </button>
            </div>

            <!-- Interactive Filter Controls -->
            <div class="mt-4 flex flex-wrap items-center gap-2">
              <button
                type="button"
                (click)="toggleDirectOnly()"
                [class]="
                  directOnly()
                    ? 'flex items-center gap-1.5 px-3.5 py-1.5 rounded-full text-xs sm:text-sm font-semibold bg-[#0E1F3B] text-white border border-[#0E1F3B] transition-colors whitespace-nowrap shrink-0'
                    : 'flex items-center gap-1.5 px-3.5 py-1.5 rounded-full text-xs sm:text-sm font-medium bg-white text-[#0E1F3B] border border-[#CDD3DE] hover:border-[#0E1F3B] transition-colors whitespace-nowrap shrink-0'
                "
              >
                <mat-icon class="!text-[16px] !w-[16px] !h-[16px]">train</mat-icon>
                <span>Direct</span>
              </button>

              <button
                type="button"
                (click)="setSortMode('cheapest')"
                [class]="
                  sortMode() === 'cheapest'
                    ? 'flex items-center gap-1.5 px-3.5 py-1.5 rounded-full text-xs sm:text-sm font-semibold bg-[#0E1F3B] text-white border border-[#0E1F3B] transition-colors whitespace-nowrap shrink-0'
                    : 'flex items-center gap-1.5 px-3.5 py-1.5 rounded-full text-xs sm:text-sm font-medium bg-white text-[#0E1F3B] border border-[#CDD3DE] hover:border-[#0E1F3B] transition-colors whitespace-nowrap shrink-0'
                "
              >
                <mat-icon class="!text-[16px] !w-[16px] !h-[16px] text-[#D63D2E]">sell</mat-icon>
                <span>Le moins cher</span>
              </button>

              <button
                type="button"
                (click)="setSortMode('fastest')"
                [class]="
                  sortMode() === 'fastest'
                    ? 'flex items-center gap-1.5 px-3.5 py-1.5 rounded-full text-xs sm:text-sm font-semibold bg-[#0E1F3B] text-white border border-[#0E1F3B] transition-colors whitespace-nowrap shrink-0'
                    : 'flex items-center gap-1.5 px-3.5 py-1.5 rounded-full text-xs sm:text-sm font-medium bg-white text-[#0E1F3B] border border-[#CDD3DE] hover:border-[#0E1F3B] transition-colors whitespace-nowrap shrink-0'
                "
              >
                <mat-icon class="!text-[16px] !w-[16px] !h-[16px] text-[#D63D2E]">bolt</mat-icon>
                <span>Le plus rapide</span>
              </button>

              <button
                type="button"
                (click)="filtersOpen.set(!filtersOpen())"
                class="hidden lg:inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-full text-xs sm:text-sm font-medium bg-white text-[#4B5A73] border border-[#E3E6EC] hover:border-[#0E1F3B] hover:text-[#0E1F3B] transition-colors whitespace-nowrap shrink-0"
              >
                <mat-icon class="!text-[16px] !w-[16px] !h-[16px]">tune</mat-icon>
                <span>Plus de filtres</span>
              </button>
            </div>

            <!-- Expanded Filter Drawer / Mobile Sheet -->
            @if (filtersOpen()) {
              <div class="mt-3 p-4 rounded-xl bg-white border border-[#E3E6EC] grid sm:grid-cols-3 gap-3 text-xs">
                <div>
                  <label for="f-dep-win" class="block font-semibold text-[#0E1F3B] mb-1">Heure de départ</label>
                  <select
                    id="f-dep-win"
                    [value]="depWindow()"
                    (change)="depWindow.set($any($event.target).value)"
                    class="w-full px-2.5 py-2 rounded-lg border border-[#CDD3DE] bg-white"
                  >
                    <option value="all">Toute la journée</option>
                    <option value="morning">Matin (05:00 – 12:00)</option>
                    <option value="afternoon">Après-midi (12:00 – 18:00)</option>
                    <option value="evening">Soir (18:00 – 23:59)</option>
                  </select>
                </div>

                <div>
                  <label for="f-flex" class="block font-semibold text-[#0E1F3B] mb-1">Flexibilité billet</label>
                  <select
                    id="f-flex"
                    [value]="flexFilter()"
                    (change)="flexFilter.set($any($event.target).value)"
                    class="w-full px-2.5 py-2 rounded-lg border border-[#CDD3DE] bg-white"
                  >
                    <option value="all">Toutes conditions</option>
                    <option value="flexible">Échangeable / remboursable sans frais</option>
                  </select>
                </div>

                <div>
                  <label for="f-op" class="block font-semibold text-[#0E1F3B] mb-1">Transporteur</label>
                  <select
                    id="f-op"
                    [value]="operatorFilter()"
                    (change)="operatorFilter.set($any($event.target).value)"
                    class="w-full px-2.5 py-2 rounded-lg border border-[#CDD3DE] bg-white"
                  >
                    <option value="all">Tous les transporteurs</option>
                    @for (op of availableOperators(); track op) {
                      <option [value]="op">{{ op }}</option>
                    }
                  </select>
                </div>
              </div>
            }

            <!-- Partial results / provider timeout alert -->
            @if (searchResponse()?.partial_results) {
              <div
                class="mt-4 p-3.5 rounded-xl bg-[#FFF7ED] border border-[#FED7AA] text-xs text-[#9A3412] flex items-start gap-2.5"
                role="status"
              >
                <mat-icon class="!text-[18px] !w-[18px] !h-[18px] shrink-0 mt-0.5">warning_amber</mat-icon>
                <div>
                  <p class="font-semibold">Résultats partiels affichés</p>
                  <p class="mt-0.5">
                    Au moins un fournisseur n’a pas répondu dans le délai imparti. Les trajets disponibles sont affichés ci-dessous.
                  </p>
                </div>
              </div>
            }

            <!-- Loading state -->
            @if (loading()) {
              <div class="mt-5 space-y-3">
                @for (n of [1, 2]; track n) {
                  <div class="h-28 rounded-2xl bg-white border border-[#E3E6EC] animate-pulse p-5"></div>
                }
              </div>
            } @else if (searchError()) {
              <div class="mt-5 p-5 rounded-2xl bg-white border border-[#F5C2BE] text-sm text-[#B42318]">
                {{ searchError() }}
              </div>
            } @else if (filteredResults().length === 0) {
              <div class="mt-5 p-6 rounded-2xl bg-white border border-[#E3E6EC] text-center">
                <p class="font-semibold text-[#0E1F3B]">Aucun trajet trouvé pour ces critères</p>
                <p class="text-sm text-[#4B5A73] mt-1">
                  Essayez d’élargir vos filtres, de sélectionner « Paris (toutes gares) » ou de tester un corridor desservi (Paris → Lyon, Bordeaux, Marseille, Strasbourg).
                </p>
              </div>
            } @else {
              <!-- Journey Cards -->
              <div class="mt-4 space-y-3.5">
                @for (item of filteredResults(); track item.itinerary.journey_reference) {
                  @let offer = item.offers[0];
                  <article class="bg-white border border-[#E3E6EC] hover:border-[#CDD3DE] rounded-2xl px-5 py-4 sm:px-6 sm:py-5 transition-colors">
                    <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                      <!-- Times & Fare Conditions Link -->
                      <div class="min-w-[175px]">
                        <div class="flex items-baseline gap-2 text-[22px] font-bold text-[#0E1F3B] tabular-nums">
                          <span>{{ item.itinerary.departure_local_label }}</span>
                          <span class="text-[#64748B] font-normal">→</span>
                          <span>{{ item.itinerary.arrival_local_label }}</span>
                          @if (item.itinerary.day_offset > 0) {
                            <span class="text-xs font-semibold text-[#D63D2E]">+{{ item.itinerary.day_offset }} j</span>
                          }
                        </div>
                        @if (item.itinerary.departure_tz !== item.itinerary.arrival_tz) {
                          <p class="text-[11px] text-[#4B5A73] mt-0.5">
                            Heures locales ({{ item.itinerary.departure_tz }} / {{ item.itinerary.arrival_tz }})
                          </p>
                        }
                        <button
                          type="button"
                          (click)="openConditionsModal(item.itinerary, offer)"
                          class="mt-1 inline-flex items-center gap-0.5 text-xs font-medium text-[#0F54D4] hover:underline ligne-focus"
                        >
                          <span>Conditions du billet</span>
                          <mat-icon class="!text-[15px] !w-[15px] !h-[15px]">chevron_right</mat-icon>
                        </button>
                      </div>

                      <!-- Duration, Changes, Operator & Timetable Status -->
                      <div class="flex-1 sm:border-l sm:border-[#E3E6EC] sm:pl-5 space-y-1">
                        <div class="flex items-center gap-2 text-sm font-medium text-[#0E1F3B]">
                          <mat-icon class="!text-[17px] !w-[17px] !h-[17px] text-[#4B5A73]">train</mat-icon>
                          <span>
                            {{ item.itinerary.changes_count === 0 ? 'Direct' : item.itinerary.changes_count + ' correspondance' }}
                            · {{ formatDuration(item.itinerary.total_duration_minutes) }}
                          </span>
                        </div>
                        <p class="text-xs text-[#4B5A73]">
                          {{ offer.travel_class === '1' ? '1re classe' : '2de classe' }}
                          · {{ item.itinerary.operators.join(' + ') }}
                          · {{ offer.ticket_product }}
                        </p>
                        <p class="text-[11px] text-[#64748B]">
                          {{ item.itinerary.origin_station.name }} → {{ item.itinerary.destination_station.name }}
                          · {{ timetableLabel(item.itinerary) }}
                          ·
                          {{
                            offer.booking_mode === 'seller_handoff'
                              ? 'Vente partenaire'
                              : 'Réservation directe démo'
                          }}
                        </p>
                      </div>

                      <!-- Price & Select Button -->
                      <div class="sm:border-l sm:border-[#E3E6EC] sm:pl-5 flex sm:flex-row items-center justify-between sm:justify-end gap-4">
                        <div class="text-left sm:text-right">
                          <div class="flex items-baseline gap-1.5 sm:justify-end">
                            <span class="text-[24px] font-bold text-[#0E1F3B] tabular-nums">
                              {{ formatPrice(offer.total_known_cents) }}
                            </span>
                            @if (offer.has_unknown_mandatory_fees) {
                              <span class="text-[11px] text-[#9A3412] font-medium">+ frais inconnus</span>
                            }
                          </div>
                          <p class="text-xs text-[#4B5A73]">
                            {{ tripType() === 'oneway' ? 'Aller simple' : selectingReturn() ? 'Retour' : 'Aller' }}
                            · {{ shortPaxLabel() }}
                          </p>
                        </div>

                        <div class="flex items-center gap-2">
                          <button
                            type="button"
                            (click)="saveItinerary(item)"
                            class="p-2 rounded-xl border border-[#E3E6EC] text-[#4B5A73] hover:text-[#0F54D4] hover:border-[#0F54D4] transition-colors ligne-focus"
                            title="Enregistrer cet itinéraire (sans achat)"
                            aria-label="Enregistrer cet itinéraire sans acheter"
                          >
                            <mat-icon class="!text-[18px] !w-[18px] !h-[18px]">bookmark_border</mat-icon>
                          </button>

                          <button
                            type="button"
                            (click)="chooseOffer(item, offer)"
                            class="px-5 py-2.5 rounded-xl bg-[#0F54D4] hover:bg-[#0B44B0] text-white text-sm font-semibold transition-colors whitespace-nowrap shrink-0 ligne-focus"
                          >
                            Choisir
                          </button>
                        </div>
                      </div>
                    </div>
                  </article>
                }
              </div>

              @if (savedToast()) {
                <p class="mt-3 text-xs text-[#0E1F3B] bg-[#EEF4FF] border border-[#C7DAFC] rounded-xl px-3.5 py-2.5">
                  {{ savedToast() }}
                </p>
              }
            }
          </div>

          <!-- Right Explanatory Sidebar -->
          <aside class="lg:col-span-4 space-y-4">
            <div class="bg-[#102342] text-white rounded-2xl p-6">
              <h3 class="font-serif-display text-2xl font-semibold text-white mb-5">
                Voyagez en toute clarté
              </h3>

              <div class="space-y-5">
                <div class="flex items-start gap-3.5 pb-4 border-b border-white/15">
                  <mat-icon class="!text-[20px] !w-[20px] !h-[20px] text-white/85 shrink-0 mt-0.5">calendar_today</mat-icon>
                  <div>
                    <h4 class="text-sm font-semibold text-white">Horaires et correspondances</h4>
                    <p class="text-xs text-white/75 mt-1 leading-relaxed">
                      Des trajets lisibles et faciles à comparer, en heure locale de chaque gare.
                    </p>
                  </div>
                </div>

                <div class="flex items-start gap-3.5 pb-4 border-b border-white/15">
                  <mat-icon class="!text-[20px] !w-[20px] !h-[20px] text-white/85 shrink-0 mt-0.5">edit_note</mat-icon>
                  <div>
                    <h4 class="text-sm font-semibold text-white">Conditions de modification</h4>
                    <p class="text-xs text-white/75 mt-1 leading-relaxed">
                      Des billets flexibles selon le tarif choisi ; toute condition inconnue reste indiquée.
                    </p>
                  </div>
                </div>

                <div class="flex items-start gap-3.5">
                  <mat-icon class="!text-[20px] !w-[20px] !h-[20px] text-white/85 shrink-0 mt-0.5">toll</mat-icon>
                  <div>
                    <h4 class="text-sm font-semibold text-white">Prix avant paiement</h4>
                    <p class="text-xs text-white/75 mt-1 leading-relaxed">
                      Un tarif clair et complet, sans option payante pré-cochée ni mauvaise surprise.
                    </p>
                  </div>
                </div>
              </div>
            </div>

            <div class="bg-white border border-[#E3E6EC] rounded-2xl px-4 py-3.5 flex items-start gap-3">
              <mat-icon class="!text-[18px] !w-[18px] !h-[18px] text-[#4B5A73] shrink-0 mt-0.5">info_outline</mat-icon>
              <div class="text-xs text-[#2A3B59] leading-relaxed">
                <p class="font-medium text-[#0E1F3B]">Billets et horaires illustratifs.</p>
                <p class="mt-0.5 text-[#4B5A73]">
                  Prototype indépendant utilisant des transporteurs fictifs.
                  <a routerLink="/aide" class="text-[#0F54D4] hover:underline font-medium">
                    Tester les scénarios d’incidents
                  </a>
                </p>
              </div>
            </div>
          </aside>
        </div>
      </section>

      <!-- DESTINATIONS SECTION -->
      <section class="max-w-[1200px] mx-auto px-4 sm:px-6 pb-14">
        <div class="mb-6">
          <h2 class="font-serif-display text-[28px] sm:text-[32px] font-semibold text-[#0E1F3B]">
            Une envie d’ailleurs ?
          </h2>
          <div class="w-12 h-[2.5px] bg-[#D63D2E] mt-1.5"></div>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
          @for (dest of featuredDestinations; track dest.stationId) {
            <button
              type="button"
              (click)="launchDestinationSearch(dest)"
              class="group text-left bg-white border border-[#E3E6EC] rounded-2xl overflow-hidden hover:border-[#0F54D4] transition-colors ligne-focus"
            >
              <div class="aspect-[16/9] bg-[#E8ECF2] overflow-hidden">
                <img
                  [src]="dest.imageUrl"
                  [alt]="dest.alt"
                  referrerpolicy="no-referrer"
                  class="w-full h-full object-cover group-hover:scale-[1.03] transition-transform duration-300"
                />
              </div>
              <div class="px-5 py-3.5 flex items-center justify-between">
                <div>
                  <h3 class="font-serif-display text-lg font-semibold text-[#0E1F3B]">
                    {{ dest.city }}
                  </h3>
                  <p class="text-xs text-[#4B5A73]">{{ dest.subtitle }}</p>
                </div>
                <mat-icon class="!text-[18px] !w-[18px] !h-[18px] text-[#D63D2E]">chevron_right</mat-icon>
              </div>
            </button>
          }
        </div>
      </section>

      <!-- QUIET FOOTER -->
      <footer class="border-t border-[#E3E6EC] bg-[#FAF8F5] py-6">
        <div class="max-w-[1200px] mx-auto px-4 sm:px-6 flex flex-col sm:flex-row items-center justify-between gap-3 text-xs text-[#4B5A73]">
          <p>
            <strong class="text-[#0E1F3B]">LIGNE</strong> · Concept indépendant · Tarifs et horaires de démonstration
          </p>
          <div class="flex items-center gap-5">
            <a routerLink="/destinations" class="hover:text-[#0E1F3B]">Destinations</a>
            <a routerLink="/mes-voyages" class="hover:text-[#0E1F3B]">Mes voyages</a>
            <a routerLink="/aide" class="hover:text-[#0E1F3B]">Scénarios & Aide</a>
            <a routerLink="/admin" class="hover:text-[#0E1F3B]">Administration</a>
          </div>
        </div>
      </footer>

      <app-fare-conditions-modal
        [offer]="inspectedOffer()"
        [itinerary]="inspectedItinerary()"
        (closed)="closeConditionsModal()"
      />
    </main>
  `,
})
export class HomePage implements OnInit {
  private readonly railApi = inject(RailApi);
  private readonly route = inject(ActivatedRoute);
  private readonly router = inject(Router);
  private readonly destroyRef = inject(DestroyRef);
  private readonly platformId = inject(PLATFORM_ID);
  readonly auth = inject(AuthStore);
  readonly bookingFlow = inject(BookingFlow);

  readonly discountCardOptions = DISCOUNT_CARD_OPTIONS;
  readonly featuredDestinations = [
    {
      city: 'Bordeaux',
      fromId: 'FRPMO',
      fromLabel: 'Paris Montparnasse',
      stationId: 'FRBDX',
      toLabel: 'Bordeaux Saint-Jean',
      subtitle: 'Dès 54 € · 2 h 04 direct',
      imageUrl: '/src/assets/images/dest_bordeaux_1795859312912.jpg',
      alt: 'Place de la Bourse et Miroir d’Eau à Bordeaux',
    },
    {
      city: 'Marseille',
      fromId: 'FRPLY',
      fromLabel: 'Paris Gare de Lyon',
      stationId: 'FRMRS',
      toLabel: 'Marseille Saint-Charles',
      subtitle: 'Dès 62 € · 3 h 08 direct',
      imageUrl: '/src/assets/images/dest_marseille_1795859313524.jpg',
      alt: 'Vieux-Port de Marseille et basilique Notre-Dame de la Garde',
    },
    {
      city: 'Strasbourg',
      fromId: 'FRPES',
      fromLabel: "Paris Gare de l'Est",
      stationId: 'FRXSB',
      toLabel: 'Strasbourg',
      subtitle: 'Dès 45 € · 1 h 46 direct',
      imageUrl: '/src/assets/images/dest_strasbourg_1795859313333.jpg',
      alt: 'Quartier de la Petite France et cathédrale de Strasbourg',
    },
  ];

  // Search form state
  readonly tripType = signal<'oneway' | 'roundtrip'>('roundtrip');
  readonly adults = signal(1);
  readonly youths = signal(0);
  readonly seniors = signal(0);
  readonly travelClass = signal<TravelClass>('2');
  readonly selectedCards = signal<DiscountCardId[]>([]);
  readonly paxPopoverOpen = signal(false);

  readonly fromStationId = signal('FRPLY');
  readonly toStationId = signal('FRLPD');

  readonly searchForm = new FormGroup({
    fromLabel: new FormControl('Paris Gare de Lyon', {nonNullable: true}),
    toLabel: new FormControl('Lyon Part-Dieu', {nonNullable: true}),
    outwardDate: new FormControl('2027-06-18', {nonNullable: true}),
    outwardTime: new FormControl('00:00', {nonNullable: true}),
    returnDate: new FormControl('2027-06-21', {nonNullable: true}),
    returnTime: new FormControl('00:00', {nonNullable: true}),
  });

  // Autocomplete
  readonly originSuggestions = signal<StationNode[]>([]);
  readonly destSuggestions = signal<StationNode[]>([]);
  readonly originDropdownOpen = signal(false);
  readonly destDropdownOpen = signal(false);
  readonly activeOriginIdx = signal(0);
  readonly activeDestIdx = signal(0);

  // Results & filters
  readonly loading = signal(false);
  readonly searchError = signal<string | null>(null);
  readonly validationError = signal<string | null>(null);
  readonly searchResponse = signal<JourneySearchResponse | null>(null);
  readonly selectingReturn = signal(false);

  readonly directOnly = signal(false);
  readonly sortMode = signal<'departure' | 'cheapest' | 'fastest'>('departure');
  readonly depWindow = signal<'all' | 'morning' | 'afternoon' | 'evening'>('all');
  readonly flexFilter = signal<'all' | 'flexible'>('all');
  readonly operatorFilter = signal('all');
  readonly filtersOpen = signal(false);

  readonly inspectedOffer = signal<FareOffer | null>(null);
  readonly inspectedItinerary = signal<JourneyItinerary | null>(null);
  readonly savedToast = signal<string | null>(null);

  private readonly searchTrigger$ = new Subject<SearchParamsPayload>();

  readonly passengerSummaryLabel = computed(() =>
    formatPassengerSummaryFr(
      this.adults(),
      this.youths(),
      this.seniors(),
      this.travelClass(),
    ),
  );

  readonly shortPaxLabel = computed(() => {
    const total = this.adults() + this.youths() + this.seniors();
    if (total === 1 && this.adults() === 1) return '1 adulte';
    return `${total} voyageur${total > 1 ? 's' : ''}`;
  });

  readonly activeDateHeading = computed(() => {
    const q = this.searchResponse()?.query;
    if (this.selectingReturn() && q?.return_date) {
      return formatDateHeadingFr(q.return_date);
    }
    return formatDateHeadingFr(q?.outward_date ?? this.searchForm.controls.outwardDate.value);
  });

  readonly passengerHeading = computed(() => {
    const q = this.searchResponse()?.query;
    const a = q?.adults ?? this.adults();
    const y = q?.youths ?? this.youths();
    const s = q?.seniors ?? this.seniors();
    const parts: string[] = [];
    if (a > 0) parts.push(`${a} adulte${a > 1 ? 's' : ''}`);
    if (y > 0) parts.push(`${y} jeune${y > 1 ? 's' : ''}`);
    if (s > 0) parts.push(`${s} senior${s > 1 ? 's' : ''}`);
    return parts.join(', ') || '1 adulte';
  });

  readonly rawActiveResults = computed<JourneySearchResultItem[]>(() => {
    const res = this.searchResponse();
    if (!res) return [];
    return this.selectingReturn() ? res.return_results : res.outward_results;
  });

  readonly availableOperators = computed(() => {
    const set = new Set<string>();
    for (const r of this.rawActiveResults()) {
      for (const op of r.itinerary.operators) set.add(op);
    }
    return Array.from(set);
  });

  readonly filteredResults = computed<JourneySearchResultItem[]>(() => {
    let list = [...this.rawActiveResults()];

    if (this.directOnly()) {
      list = list.filter((r) => r.itinerary.changes_count === 0);
    }

    const win = this.depWindow();
    if (win !== 'all') {
      list = list.filter((r) => {
        const hh = Number(r.itinerary.departure_local_label.slice(0, 2));
        if (win === 'morning') return hh >= 5 && hh < 12;
        if (win === 'afternoon') return hh >= 12 && hh < 18;
        return hh >= 18;
      });
    }

    if (this.flexFilter() === 'flexible') {
      list = list.filter((r) =>
        r.offers.some(
          (o) =>
            o.change_conditions.status === 'allowed' &&
            o.refund_conditions.status === 'allowed',
        ),
      );
    }

    if (this.operatorFilter() !== 'all') {
      list = list.filter((r) =>
        r.itinerary.operators.includes(this.operatorFilter()),
      );
    }

    if (this.sortMode() === 'cheapest') {
      // Never classify offers with unknown mandatory fees as "cheapest"
      list = list
        .filter((r) => !r.offers[0].has_unknown_mandatory_fees)
        .sort(
          (a, b) =>
            a.offers[0].total_known_cents - b.offers[0].total_known_cents,
        );
    } else if (this.sortMode() === 'fastest') {
      list.sort(
        (a, b) =>
          a.itinerary.total_duration_minutes - b.itinerary.total_duration_minutes,
      );
    } else {
      list.sort(
        (a, b) =>
          new Date(a.itinerary.departure_iso).getTime() -
          new Date(b.itinerary.departure_iso).getTime(),
      );
    }

    return list;
  });

  ngOnInit(): void {
    // RxJS switchMap cancels any superseded search requests automatically
    this.searchTrigger$
      .pipe(
        switchMap((payload) => {
          this.loading.set(true);
          this.searchError.set(null);
          return this.railApi.searchJourneys(payload).pipe(
            catchError((err: unknown) => {
              const msg =
                (err as {error?: {error?: string}})?.error?.error ||
                'Erreur lors de la recherche ferroviaire.';
              this.searchError.set(msg);
              return of(null);
            }),
          );
        }),
        takeUntilDestroyed(this.destroyRef),
      )
      .subscribe((res) => {
        this.loading.set(false);
        if (res) {
          this.searchResponse.set(res);
          this.fromStationId.set(res.from_station.id);
          this.toStationId.set(res.to_station.id);
          this.searchForm.patchValue(
            {
              fromLabel: res.from_station.name,
              toLabel: res.to_station.name,
            },
            {emitEvent: false},
          );
        }
      });

    // Debounced station autocomplete
    this.searchForm.controls.fromLabel.valueChanges
      .pipe(
        debounceTime(180),
        distinctUntilChanged(),
        switchMap((val) => this.railApi.searchStations(val).pipe(catchError(() => of({stations: []})))),
        takeUntilDestroyed(this.destroyRef),
      )
      .subscribe((res) => {
        this.originSuggestions.set(res.stations);
        this.activeOriginIdx.set(0);
      });

    this.searchForm.controls.toLabel.valueChanges
      .pipe(
        debounceTime(180),
        distinctUntilChanged(),
        switchMap((val) => this.railApi.searchStations(val).pipe(catchError(() => of({stations: []})))),
        takeUntilDestroyed(this.destroyRef),
      )
      .subscribe((res) => {
        this.destSuggestions.set(res.stations);
        this.activeDestIdx.set(0);
      });

    // Sync browser URL query params (Back/Forward & shareable links)
    this.route.queryParams
      .pipe(takeUntilDestroyed(this.destroyRef))
      .subscribe((qp) => {
        if (!isPlatformBrowser(this.platformId)) return;
        const from = qp['from'] || 'FRPLY';
        const to = qp['to'] || 'FRLPD';
        const trip: 'oneway' | 'roundtrip' = qp['trip'] === 'oneway' ? 'oneway' : 'roundtrip';
        const out = qp['out'] || '2027-06-18';
        const outTime = qp['out_time'] || '00:00';
        const ret = qp['ret'] || '2027-06-21';
        const retTime = qp['ret_time'] || '00:00';
        const adults = Number(qp['adults'] ?? 1) || 1;
        const youths = Number(qp['youths'] ?? 0) || 0;
        const seniors = Number(qp['seniors'] ?? 0) || 0;
        const travelClass: TravelClass = qp['class'] === '1' ? '1' : '2';
        const cards = qp['cards']
          ? (String(qp['cards']).split(',').filter(Boolean) as DiscountCardId[])
          : [];

        this.fromStationId.set(from);
        this.toStationId.set(to);
        this.tripType.set(trip);
        this.adults.set(adults);
        this.youths.set(youths);
        this.seniors.set(seniors);
        this.travelClass.set(travelClass);
        this.selectedCards.set(cards);
        this.selectingReturn.set(false);
        this.bookingFlow.startSelection(trip);

        this.searchForm.patchValue(
          {
            outwardDate: out,
            outwardTime: outTime,
            returnDate: ret,
            returnTime: retTime,
          },
          {emitEvent: false},
        );

        this.searchTrigger$.next({
          from,
          to,
          trip,
          out,
          out_time: outTime,
          ret: trip === 'roundtrip' ? ret : undefined,
          ret_time: trip === 'roundtrip' ? retTime : undefined,
          adults,
          youths,
          seniors,
          class: travelClass,
          cards,
        });
      });
  }

  setTripType(type: 'oneway' | 'roundtrip'): void {
    this.tripType.set(type);
  }

  adjustPax(field: 'adults' | 'youths' | 'seniors', delta: number): void {
    const total = this.adults() + this.youths() + this.seniors();
    if (delta > 0 && total >= 6) return;
    if (field === 'adults') {
      const next = Math.max(0, this.adults() + delta);
      if (next + this.youths() + this.seniors() >= 1) this.adults.set(next);
    } else if (field === 'youths') {
      const next = Math.max(0, this.youths() + delta);
      if (this.adults() + next + this.seniors() >= 1) this.youths.set(next);
    } else {
      const next = Math.max(0, this.seniors() + delta);
      if (this.adults() + this.youths() + next >= 1) this.seniors.set(next);
    }
  }

  toggleDiscountCard(cardId: DiscountCardId): void {
    this.selectedCards.update((cards) =>
      cards.includes(cardId) ? cards.filter((c) => c !== cardId) : [...cards, cardId],
    );
  }

  openOriginSuggestions(): void {
    this.originDropdownOpen.set(true);
    this.destDropdownOpen.set(false);
    this.railApi
      .searchStations(this.searchForm.controls.fromLabel.value)
      .pipe(catchError(() => of({stations: []})))
      .subscribe((r) => this.originSuggestions.set(r.stations));
  }

  openDestSuggestions(): void {
    this.destDropdownOpen.set(true);
    this.originDropdownOpen.set(false);
    this.railApi
      .searchStations(this.searchForm.controls.toLabel.value)
      .pipe(catchError(() => of({stations: []})))
      .subscribe((r) => this.destSuggestions.set(r.stations));
  }

  selectStation(side: 'origin' | 'dest', station: StationNode): void {
    if (side === 'origin') {
      this.fromStationId.set(station.id);
      this.searchForm.controls.fromLabel.setValue(station.name, {emitEvent: false});
      this.originDropdownOpen.set(false);
    } else {
      this.toStationId.set(station.id);
      this.searchForm.controls.toLabel.setValue(station.name, {emitEvent: false});
      this.destDropdownOpen.set(false);
    }
  }

  handleStationKeydown(event: KeyboardEvent, side: 'origin' | 'dest'): void {
    const list = side === 'origin' ? this.originSuggestions() : this.destSuggestions();
    const idxSig = side === 'origin' ? this.activeOriginIdx : this.activeDestIdx;
    const openSig = side === 'origin' ? this.originDropdownOpen : this.destDropdownOpen;

    if (event.key === 'Escape') {
      openSig.set(false);
      return;
    }
    if (!openSig() || list.length === 0) return;

    if (event.key === 'ArrowDown') {
      event.preventDefault();
      idxSig.update((i) => (i + 1) % list.length);
    } else if (event.key === 'ArrowUp') {
      event.preventDefault();
      idxSig.update((i) => (i - 1 + list.length) % list.length);
    } else if (event.key === 'Enter') {
      event.preventDefault();
      const chosen = list[idxSig()];
      if (chosen) this.selectStation(side, chosen);
    }
  }

  swapStations(): void {
    const oldFromId = this.fromStationId();
    const oldToId = this.toStationId();
    const oldFromLabel = this.searchForm.controls.fromLabel.value;
    const oldToLabel = this.searchForm.controls.toLabel.value;

    this.fromStationId.set(oldToId);
    this.toStationId.set(oldFromId);
    this.searchForm.patchValue(
      {fromLabel: oldToLabel, toLabel: oldFromLabel},
      {emitEvent: false},
    );
  }

  submitSearch(): void {
    this.validationError.set(null);
    this.originDropdownOpen.set(false);
    this.destDropdownOpen.set(false);
    this.paxPopoverOpen.set(false);

    if (this.fromStationId() === this.toStationId()) {
      this.validationError.set('Choisissez deux gares distinctes.');
      return;
    }

    const raw = this.searchForm.getRawValue();
    if (this.tripType() === 'roundtrip' && raw.returnDate < raw.outwardDate) {
      this.validationError.set('La date de retour doit être postérieure ou égale à l’aller.');
      return;
    }

    void this.router.navigate([], {
      relativeTo: this.route,
      queryParams: {
        from: this.fromStationId(),
        to: this.toStationId(),
        trip: this.tripType(),
        out: raw.outwardDate,
        out_time: raw.outwardTime,
        ret: this.tripType() === 'roundtrip' ? raw.returnDate : null,
        ret_time: this.tripType() === 'roundtrip' ? raw.returnTime : null,
        adults: this.adults(),
        youths: this.youths(),
        seniors: this.seniors(),
        class: this.travelClass(),
        cards: this.selectedCards().length > 0 ? this.selectedCards().join(',') : null,
      },
    });
  }

  launchDestinationSearch(dest: (typeof this.featuredDestinations)[number]): void {
    this.fromStationId.set(dest.fromId);
    this.toStationId.set(dest.stationId);
    this.searchForm.patchValue(
      {fromLabel: dest.fromLabel, toLabel: dest.toLabel},
      {emitEvent: false},
    );
    this.submitSearch();
    if (isPlatformBrowser(this.platformId)) {
      window.scrollTo({top: 320, behavior: 'smooth'});
    }
  }

  toggleDirectOnly(): void {
    this.directOnly.update((v) => !v);
  }

  setSortMode(mode: 'cheapest' | 'fastest'): void {
    this.sortMode.update((cur) => (cur === mode ? 'departure' : mode));
  }

  openConditionsModal(itinerary: JourneyItinerary, offer: FareOffer): void {
    this.inspectedItinerary.set(itinerary);
    this.inspectedOffer.set(offer);
  }

  closeConditionsModal(): void {
    this.inspectedOffer.set(null);
    this.inspectedItinerary.set(null);
  }

  chooseOffer(item: JourneySearchResultItem, offer: FareOffer): void {
    if (offer.booking_mode === 'seller_handoff') {
      // Explicit Seller Handoff path
      this.bookingFlow.selectOutward(item.itinerary, offer);
      void this.router.navigate(['/reservation']);
      return;
    }

    if (this.tripType() === 'oneway') {
      this.bookingFlow.startSelection('oneway');
      this.bookingFlow.selectOutward(item.itinerary, offer);
      void this.router.navigate(['/reservation']);
      return;
    }

    if (!this.selectingReturn()) {
      this.bookingFlow.selectOutward(item.itinerary, offer);
      this.selectingReturn.set(true);
      this.sortMode.set('departure');
      if (isPlatformBrowser(this.platformId)) {
        window.scrollTo({top: 300, behavior: 'smooth'});
      }
    } else {
      this.bookingFlow.selectReturn(item.itinerary, offer);
      void this.router.navigate(['/reservation']);
    }
  }

  resetToOutwardStep(): void {
    this.selectingReturn.set(false);
    this.bookingFlow.startSelection(this.tripType());
  }

  saveItinerary(item: JourneySearchResultItem): void {
    if (!this.auth.isAuthenticated()) {
      this.auth.openModal();
      return;
    }
    const label = `${item.itinerary.origin_station.name} → ${item.itinerary.destination_station.name} (${formatDateShortFr(
      item.itinerary.departure_iso.slice(0, 10),
    )})`;
    this.railApi
      .saveItinerary(label, item.itinerary, item.offers[0].total_known_cents)
      .subscribe({
        next: () => {
          this.savedToast.set(
            'Itinéraire enregistré dans « Mes voyages » (rappel : un itinéraire enregistré ne constitue pas un billet acheté).',
          );
          setTimeout(() => this.savedToast.set(null), 5000);
        },
      });
  }

  formatPrice(cents: number): string {
    return formatEuroCents(cents);
  }

  formatDuration(min: number): string {
    return formatDurationFr(min);
  }

  kindLabel(kind: StationNode['kind']): string {
    return formatStationKindFr(kind);
  }

  timetableLabel(itin: JourneyItinerary): string {
    return formatTimetableStateFr(
      itin.disruption_summary.state,
      itin.disruption_summary.delay_minutes,
    );
  }
}
