import {ChangeDetectionStrategy, Component, inject, OnInit} from '@angular/core';
import {RouterOutlet} from '@angular/router';
import {AuthModal} from './components/auth-modal';
import {HeaderBar} from './components/header-bar';
import {AuthStore} from './services/auth-store';

@Component({
  changeDetection: ChangeDetectionStrategy.OnPush,
  selector: 'app-root',
  imports: [RouterOutlet, HeaderBar, AuthModal],
  templateUrl: './app.html',
  styleUrl: './app.css',
})
export class App implements OnInit {
  private readonly auth = inject(AuthStore);

  ngOnInit(): void {
    void this.auth.refreshSession();
  }
}
