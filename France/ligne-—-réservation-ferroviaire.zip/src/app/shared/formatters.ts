import type {
  BookingState,
  FlexibilityConditionStatus,
  RefundState,
  StationKind,
  TimetableState,
} from '../../shared/models';

export function formatEuroCents(cents: number | null | undefined): string {
  if (cents === null || cents === undefined) return 'Non communiqué';
  const euros = cents / 100;
  if (Number.isInteger(euros)) {
    return `${euros} €`;
  }
  return `${euros.toFixed(2).replace('.', ',')} €`;
}

export function formatDurationFr(minutes: number): string {
  const h = Math.floor(minutes / 60);
  const m = minutes % 60;
  if (h === 0) return `${m} min`;
  if (m === 0) return `${h} h`;
  return `${h} h ${String(m).padStart(2, '0')}`;
}

export function formatDateHeadingFr(isoDate: string): string {
  if (!isoDate) return '';
  const d = new Date(`${isoDate}T12:00:00Z`);
  if (Number.isNaN(d.getTime())) return isoDate;
  const formatted = new Intl.DateTimeFormat('fr-FR', {
    weekday: 'long',
    day: 'numeric',
    month: 'long',
    timeZone: 'UTC',
  }).format(d);
  return formatted.charAt(0).toUpperCase() + formatted.slice(1);
}

export function formatDateShortFr(isoDate: string): string {
  if (!isoDate) return '';
  const d = new Date(`${isoDate}T12:00:00Z`);
  if (Number.isNaN(d.getTime())) return isoDate;
  return new Intl.DateTimeFormat('fr-FR', {
    day: 'numeric',
    month: 'short',
    year: 'numeric',
    timeZone: 'UTC',
  }).format(d);
}

export function formatStationKindFr(kind: StationKind): string {
  switch (kind) {
    case 'individual_station':
      return 'Gare';
    case 'city_group':
      return 'Toutes gares';
    case 'transport_hub':
      return 'Pôle d’échanges';
  }
}

export function formatConditionStatusFr(status: FlexibilityConditionStatus): string {
  switch (status) {
    case 'allowed':
      return 'Autorisé sans frais';
    case 'with_fee':
      return 'Possible avec frais';
    case 'non_modifiable':
      return 'Non modifiable / non remboursable';
    case 'unknown':
      return 'Inconnu (non communiqué)';
  }
}

export function formatTimetableStateFr(state: TimetableState, delayMinutes: number | null): string {
  switch (state) {
    case 'scheduled':
      return 'Prévu à l’heure';
    case 'estimated':
      return delayMinutes && delayMinutes > 0
        ? `Estimé (+${delayMinutes} min)`
        : 'Horaire estimé';
    case 'actual':
      return 'Confirmé (effectif)';
    case 'cancelled':
      return 'Supprimé';
    case 'unknown':
      return 'État inconnu';
  }
}

export function formatBookingStateFr(state: BookingState): string {
  const map: Record<BookingState, string> = {
    offer_selected: 'Offre sélectionnée',
    revalidation_pending: 'Revalidation en cours',
    reservation_pending: 'Placement en cours',
    reservation_held: 'Place retenue',
    payment_pending: 'Paiement en attente',
    payment_confirmed: 'Paiement confirmé',
    booking_confirmation_pending: 'Confirmation en attente',
    booking_confirmed: 'Réservation confirmée',
    ticket_issuance_pending: 'Émission en cours',
    ticket_issued: 'Billet émis (spécimen)',
    failed: 'Échec',
    reconciliation_required: 'Réconciliation requise',
  };
  return map[state];
}

export function formatRefundStateFr(state: RefundState): string {
  const map: Record<RefundState, string> = {
    requested: 'Demande enregistrée',
    under_review: 'En cours de vérification',
    approved: 'Remboursement approuvé',
    credited: 'Crédité (simulé)',
    rejected: 'Refusé',
  };
  return map[state];
}

export function formatPassengerSummaryFr(adults: number, youths: number, seniors: number, travelClass: '1' | '2'): string {
  const parts: string[] = [];
  if (adults > 0) parts.push(`${adults} adulte${adults > 1 ? 's' : ''}`);
  if (youths > 0) parts.push(`${youths} jeune${youths > 1 ? 's' : ''}`);
  if (seniors > 0) parts.push(`${seniors} senior${seniors > 1 ? 's' : ''}`);
  const paxText = parts.length > 0 ? parts.join(', ') : '1 adulte';
  const classText = travelClass === '1' ? '1re classe' : '2de classe';
  return `${paxText} · ${classText}`;
}
