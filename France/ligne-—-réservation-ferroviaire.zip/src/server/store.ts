import crypto from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';
import type {
  AuditEntry,
  BookingRecord,
  FareOffer,
  SavedItinerary,
  SimulationFlags,
  SupportCase,
  UserSession,
} from '../shared/models';

export interface StoredUser {
  user_id: string;
  email: string;
  display_name: string;
  role: 'traveler' | 'admin';
  password_hash: string;
  created_at: string;
}

export interface StoreSchema {
  users: StoredUser[];
  admin_claimed_hash: string | null;
  bookings: BookingRecord[];
  saved_itineraries: SavedItinerary[];
  support_cases: SupportCase[];
  audit_logs: AuditEntry[];
  idempotency_records: Record<string, { booking_id: string; response_json: string; created_at: string }>;
  processed_payment_events: string[];
  fixture_price_overrides: Record<string, number>;
  fixture_unavailable_templates: string[];
  simulation: SimulationFlags;
}

const DATA_DIR = path.resolve(process.cwd(), '.ligne-data');
const STORE_PATH = path.join(DATA_DIR, 'store.json');

const SESSION_SECRET =
  process.env['SESSION_SECRET'] || crypto.randomBytes(32).toString('hex');

export function hashPassword(password: string): string {
  const salt = crypto.randomBytes(16).toString('hex');
  const derived = crypto.scryptSync(password, salt, 64).toString('hex');
  return `${salt}:${derived}`;
}

export function verifyPassword(password: string, stored: string): boolean {
  const parts = stored.split(':');
  if (parts.length !== 2) return false;
  const [salt, keyHex] = parts;
  const derived = crypto.scryptSync(password, salt, 64);
  const storedBuf = Buffer.from(keyHex, 'hex');
  if (derived.length !== storedBuf.length) return false;
  return crypto.timingSafeEqual(derived, storedBuf);
}

export function signSessionToken(session: UserSession): string {
  const payload = {
    ...session,
    exp: Date.now() + 1000 * 60 * 60 * 12,
  };
  const encoded = Buffer.from(JSON.stringify(payload), 'utf8').toString('base64url');
  const sig = crypto
    .createHmac('sha256', SESSION_SECRET)
    .update(encoded)
    .digest('base64url');
  return `${encoded}.${sig}`;
}

export function verifySessionToken(token: string | undefined | null): UserSession | null {
  if (!token) return null;
  const parts = token.split('.');
  if (parts.length !== 2) return null;
  const [encoded, sig] = parts;
  const expectedSig = crypto
    .createHmac('sha256', SESSION_SECRET)
    .update(encoded)
    .digest('base64url');
  const sigBuf = Buffer.from(sig);
  const expBuf = Buffer.from(expectedSig);
  if (sigBuf.length !== expBuf.length || !crypto.timingSafeEqual(sigBuf, expBuf)) {
    return null;
  }
  try {
    const decoded = JSON.parse(Buffer.from(encoded, 'base64url').toString('utf8')) as UserSession & {
      exp: number;
    };
    if (!decoded.exp || decoded.exp < Date.now()) {
      return null;
    }
    return {
      user_id: decoded.user_id,
      email: decoded.email,
      display_name: decoded.display_name,
      role: decoded.role,
    };
  } catch {
    return null;
  }
}

function createInitialStore(): StoreSchema {
  const nowIso = new Date().toISOString();
  const demoUserId = 'usr_demo_camille';

  const sampleUpcoming: BookingRecord = {
    booking_id: 'bkg_demo_upcoming_01',
    user_id: demoUserId,
    booking_reference: 'LG-482910',
    provider_order_ref: 'ORD-LD-482910',
    provider_id: 'rail_direct_demo',
    provider_name: 'Ligne Direct Démo',
    booking_mode: 'integrated_demo',
    state: 'ticket_issued',
    state_history: [
      { state: 'offer_selected', timestamp: '2026-11-18T10:12:00Z', note: 'Offre sélectionnée' },
      { state: 'revalidation_pending', timestamp: '2026-11-18T10:12:05Z', note: 'Vérification du tarif' },
      { state: 'reservation_held', timestamp: '2026-11-18T10:12:08Z', note: 'Place Voiture 4 · Place 62 retenue' },
      { state: 'payment_confirmed', timestamp: '2026-11-18T10:12:15Z', note: 'Paiement simulé validé (49,00 €)' },
      { state: 'booking_confirmed', timestamp: '2026-11-18T10:12:18Z', note: 'Confirmation fournisseur reçue' },
      { state: 'ticket_issued', timestamp: '2026-11-18T10:12:20Z', note: 'Billet spécimen émis' },
    ],
    outward_itinerary: {
      journey_reference: 'JRN-LD6601-20270618',
      origin_station: {
        id: 'FRPLY',
        name: 'Paris Gare de Lyon',
        city: 'Paris',
        country: 'FR',
        kind: 'individual_station',
        iana_timezone: 'Europe/Paris',
        aliases: [],
        accessibility: {
          level: 'accessible',
          step_free_platforms: true,
          assistance_desk: true,
          summary: 'Accès de plain-pied aux quais Grandes Lignes.',
          source: 'Registre Accessibilité Pôle Gares (données de démonstration)',
          updated_at: '2026-11-20T09:00:00Z',
        },
      },
      destination_station: {
        id: 'FRLPD',
        name: 'Lyon Part-Dieu',
        city: 'Lyon',
        country: 'FR',
        kind: 'individual_station',
        iana_timezone: 'Europe/Paris',
        aliases: [],
        accessibility: {
          level: 'accessible',
          step_free_platforms: true,
          assistance_desk: true,
          summary: 'Ascenseurs vers toutes les voies.',
          source: 'Registre Accessibilité Pôle Gares (données de démonstration)',
          updated_at: '2026-11-20T09:00:00Z',
        },
      },
      departure_iso: '2027-06-18T06:00:00.000Z',
      arrival_iso: '2027-06-18T08:00:00.000Z',
      departure_local_label: '08:00',
      arrival_local_label: '10:00',
      departure_tz: 'Europe/Paris',
      arrival_tz: 'Europe/Paris',
      day_offset: 0,
      total_duration_minutes: 120,
      changes_count: 0,
      operators: ['Ligne Direct Grande Vitesse'],
      segments: [],
      disruption_summary: {
        state: 'scheduled',
        delay_minutes: 0,
        message: 'Circulation prévue à l’heure.',
        source: 'Bulletin d’exploitation Ligne Direct (démo)',
        updated_at: '2026-11-20T09:00:00Z',
      },
    },
    outward_offer: {
      offer_id: 'OFR-DEMO-SEED-01',
      provider_id: 'rail_direct_demo',
      provider_name: 'Ligne Direct Démo',
      booking_mode: 'integrated_demo',
      journey_reference: 'JRN-LD6601-20270618',
      passenger_composition: { adults: 1, youths: 0, seniors: 0 },
      discount_cards_applied: [],
      travel_class: '2',
      ticket_product: 'Tarif Standard',
      included_services: ['Bagage inclus', 'Prise électrique individuelle'],
      train_binding: 'train_specific',
      route_or_operator_restrictions: 'Valable uniquement sur le train LD 6601.',
      change_conditions: {
        status: 'with_fee',
        summary: 'Échangeable jusqu’à 30 min avant départ (frais 19 €).',
        fee_cents: 1900,
        deadline_description: '30 minutes avant le départ',
      },
      refund_conditions: {
        status: 'with_fee',
        summary: 'Remboursable avec retenue de 19 € jusqu’à 24 h avant le départ.',
        fee_cents: 1900,
        deadline_description: '24 heures avant le départ',
      },
      mandatory_price_components: [
        { code: 'BASE_RAIL', label: 'Tarif ferroviaire aller (1 adulte)', amount_cents: 4900, mandatory: true },
      ],
      base_fare_cents: 4900,
      discount_cents: 0,
      total_known_cents: 4900,
      has_unknown_mandatory_fees: false,
      currency: 'EUR',
      quoted_at: '2026-11-18T10:11:00Z',
      expires_at: '2026-11-18T10:26:00Z',
      required_passenger_fields: ['first_name', 'last_name'],
      available_seats: 38,
    },
    return_itinerary: null,
    return_offer: null,
    passengers: [{ first_name: 'Camille', last_name: 'Laurent', category: 'adult' }],
    contact_email: 'voyageur@ligne.demo',
    contact_phone: '+33 6 12 34 56 78',
    optional_extras: [],
    base_total_cents: 4900,
    mandatory_fees_cents: 0,
    discount_total_cents: 0,
    extras_total_cents: 0,
    total_paid_cents: 4900,
    currency: 'EUR',
    seat_reservations: [
      {
        reservation_id: 'RES-DEMO-01',
        provider_id: 'rail_direct_demo',
        journey_reference: 'JRN-LD6601-20270618',
        coach: 'Voiture 4',
        seat_numbers: ['Place 62 (Fenêtre)'],
        held_until: '2026-11-18T10:30:00Z',
        status: 'confirmed',
      },
    ],
    payment: {
      payment_id: 'PAY-DEMO-01',
      idempotency_key: 'idem-seed-01',
      booking_id: 'bkg_demo_upcoming_01',
      amount_cents: 4900,
      currency: 'EUR',
      method_label: 'Carte de démonstration',
      masked_reference: '•••• 4242',
      state: 'confirmed',
      provider_event_ids: ['evt_seed_01'],
      created_at: '2026-11-18T10:12:15Z',
      updated_at: '2026-11-18T10:12:15Z',
    },
    tickets: [
      {
        ticket_id: 'TKT-DEMO-01',
        booking_id: 'bkg_demo_upcoming_01',
        is_simulated: true,
        watermark_text: 'DÉMONSTRATION — NON VALABLE POUR VOYAGER',
        ticket_number: 'SPECIMEN-LG-482910',
        passenger_names: ['Camille Laurent'],
        travel_class: '2',
        ticket_product: 'Tarif Standard',
        issued_at: '2026-11-18T10:12:20Z',
        document_url: '/api/bookings/bkg_demo_upcoming_01/ticket',
      },
    ],
    refunds: [],
    assistance_requests: [],
    cancellation_status: 'active',
    created_at: '2026-11-18T10:12:00Z',
    updated_at: '2026-11-18T10:12:20Z',
  };

  const samplePast: BookingRecord = {
    ...sampleUpcoming,
    booking_id: 'bkg_demo_past_01',
    booking_reference: 'LG-193402',
    provider_order_ref: 'ORD-LD-193402',
    outward_itinerary: {
      ...sampleUpcoming.outward_itinerary,
      journey_reference: 'JRN-LD8511-20260912',
      departure_iso: '2026-09-12T06:42:00.000Z',
      arrival_iso: '2026-09-12T08:46:00.000Z',
      departure_local_label: '08:42',
      arrival_local_label: '10:46',
      total_duration_minutes: 124,
      operators: ['Ligne Direct Atlantique'],
    },
    total_paid_cents: 5400,
    base_total_cents: 5400,
    tickets: [
      {
        ...sampleUpcoming.tickets[0],
        ticket_id: 'TKT-DEMO-PAST-01',
        booking_id: 'bkg_demo_past_01',
        ticket_number: 'SPECIMEN-LG-193402',
        document_url: '/api/bookings/bkg_demo_past_01/ticket',
      },
    ],
    created_at: '2026-09-01T14:00:00Z',
    updated_at: '2026-09-01T14:01:00Z',
  };

  return {
    users: [
      {
        user_id: demoUserId,
        email: 'voyageur@ligne.demo',
        display_name: 'Camille Laurent',
        role: 'traveler',
        // Scrypt hash only for explicit demo sign-in flow; demo account signs in via /api/auth/demo-traveler
        password_hash: '',
        created_at: nowIso,
      },
    ],
    admin_claimed_hash: null,
    bookings: [sampleUpcoming, samplePast],
    saved_itineraries: [],
    support_cases: [
      {
        case_id: 'CAS-901',
        booking_id: 'bkg_demo_upcoming_01',
        booking_reference: 'LG-482910',
        user_email: 'voyageur@ligne.demo',
        category: 'assistance',
        summary: 'Information demandée sur l’accès ascenseur Hall 1 Paris Gare de Lyon.',
        status: 'resolved',
        created_at: '2026-11-19T08:30:00Z',
        updated_at: '2026-11-19T09:10:00Z',
      },
    ],
    audit_logs: [
      {
        audit_id: 'AUD-001',
        actor: 'system',
        action: 'STORE_INITIALIZED',
        target_type: 'system',
        target_id: 'ligne_demo',
        detail: 'Initialisation du référentiel de démonstration LIGNE.',
        timestamp: nowIso,
      },
    ],
    idempotency_records: {},
    processed_payment_events: ['evt_seed_01'],
    fixture_price_overrides: {},
    fixture_unavailable_templates: [],
    simulation: {
      timeout_provider_id: null,
      partial_results_mode: false,
      force_expired_offer: false,
      force_price_change_cents: 0,
      force_unavailable_inventory: false,
      simulate_duplicate_payment_event: false,
      force_uncertain_booking_outcome: false,
    },
  };
}

class StoreService {
  private data: StoreSchema;
  // Ephemeral offer quote cache so offer revalidation & expiry can be enforced authoritatively on server
  private offerCache = new Map<string, { offer: FareOffer; template_id: string }>();

  constructor() {
    this.data = this.load();
  }

  private load(): StoreSchema {
    try {
      if (fs.existsSync(STORE_PATH)) {
        const raw = fs.readFileSync(STORE_PATH, 'utf8');
        return JSON.parse(raw) as StoreSchema;
      }
    } catch {
      // Fallback to fresh store if corrupted
    }
    const fresh = createInitialStore();
    this.persist(fresh);
    return fresh;
  }

  private persist(schema: StoreSchema): void {
    fs.mkdirSync(DATA_DIR, { recursive: true });
    const tmp = `${STORE_PATH}.tmp`;
    fs.writeFileSync(tmp, JSON.stringify(schema, null, 2), 'utf8');
    fs.renameSync(tmp, STORE_PATH);
  }

  get state(): StoreSchema {
    return this.data;
  }

  save(): void {
    this.persist(this.data);
  }

  cacheOffer(offer: FareOffer, templateId: string): void {
    this.offerCache.set(offer.offer_id, { offer, template_id: templateId });
  }

  getCachedOffer(offerId: string): { offer: FareOffer; template_id: string } | undefined {
    return this.offerCache.get(offerId);
  }

  addAudit(actor: string, action: string, targetType: string, targetId: string, detail: string): void {
    this.data.audit_logs.unshift({
      audit_id: `AUD-${crypto.randomBytes(4).toString('hex').toUpperCase()}`,
      actor,
      action,
      target_type: targetType,
      target_id: targetId,
      detail,
      timestamp: new Date().toISOString(),
    });
    if (this.data.audit_logs.length > 250) {
      this.data.audit_logs = this.data.audit_logs.slice(0, 250);
    }
    this.save();
  }
}

export const store = new StoreService();
