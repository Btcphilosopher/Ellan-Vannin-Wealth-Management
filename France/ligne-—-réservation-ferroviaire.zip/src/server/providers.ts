import crypto from 'node:crypto';
import type {
  BookingMode,
  DiscountCardId,
  FareOffer,
  JourneyItinerary,
  JourneySearchResultItem,
  PassengerComposition,
  PassengerDetailInput,
  PriceComponent,
  ProviderCapabilities,
  RevalidationResult,
  SeatReservation,
  StationNode,
  TravelClass,
} from '../shared/models';
import {
  DISCOUNT_CARDS,
  FIXTURE_JOURNEYS,
  type FixtureJourneyTemplate,
  STATION_MAP,
  STATIONS,
} from './fixtures';
import { store } from './store';
import { formatLocalTime, zonedWallTimeToUtc } from './timezone';

export interface SearchQueryInput {
  from_station_id: string;
  to_station_id: string;
  date: string;
  time: string;
  adults: number;
  youths: number;
  seniors: number;
  travel_class: TravelClass;
  discount_cards: DiscountCardId[];
}

export interface ProviderBookingRequest {
  offer: FareOffer;
  passengers: PassengerDetailInput[];
  provider_order_ref: string;
}

export interface ProviderBookingOutcome {
  status: 'confirmed' | 'uncertain_timeout' | 'unavailable';
  seat_reservation: SeatReservation | null;
  message: string;
}

export interface RailProviderAdapter {
  readonly provider_id: 'rail_direct_demo' | 'horizon_handoff';
  readonly provider_name: string;
  readonly booking_mode: BookingMode;
  readonly capabilities: ProviderCapabilities;

  lookupStations(query: string): StationNode[];
  searchJourneys(query: SearchQueryInput): Promise<JourneySearchResultItem[]>;
  revalidateOffer(offerId: string, providedOffer?: FareOffer): Promise<RevalidationResult>;
  createReservationAndConfirm?(req: ProviderBookingRequest): Promise<ProviderBookingOutcome>;
  lookupBookingStatus?(providerOrderRef: string): Promise<'confirmed' | 'pending' | 'failed'>;
  requestCancellation?(providerOrderRef: string, amountCents: number): Promise<{ penalty_cents: number; accepted: boolean }>;
  buildSellerHandoffUrl?(offer: FareOffer): string;
}

export const ALLOWED_SELLER_ORIGINS = new Set<string>([
  'https://horizon-rail-demo.ligne.example',
  'https://billets-demo.ligne.example',
]);

export function isAllowlistedSellerUrl(rawUrl: string): boolean {
  try {
    const parsed = new URL(rawUrl);
    if (parsed.protocol !== 'https:') return false;
    return ALLOWED_SELLER_ORIGINS.has(parsed.origin);
  } catch {
    return false;
  }
}

function resolveMatchingStationIds(stationId: string): Set<string> {
  const station = STATION_MAP.get(stationId);
  if (!station) return new Set();
  if (station.kind === 'city_group' && station.child_station_ids) {
    return new Set(station.child_station_ids);
  }
  return new Set([station.id]);
}

function buildOfferForTemplate(
  tpl: FixtureJourneyTemplate,
  query: SearchQueryInput,
  journeyRef: string,
  providerName: string,
  bookingMode: BookingMode,
): FareOffer {
  const totalPax = query.adults + query.youths + query.seniors;
  const overrideCents = store.state.fixture_price_overrides[tpl.template_id];
  const baseUnitCents =
    overrideCents ??
    (query.travel_class === '1' ? tpl.base_first_class_cents : tpl.base_second_class_cents);

  const rawBaseTotal = baseUnitCents * totalPax;

  // Apply eligible discount card reduction
  let discountCents = 0;
  const appliedCards: DiscountCardId[] = [];
  for (const cardId of query.discount_cards) {
    const meta = DISCOUNT_CARDS.find((c) => c.id === cardId);
    if (!meta) continue;
    let eligibleCount = 0;
    if (meta.eligible_categories.includes('adult')) eligibleCount += query.adults;
    if (meta.eligible_categories.includes('youth')) eligibleCount += query.youths;
    if (meta.eligible_categories.includes('senior')) eligibleCount += query.seniors;
    if (eligibleCount > 0) {
      appliedCards.push(cardId);
      const cardDiscount = Math.round(baseUnitCents * eligibleCount * meta.discount_rate);
      discountCents = Math.max(discountCents, cardDiscount);
    }
  }

  // Youth & senior illustrative reduction if no card applied
  if (appliedCards.length === 0) {
    discountCents += Math.round(baseUnitCents * query.youths * 0.25);
    discountCents += Math.round(baseUnitCents * query.seniors * 0.15);
  }

  const netFareCents = Math.max(1200 * totalPax, rawBaseTotal - discountCents);

  const components: PriceComponent[] = [
    {
      code: 'RAIL_FARE',
      label: `Billet ferroviaire (${totalPax} voyageur${totalPax > 1 ? 's' : ''})`,
      amount_cents: netFareCents,
      mandatory: true,
    },
  ];

  if (tpl.mandatory_fee_cents && tpl.mandatory_fee_cents > 0) {
    components.push({
      code: 'BOOKING_FEE',
      label: 'Frais de distribution',
      amount_cents: tpl.mandatory_fee_cents,
      mandatory: true,
    });
  }

  if (tpl.has_unknown_mandatory_fees) {
    components.push({
      code: 'UNKNOWN_CARRIER_FEE',
      label: 'Supplément de réservation transporteur (montant non transmis)',
      amount_cents: null,
      mandatory: true,
      unknown_amount: true,
    });
  }

  const knownMandatoryTotal = components.reduce(
    (sum, c) => sum + (c.amount_cents ?? 0),
    0,
  );

  const quotedAt = new Date();
  const expiresAt = new Date(quotedAt.getTime() + 15 * 60 * 1000);
  const comp: PassengerComposition = {
    adults: query.adults,
    youths: query.youths,
    seniors: query.seniors,
  };

  const requiredFields: FareOffer['required_passenger_fields'] = ['first_name', 'last_name'];
  if (query.youths > 0 || query.seniors > 0 || appliedCards.length > 0) {
    requiredFields.push('birth_date');
  }
  if (appliedCards.length > 0) {
    requiredFields.push('discount_card_number');
  }

  const offerId = `OFR-${tpl.template_id}-${query.date}-C${query.travel_class}-${crypto
    .randomBytes(3)
    .toString('hex')
    .toUpperCase()}`;

  const offer: FareOffer = {
    offer_id: offerId,
    provider_id: tpl.provider_id,
    provider_name: providerName,
    booking_mode: bookingMode,
    journey_reference: journeyRef,
    passenger_composition: comp,
    discount_cards_applied: appliedCards,
    travel_class: query.travel_class,
    ticket_product: tpl.ticket_product,
    included_services: tpl.included_services,
    train_binding: tpl.train_binding,
    route_or_operator_restrictions: tpl.route_restrictions,
    change_conditions: {
      status: tpl.change_status,
      summary: tpl.change_summary,
      fee_cents: tpl.change_fee_cents,
      deadline_description: tpl.change_status === 'unknown' ? null : 'Avant départ',
    },
    refund_conditions: {
      status: tpl.refund_status,
      summary: tpl.refund_summary,
      fee_cents: tpl.refund_fee_cents,
      deadline_description: tpl.refund_status === 'unknown' ? null : 'Avant départ',
    },
    mandatory_price_components: components,
    base_fare_cents: rawBaseTotal,
    discount_cents: discountCents,
    total_known_cents: knownMandatoryTotal,
    has_unknown_mandatory_fees: Boolean(tpl.has_unknown_mandatory_fees),
    currency: 'EUR',
    quoted_at: quotedAt.toISOString(),
    expires_at: expiresAt.toISOString(),
    required_passenger_fields: requiredFields,
    available_seats: store.state.fixture_unavailable_templates.includes(tpl.template_id)
      ? 0
      : 42,
  };

  store.cacheOffer(offer, tpl.template_id);
  return offer;
}

function buildItinerary(tpl: FixtureJourneyTemplate, dateStr: string): JourneyItinerary {
  const segments = tpl.segments.map((seg, idx) => {
    const origin = STATION_MAP.get(seg.origin_station_id)!;
    const dest = STATION_MAP.get(seg.destination_station_id)!;
    const depUtc = zonedWallTimeToUtc(dateStr, seg.dep_time, origin.iana_timezone, 0);
    const arrUtc = zonedWallTimeToUtc(
      dateStr,
      seg.arr_time,
      dest.iana_timezone,
      seg.day_offset,
    );
    const durationMin = Math.max(15, Math.round((arrUtc.getTime() - depUtc.getTime()) / 60000));

    return {
      segment_id: `${tpl.template_id}-SEG-${idx + 1}`,
      service_id: `SVC-${seg.train_number.replace(/\s+/g, '')}`,
      train_number: seg.train_number,
      operator_name: seg.operator_name,
      service_category: seg.service_category,
      origin_station: origin,
      destination_station: dest,
      departure_iso: depUtc.toISOString(),
      arrival_iso: arrUtc.toISOString(),
      departure_local_label: formatLocalTime(depUtc.toISOString(), origin.iana_timezone),
      arrival_local_label: formatLocalTime(arrUtc.toISOString(), dest.iana_timezone),
      departure_tz: origin.iana_timezone,
      arrival_tz: dest.iana_timezone,
      day_offset: seg.day_offset,
      duration_minutes: durationMin,
      disruption: {
        state: seg.disruption?.state ?? 'scheduled',
        delay_minutes: seg.disruption?.delay_minutes ?? 0,
        message: seg.disruption?.message ?? 'Circulation prévue à l’heure.',
        source: seg.disruption?.source ?? 'Bulletin d’exploitation Ligne Direct (démo)',
        updated_at: new Date().toISOString(),
      },
    };
  });

  const firstSeg = segments[0];
  const lastSeg = segments[segments.length - 1];
  const totalDuration = Math.round(
    (new Date(lastSeg.arrival_iso).getTime() - new Date(firstSeg.departure_iso).getTime()) / 60000,
  );
  const operators = Array.from(new Set(segments.map((s) => s.operator_name)));

  return {
    journey_reference: `JRN-${tpl.template_id}-${dateStr.replace(/-/g, '')}`,
    origin_station: firstSeg.origin_station,
    destination_station: lastSeg.destination_station,
    departure_iso: firstSeg.departure_iso,
    arrival_iso: lastSeg.arrival_iso,
    departure_local_label: firstSeg.departure_local_label,
    arrival_local_label: lastSeg.arrival_local_label,
    departure_tz: firstSeg.departure_tz,
    arrival_tz: lastSeg.arrival_tz,
    day_offset: lastSeg.day_offset,
    total_duration_minutes: totalDuration,
    changes_count: Math.max(0, segments.length - 1),
    operators,
    segments,
    disruption_summary: segments.find((s) => s.disruption.state !== 'scheduled')?.disruption ??
      firstSeg.disruption,
  };
}

class BaseDemoAdapter implements RailProviderAdapter {
  constructor(
    public readonly provider_id: 'rail_direct_demo' | 'horizon_handoff',
    public readonly provider_name: string,
    public readonly booking_mode: BookingMode,
    public readonly capabilities: ProviderCapabilities,
  ) {}

  lookupStations(query: string): StationNode[] {
    const q = query.trim().toLowerCase();
    if (!q) return STATIONS.slice(0, 8);
    return STATIONS.filter(
      (s) =>
        s.name.toLowerCase().includes(q) ||
        s.city.toLowerCase().includes(q) ||
        s.id.toLowerCase().includes(q) ||
        s.aliases.some((a) => a.includes(q)),
    );
  }

  async searchJourneys(query: SearchQueryInput): Promise<JourneySearchResultItem[]> {
    const sim = store.state.simulation;
    if (sim.timeout_provider_id === this.provider_id) {
      throw new Error(`TIMEOUT_PROVIDER:${this.provider_id}`);
    }
    if (sim.partial_results_mode && this.provider_id === 'horizon_handoff') {
      throw new Error(`TIMEOUT_PROVIDER:${this.provider_id}`);
    }

    const allowedOrigins = resolveMatchingStationIds(query.from_station_id);
    const allowedDests = resolveMatchingStationIds(query.to_station_id);

    const matchingTemplates = FIXTURE_JOURNEYS.filter((tpl) => {
      if (tpl.provider_id !== this.provider_id) return false;
      const firstOrig = tpl.segments[0].origin_station_id;
      const lastDest = tpl.segments[tpl.segments.length - 1].destination_station_id;
      return allowedOrigins.has(firstOrig) && allowedDests.has(lastDest);
    });

    const results: JourneySearchResultItem[] = [];
    for (const tpl of matchingTemplates) {
      const itinerary = buildItinerary(tpl, query.date);
      if (query.time && itinerary.departure_local_label < query.time) {
        // Keep early morning results for exact showcase unless time is far later
        if (query.time > '10:00') continue;
      }
      const offer = buildOfferForTemplate(
        tpl,
        query,
        itinerary.journey_reference,
        this.provider_name,
        this.booking_mode,
      );
      results.push({
        itinerary,
        offers: [offer],
        lowest_known_offer_id: offer.has_unknown_mandatory_fees ? null : offer.offer_id,
      });
    }

    results.sort(
      (a, b) =>
        new Date(a.itinerary.departure_iso).getTime() -
        new Date(b.itinerary.departure_iso).getTime(),
    );
    return results;
  }

  async revalidateOffer(offerId: string, providedOffer?: FareOffer): Promise<RevalidationResult> {
    const cached = store.getCachedOffer(offerId);
    const baseOffer = cached?.offer ?? providedOffer;
    if (!baseOffer) {
      throw new Error('OFFER_NOT_FOUND');
    }

    const sim = store.state.simulation;
    const now = new Date();
    const isActuallyExpired = new Date(baseOffer.expires_at).getTime() < now.getTime();

    if (sim.force_unavailable_inventory || (cached && store.state.fixture_unavailable_templates.includes(cached.template_id))) {
      return {
        offer_id: offerId,
        status: 'unavailable',
        previous_total_cents: baseOffer.total_known_cents,
        new_total_cents: baseOffer.total_known_cents,
        message: 'Inventaire épuisé sur ce train au tarif sélectionné.',
        offer: { ...baseOffer, available_seats: 0 },
        revalidated_at: now.toISOString(),
      };
    }

    if (sim.force_expired_offer || isActuallyExpired) {
      const refreshedOffer: FareOffer = {
        ...baseOffer,
        quoted_at: now.toISOString(),
        expires_at: new Date(now.getTime() + 15 * 60 * 1000).toISOString(),
      };
      if (cached) store.cacheOffer(refreshedOffer, cached.template_id);
      return {
        offer_id: offerId,
        status: 'expired',
        previous_total_cents: baseOffer.total_known_cents,
        new_total_cents: refreshedOffer.total_known_cents,
        message: 'Le devis initial a expiré. Un nouveau devis actualisé vient d’être vérifié.',
        offer: refreshedOffer,
        revalidated_at: now.toISOString(),
      };
    }

    const deltaCents = sim.force_price_change_cents || 0;
    if (deltaCents !== 0) {
      const newTotal = Math.max(1000, baseOffer.total_known_cents + deltaCents);
      const updatedOffer: FareOffer = {
        ...baseOffer,
        total_known_cents: newTotal,
        base_fare_cents: baseOffer.base_fare_cents + deltaCents,
        quoted_at: now.toISOString(),
        expires_at: new Date(now.getTime() + 15 * 60 * 1000).toISOString(),
      };
      if (cached) store.cacheOffer(updatedOffer, cached.template_id);
      return {
        offer_id: offerId,
        status: 'price_changed',
        previous_total_cents: baseOffer.total_known_cents,
        new_total_cents: newTotal,
        message: `Le tarif a évolué lors de la vérification (+${(deltaCents / 100).toFixed(2).replace('.', ',')} €). Veuillez confirmer ce nouveau montant.`,
        offer: updatedOffer,
        revalidated_at: now.toISOString(),
      };
    }

    return {
      offer_id: offerId,
      status: 'unchanged',
      previous_total_cents: baseOffer.total_known_cents,
      new_total_cents: baseOffer.total_known_cents,
      message: 'Tarif et disponibilité confirmés à l’identique.',
      offer: baseOffer,
      revalidated_at: now.toISOString(),
    };
  }
}

export class LigneDirectDemoAdapter extends BaseDemoAdapter {
  constructor() {
    super('rail_direct_demo', 'Ligne Direct Démo', 'integrated_demo', {
      station_lookup: true,
      journey_search: true,
      fare_search: true,
      offer_revalidation: true,
      integrated_booking: true,
      booking_status_lookup: true,
      ticket_retrieval: true,
      cancellation_refund: true,
      seller_handoff: false,
    });
  }

  async createReservationAndConfirm(
    req: ProviderBookingRequest,
  ): Promise<ProviderBookingOutcome> {
    const sim = store.state.simulation;
    if (sim.force_unavailable_inventory) {
      return {
        status: 'unavailable',
        seat_reservation: null,
        message: 'Inventaire épuisé au moment du placement.',
      };
    }

    const seats = req.passengers.map((_, i) => `Place ${61 + i} (${i % 2 === 0 ? 'Fenêtre' : 'Couloir'})`);
    const reservation: SeatReservation = {
      reservation_id: `RES-${crypto.randomBytes(3).toString('hex').toUpperCase()}`,
      provider_id: this.provider_id,
      journey_reference: req.offer.journey_reference,
      coach: 'Voiture 4',
      seat_numbers: seats,
      held_until: new Date(Date.now() + 15 * 60 * 1000).toISOString(),
      status: sim.force_uncertain_booking_outcome ? 'held' : 'confirmed',
    };

    if (sim.force_uncertain_booking_outcome) {
      return {
        status: 'uncertain_timeout',
        seat_reservation: reservation,
        message:
          'Le fournisseur n’a pas répondu dans le délai imparti après le paiement. Réconciliation automatique planifiée.',
      };
    }

    return {
      status: 'confirmed',
      seat_reservation: reservation,
      message: 'Réservation confirmée par Ligne Direct Démo.',
    };
  }

  async lookupBookingStatus(
    providerOrderRef: string,
  ): Promise<'confirmed' | 'pending' | 'failed'> {
    if (!providerOrderRef.startsWith('ORD-')) return 'failed';
    return 'confirmed';
  }

  async requestCancellation(
    _providerOrderRef: string,
    amountCents: number,
  ): Promise<{ penalty_cents: number; accepted: boolean }> {
    return {
      accepted: true,
      penalty_cents: Math.min(amountCents, 1900),
    };
  }
}

export class HorizonHandoffAdapter extends BaseDemoAdapter {
  constructor() {
    super('horizon_handoff', 'Horizon Distribution', 'seller_handoff', {
      station_lookup: true,
      journey_search: true,
      fare_search: true,
      offer_revalidation: true,
      integrated_booking: false,
      booking_status_lookup: false,
      ticket_retrieval: false,
      cancellation_refund: false,
      seller_handoff: true,
    });
  }

  buildSellerHandoffUrl(offer: FareOffer): string {
    const candidate = `https://horizon-rail-demo.ligne.example/handoff?offer=${encodeURIComponent(
      offer.offer_id,
    )}&journey=${encodeURIComponent(offer.journey_reference)}`;
    if (!isAllowlistedSellerUrl(candidate)) {
      throw new Error('SELLER_URL_NOT_ALLOWLISTED');
    }
    return candidate;
  }
}

export const PROVIDERS: Record<'rail_direct_demo' | 'horizon_handoff', RailProviderAdapter> = {
  rail_direct_demo: new LigneDirectDemoAdapter(),
  horizon_handoff: new HorizonHandoffAdapter(),
};
