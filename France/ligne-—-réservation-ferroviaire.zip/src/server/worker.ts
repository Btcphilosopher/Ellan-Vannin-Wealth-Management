import crypto from 'node:crypto';
import { PROVIDERS } from './providers';
import { store } from './store';

export interface ReconciliationSummary {
  checked: number;
  resolved: number;
  details: string[];
}

export async function runReconciliationPass(actor = 'worker:reconciliation'): Promise<ReconciliationSummary> {
  const pendingBookings = store.state.bookings.filter(
    (b) =>
      b.state === 'reconciliation_required' ||
      b.state === 'booking_confirmation_pending',
  );

  let resolved = 0;
  const details: string[] = [];

  for (const booking of pendingBookings) {
    const adapter = PROVIDERS[booking.provider_id as keyof typeof PROVIDERS];
    if (!adapter || !adapter.lookupBookingStatus) continue;

    // Always query provider using stable provider_order_ref to avoid duplicate bookings
    const outcome = await adapter.lookupBookingStatus(booking.provider_order_ref);
    const now = new Date().toISOString();

    if (outcome === 'confirmed') {
      booking.state = 'booking_confirmed';
      booking.state_history.push({
        state: 'booking_confirmed',
        timestamp: now,
        note: `Confirmé après interrogation fournisseur par référence stable (${booking.provider_order_ref}).`,
      });
      for (const res of booking.seat_reservations) {
        res.status = 'confirmed';
      }

      booking.state = 'ticket_issued';
      booking.state_history.push({
        state: 'ticket_issued',
        timestamp: now,
        note: 'Billet spécimen émis suite à la réconciliation.',
      });

      if (booking.tickets.length === 0) {
        booking.tickets.push({
          ticket_id: `TKT-${crypto.randomBytes(3).toString('hex').toUpperCase()}`,
          booking_id: booking.booking_id,
          is_simulated: true,
          watermark_text: 'DÉMONSTRATION — NON VALABLE POUR VOYAGER',
          ticket_number: `SPECIMEN-${booking.booking_reference}`,
          passenger_names: booking.passengers.map((p) => `${p.first_name} ${p.last_name}`),
          travel_class: booking.outward_offer.travel_class,
          ticket_product: booking.outward_offer.ticket_product,
          issued_at: now,
          document_url: `/api/bookings/${booking.booking_id}/ticket`,
        });
      }
      booking.updated_at = now;
      resolved += 1;
      details.push(`${booking.booking_reference} réconcilié -> ticket_issued`);
      store.addAudit(
        actor,
        'BOOKING_RECONCILED',
        'booking',
        booking.booking_id,
        `Référence ${booking.provider_order_ref} confirmée sans doublon.`,
      );
    }
  }

  if (resolved > 0) {
    store.save();
  }

  return {
    checked: pendingBookings.length,
    resolved,
    details,
  };
}

let workerStarted = false;

export function startReconciliationWorker(): void {
  if (workerStarted) return;
  workerStarted = true;
  const timer = setInterval(() => {
    void runReconciliationPass('worker:background');
  }, 15000);
  timer.unref?.();
}
