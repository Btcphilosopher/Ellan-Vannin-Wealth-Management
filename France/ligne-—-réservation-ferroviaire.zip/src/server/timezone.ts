/**
 * Converts a local calendar date (YYYY-MM-DD) + local wall-clock time (HH:MM)
 * in a given IANA time zone into an exact UTC Date, handling DST transitions accurately.
 */
export function zonedWallTimeToUtc(
  dateStr: string,
  timeStr: string,
  timeZone: string,
  dayOffset = 0,
): Date {
  const [year, month, day] = dateStr.split('-').map(Number);
  const [hour, minute] = timeStr.split(':').map(Number);

  // Start with a UTC guess at the target calendar components
  const baseUtcMs = Date.UTC(year, month - 1, day + dayOffset, hour, minute, 0, 0);

  const getOffsetMs = (utcMs: number): number => {
    const d = new Date(utcMs);
    const parts = new Intl.DateTimeFormat('en-US', {
      timeZone,
      year: 'numeric',
      month: '2-digit',
      day: '2-digit',
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit',
      hour12: false,
    }).formatToParts(d);

    const map: Record<string, number> = {};
    for (const p of parts) {
      if (p.type !== 'literal') {
        map[p.type] = Number(p.value);
      }
    }
    const h = map['hour'] === 24 ? 0 : map['hour'];
    const asUtc = Date.UTC(
      map['year'],
      map['month'] - 1,
      map['day'],
      h,
      map['minute'],
      map['second'],
    );
    return asUtc - utcMs;
  };

  const offset1 = getOffsetMs(baseUtcMs);
  const candidate = baseUtcMs - offset1;
  const offset2 = getOffsetMs(candidate);
  return new Date(baseUtcMs - offset2);
}

export function formatLocalTime(iso: string, timeZone: string): string {
  return new Intl.DateTimeFormat('fr-FR', {
    timeZone,
    hour: '2-digit',
    minute: '2-digit',
    hour12: false,
  })
    .format(new Date(iso))
    .replace(':', ':');
}

export function getLocalDateKey(iso: string, timeZone: string): string {
  const parts = new Intl.DateTimeFormat('en-CA', {
    timeZone,
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
  }).formatToParts(new Date(iso));
  const y = parts.find((p) => p.type === 'year')?.value ?? '2027';
  const m = parts.find((p) => p.type === 'month')?.value ?? '01';
  const d = parts.find((p) => p.type === 'day')?.value ?? '01';
  return `${y}-${m}-${d}`;
}

export function formatDurationFr(minutes: number): string {
  const h = Math.floor(minutes / 60);
  const m = minutes % 60;
  if (h === 0) return `${m} min`;
  if (m === 0) return `${h} h`;
  return `${h} h ${String(m).padStart(2, '0')}`;
}
