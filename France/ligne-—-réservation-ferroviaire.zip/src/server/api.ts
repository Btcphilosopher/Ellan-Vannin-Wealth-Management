import crypto from 'node:crypto';
import express, { type NextFunction, type Request, type Response } from 'express';
import type {
  BookingRecord,
  DiscountCardId,
  FareOffer,
  JourneyItinerary,
  OptionalExtraSelection,
  PassengerDetailInput,
  ProviderHealth,
  ProviderSearchNotice,
  RevalidationResult,
  TravelClass,
  UserSession,
} from '../shared/models';
import { DISCOUNT_CARDS, FIXTURE_JOURNEYS, STATION_MAP, STATIONS } from './fixtures';
import { isAllowlistedSellerUrl, PROVIDERS } from './providers';
import {
  hashPassword,
  signSessionToken,
  store,
  verifyPassword,
  verifySessionToken,
} from './store';
import { runReconciliationPass } from './worker';

interface AuthedRequest extends Request {
  session?: UserSession | null;
}

const rateBuckets = new Map<string, { count: number; resetAt: number }>();

function rateLimit(maxPerMinute: number) {
  return (req: Request, res: Response, next: NextFunction): void => {
    const key = `${req.ip || 'local'}:${req.baseUrl}`;
    const now = Date.now();
    const bucket = rateBuckets.get(key);
    if (!bucket || bucket.resetAt < now) {
      rateBuckets.set(key, { count: 1, resetAt: now + 60_000 });
      next();
      return;
    }
    if (bucket.count >= maxPerMinute) {
      res.status(429).json({
        error: 'Trop de requêtes. Veuillez patienter quelques instants.',
      });
      return;
    }
    bucket.count += 1;
    next();
  };
}

function parseCookies(cookieHeader: string | undefined): Record<string, string> {
  const out: Record<string, string> = {};
  if (!cookieHeader) return out;
  for (const part of cookieHeader.split(';')) {
    const idx = part.indexOf('=');
    if (idx > 0) {
      const k = part.slice(0, idx).trim();
      const v = part.slice(idx + 1).trim();
      out[k] = decodeURIComponent(v);
    }
  }
  return out;
}

function extractSession(req: Request): UserSession | null {
  const auth = req.headers.authorization;
  if (auth && auth.startsWith('Bearer ')) {
    const verified = verifySessionToken(auth.slice(7).trim());
    if (verified) return verified;
  }
  const cookies = parseCookies(req.headers.cookie);
  if (cookies['ligne_session']) {
    return verifySessionToken(cookies['ligne_session']);
  }
  return null;
}

function attachSession(req: AuthedRequest, _res: Response, next: NextFunction): void {
  req.session = extractSession(req);
  next();
}

function requireAuth(req: AuthedRequest, res: Response, next: NextFunction): void {
  if (!req.session) {
    res.status(401).json({ error: 'Authentification requise pour accéder à cet espace.' });
    return;
  }
  next();
}

function requireAdmin(req: AuthedRequest, res: Response, next: NextFunction): void {
  if (!req.session || req.session.role !== 'admin') {
    res.status(403).json({ error: 'Accès réservé aux administrateurs LIGNE.' });
    return;
  }
  next();
}

function setSessionCookie(req: Request, res: Response, token: string): void {
  const isHttps = req.secure || req.headers['x-forwarded-proto'] === 'https';
  res.cookie('ligne_session', token, {
    httpOnly: true,
    secure: isHttps,
    sameSite: isHttps ? 'none' : 'lax',
    path: '/',
    maxAge: 1000 * 60 * 60 * 12,
  });
}

function isValidIsoDate(str: string): boolean {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(str)) return false;
  const d = new Date(`${str}T12:00:00Z`);
  return !Number.isNaN(d.getTime());
}

export function createApiRouter(): express.Router {
  const router = express.Router();
  router.use(express.json({ limit: '512kb' }));
  router.use(attachSession);

  // Health
  router.get('/health', (_req, res) => {
    res.json({
      status: 'ok',
      service: 'LIGNE Prototype API',
      timestamp: new Date().toISOString(),
    });
  });

  // Stations lookup (individual stations, city groups, hubs, free text)
  router.get('/stations', (req, res) => {
    const q = String(req.query['q'] ?? '');
    const results = PROVIDERS.rail_direct_demo.lookupStations(q);
    res.json({ stations: results, discount_cards: DISCOUNT_CARDS });
  });

  // Journey search across providers
  router.get('/journeys/search', async (req, res) => {
    const fromId = String(req.query['from'] ?? 'FRPLY');
    const toId = String(req.query['to'] ?? 'FRLPD');
    const tripType = req.query['trip'] === 'oneway' ? 'oneway' : 'roundtrip';
    const outwardDate = String(req.query['out'] ?? '2027-06-18');
    const outwardTime = String(req.query['out_time'] ?? '00:00');
    const returnDate = req.query['ret'] ? String(req.query['ret']) : undefined;
    const returnTime = String(req.query['ret_time'] ?? '00:00');
    const adults = Math.max(0, Math.min(6, Number(req.query['adults'] ?? 1) || 0));
    const youths = Math.max(0, Math.min(6, Number(req.query['youths'] ?? 0) || 0));
    const seniors = Math.max(0, Math.min(6, Number(req.query['seniors'] ?? 0) || 0));
    const travelClass: TravelClass = req.query['class'] === '1' ? '1' : '2';
    const rawCards = String(req.query['cards'] ?? '')
      .split(',')
      .map((s) => s.trim())
      .filter(Boolean) as DiscountCardId[];

    const fromStation = STATION_MAP.get(fromId);
    const toStation = STATION_MAP.get(toId);
    if (!fromStation || !toStation) {
      res.status(400).json({ error: 'Identifiant de gare inconnu.' });
      return;
    }
    if (fromStation.id === toStation.id) {
      res.status(400).json({ error: 'La gare de départ et la gare d’arrivée doivent être distinctes.' });
      return;
    }
    if (!isValidIsoDate(outwardDate)) {
      res.status(400).json({ error: 'Date aller invalide.' });
      return;
    }
    if (outwardDate < '2026-01-01' || outwardDate > '2028-12-31') {
      res.status(400).json({
        error: "Date hors de l'horizon de réservation pris en charge (2026–2028).",
      });
      return;
    }
    if (tripType === 'roundtrip') {
      if (!returnDate || !isValidIsoDate(returnDate) || returnDate < outwardDate) {
        res.status(400).json({
          error: 'La date de retour doit être postérieure ou égale à la date aller.',
        });
        return;
      }
    }
    if (adults + youths + seniors === 0) {
      res.status(400).json({ error: 'Sélectionnez au moins un voyageur.' });
      return;
    }

    const providerList = [PROVIDERS.rail_direct_demo, PROVIDERS.horizon_handoff];
    const notices: ProviderSearchNotice[] = [];
    const outwardSettled = await Promise.allSettled(
      providerList.map((p) =>
        p.searchJourneys({
          from_station_id: fromId,
          to_station_id: toId,
          date: outwardDate,
          time: outwardTime,
          adults,
          youths,
          seniors,
          travel_class: travelClass,
          discount_cards: rawCards,
        }),
      ),
    );

    const outwardResults = [];
    let partialResults = false;

    for (let i = 0; i < providerList.length; i++) {
      const p = providerList[i];
      const settled = outwardSettled[i];
      if (settled.status === 'fulfilled') {
        outwardResults.push(...settled.value);
        notices.push({
          provider_id: p.provider_id,
          provider_name: p.provider_name,
          status: 'ok',
          message: `${settled.value.length} trajet(s) reçu(s)`,
          responded_at: new Date().toISOString(),
        });
      } else {
        partialResults = true;
        notices.push({
          provider_id: p.provider_id,
          provider_name: p.provider_name,
          status: 'timeout',
          message: 'Délai fournisseur dépassé — résultats partiels affichés.',
          responded_at: new Date().toISOString(),
        });
      }
    }

    outwardResults.sort(
      (a, b) =>
        new Date(a.itinerary.departure_iso).getTime() -
        new Date(b.itinerary.departure_iso).getTime(),
    );

    const returnResults = [];
    if (tripType === 'roundtrip' && returnDate) {
      const returnSettled = await Promise.allSettled(
        providerList.map((p) =>
          p.searchJourneys({
            from_station_id: toId,
            to_station_id: fromId,
            date: returnDate,
            time: returnTime,
            adults,
            youths,
            seniors,
            travel_class: travelClass,
            discount_cards: rawCards,
          }),
        ),
      );
      for (const settled of returnSettled) {
        if (settled.status === 'fulfilled') {
          returnResults.push(...settled.value);
        }
      }
      returnResults.sort(
        (a, b) =>
          new Date(a.itinerary.departure_iso).getTime() -
          new Date(b.itinerary.departure_iso).getTime(),
      );
    }

    res.json({
      search_id: `SRC-${crypto.randomBytes(4).toString('hex').toUpperCase()}`,
      query: {
        from_station_id: fromId,
        to_station_id: toId,
        trip_type: tripType,
        outward_date: outwardDate,
        outward_time: outwardTime,
        return_date: returnDate,
        return_time: returnTime,
        adults,
        youths,
        seniors,
        travel_class: travelClass,
        discount_cards: rawCards,
      },
      from_station: fromStation,
      to_station: toStation,
      outward_results: outwardResults,
      return_results: returnResults,
      provider_notices: notices,
      partial_results: partialResults,
      generated_at: new Date().toISOString(),
    });
  });

  // Offer revalidation (authoritative server check)
  router.post('/offers/revalidate', async (req, res) => {
    const body = req.body as { outward_offer?: FareOffer; return_offer?: FareOffer | null };
    if (!body?.outward_offer?.offer_id) {
      res.status(400).json({ error: 'Offre aller manquante.' });
      return;
    }

    try {
      const outAdapter =
        PROVIDERS[body.outward_offer.provider_id as keyof typeof PROVIDERS];
      if (!outAdapter) {
        res.status(400).json({ error: 'Fournisseur inconnu.' });
        return;
      }
      const outResult = await outAdapter.revalidateOffer(
        body.outward_offer.offer_id,
        body.outward_offer,
      );

      let retResult: RevalidationResult | null = null;
      if (body.return_offer?.offer_id) {
        const retAdapter =
          PROVIDERS[body.return_offer.provider_id as keyof typeof PROVIDERS];
        if (retAdapter) {
          retResult = await retAdapter.revalidateOffer(
            body.return_offer.offer_id,
            body.return_offer,
          );
        }
      }

      res.json({
        outward: outResult,
        return: retResult,
      });
    } catch (err) {
      res.status(404).json({
        error: err instanceof Error ? err.message : 'Offre introuvable.',
      });
    }
  });

  // Seller handoff preparation (Horizon Distribution)
  router.post('/handoff/prepare', async (req: AuthedRequest, res) => {
    const body = req.body as { offer?: FareOffer };
    if (!body?.offer?.offer_id) {
      res.status(400).json({ error: 'Offre requise pour préparer la redirection.' });
      return;
    }
    const adapter = PROVIDERS[body.offer.provider_id as keyof typeof PROVIDERS];
    if (!adapter || !adapter.capabilities.seller_handoff || !adapter.buildSellerHandoffUrl) {
      res.status(400).json({ error: 'Ce fournisseur ne supporte pas la redirection vendeur.' });
      return;
    }

    const reval = await adapter.revalidateOffer(body.offer.offer_id, body.offer);
    const redirectUrl = adapter.buildSellerHandoffUrl(reval.offer);
    if (!isAllowlistedSellerUrl(redirectUrl)) {
      res.status(403).json({ error: 'Destination de redirection non autorisée.' });
      return;
    }

    store.addAudit(
      req.session?.email ?? 'guest',
      'SELLER_HANDOFF_PREPARED',
      'offer',
      reval.offer.offer_id,
      `Redirection autorisée vers ${adapter.provider_name}`,
    );

    res.json({
      revalidation: reval,
      seller_name: adapter.provider_name,
      redirect_url: redirectUrl,
      notice:
        "LIGNE transfère cette sélection vers le vendeur partenaire agréé. LIGNE n'émet pas ce billet.",
    });
  });

  // Auth routes
  router.get('/auth/me', (req: AuthedRequest, res) => {
    res.json({ user: req.session ?? null });
  });

  router.post('/auth/demo-traveler', rateLimit(30), (req, res) => {
    const demoUser = store.state.users.find((u) => u.user_id === 'usr_demo_camille');
    if (!demoUser) {
      res.status(404).json({ error: 'Compte voyageur de démonstration introuvable.' });
      return;
    }
    const session: UserSession = {
      user_id: demoUser.user_id,
      email: demoUser.email,
      display_name: demoUser.display_name,
      role: 'traveler',
    };
    const token = signSessionToken(session);
    setSessionCookie(req, res, token);
    res.json({ user: session, token });
  });

  router.post('/auth/register', rateLimit(20), (req, res) => {
    const { email, password, display_name } = req.body as {
      email?: string;
      password?: string;
      display_name?: string;
    };
    if (!email || !email.includes('@') || !password || password.length < 8) {
      res.status(400).json({
        error: 'E-mail valide et mot de passe d’au moins 8 caractères requis.',
      });
      return;
    }
    const normalized = email.trim().toLowerCase();
    if (store.state.users.some((u) => u.email.toLowerCase() === normalized)) {
      res.status(409).json({ error: 'Un compte existe déjà avec cet e-mail.' });
      return;
    }
    const userId = `usr_${crypto.randomBytes(6).toString('hex')}`;
    const name = (display_name || normalized.split('@')[0]).trim().slice(0, 80);
    store.state.users.push({
      user_id: userId,
      email: normalized,
      display_name: name,
      role: 'traveler',
      password_hash: hashPassword(password),
      created_at: new Date().toISOString(),
    });
    store.save();

    const session: UserSession = {
      user_id: userId,
      email: normalized,
      display_name: name,
      role: 'traveler',
    };
    const token = signSessionToken(session);
    setSessionCookie(req, res, token);
    res.status(201).json({ user: session, token });
  });

  router.post('/auth/login', rateLimit(20), (req, res) => {
    const { email, password } = req.body as { email?: string; password?: string };
    if (!email || !password) {
      res.status(400).json({ error: 'E-mail et mot de passe requis.' });
      return;
    }
    const user = store.state.users.find(
      (u) => u.email.toLowerCase() === email.trim().toLowerCase(),
    );
    if (!user || !user.password_hash || !verifyPassword(password, user.password_hash)) {
      res.status(401).json({ error: 'Identifiants invalides.' });
      return;
    }
    const session: UserSession = {
      user_id: user.user_id,
      email: user.email,
      display_name: user.display_name,
      role: user.role,
    };
    const token = signSessionToken(session);
    setSessionCookie(req, res, token);
    res.json({ user: session, token });
  });

  router.post('/auth/logout', (req, res) => {
    res.clearCookie('ligne_session', { path: '/' });
    res.json({ ok: true });
  });

  // Integrated checkout with Idempotency-Key & explicit state transitions
  router.post('/bookings/checkout', rateLimit(30), async (req: AuthedRequest, res) => {
    const idempotencyKey =
      String(req.headers['idempotency-key'] ?? req.body?.idempotency_key ?? '').trim();
    if (!idempotencyKey) {
      res.status(400).json({ error: 'En-tête Idempotency-Key requis pour éviter les doubles débits.' });
      return;
    }

    // Check idempotency cache first
    const existingIdem = store.state.idempotency_records[idempotencyKey];
    if (existingIdem) {
      res.json(JSON.parse(existingIdem.response_json));
      return;
    }

    const body = req.body as {
      outward_itinerary: JourneyItinerary;
      outward_offer: FareOffer;
      return_itinerary?: JourneyItinerary | null;
      return_offer?: FareOffer | null;
      passengers: PassengerDetailInput[];
      contact_email: string;
      contact_phone: string;
      optional_extras?: OptionalExtraSelection[];
      payment_method_label?: string;
      accept_price_change?: boolean;
      accepted_conditions?: boolean;
    };

    if (!body.outward_offer || !body.outward_itinerary || !body.accepted_conditions) {
      res.status(400).json({
        error: 'Veuillez sélectionner un trajet et accepter les conditions tarifaires.',
      });
      return;
    }
    if (!body.contact_email || !body.contact_email.includes('@')) {
      res.status(400).json({ error: 'Adresse e-mail de contact invalide.' });
      return;
    }
    if (!Array.isArray(body.passengers) || body.passengers.length === 0) {
      res.status(400).json({ error: 'Renseignez les coordonnées des voyageurs.' });
      return;
    }

    // Determine authenticated traveler or bind safely to a newly created session if guest
    let activeSession = req.session ?? null;
    let issuedToken: string | null = null;
    if (!activeSession) {
      const normalizedEmail = body.contact_email.trim().toLowerCase();
      const existingUser = store.state.users.find(
        (u) => u.email.toLowerCase() === normalizedEmail,
      );
      if (existingUser && existingUser.user_id !== 'usr_demo_camille') {
        res.status(401).json({
          error:
            'Un compte existe déjà pour cet e-mail. Connectez-vous pour associer cette réservation à votre espace.',
        });
        return;
      }
      if (existingUser) {
        activeSession = {
          user_id: existingUser.user_id,
          email: existingUser.email,
          display_name: existingUser.display_name,
          role: existingUser.role,
        };
      } else {
        const newUserId = `usr_${crypto.randomBytes(6).toString('hex')}`;
        const leadPax = body.passengers[0];
        const displayName = `${leadPax.first_name} ${leadPax.last_name}`.trim();
        store.state.users.push({
          user_id: newUserId,
          email: normalizedEmail,
          display_name: displayName || normalizedEmail,
          role: 'traveler',
          password_hash: '',
          created_at: new Date().toISOString(),
        });
        activeSession = {
          user_id: newUserId,
          email: normalizedEmail,
          display_name: displayName || normalizedEmail,
          role: 'traveler',
        };
      }
      issuedToken = signSessionToken(activeSession);
      setSessionCookie(req, res, issuedToken);
    }

    const adapter = PROVIDERS[body.outward_offer.provider_id as keyof typeof PROVIDERS];
    if (!adapter || !adapter.capabilities.integrated_booking || !adapter.createReservationAndConfirm) {
      res.status(400).json({
        error: 'Ce fournisseur ne permet pas la réservation intégrée.',
      });
      return;
    }

    // Step 1: Authoritative revalidation
    const outReval = await adapter.revalidateOffer(
      body.outward_offer.offer_id,
      body.outward_offer,
    );
    let retReval: RevalidationResult | null = null;
    if (body.return_offer) {
      const retAdapter = PROVIDERS[body.return_offer.provider_id as keyof typeof PROVIDERS];
      if (retAdapter) {
        retReval = await retAdapter.revalidateOffer(
          body.return_offer.offer_id,
          body.return_offer,
        );
      }
    }

    if (outReval.status === 'unavailable' || retReval?.status === 'unavailable') {
      res.status(409).json({
        code: 'INVENTORY_UNAVAILABLE',
        error: 'La disponibilité vient d’expirer sur ce train.',
        revalidation: outReval,
      });
      return;
    }

    if (
      (outReval.status === 'price_changed' || retReval?.status === 'price_changed') &&
      !body.accept_price_change
    ) {
      res.status(409).json({
        code: 'PRICE_CHANGED_CONFIRMATION_REQUIRED',
        error: 'Le tarif a évolué lors de la vérification. Confirmez le nouveau montant.',
        revalidation: outReval,
        return_revalidation: retReval,
      });
      return;
    }

    // Compute authoritative totals on backend (integer euro cents)
    const authoritativeOutOffer = outReval.offer;
    const authoritativeRetOffer = retReval?.offer ?? null;
    const extras = (body.optional_extras ?? []).filter((e) => e.amount_cents >= 0);
    const extrasCents = extras.reduce((sum, e) => sum + e.amount_cents, 0);
    const baseTotalCents =
      authoritativeOutOffer.base_fare_cents +
      (authoritativeRetOffer?.base_fare_cents ?? 0);
    const discountTotalCents =
      authoritativeOutOffer.discount_cents +
      (authoritativeRetOffer?.discount_cents ?? 0);
    const farePayableCents =
      authoritativeOutOffer.total_known_cents +
      (authoritativeRetOffer?.total_known_cents ?? 0);
    const totalPayableCents = farePayableCents + extrasCents;

    const now = new Date().toISOString();
    const bookingId = `bkg_${crypto.randomBytes(5).toString('hex')}`;
    const bookingRef = `LG-${Math.floor(100000 + Math.random() * 899999)}`;
    const providerOrderRef = `ORD-LD-${bookingRef.slice(3)}`;

    const history: BookingRecord['state_history'] = [
      { state: 'offer_selected', timestamp: now, note: 'Offre(s) sélectionnée(s)' },
      { state: 'revalidation_pending', timestamp: now, note: outReval.message },
      { state: 'reservation_pending', timestamp: now, note: 'Demande de placement envoyée' },
    ];

    // Step 2: Hold & confirm reservation with provider
    const providerOutcome = await adapter.createReservationAndConfirm({
      offer: authoritativeOutOffer,
      passengers: body.passengers,
      provider_order_ref: providerOrderRef,
    });

    if (providerOutcome.status === 'unavailable') {
      res.status(409).json({
        code: 'INVENTORY_UNAVAILABLE',
        error: providerOutcome.message,
      });
      return;
    }

    const reservations = providerOutcome.seat_reservation
      ? [providerOutcome.seat_reservation]
      : [];

    history.push({
      state: 'reservation_held',
      timestamp: now,
      note: providerOutcome.seat_reservation
        ? `${providerOutcome.seat_reservation.coach} · ${providerOutcome.seat_reservation.seat_numbers.join(', ')}`
        : 'Placement provisoire obtenu',
    });

    // Step 3: Payment simulation (idempotent, never stores raw card details)
    const paymentId = `PAY-${crypto.randomBytes(4).toString('hex').toUpperCase()}`;
    const eventId = `evt_${idempotencyKey.slice(0, 12)}`;
    const eventIds = [eventId];
    if (store.state.simulation.simulate_duplicate_payment_event) {
      // Simulate duplicate webhook delivery safely deduplicated
      eventIds.push(`${eventId}_dup_ignored`);
    }

    history.push(
      { state: 'payment_pending', timestamp: now, note: 'Autorisation de paiement simulé en cours' },
      {
        state: 'payment_confirmed',
        timestamp: now,
        note: `Paiement confirmé (${(totalPayableCents / 100).toFixed(2).replace('.', ',')} €)${
          store.state.simulation.simulate_duplicate_payment_event
            ? ' · événement dupliqué neutralisé par idempotence'
            : ''
        }`,
      },
      {
        state: 'booking_confirmation_pending',
        timestamp: now,
        note: 'Attente de confirmation définitive du transporteur',
      },
    );

    let finalState: BookingRecord['state'] = 'ticket_issued';
    const tickets: BookingRecord['tickets'] = [];

    if (providerOutcome.status === 'uncertain_timeout') {
      finalState = 'reconciliation_required';
      history.push({
        state: 'reconciliation_required',
        timestamp: now,
        note: 'Paiement encaissé mais confirmation fournisseur incertaine : dossier pris en charge par le worker de réconciliation.',
      });
      store.state.support_cases.unshift({
        case_id: `CAS-${crypto.randomBytes(3).toString('hex').toUpperCase()}`,
        booking_id: bookingId,
        booking_reference: bookingRef,
        user_email: activeSession.email,
        category: 'reconciliation',
        summary: `Confirmation incertaine après paiement (${providerOrderRef}). Réconciliation automatique déclenchée.`,
        status: 'investigating',
        created_at: now,
        updated_at: now,
      });
    } else {
      history.push(
        { state: 'booking_confirmed', timestamp: now, note: providerOutcome.message },
        { state: 'ticket_issuance_pending', timestamp: now, note: 'Génération du document spécimen' },
        { state: 'ticket_issued', timestamp: now, note: 'Billet spécimen disponible dans Mes voyages' },
      );
      tickets.push({
        ticket_id: `TKT-${crypto.randomBytes(3).toString('hex').toUpperCase()}`,
        booking_id: bookingId,
        is_simulated: true,
        watermark_text: 'DÉMONSTRATION — NON VALABLE POUR VOYAGER',
        ticket_number: `SPECIMEN-${bookingRef}`,
        passenger_names: body.passengers.map((p) => `${p.first_name} ${p.last_name}`),
        travel_class: authoritativeOutOffer.travel_class,
        ticket_product: authoritativeOutOffer.ticket_product,
        issued_at: now,
        document_url: `/api/bookings/${bookingId}/ticket`,
      });
    }

    const record: BookingRecord = {
      booking_id: bookingId,
      user_id: activeSession.user_id,
      booking_reference: bookingRef,
      provider_order_ref: providerOrderRef,
      provider_id: adapter.provider_id,
      provider_name: adapter.provider_name,
      booking_mode: 'integrated_demo',
      state: finalState,
      state_history: history,
      outward_itinerary: body.outward_itinerary,
      outward_offer: authoritativeOutOffer,
      return_itinerary: body.return_itinerary ?? null,
      return_offer: authoritativeRetOffer,
      passengers: body.passengers,
      contact_email: body.contact_email.trim(),
      contact_phone: body.contact_phone?.trim() || '',
      optional_extras: extras,
      base_total_cents: baseTotalCents,
      mandatory_fees_cents: 0,
      discount_total_cents: discountTotalCents,
      extras_total_cents: extrasCents,
      total_paid_cents: totalPayableCents,
      currency: 'EUR',
      seat_reservations: reservations,
      payment: {
        payment_id: paymentId,
        idempotency_key: idempotencyKey,
        booking_id: bookingId,
        amount_cents: totalPayableCents,
        currency: 'EUR',
        method_label: body.payment_method_label || 'Carte de démonstration',
        masked_reference: '•••• 4242',
        state: 'confirmed',
        provider_event_ids: eventIds,
        created_at: now,
        updated_at: now,
      },
      tickets,
      refunds: [],
      assistance_requests: [],
      cancellation_status: 'active',
      created_at: now,
      updated_at: now,
    };

    store.state.bookings.unshift(record);
    store.state.processed_payment_events.push(eventId);
    const responsePayload = {
      booking: record,
      user: activeSession,
      token: issuedToken,
    };
    store.state.idempotency_records[idempotencyKey] = {
      booking_id: bookingId,
      response_json: JSON.stringify(responsePayload),
      created_at: now,
    };
    store.addAudit(
      activeSession.email,
      'BOOKING_CHECKOUT_COMPLETED',
      'booking',
      bookingId,
      `Réservation ${bookingRef} -> état ${finalState}`,
    );

    res.status(201).json(responsePayload);
  });

  // Duplicate payment webhook simulation endpoint (idempotent)
  router.post('/payments/webhook-demo', (req, res) => {
    const { event_id, booking_id } = req.body as { event_id?: string; booking_id?: string };
    if (!event_id) {
      res.status(400).json({ error: 'event_id requis.' });
      return;
    }
    if (store.state.processed_payment_events.includes(event_id)) {
      res.json({
        deduplicated: true,
        message: `Événement ${event_id} déjà traité — aucun double débit appliqué.`,
      });
      return;
    }
    store.state.processed_payment_events.push(event_id);
    store.addAudit(
      'payment_webhook',
      'PAYMENT_EVENT_RECORDED',
      'booking',
      booking_id || 'unknown',
      `Événement ${event_id} enregistré.`,
    );
    res.json({ deduplicated: false, message: `Événement ${event_id} enregistré.` });
  });

  // Account-scoped bookings ("Mes voyages")
  router.get('/bookings', requireAuth, (req: AuthedRequest, res) => {
    const user = req.session!;
    const bookings = store.state.bookings.filter((b) => b.user_id === user.user_id);
    res.json({ bookings });
  });

  router.get('/bookings/:id', requireAuth, (req: AuthedRequest, res) => {
    const user = req.session!;
    const booking = store.state.bookings.find((b) => b.booking_id === req.params['id']);
    if (!booking || (booking.user_id !== user.user_id && user.role !== 'admin')) {
      res.status(404).json({ error: 'Dossier introuvable.' });
      return;
    }
    res.json({ booking });
  });

  // Specimen travel document download
  router.get('/bookings/:id/ticket', requireAuth, (req: AuthedRequest, res) => {
    const user = req.session!;
    const booking = store.state.bookings.find((b) => b.booking_id === req.params['id']);
    if (!booking || (booking.user_id !== user.user_id && user.role !== 'admin')) {
      res.status(404).json({ error: 'Document introuvable.' });
      return;
    }
    if (booking.state !== 'ticket_issued' && booking.state !== 'booking_confirmed') {
      res.status(409).json({
        error: 'Aucun billet émis tant que la réservation n’est pas confirmée.',
      });
      return;
    }

    const html = `<!doctype html>
<html lang="fr">
<head>
  <meta charset="utf-8" />
  <title>Spécimen billet ${booking.booking_reference} — LIGNE</title>
  <style>
    body { font-family: system-ui, -apple-system, sans-serif; background: #FAF8F5; color: #0E1F3B; padding: 32px; }
    .card { max-width: 720px; margin: 0 auto; background: #fff; border: 1px solid #E3E6EC; border-radius: 14px; padding: 28px; }
    .banner { background: #FDECEA; color: #B42318; border: 1px solid #F5C2BE; padding: 12px 16px; border-radius: 8px; font-weight: 700; text-align: center; margin-bottom: 24px; letter-spacing: 0.04em; }
    .specimen { border: 2px dashed #CBD5E1; padding: 18px; text-align: center; color: #475569; margin-top: 20px; border-radius: 10px; font-family: monospace; }
  </style>
</head>
<body>
  <div class="card">
    <div class="banner">DÉMONSTRATION — NON VALABLE POUR VOYAGER</div>
    <h1>LIGNE — Document de voyage de démonstration</h1>
    <p><strong>Référence dossier :</strong> ${booking.booking_reference} · <strong>Fournisseur :</strong> ${booking.provider_name}</p>
    <p><strong>Trajet aller :</strong> ${booking.outward_itinerary.origin_station.name} (${booking.outward_itinerary.departure_local_label}) → ${booking.outward_itinerary.destination_station.name} (${booking.outward_itinerary.arrival_local_label})</p>
    ${booking.return_itinerary ? `<p><strong>Trajet retour :</strong> ${booking.return_itinerary.origin_station.name} (${booking.return_itinerary.departure_local_label}) → ${booking.return_itinerary.destination_station.name} (${booking.return_itinerary.arrival_local_label})</p>` : ''}
    <p><strong>Voyageurs :</strong> ${booking.passengers.map((p) => `${p.first_name} ${p.last_name}`).join(', ')}</p>
    <p><strong>Classe :</strong> ${booking.outward_offer.travel_class}e classe · <strong>Tarif :</strong> ${booking.outward_offer.ticket_product}</p>
    <p><strong>Total payé (simulé) :</strong> ${(booking.total_paid_cents / 100).toFixed(2).replace('.', ',')} €</p>
    <div class="specimen">SPECIMEN VISUEL NON FONCTIONNEL — AUCUN CODE-BARRES FERROVIAIRE OPÉRATIONNEL</div>
  </div>
</body>
</html>`;

    res.setHeader('Content-Type', 'text/html; charset=utf-8');
    res.setHeader(
      'Content-Disposition',
      `attachment; filename="LIGNE-specimen-${booking.booking_reference}.html"`,
    );
    res.send(html);
  });

  // Cancellation & refund tracking
  router.post('/bookings/:id/cancel', requireAuth, async (req: AuthedRequest, res) => {
    const user = req.session!;
    const booking = store.state.bookings.find((b) => b.booking_id === req.params['id']);
    if (!booking || (booking.user_id !== user.user_id && user.role !== 'admin')) {
      res.status(404).json({ error: 'Réservation introuvable.' });
      return;
    }
    if (booking.cancellation_status === 'cancelled') {
      res.status(409).json({ error: 'Cette réservation est déjà annulée.' });
      return;
    }

    const reason = String(req.body?.reason || 'Annulation demandée par le voyageur').slice(0, 240);
    const feeFromOffer = booking.outward_offer.refund_conditions.fee_cents ?? 0;
    const penaltyCents =
      booking.outward_offer.refund_conditions.status === 'non_modifiable'
        ? booking.total_paid_cents
        : Math.min(booking.total_paid_cents, feeFromOffer);
    const netRefundCents = Math.max(0, booking.total_paid_cents - penaltyCents);
    const now = new Date().toISOString();

    const refundId = `REF-${crypto.randomBytes(4).toString('hex').toUpperCase()}`;
    booking.cancellation_status = 'cancelled';
    booking.refunds.unshift({
      refund_id: refundId,
      booking_id: booking.booking_id,
      payment_id: booking.payment?.payment_id ?? 'NONE',
      requested_amount_cents: booking.total_paid_cents,
      penalty_cents: penaltyCents,
      net_refund_cents: netRefundCents,
      reason,
      state: 'requested',
      created_at: now,
      updated_at: now,
    });
    booking.updated_at = now;

    store.state.support_cases.unshift({
      case_id: `CAS-${crypto.randomBytes(3).toString('hex').toUpperCase()}`,
      booking_id: booking.booking_id,
      booking_reference: booking.booking_reference,
      user_email: user.email,
      category: 'refund',
      summary: `Demande d'annulation (${refundId}) : remboursement net estimé ${(netRefundCents / 100).toFixed(2).replace('.', ',')} €`,
      status: 'open',
      created_at: now,
      updated_at: now,
    });

    store.addAudit(
      user.email,
      'CANCELLATION_REQUESTED',
      'booking',
      booking.booking_id,
      `Demande ${refundId} (net ${(netRefundCents / 100).toFixed(2)} €)`,
    );

    res.json({ booking });
  });

  // Exchange request
  router.post('/bookings/:id/exchange', requireAuth, (req: AuthedRequest, res) => {
    const user = req.session!;
    const booking = store.state.bookings.find((b) => b.booking_id === req.params['id']);
    if (!booking || (booking.user_id !== user.user_id && user.role !== 'admin')) {
      res.status(404).json({ error: 'Réservation introuvable.' });
      return;
    }
    const desiredDate = String(req.body?.desired_date || '').slice(0, 40);
    const note = String(req.body?.note || '').slice(0, 200);
    const now = new Date().toISOString();

    booking.cancellation_status = 'exchange_requested';
    booking.updated_at = now;
    store.state.support_cases.unshift({
      case_id: `CAS-${crypto.randomBytes(3).toString('hex').toUpperCase()}`,
      booking_id: booking.booking_id,
      booking_reference: booking.booking_reference,
      user_email: user.email,
      category: 'exchange',
      summary: `Demande d'échange vers ${desiredDate || 'nouvel horaire'} — ${note || 'aucune précision'}`,
      status: 'open',
      created_at: now,
      updated_at: now,
    });
    store.addAudit(
      user.email,
      'EXCHANGE_REQUESTED',
      'booking',
      booking.booking_id,
      `Souhait : ${desiredDate}`,
    );
    res.json({ booking });
  });

  // Assistance request (strictly separate from confirmed assistance)
  router.post('/bookings/:id/assistance', requireAuth, (req: AuthedRequest, res) => {
    const user = req.session!;
    const booking = store.state.bookings.find((b) => b.booking_id === req.params['id']);
    if (!booking || (booking.user_id !== user.user_id && user.role !== 'admin')) {
      res.status(404).json({ error: 'Réservation introuvable.' });
      return;
    }
    const stationId = String(req.body?.station_id || booking.outward_itinerary.origin_station.id);
    const station = STATION_MAP.get(stationId) ?? booking.outward_itinerary.origin_station;
    const assistanceType = String(req.body?.assistance_type || 'Accompagnement fauteuil / quai').slice(0, 120);
    const notes = String(req.body?.notes || '').slice(0, 240);
    const now = new Date().toISOString();

    booking.assistance_requests.push({
      request_id: `AST-${crypto.randomBytes(3).toString('hex').toUpperCase()}`,
      station_id: station.id,
      station_name: station.name,
      assistance_type: assistanceType,
      notes,
      status: 'requested_unconfirmed',
      created_at: now,
    });
    booking.updated_at = now;
    store.addAudit(
      user.email,
      'ASSISTANCE_REQUESTED',
      'booking',
      booking.booking_id,
      `Demande enregistrée (non confirmée) pour ${station.name}`,
    );
    res.json({ booking });
  });

  // Saved itineraries (explicitly separate from purchased bookings)
  router.get('/saved-itineraries', requireAuth, (req: AuthedRequest, res) => {
    const user = req.session!;
    const items = store.state.saved_itineraries.filter((s) => s.user_id === user.user_id);
    res.json({ saved_itineraries: items });
  });

  router.post('/saved-itineraries', requireAuth, (req: AuthedRequest, res) => {
    const user = req.session!;
    const { label, outward_itinerary, quoted_cents } = req.body as {
      label?: string;
      outward_itinerary: JourneyItinerary;
      quoted_cents: number;
    };
    if (!outward_itinerary) {
      res.status(400).json({ error: 'Itinéraire requis.' });
      return;
    }
    const item = {
      saved_id: `SAV-${crypto.randomBytes(4).toString('hex').toUpperCase()}`,
      user_id: user.user_id,
      label:
        label ||
        `${outward_itinerary.origin_station.name} → ${outward_itinerary.destination_station.name}`,
      from_station: outward_itinerary.origin_station,
      to_station: outward_itinerary.destination_station,
      outward_itinerary,
      quoted_cents: Number(quoted_cents) || 0,
      created_at: new Date().toISOString(),
    };
    store.state.saved_itineraries.unshift(item);
    store.save();
    res.status(201).json({ saved_itinerary: item });
  });

  router.delete('/saved-itineraries/:id', requireAuth, (req: AuthedRequest, res) => {
    const user = req.session!;
    const idx = store.state.saved_itineraries.findIndex(
      (s) => s.saved_id === req.params['id'] && s.user_id === user.user_id,
    );
    if (idx === -1) {
      res.status(404).json({ error: 'Itinéraire enregistré introuvable.' });
      return;
    }
    store.state.saved_itineraries.splice(idx, 1);
    store.save();
    res.json({ ok: true });
  });

  // Demo resilience & simulation flags (non-sensitive synthetic test toggles)
  router.get('/demo/simulation', (_req, res) => {
    res.json({ simulation: store.state.simulation });
  });

  router.post('/demo/simulation', (req: AuthedRequest, res) => {
    const incoming = req.body as Partial<typeof store.state.simulation>;
    store.state.simulation = {
      ...store.state.simulation,
      ...incoming,
    };
    store.addAudit(
      req.session?.email ?? 'demo_console',
      'SIMULATION_FLAGS_UPDATED',
      'simulation',
      'flags',
      JSON.stringify(store.state.simulation),
    );
    res.json({ simulation: store.state.simulation });
  });

  router.post('/demo/reconcile', async (_req, res) => {
    const result = await runReconciliationPass('demo:trigger');
    res.json(result);
  });

  // Admin bootstrap & auth (no hardcoded passwords!)
  router.get('/admin/status', (_req, res) => {
    const configuredViaEnv = Boolean(process.env['ADMIN_PASSCODE']?.trim());
    const claimed = Boolean(store.state.admin_claimed_hash);
    res.json({
      needs_bootstrap: !configuredViaEnv && !claimed,
      configured_via_env: configuredViaEnv,
    });
  });

  router.post('/admin/bootstrap', rateLimit(10), (req, res) => {
    if (process.env['ADMIN_PASSCODE']?.trim() || store.state.admin_claimed_hash) {
      res.status(409).json({
        error: 'L’accès administrateur est déjà configuré.',
      });
      return;
    }
    const { passcode } = req.body as { passcode?: string };
    if (!passcode || passcode.length < 8) {
      res.status(400).json({
        error: 'Choisissez un mot de passe administrateur d’au moins 8 caractères.',
      });
      return;
    }
    store.state.admin_claimed_hash = hashPassword(passcode);
    store.addAudit(
      'admin_bootstrap',
      'ADMIN_CLAIMED',
      'admin',
      'root',
      'Accès administrateur initialisé lors du premier démarrage.',
    );

    const session: UserSession = {
      user_id: 'usr_admin',
      email: 'admin@ligne.local',
      display_name: 'Administrateur LIGNE',
      role: 'admin',
    };
    const token = signSessionToken(session);
    setSessionCookie(req, res, token);
    res.status(201).json({ user: session, token });
  });

  router.post('/admin/login', rateLimit(15), (req, res) => {
    const { passcode } = req.body as { passcode?: string };
    if (!passcode) {
      res.status(400).json({ error: 'Mot de passe administrateur requis.' });
      return;
    }
    const envPass = process.env['ADMIN_PASSCODE']?.trim();
    let valid = false;
    if (envPass) {
      const a = Buffer.from(passcode);
      const b = Buffer.from(envPass);
      valid = a.length === b.length && crypto.timingSafeEqual(a, b);
    } else if (store.state.admin_claimed_hash) {
      valid = verifyPassword(passcode, store.state.admin_claimed_hash);
    }
    if (!valid) {
      res.status(401).json({ error: 'Mot de passe administrateur incorrect.' });
      return;
    }

    const session: UserSession = {
      user_id: 'usr_admin',
      email: 'admin@ligne.local',
      display_name: 'Administrateur LIGNE',
      role: 'admin',
    };
    const token = signSessionToken(session);
    setSessionCookie(req, res, token);
    res.json({ user: session, token });
  });

  // Protected Admin routes
  router.get('/admin/overview', requireAdmin, (_req, res) => {
    const sim = store.state.simulation;
    const providerHealth: ProviderHealth[] = Object.values(PROVIDERS).map((p) => ({
      provider_id: p.provider_id,
      provider_name: p.provider_name,
      booking_mode: p.booking_mode,
      status:
        sim.timeout_provider_id === p.provider_id ||
        (sim.partial_results_mode && p.provider_id === 'horizon_handoff')
          ? 'timeout_simulated'
          : 'healthy',
      avg_latency_ms: p.provider_id === 'rail_direct_demo' ? 42 : 78,
      last_checked_at: new Date().toISOString(),
      capabilities: p.capabilities,
    }));

    const fixtures = FIXTURE_JOURNEYS.map((f) => ({
      template_id: f.template_id,
      provider_id: f.provider_id,
      origin: f.segments[0].origin_station_id,
      destination: f.segments[f.segments.length - 1].destination_station_id,
      departure: f.segments[0].dep_time,
      product: f.ticket_product,
      default_second_class_cents: f.base_second_class_cents,
      override_cents: store.state.fixture_price_overrides[f.template_id] ?? null,
      unavailable: store.state.fixture_unavailable_templates.includes(f.template_id),
    }));

    res.json({
      providers: providerHealth,
      fixtures,
      bookings: store.state.bookings,
      support_cases: store.state.support_cases,
      audit_logs: store.state.audit_logs,
      simulation: store.state.simulation,
      stations_count: STATIONS.length,
    });
  });

  router.post('/admin/fixtures/update', requireAdmin, (req: AuthedRequest, res) => {
    const { template_id, override_cents, unavailable } = req.body as {
      template_id: string;
      override_cents?: number | null;
      unavailable?: boolean;
    };
    if (!template_id) {
      res.status(400).json({ error: 'template_id requis.' });
      return;
    }
    if (override_cents === null || override_cents === undefined) {
      delete store.state.fixture_price_overrides[template_id];
    } else {
      store.state.fixture_price_overrides[template_id] = Math.max(500, Number(override_cents));
    }
    const idx = store.state.fixture_unavailable_templates.indexOf(template_id);
    if (unavailable && idx === -1) {
      store.state.fixture_unavailable_templates.push(template_id);
    } else if (!unavailable && idx !== -1) {
      store.state.fixture_unavailable_templates.splice(idx, 1);
    }
    store.addAudit(
      req.session!.email,
      'FIXTURE_UPDATED',
      'fixture',
      template_id,
      `Prix=${override_cents ?? 'défaut'}, Indisponible=${Boolean(unavailable)}`,
    );
    res.json({ ok: true });
  });

  router.post('/admin/reconciliation/run', requireAdmin, async (req: AuthedRequest, res) => {
    const result = await runReconciliationPass(req.session!.email);
    res.json(result);
  });

  router.post('/admin/refunds/:refundId/advance', requireAdmin, (req: AuthedRequest, res) => {
    const refundId = String(req.params['refundId']);
    const { next_state } = req.body as { next_state: 'under_review' | 'approved' | 'credited' | 'rejected' };
    for (const b of store.state.bookings) {
      const ref = b.refunds.find((r) => r.refund_id === refundId);
      if (ref) {
        ref.state = next_state;
        ref.updated_at = new Date().toISOString();
        if (next_state === 'credited' && b.payment) {
          b.payment.state = 'refunded';
          b.payment.updated_at = ref.updated_at;
        }
        store.addAudit(
          req.session!.email,
          'REFUND_STATE_ADVANCED',
          'refund',
          refundId,
          `Statut remboursement -> ${next_state}`,
        );
        res.json({ refund: ref });
        return;
      }
    }
    res.status(404).json({ error: 'Remboursement introuvable.' });
  });

  router.post('/admin/cases/:caseId/update', requireAdmin, (req: AuthedRequest, res) => {
    const c = store.state.support_cases.find((x) => x.case_id === req.params['caseId']);
    if (!c) {
      res.status(404).json({ error: 'Dossier SAV introuvable.' });
      return;
    }
    const { status } = req.body as { status: 'open' | 'investigating' | 'resolved' };
    c.status = status;
    c.updated_at = new Date().toISOString();
    store.addAudit(
      req.session!.email,
      'SUPPORT_CASE_UPDATED',
      'support_case',
      c.case_id,
      `Statut -> ${status}`,
    );
    res.json({ support_case: c });
  });

  return router;
}
