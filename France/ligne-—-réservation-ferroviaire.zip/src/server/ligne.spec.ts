import {isAllowlistedSellerUrl, PROVIDERS} from './providers';
import {hashPassword, signSessionToken, store, verifyPassword, verifySessionToken} from './store';
import {formatLocalTime, zonedWallTimeToUtc} from './timezone';
import {runReconciliationPass} from './worker';

describe('LIGNE Core Railway Domain & Security', () => {
  afterEach(() => {
    store.state.simulation = {
      timeout_provider_id: null,
      partial_results_mode: false,
      force_expired_offer: false,
      force_price_change_cents: 0,
      force_unavailable_inventory: false,
      simulate_duplicate_payment_event: false,
      force_uncertain_booking_outcome: false,
    };
  });

  it('keeps Paris stations distinct and never substitutes FRPLY with FRPMO', async () => {
    const plyResults = await PROVIDERS.rail_direct_demo.searchJourneys({
      from_station_id: 'FRPLY',
      to_station_id: 'FRLPD',
      date: '2027-06-18',
      time: '00:00',
      adults: 1,
      youths: 0,
      seniors: 0,
      travel_class: '2',
      discount_cards: [],
    });
    expect(plyResults.length).toBeGreaterThanOrEqual(2);
    expect(plyResults.every((r) => r.itinerary.origin_station.id === 'FRPLY')).toBe(true);

    // Searching from Paris Montparnasse to Lyon Part-Dieu must NOT silently serve Gare de Lyon trains
    const pmoResults = await PROVIDERS.rail_direct_demo.searchJourneys({
      from_station_id: 'FRPMO',
      to_station_id: 'FRLPD',
      date: '2027-06-18',
      time: '00:00',
      adults: 1,
      youths: 0,
      seniors: 0,
      travel_class: '2',
      discount_cards: [],
    });
    expect(pmoResults.length).toBe(0);
  });

  it('returns illustrative 49 EUR and 59 EUR Paris-Lyon offers and excludes unknown-fee offers from cheapest', async () => {
    const directRes = await PROVIDERS.rail_direct_demo.searchJourneys({
      from_station_id: 'FRPLY',
      to_station_id: 'FRLPD',
      date: '2027-06-18',
      time: '00:00',
      adults: 1,
      youths: 0,
      seniors: 0,
      travel_class: '2',
      discount_cards: [],
    });
    const prices = directRes.map((r) => r.offers[0].total_known_cents);
    expect(prices).toContain(4900);
    expect(prices).toContain(5900);

    const horizonRes = await PROVIDERS.horizon_handoff.searchJourneys({
      from_station_id: 'FRPLY',
      to_station_id: 'FRLPD',
      date: '2027-06-18',
      time: '00:00',
      adults: 1,
      youths: 0,
      seniors: 0,
      travel_class: '2',
      discount_cards: [],
    });
    const conn = horizonRes.find((r) => r.itinerary.changes_count > 0);
    expect(conn).toBeDefined();
    expect(conn?.offers[0].has_unknown_mandatory_fees).toBe(true);
    expect(conn?.lowest_known_offer_id).toBeNull();
  });

  it('computes IANA timezone & DST spring-forward overnight elapsed duration accurately', () => {
    // 2027-03-28 is Europe/Paris spring forward (02:00 -> 03:00, 23-hour day)
    const dep = zonedWallTimeToUtc('2027-03-27', '22:45', 'Europe/Paris', 0);
    const arr = zonedWallTimeToUtc('2027-03-27', '06:15', 'Europe/Paris', 1);
    const elapsedMinutes = Math.round((arr.getTime() - dep.getTime()) / 60000);
    // From 22:45 CET to 06:15 CEST on spring-forward night is 6h30 (390 min), not 7h30!
    expect(elapsedMinutes).toBe(390);
    expect(formatLocalTime(dep.toISOString(), 'Europe/Paris')).toBe('22:45');
    expect(formatLocalTime(arr.toISOString(), 'Europe/Paris')).toBe('06:15');
  });

  it('handles offer revalidation states: expired, price_changed, and unavailable', async () => {
    const res = await PROVIDERS.rail_direct_demo.searchJourneys({
      from_station_id: 'FRPLY',
      to_station_id: 'FRLPD',
      date: '2027-06-18',
      time: '00:00',
      adults: 1,
      youths: 0,
      seniors: 0,
      travel_class: '2',
      discount_cards: [],
    });
    const offer = res[0].offers[0];

    store.state.simulation.force_expired_offer = true;
    const expReval = await PROVIDERS.rail_direct_demo.revalidateOffer(offer.offer_id, offer);
    expect(expReval.status).toBe('expired');
    store.state.simulation.force_expired_offer = false;

    store.state.simulation.force_price_change_cents = 1200;
    const priceReval = await PROVIDERS.rail_direct_demo.revalidateOffer(offer.offer_id, offer);
    expect(priceReval.status).toBe('price_changed');
    expect(priceReval.new_total_cents).toBe(offer.total_known_cents + 1200);
    store.state.simulation.force_price_change_cents = 0;

    store.state.simulation.force_unavailable_inventory = true;
    const unavailReval = await PROVIDERS.rail_direct_demo.revalidateOffer(offer.offer_id, offer);
    expect(unavailReval.status).toBe('unavailable');
  });

  it('enforces seller redirect allowlist and rejects untrusted redirect URLs', () => {
    expect(
      isAllowlistedSellerUrl('https://horizon-rail-demo.ligne.example/handoff?offer=123'),
    ).toBe(true);
    expect(isAllowlistedSellerUrl('https://evil.attacker.example/phish')).toBe(false);
    expect(isAllowlistedSellerUrl('javascript:alert(1)')).toBe(false);
  });

  it('verifies scrypt passwords and HMAC session tokens securely', () => {
    const hash = hashPassword('SuperMotDePasse2027');
    expect(verifyPassword('SuperMotDePasse2027', hash)).toBe(true);
    expect(verifyPassword('MauvaisMotDePasse', hash)).toBe(false);

    const token = signSessionToken({
      user_id: 'usr_1',
      email: 'test@ligne.fr',
      display_name: 'Test',
      role: 'traveler',
    });
    const verified = verifySessionToken(token);
    expect(verified?.user_id).toBe('usr_1');
    expect(verifySessionToken(`${token}tamper`)).toBeNull();
  });

  it('reconciles uncertain bookings by stable provider_order_ref without duplicating orders', async () => {
    const beforeCount = store.state.bookings.length;
    store.state.bookings.push({
      ...store.state.bookings[0],
      booking_id: 'bkg_reconcile_test',
      booking_reference: 'LG-999111',
      provider_order_ref: 'ORD-LD-999111',
      state: 'reconciliation_required',
      tickets: [],
    });

    const summary = await runReconciliationPass('test:reconcile');
    expect(summary.resolved).toBeGreaterThanOrEqual(1);
    const updated = store.state.bookings.find((b) => b.booking_id === 'bkg_reconcile_test');
    expect(updated?.state).toBe('ticket_issued');
    expect(updated?.tickets.length).toBe(1);
    expect(store.state.bookings.length).toBe(beforeCount + 1);

    // Clean up test booking
    store.state.bookings = store.state.bookings.filter((b) => b.booking_id !== 'bkg_reconcile_test');
    store.save();
  });
});
