export type SearchVertical =
  | 'web'
  | 'images'
  | 'actualites'
  | 'savoirs'
  | 'cartes';

export type SearchMode = 'local' | 'external';

export type ContentType =
  | 'text/html'
  | 'text/markdown'
  | 'text/plain'
  | 'application/pdf'
  | 'image/jpeg'
  | 'application/geo+json';

export type IndexStatus = 'indexed' | 'failed' | 'duplicate_skipped' | 'removed';

export interface ImageMetadata {
  asset_url: string;
  alt_text: string;
  credit: string;
  license: string;
  dimensions: string;
  keywords: string[];
}

export interface PlaceMetadata {
  city: string;
  region: string;
  latitude: number;
  longitude: number;
  category: string;
  address: string;
}

export interface CrawlProvenance {
  job_id?: string;
  depth: number;
  status_code: number;
  robots_checked: boolean;
  crawl_delay_ms: number;
  redirects_followed: number;
}

export interface DocumentRecord {
  document_id: string;
  source_url: string;
  canonical_url: string;
  title: string;
  language: 'fr';
  body_text: string;
  content_type: ContentType;
  published_at: string | null;
  modified_at: string | null;
  fetched_at: string;
  content_hash: string;
  source_name: string;
  rights_metadata: string;
  index_status: IndexStatus;
  vertical: SearchVertical;
  domain: string;
  excerpt: string;
  raw_representation_ref?: string;
  crawl_provenance?: CrawlProvenance;
  image_metadata?: ImageMetadata;
  place_metadata?: PlaceMetadata;
}

export interface SearchHit {
  document_id: string;
  title: string;
  source_url: string;
  canonical_url: string;
  domain: string;
  source_name: string;
  snippet: string;
  highlight_terms: string[];
  published_at: string | null;
  modified_at: string | null;
  content_type: ContentType;
  vertical: SearchVertical;
  rights_metadata: string;
  score: number;
  image_metadata?: ImageMetadata;
  place_metadata?: PlaceMetadata;
}

export interface ProviderStatus {
  mode: SearchMode;
  adapter_name: string;
  available: boolean;
  honest_notice: string;
  error_code?: 'MISSING_CREDENTIALS' | 'PROVIDER_TIMEOUT' | 'PROVIDER_ERROR';
}

export interface SearchFacets {
  domains: {domain: string; count: number}[];
  verticals: {vertical: SearchVertical; count: number}[];
}

export interface SearchResponse {
  query: string;
  normalized_query: string;
  vertical: SearchVertical;
  mode: SearchMode;
  provider_status: ProviderStatus;
  results: SearchHit[];
  next_cursor: string | null;
  returned_count: number;
  corpus_scope_note: string;
  spelling_suggestion: string | null;
  did_not_replace_query: boolean;
  facets: SearchFacets;
  elapsed_ms: number;
}

export interface SuggestionItem {
  text: string;
  kind: 'completion' | 'spelling';
  source_hint?: string;
}

export interface SuggestionsResponse {
  query: string;
  suggestions: SuggestionItem[];
  spelling_suggestion: string | null;
}

export interface AssistantQuotation {
  document_id: string;
  title: string;
  source_name: string;
  source_url: string;
  exact_quote: string;
}

export interface AssistantResponse {
  query: string;
  status: 'grounded' | 'insufficient_evidence' | 'provider_unavailable';
  summary: string | null;
  uncertainty_note: string;
  quotations: AssistantQuotation[];
  citations: {
    document_id: string;
    title: string;
    source_name: string;
    source_url: string;
  }[];
  adapter_name: string;
  notice: string;
}

export interface ApprovedSource {
  source_id: string;
  name: string;
  base_url: string;
  domain: string;
  allowed_paths: string[];
  vertical: SearchVertical;
  rights_default: string;
  crawl_delay_ms: number;
  max_depth: number;
  enabled: boolean;
  created_at: string;
}

export interface IngestionJob {
  job_id: string;
  kind: 'crawl' | 'upload_text' | 'upload_html' | 'upload_markdown' | 'upload_pdf';
  target_url?: string;
  source_name: string;
  status: 'completed' | 'failed' | 'duplicate_skipped' | 'blocked_ssrf' | 'blocked_robots';
  document_id?: string;
  error_message?: string;
  created_at: string;
  finished_at: string;
  provenance?: Record<string, unknown>;
}

export interface DuplicateCluster {
  content_hash: string;
  canonical_urls: string[];
  document_ids: string[];
  title: string;
}

export interface AbuseReport {
  report_id: string;
  document_id?: string;
  source_url: string;
  reason: string;
  details: string;
  status: 'open' | 'resolved' | 'removed';
  created_at: string;
}

export interface EvaluationQueryResult {
  id: string;
  query: string;
  category:
    | 'navigational'
    | 'informational'
    | 'accented'
    | 'unaccented'
    | 'phrase'
    | 'ambiguous'
    | 'no_result';
  expected_doc_ids: string[];
  top_doc_ids: string[];
  reciprocal_rank: number;
  recall_at_5: number;
  latency_ms: number;
  passed: boolean;
}

export interface EvaluationRunResult {
  run_id: string;
  executed_at: string;
  dataset_label: string;
  total_queries: number;
  mrr_at_5: number;
  recall_at_5: number;
  accent_parity_rate: number;
  no_result_accuracy: number;
  p50_latency_ms: number;
  p95_latency_ms: number;
  indexed_document_count: number;
  failed_document_count: number;
  source_count: number;
  results: EvaluationQueryResult[];
}

export interface SavedResult {
  saved_id: string;
  document_id: string;
  title: string;
  source_url: string;
  domain: string;
  snippet: string;
  collection: string;
  saved_at: string;
}

export interface SearchHistoryItem {
  query: string;
  vertical: SearchVertical;
  searched_at: string;
}

export interface UserPreferences {
  save_search_history: boolean;
  default_mode: SearchMode;
  language: 'fr';
}

export interface UserProfile {
  user_id: string;
  email: string;
  display_name: string;
  preferences: UserPreferences;
}
