import {Routes} from '@angular/router';

export const routes: Routes = [
  {
    path: '',
    loadComponent: () => import('./pages/home').then((m) => m.HomePage),
  },
  {
    path: 'recherche',
    loadComponent: () =>
      import('./pages/search-results').then((m) => m.SearchResultsPage),
  },
  {
    path: 'source/:document_id',
    loadComponent: () =>
      import('./pages/document-detail').then((m) => m.DocumentDetailPage),
  },
  {
    path: 'administration',
    loadComponent: () => import('./pages/admin').then((m) => m.AdminPage),
  },
  {
    path: 'confidentialite',
    loadComponent: () => import('./pages/privacy').then((m) => m.PrivacyPage),
  },
  {
    path: 'demonstration',
    loadComponent: () =>
      import('./pages/demo-guide').then((m) => m.DemoGuidePage),
  },
  {
    path: '**',
    redirectTo: '',
  },
];
