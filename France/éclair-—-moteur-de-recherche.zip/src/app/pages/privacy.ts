import {ChangeDetectionStrategy, Component} from '@angular/core';
import {MatIconModule} from '@angular/material/icon';
import {RouterLink} from '@angular/router';
import {EclairEmblem} from '../components/eclair-emblem';

@Component({
  changeDetection: ChangeDetectionStrategy.OnPush,
  selector: 'app-privacy-page',
  imports: [RouterLink, MatIconModule, EclairEmblem],
  template: `
    <div class="min-h-screen bg-[#F8F9FB] text-[#0B1E46]">
      <header class="border-b border-[#0B1E46]/10 bg-white">
        <div class="mx-auto flex h-16 max-w-[1040px] items-center justify-between px-4 sm:px-6">
          <a routerLink="/" class="flex items-center gap-2 whitespace-nowrap">
            <app-eclair-emblem size="sm" />
            <span class="font-display-serif text-xl font-semibold text-[#0B1E46]">Éclair</span>
          </a>
          <a routerLink="/recherche" class="text-xs font-semibold text-[#114AC4] hover:underline">
            Accéder à la recherche
          </a>
        </div>
      </header>

      <main class="mx-auto max-w-[860px] px-4 py-10 sm:px-6">
        <h1 class="font-display-serif text-3xl font-semibold text-[#0B1E46]">
          Confidentialité, portée du corpus et transparence
        </h1>
        <p class="mt-3 max-w-[70ch] text-sm leading-relaxed text-[#0B1E46]/80">
          Éclair privilégie l’honnêteté technique plutôt que les promesses absolues. Cette page documente exactement quelles données circulent selon le mode de recherche choisi.
        </p>

        <div class="mt-8 space-y-6">
          <section class="rounded-2xl border border-[#0B1E46]/10 bg-white p-6">
            <h2 class="font-display-serif text-xl font-semibold">1. Mode Corpus local vs Mode Web externe</h2>
            <p class="mt-2 text-sm leading-relaxed text-[#0B1E46]/80">
              En mode <strong>Corpus local</strong>, vos requêtes sont traitées exclusivement par l’index lexical BM25 hébergé sur ce serveur sur une collection francophone délimitée (Culture, Sciences, Architecture, Voyages, Actualités, Lieux). Ce corpus ne prétend pas couvrir l’ensemble du Web.
            </p>
            <p class="mt-2 text-sm leading-relaxed text-[#0B1E46]/80">
              En mode <strong>Web externe</strong> (lorsqu’un fournisseur autorisé est configuré), votre requête est transmise au fournisseur tiers configuré par l’exploitant : nous ne promettons jamais « zéro trace » sur un chemin réseau externe.
            </p>
          </section>

          <section class="rounded-2xl border border-[#0B1E46]/10 bg-white p-6">
            <h2 class="font-display-serif text-xl font-semibold">2. Journalisation des requêtes et comptes optionnels</h2>
            <ul class="mt-2 list-disc space-y-2 pl-5 text-sm leading-relaxed text-[#0B1E46]/80">
              <li>La recherche anonyme ne crée aucun profil ni historique persistant.</li>
              <li>Dans un compte optionnel, l’historique de recherche est <strong>désactivé par défaut</strong> et n’enregistre que les 50 dernières requêtes si vous l’activez explicitement.</li>
              <li>Vous pouvez exporter l’intégralité de vos résultats enregistrés au format JSON ou supprimer votre compte à tout moment.</li>
              <li>Les jetons de session sont conservés uniquement en mémoire vive durant la visite (jamais en stockage local persistant du navigateur).</li>
            </ul>
          </section>

          <section class="rounded-2xl border border-[#0B1E46]/10 bg-white p-6">
            <h2 class="font-display-serif text-xl font-semibold">3. Voix, images et assistant documentaire</h2>
            <ul class="mt-2 list-disc space-y-2 pl-5 text-sm leading-relaxed text-[#0B1E46]/80">
              <li>Le microphone et la sélection d’image ne s’activent jamais sans action explicite de votre part.</li>
              <li>Les images sélectionnées pour la recherche par métadonnées ne sont ni conservées ni publiées.</li>
              <li>L’assistant IA optionnel s’appuie sur les documents récupérés, distingue les citations textuelles de la synthèse, et signale son indisponibilité sans rien fabriquer.</li>
            </ul>
          </section>
        </div>
      </main>
    </div>
  `,
})
export class PrivacyPage {}
