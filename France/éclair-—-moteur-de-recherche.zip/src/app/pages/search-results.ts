import {
  ChangeDetectionStrategy,
  Component,
  OnInit,
  computed,
  inject,
  signal,
} from '@angular/core';
import {FormControl, FormGroup, ReactiveFormsModule} from '@angular/forms';
import {MatIconModule} from '@angular/material/icon';
import {ActivatedRoute, Router, RouterLink} from '@angular/router';
import {
  AssistantResponse,
  SearchHit,
  SearchMode,
  SearchResponse,
  SearchVertical,
} from '../../shared/eclair.types';
import {EclairEmblem} from '../components/eclair-emblem';
import {AccountModal, ImageModal, VoiceModal} from '../components/voice-image-modals';
import {EclairApi} from '../services/eclair-api';

interface SnippetPart {
  text: string;
  highlighted: boolean;
}

@Component({
  changeDetection: ChangeDetectionStrategy.OnPush,
  selector: 'app-search-results-page',
  imports: [
    ReactiveFormsModule,
    RouterLink,
    MatIconModule,
    EclairEmblem,
    VoiceModal,
    ImageModal,
    AccountModal,
  ],
  template: `
    <div class="min-h-screen bg-[#F8F9FB] text-[#0B1E46]">
      <!-- Calm Compact Header -->
      <header class="sticky top-0 z-30 border-b border-[#0B1E46]/10 bg-white/95 backdrop-blur-md">
        <div class="mx-auto flex max-w-[1280px] flex-wrap items-center justify-between gap-4 px-4 py-3 sm:px-6">
          <div class="flex items-center gap-5">
            <a
              routerLink="/"
              class="flex shrink-0 items-center gap-2 whitespace-nowrap focus-visible:outline-2 focus-visible:outline-[#114AC4]"
            >
              <app-eclair-emblem size="sm" />
              <span class="font-display-serif text-xl font-semibold text-[#0B1E46]">
                Éclair
              </span>
            </a>

            <form
              (ngSubmit)="submitNewSearch()"
              class="flex w-full min-w-[240px] max-w-[620px] items-center gap-1.5 rounded-full border border-[#E6D5B3] bg-[#F8F9FB] py-1 pr-1.5 pl-4 shadow-sm sm:w-[480px] lg:w-[580px]"
              role="search"
            >
              <mat-icon class="shrink-0 text-base text-[#0B1E46]/55">search</mat-icon>
              <label for="results-search-input" class="sr-only">Rechercher sur Éclair</label>
              <input
                id="results-search-input"
                type="text"
                [formControl]="queryControl"
                placeholder="Que souhaitez-vous découvrir ?"
                class="min-w-0 flex-1 bg-transparent py-1.5 text-sm font-medium text-[#0B1E46] focus:outline-none"
              />
              <button
                type="button"
                (click)="voiceModalOpen.set(true)"
                class="flex h-9 w-9 shrink-0 items-center justify-center rounded-full text-[#0B1E46]/65 hover:bg-[#0B1E46]/5 hover:text-[#114AC4]"
                aria-label="Recherche vocale"
              >
                <mat-icon class="text-lg">mic</mat-icon>
              </button>
              <button
                type="button"
                (click)="imageModalOpen.set(true)"
                class="flex h-9 w-9 shrink-0 items-center justify-center rounded-full text-[#0B1E46]/65 hover:bg-[#0B1E46]/5 hover:text-[#114AC4]"
                aria-label="Recherche par image"
              >
                <mat-icon class="text-lg">photo_camera</mat-icon>
              </button>
              <button
                type="submit"
                class="eclair-btn-sapphire rounded-full px-4 py-1.5 text-xs font-semibold whitespace-nowrap"
              >
                Rechercher
              </button>
            </form>
          </div>

          <div class="flex shrink-0 items-center gap-2.5">
            <a
              routerLink="/demonstration"
              class="hidden rounded-lg px-2.5 py-2 text-xs font-medium text-[#0B1E46]/75 hover:bg-[#0B1E46]/5 hover:text-[#0B1E46] sm:inline-flex whitespace-nowrap"
            >
              Démonstration
            </a>
            <a
              routerLink="/administration"
              class="rounded-lg px-2.5 py-2 text-xs font-medium text-[#0B1E46]/75 hover:bg-[#0B1E46]/5 hover:text-[#0B1E46] whitespace-nowrap"
            >
              Administration
            </a>
            <button
              type="button"
              (click)="accountModalOpen.set(true)"
              class="inline-flex h-9 items-center gap-1.5 rounded-xl border border-[#0B1E46]/15 bg-white px-3 text-xs font-medium text-[#0B1E46] hover:bg-[#0B1E46]/5 whitespace-nowrap"
            >
              <mat-icon class="text-base text-[#114AC4]">account_circle</mat-icon>
              <span>{{ api.isSignedIn() ? api.userProfile()?.display_name : 'Se connecter' }}</span>
            </button>
          </div>
        </div>

        <!-- Verticals & Search Mode Bar -->
        <div class="mx-auto flex max-w-[1280px] flex-wrap items-center justify-between gap-3 border-t border-[#0B1E46]/6 px-4 py-2 sm:px-6">
          <nav aria-label="Onglets de recherche" class="flex items-center gap-1 overflow-x-auto">
            @for (tab of verticals; track tab.id) {
              <button
                type="button"
                (click)="switchVertical(tab.id)"
                class="inline-flex items-center gap-1.5 rounded-lg px-3 py-1.5 text-xs font-medium transition-colors whitespace-nowrap shrink-0"
                [class]="vertical() === tab.id ? 'bg-[#0B1E46] text-white' : 'text-[#0B1E46]/75 hover:bg-[#0B1E46]/6 hover:text-[#0B1E46]'"
              >
                <mat-icon class="text-sm">{{ tab.icon }}</mat-icon>
                <span>{{ tab.label }}</span>
              </button>
            }
          </nav>

          <div class="flex items-center gap-2">
            <div class="inline-flex items-center rounded-lg border border-[#0B1E46]/12 bg-[#F8F9FB] p-0.5 text-xs">
              <button
                type="button"
                (click)="switchMode('local')"
                class="rounded-md px-2.5 py-1 font-medium transition-colors whitespace-nowrap"
                [class]="mode() === 'local' ? 'bg-white text-[#114AC4] shadow-sm' : 'text-[#0B1E46]/70'"
              >
                Corpus local
              </button>
              <button
                type="button"
                (click)="switchMode('external')"
                class="rounded-md px-2.5 py-1 font-medium transition-colors whitespace-nowrap"
                [class]="mode() === 'external' ? 'bg-white text-[#C93428] shadow-sm' : 'text-[#0B1E46]/70'"
              >
                Web externe
              </button>
            </div>

            <button
              type="button"
              (click)="toggleAssistant()"
              class="inline-flex items-center gap-1.5 rounded-lg border px-3 py-1.5 text-xs font-semibold transition-colors whitespace-nowrap"
              [class]="assistantOpen() ? 'border-[#114AC4] bg-[#114AC4] text-white' : 'border-[#E6D5B3] bg-white text-[#0B1E46] hover:bg-[#E6D5B3]/20'"
            >
              <mat-icon class="text-sm">auto_awesome</mat-icon>
              <span>Assistant IA</span>
            </button>
          </div>
        </div>
      </header>

      <!-- Main Workspace -->
      <main class="mx-auto max-w-[1280px] px-4 py-6 sm:px-6">
        <!-- Filters Row -->
        <form
          [formGroup]="filterForm"
          (ngSubmit)="applyFilters()"
          class="mb-6 flex flex-wrap items-end gap-3 rounded-2xl border border-[#0B1E46]/10 bg-white p-4"
        >
          <div class="min-w-[180px] flex-1">
            <label for="filter-domain" class="block text-[11px] font-semibold text-[#0B1E46]/70">
              Filtrer par domaine
            </label>
            <select
              id="filter-domain"
              formControlName="domain"
              class="mt-1 w-full rounded-lg border border-[#0B1E46]/15 bg-[#F8F9FB] px-3 py-2 text-xs text-[#0B1E46]"
            >
              <option value="">Tous les domaines autorisés</option>
              @for (facet of searchResponse()?.facets?.domains ?? []; track facet.domain) {
                <option [value]="facet.domain">
                  {{ facet.domain }} ({{ facet.count }})
                </option>
              }
            </select>
          </div>

          <div>
            <label for="filter-date-from" class="block text-[11px] font-semibold text-[#0B1E46]/70">
              Publié depuis
            </label>
            <input
              id="filter-date-from"
              type="date"
              formControlName="dateFrom"
              class="mt-1 rounded-lg border border-[#0B1E46]/15 bg-[#F8F9FB] px-3 py-1.5 text-xs text-[#0B1E46]"
            />
          </div>

          <div>
            <label for="filter-date-to" class="block text-[11px] font-semibold text-[#0B1E46]/70">
              Jusqu’au
            </label>
            <input
              id="filter-date-to"
              type="date"
              formControlName="dateTo"
              class="mt-1 rounded-lg border border-[#0B1E46]/15 bg-[#F8F9FB] px-3 py-1.5 text-xs text-[#0B1E46]"
            />
          </div>

          <div class="flex items-center gap-2">
            <button
              type="submit"
              class="inline-flex items-center gap-1.5 rounded-lg bg-[#0B1E46] px-3.5 py-2 text-xs font-medium text-white hover:bg-[#12264D]"
            >
              <mat-icon class="text-sm">filter_list</mat-icon>
              <span>Appliquer</span>
            </button>
            <button
              type="button"
              (click)="resetFilters()"
              class="rounded-lg border border-[#0B1E46]/15 px-3 py-2 text-xs font-medium text-[#0B1E46]/75 hover:bg-[#0B1E46]/5"
            >
              Réinitialiser
            </button>
          </div>
        </form>

        <!-- Search Mode & Honesty Banner -->
        @if (searchResponse(); as resp) {
          <div
            class="mb-5 flex flex-wrap items-center justify-between gap-3 rounded-xl border px-4 py-3 text-xs"
            [class]="resp.provider_status.available ? 'border-[#E6D5B3] bg-white text-[#0B1E46]' : 'border-[#C93428]/35 bg-[#C93428]/5 text-[#8C1D14]'"
          >
            <div class="flex items-start gap-2.5">
              <mat-icon class="mt-0.5 shrink-0 text-base" [class]="resp.provider_status.available ? 'text-[#114AC4]' : 'text-[#C93428]'">
                {{ resp.provider_status.available ? 'verified_user' : 'cloud_off' }}
              </mat-icon>
              <div>
                <span class="font-semibold">
                  {{ resp.mode === 'local' ? 'Mode Corpus local' : 'Mode Web externe' }}
                </span>
                <span class="mx-1.5" aria-hidden="true">·</span>
                <span>{{ resp.provider_status.honest_notice }}</span>
              </div>
            </div>
            @if (!resp.provider_status.available && resp.mode === 'external') {
              <button
                type="button"
                (click)="switchMode('local')"
                class="eclair-btn-sapphire shrink-0 rounded-lg px-3 py-1.5 text-xs font-semibold"
              >
                Revenir au Corpus local
              </button>
            }
          </div>

          <!-- Spelling Suggestion (Never silently replacing user's query) -->
          @if (resp.spelling_suggestion) {
            <div class="mb-5 flex items-center gap-2 rounded-xl border border-[#114AC4]/20 bg-[#114AC4]/5 px-4 py-2.5 text-sm text-[#0B1E46]">
              <mat-icon class="text-base text-[#114AC4]">spellcheck</mat-icon>
              <span>Votre requête a été conservée telle quelle. Essayez plutôt :</span>
              <button
                type="button"
                (click)="useSuggestion(resp.spelling_suggestion!)"
                class="font-semibold text-[#114AC4] underline underline-offset-2 hover:text-[#0B1E46]"
              >
                {{ resp.spelling_suggestion }}
              </button>
            </div>
          }
        }

        <div class="grid grid-cols-1 gap-8 lg:grid-cols-12">
          <!-- Primary Results Column -->
          <div [class]="assistantOpen() ? 'lg:col-span-7' : 'lg:col-span-12'">
            @if (loading()) {
              <div class="space-y-4">
                @for (s of [1, 2, 3]; track s) {
                  <div class="animate-pulse rounded-2xl border border-[#0B1E46]/8 bg-white p-5">
                    <div class="h-3 w-40 rounded bg-[#0B1E46]/10"></div>
                    <div class="mt-3 h-5 w-3/4 rounded bg-[#0B1E46]/15"></div>
                    <div class="mt-3 h-3 w-full rounded bg-[#0B1E46]/8"></div>
                    <div class="mt-2 h-3 w-5/6 rounded bg-[#0B1E46]/8"></div>
                  </div>
                }
              </div>
            } @else if (errorMessage()) {
              <div class="rounded-2xl border border-[#C93428]/30 bg-white p-6 text-sm text-[#8C1D14]">
                {{ errorMessage() }}
              </div>
            } @else if (hits().length === 0) {
              <!-- Honest Empty State -->
              <div class="rounded-2xl border border-[#0B1E46]/10 bg-white p-8">
                <div class="flex items-start gap-3">
                  <mat-icon class="text-2xl text-[#0B1E46]/45">search_off</mat-icon>
                  <div>
                    <h2 class="font-display-serif text-xl font-semibold text-[#0B1E46]">
                      Aucun document correspondant dans cet onglet
                    </h2>
                    <p class="mt-2 text-sm leading-relaxed text-[#0B1E46]/75">
                      @if (mode() === 'external') {
                        Le fournisseur Web externe n’a retourné aucun résultat (ou n’est pas configuré). Éclair n’invente pas de liens de substitution.
                      } @else {
                        Votre requête « {{ queryControl.value }} » ne correspond à aucun document indexé avec les filtres actuels. Vérifiez l’orthographe, retirez les guillemets ou élargissez la période.
                      }
                    </p>
                    <div class="mt-4 flex flex-wrap gap-3">
                      <button
                        type="button"
                        (click)="resetFilters()"
                        class="rounded-xl border border-[#0B1E46]/15 px-4 py-2 text-xs font-semibold text-[#0B1E46] hover:bg-[#0B1E46]/5"
                      >
                        Effacer les filtres
                      </button>
                      <button
                        type="button"
                        (click)="useSuggestion('La France qui innove')"
                        class="eclair-btn-sapphire rounded-xl px-4 py-2 text-xs font-semibold"
                      >
                        Essayer « La France qui innove »
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            } @else {
              <!-- Cartes Vertical Special Map Panel -->
              @if (vertical() === 'cartes') {
                <div class="mb-6 rounded-2xl border border-[#E6D5B3] bg-white p-5">
                  <div class="flex flex-wrap items-start justify-between gap-4 border-b border-[#0B1E46]/8 pb-4">
                    <div>
                      <h2 class="font-display-serif text-lg font-semibold text-[#0B1E46]">
                        Adaptateur de lieux Éclair Cartes
                      </h2>
                      <p class="mt-1 text-xs text-[#0B1E46]/70">
                        Repères géographiques vérifiés issus du corpus territorial. Le routage cartographique temps réel nécessite un adaptateur de tuiles externe séparé.
                      </p>
                    </div>
                  </div>
                  <div class="mt-4 grid grid-cols-1 gap-4 md:grid-cols-2">
                    <div class="relative flex h-60 items-center justify-center overflow-hidden rounded-xl border border-[#0B1E46]/10 bg-[#0B1E46] p-4 text-white">
                      <svg viewBox="0 0 260 220" class="h-full w-full" aria-label="Carte schématique de localisation en France">
                        <path
                          d="M115 20 L165 32 L195 65 L205 115 L182 170 L132 195 L72 178 L58 122 L40 78 L80 42 Z"
                          fill="#122B5E"
                          stroke="#E6D5B3"
                          stroke-opacity="0.45"
                          stroke-width="1.5"
                        />
                        @for (hit of hits(); track hit.document_id) {
                          @if (hit.place_metadata; as pm) {
                            <g class="cursor-pointer" (click)="selectedPlace.set(hit)">
                              <circle
                                [attr.cx]="projectLon(pm.longitude)"
                                [attr.cy]="projectLat(pm.latitude)"
                                r="7"
                                [attr.fill]="selectedPlace()?.document_id === hit.document_id ? '#C93428' : '#1B65F2'"
                                stroke="#F8F9FB"
                                stroke-width="2"
                              />
                              <text
                                [attr.x]="projectLon(pm.longitude) + 11"
                                [attr.y]="projectLat(pm.latitude) + 4"
                                fill="#F8F9FB"
                                font-size="10"
                                font-weight="600"
                              >
                                {{ pm.city }}
                              </text>
                            </g>
                          }
                        }
                      </svg>
                    </div>
                    <div class="flex flex-col justify-center space-y-2 text-xs">
                      @if (activePlace(); as place) {
                        <div class="rounded-xl border border-[#0B1E46]/10 bg-[#F8F9FB] p-4">
                          <div class="font-semibold text-[#0B1E46]">{{ place.title }}</div>
                          <div class="mt-1 text-[#0B1E46]/70">
                            {{ place.place_metadata?.address }}
                          </div>
                          <div class="mt-2 font-mono-tabular text-[11px] text-[#114AC4]">
                            {{ place.place_metadata?.latitude }}° N · {{ place.place_metadata?.longitude }}° E
                          </div>
                          <p class="mt-2 leading-relaxed text-[#0B1E46]/80">
                            {{ place.snippet }}
                          </p>
                          <a
                            [routerLink]="['/source', place.document_id]"
                            class="mt-3 inline-flex items-center gap-1 font-semibold text-[#114AC4] hover:underline"
                          >
                            <span>Ouvrir la fiche du lieu</span>
                            <mat-icon class="text-sm">arrow_forward</mat-icon>
                          </a>
                        </div>
                      }
                    </div>
                  </div>
                </div>
              }

              <!-- Images Vertical Grid -->
              @if (vertical() === 'images') {
                <div class="grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-3">
                  @for (hit of hits(); track hit.document_id) {
                    <article class="flex flex-col overflow-hidden rounded-2xl border border-[#0B1E46]/10 bg-white shadow-sm">
                      @if (hit.image_metadata; as img) {
                        <a [routerLink]="['/source', hit.document_id]" class="block overflow-hidden bg-[#0B1E46]/5">
                          <img
                            [src]="img.asset_url"
                            [alt]="img.alt_text"
                            referrerpolicy="no-referrer"
                            class="h-48 w-full object-cover transition-transform duration-300 hover:scale-[1.02]"
                          />
                        </a>
                        <div class="flex flex-1 flex-col justify-between p-4">
                          <div>
                            <a
                              [routerLink]="['/source', hit.document_id]"
                              class="font-display-serif text-base font-semibold text-[#0B1E46] hover:text-[#114AC4]"
                            >
                              {{ hit.title }}
                            </a>
                            <div class="mt-1.5 text-xs text-[#0B1E46]/65">
                              <span>{{ img.credit }}</span>
                              <span aria-hidden="true"> · </span>
                              <span class="font-mono-tabular">{{ img.dimensions }}</span>
                            </div>
                            <p class="mt-2 text-xs text-[#0B1E46]/75">
                              {{ img.license }}
                            </p>
                          </div>
                          <div class="mt-3 flex items-center justify-between border-t border-[#0B1E46]/8 pt-3 text-xs">
                            <a
                              [routerLink]="['/source', hit.document_id]"
                              class="font-semibold text-[#114AC4] hover:underline"
                            >
                              Métadonnées & droits
                            </a>
                            <button
                              type="button"
                              (click)="saveHit(hit)"
                              class="inline-flex items-center gap-1 font-medium text-[#0B1E46]/75 hover:text-[#114AC4]"
                            >
                              <mat-icon class="text-sm">{{ isSaved(hit.document_id) ? 'bookmark' : 'bookmark_border' }}</mat-icon>
                              <span>{{ isSaved(hit.document_id) ? 'Enregistré' : 'Enregistrer' }}</span>
                            </button>
                          </div>
                        </div>
                      }
                    </article>
                  }
                </div>
              } @else {
                <!-- Standard Web / Actualités / Savoirs / Cartes List -->
                <div class="space-y-4">
                  @for (hit of hits(); track hit.document_id) {
                    <article class="rounded-2xl border border-[#0B1E46]/10 bg-white p-5 transition-colors hover:border-[#E6D5B3]">
                      <!-- Unboxed Metadata Line (Zero-Pill Rule) -->
                      <div class="flex flex-wrap items-center gap-x-2 gap-y-1 text-xs text-[#0B1E46]/65">
                        <span class="font-semibold text-[#0B1E46]/85">{{ hit.source_name }}</span>
                        <span aria-hidden="true">·</span>
                        <span class="font-mono-tabular text-[11px]">{{ hit.domain }}</span>
                        @if (hit.published_at) {
                          <span aria-hidden="true">·</span>
                          <time [attr.datetime]="hit.published_at" class="tabular-nums">
                            {{ formatDate(hit.published_at) }}
                          </time>
                        }
                        <span aria-hidden="true">·</span>
                        <span>{{ formatContentType(hit.content_type) }}</span>
                      </div>

                      <h2 class="mt-2">
                        <a
                          [routerLink]="['/source', hit.document_id]"
                          class="font-display-serif text-xl font-semibold text-[#0B1E46] transition-colors hover:text-[#114AC4]"
                        >
                          {{ hit.title }}
                        </a>
                      </h2>

                      <p class="mt-2 max-w-[75ch] text-sm leading-relaxed text-[#0B1E46]/80">
                        @for (part of splitSnippet(hit); track $index) {
                          @if (part.highlighted) {
                            <mark class="rounded bg-[#E6D5B3]/55 px-0.5 font-semibold text-[#0B1E46]">{{ part.text }}</mark>
                          } @else {
                            <span>{{ part.text }}</span>
                          }
                        }
                      </p>

                      <div class="mt-4 flex flex-wrap items-center justify-between gap-3 border-t border-[#0B1E46]/8 pt-3 text-xs">
                        <div class="flex flex-wrap items-center gap-4">
                          <a
                            [routerLink]="['/source', hit.document_id]"
                            class="inline-flex items-center gap-1 font-semibold text-[#114AC4] hover:underline"
                          >
                            <mat-icon class="text-sm">article</mat-icon>
                            <span>Consulter le document</span>
                          </a>
                          <span class="text-[#0B1E46]/60">{{ hit.rights_metadata }}</span>
                        </div>

                        <div class="flex items-center gap-3">
                          <button
                            type="button"
                            (click)="saveHit(hit)"
                            class="inline-flex items-center gap-1 rounded-lg px-2.5 py-1.5 font-medium text-[#0B1E46]/80 hover:bg-[#0B1E46]/5 hover:text-[#114AC4]"
                          >
                            <mat-icon class="text-sm">{{ isSaved(hit.document_id) ? 'bookmark' : 'bookmark_border' }}</mat-icon>
                            <span>{{ isSaved(hit.document_id) ? 'Enregistré' : 'Enregistrer' }}</span>
                          </button>
                          <button
                            type="button"
                            (click)="openReport(hit)"
                            class="inline-flex items-center gap-1 rounded-lg px-2.5 py-1.5 font-medium text-[#0B1E46]/60 hover:bg-[#C93428]/8 hover:text-[#C93428]"
                          >
                            <mat-icon class="text-sm">flag</mat-icon>
                            <span>Signaler</span>
                          </button>
                        </div>
                      </div>
                    </article>
                  }
                </div>
              }

              <!-- Cursor Pagination -->
              @if (nextCursor()) {
                <div class="mt-6 flex justify-center">
                  <button
                    type="button"
                    [disabled]="loadingMore()"
                    (click)="loadMore()"
                    class="inline-flex items-center gap-2 rounded-xl border border-[#0B1E46]/20 bg-white px-5 py-2.5 text-sm font-semibold text-[#0B1E46] shadow-sm hover:border-[#114AC4] hover:text-[#114AC4]"
                  >
                    <mat-icon class="text-base">expand_more</mat-icon>
                    <span>{{ loadingMore() ? 'Chargement…' : 'Afficher les résultats suivants' }}</span>
                  </button>
                </div>
              }
            }
          </div>

          <!-- Optional Retrieval-Grounded AI Assistant Column -->
          @if (assistantOpen()) {
            <aside
              aria-label="Assistant documentaire sourcé"
              class="lg:col-span-5"
            >
              <div class="sticky top-32 rounded-2xl border border-[#114AC4]/25 bg-white p-5 shadow-sm">
                <div class="flex items-start justify-between gap-3 border-b border-[#0B1E46]/10 pb-3">
                  <div class="flex items-center gap-2.5">
                    <div class="flex h-9 w-9 items-center justify-center rounded-xl bg-[#114AC4]/10 text-[#114AC4]">
                      <mat-icon>auto_awesome</mat-icon>
                    </div>
                    <div>
                      <h2 class="font-display-serif text-lg font-semibold text-[#0B1E46]">
                        Assistant documentaire Éclair
                      </h2>
                      <p class="text-[11px] text-[#0B1E46]/65">
                        Réponse distincte des résultats ordinaires · Ancrée sur le corpus
                      </p>
                    </div>
                  </div>
                  <button
                    type="button"
                    (click)="assistantOpen.set(false)"
                    class="rounded-lg p-1.5 text-[#0B1E46]/60 hover:bg-[#0B1E46]/5"
                    aria-label="Fermer l’assistant"
                  >
                    <mat-icon class="text-base">close</mat-icon>
                  </button>
                </div>

                @if (assistantLoading()) {
                  <div class="mt-4 space-y-3">
                    <div class="h-4 w-2/3 animate-pulse rounded bg-[#0B1E46]/10"></div>
                    <div class="h-20 animate-pulse rounded-xl bg-[#0B1E46]/6"></div>
                  </div>
                } @else if (assistantResponse(); as ans) {
                  <div class="mt-4 space-y-4 text-sm">
                    <div class="rounded-xl border border-[#0B1E46]/10 bg-[#F8F9FB] p-3 text-xs text-[#0B1E46]/80">
                      {{ ans.notice }}
                    </div>

                    @if (ans.status === 'grounded' && ans.summary) {
                      <div>
                        <h3 class="text-xs font-bold tracking-wide text-[#114AC4]">
                          Synthèse générée à partir des sources
                        </h3>
                        <p class="mt-1.5 leading-relaxed text-[#0B1E46]">
                          {{ ans.summary }}
                        </p>
                      </div>
                    } @else {
                      <div class="rounded-xl border border-[#C93428]/30 bg-[#C93428]/5 p-3.5 text-xs text-[#8C1D14]">
                        {{ ans.uncertainty_note }}
                      </div>
                    }

                    @if (ans.quotations.length > 0) {
                      <div>
                        <h3 class="text-xs font-bold tracking-wide text-[#0B1E46]">
                          Citations textuelles exactes (verbatim)
                        </h3>
                        <div class="mt-2 space-y-2.5">
                          @for (quote of ans.quotations; track quote.document_id + quote.exact_quote) {
                            <blockquote class="rounded-xl border border-[#E6D5B3] bg-[#F8F9FB] p-3 text-xs leading-relaxed text-[#0B1E46]/90">
                              <p class="italic">« {{ quote.exact_quote }} »</p>
                              <footer class="mt-1.5 font-medium text-[#0B1E46]">
                                — {{ quote.source_name }} ·
                                <a [routerLink]="['/source', quote.document_id]" class="text-[#114AC4] hover:underline">
                                  {{ quote.title }}
                                </a>
                              </footer>
                            </blockquote>
                          }
                        </div>
                      </div>
                    }

                    @if (ans.status === 'grounded') {
                      <div class="rounded-xl border border-[#0B1E46]/10 bg-[#F8F9FB] p-3 text-xs text-[#0B1E46]/75">
                        <strong class="block text-[#0B1E46]">Incertitude et limites :</strong>
                        {{ ans.uncertainty_note }}
                      </div>
                    }

                    @if (ans.citations.length > 0) {
                      <div>
                        <h3 class="text-xs font-bold text-[#0B1E46]">Documents liés</h3>
                        <ul class="mt-1.5 space-y-1.5 text-xs">
                          @for (cit of ans.citations; track cit.document_id) {
                            <li>
                              <a
                                [routerLink]="['/source', cit.document_id]"
                                class="inline-flex items-center gap-1.5 font-medium text-[#114AC4] hover:underline"
                              >
                                <mat-icon class="text-sm">link</mat-icon>
                                <span>{{ cit.title }} ({{ cit.source_name }})</span>
                              </a>
                            </li>
                          }
                        </ul>
                      </div>
                    }
                  </div>
                } @else {
                  <div class="mt-4 text-xs text-[#0B1E46]/70">
                    <p>Posez une question ou lancez une recherche pour obtenir une synthèse ancrée dans les documents du corpus.</p>
                    <button
                      type="button"
                      (click)="runAssistant()"
                      class="eclair-btn-sapphire mt-3 inline-flex items-center gap-1.5 rounded-xl px-4 py-2 text-xs font-semibold"
                    >
                      <mat-icon class="text-sm">auto_awesome</mat-icon>
                      <span>Générer une synthèse sourcée</span>
                    </button>
                  </div>
                }
              </div>
            </aside>
          }
        </div>
      </main>

      <!-- Abuse Report Modal -->
      @if (reportTarget(); as target) {
        <div
          class="fixed inset-0 z-50 flex items-center justify-center bg-[#07142E]/70 p-4 backdrop-blur-sm"
          role="dialog"
          aria-modal="true"
        >
          <div class="w-full max-w-md rounded-2xl border border-[#E6D5B3] bg-white p-6 text-[#0B1E46] shadow-2xl">
            <h2 class="font-display-serif text-lg font-semibold">Signaler un document ou une erreur</h2>
            <p class="mt-1 text-xs text-[#0B1E46]/70">{{ target.title }}</p>
            <form [formGroup]="reportForm" (ngSubmit)="submitReport()" class="mt-4 space-y-3">
              <div>
                <label for="rep-reason" class="block text-xs font-semibold">Motif</label>
                <select id="rep-reason" formControlName="reason" class="mt-1 w-full rounded-xl border border-[#0B1E46]/20 px-3 py-2 text-xs">
                  <option value="Contenu inexact ou obsolète">Contenu inexact ou obsolète</option>
                  <option value="Droits d’auteur / demande de retrait">Droits d’auteur / demande de retrait</option>
                  <option value="Contenu illicite ou abus">Contenu illicite ou abus</option>
                </select>
              </div>
              <div>
                <label for="rep-details" class="block text-xs font-semibold">Précisions</label>
                <textarea id="rep-details" rows="3" formControlName="details" class="mt-1 w-full rounded-xl border border-[#0B1E46]/20 px-3 py-2 text-xs"></textarea>
              </div>
              @if (reportStatus()) {
                <p class="text-xs font-medium text-[#114AC4]">{{ reportStatus() }}</p>
              }
              <div class="flex justify-end gap-2 pt-2">
                <button type="button" (click)="reportTarget.set(null)" class="rounded-xl border border-[#0B1E46]/15 px-4 py-2 text-xs font-medium">
                  Fermer
                </button>
                <button type="submit" class="rounded-xl bg-[#C93428] px-4 py-2 text-xs font-semibold text-white">
                  Envoyer le signalement
                </button>
              </div>
            </form>
          </div>
        </div>
      }

      <app-voice-modal
        [open]="voiceModalOpen()"
        (closed)="voiceModalOpen.set(false)"
        (searchSubmitted)="useSuggestion($event)"
      />
      <app-image-modal
        [open]="imageModalOpen()"
        (closed)="imageModalOpen.set(false)"
        (hitSelected)="openDocument($event)"
      />
      <app-account-modal
        [open]="accountModalOpen()"
        (closed)="accountModalOpen.set(false)"
      />
    </div>
  `,
})
export class SearchResultsPage implements OnInit {
  private readonly route = inject(ActivatedRoute);
  private readonly router = inject(Router);
  readonly api = inject(EclairApi);

  readonly queryControl = new FormControl('', {nonNullable: true});
  readonly filterForm = new FormGroup({
    domain: new FormControl('', {nonNullable: true}),
    dateFrom: new FormControl('', {nonNullable: true}),
    dateTo: new FormControl('', {nonNullable: true}),
  });

  readonly vertical = signal<SearchVertical>('web');
  readonly mode = signal<SearchMode>('local');
  readonly loading = signal(false);
  readonly loadingMore = signal(false);
  readonly errorMessage = signal<string | null>(null);
  readonly searchResponse = signal<SearchResponse | null>(null);
  readonly hits = signal<SearchHit[]>([]);
  readonly nextCursor = signal<string | null>(null);
  readonly selectedPlace = signal<SearchHit | null>(null);

  readonly assistantOpen = signal(false);
  readonly assistantLoading = signal(false);
  readonly assistantResponse = signal<AssistantResponse | null>(null);

  readonly voiceModalOpen = signal(false);
  readonly imageModalOpen = signal(false);
  readonly accountModalOpen = signal(false);

  readonly reportTarget = signal<SearchHit | null>(null);
  readonly reportStatus = signal<string | null>(null);
  readonly reportForm = new FormGroup({
    reason: new FormControl('Contenu inexact ou obsolète', {nonNullable: true}),
    details: new FormControl('', {nonNullable: true}),
  });

  readonly activePlace = computed(() => {
    const sel = this.selectedPlace();
    if (sel) return sel;
    return this.hits().find((h) => Boolean(h.place_metadata)) ?? null;
  });

  readonly verticals: {id: SearchVertical; label: string; icon: string}[] = [
    {id: 'web', label: 'Web', icon: 'language'},
    {id: 'images', label: 'Images', icon: 'image'},
    {id: 'actualites', label: 'Actualités', icon: 'newspaper'},
    {id: 'savoirs', label: 'Savoirs', icon: 'menu_book'},
    {id: 'cartes', label: 'Cartes', icon: 'location_on'},
  ];

  ngOnInit(): void {
    this.route.queryParamMap.subscribe((params) => {
      const q = params.get('q') ?? '';
      const v = (params.get('vertical') as SearchVertical) || 'web';
      const m: SearchMode = params.get('mode') === 'external' ? 'external' : 'local';
      const domain = params.get('domain') ?? '';
      const dateFrom = params.get('dateFrom') ?? '';
      const dateTo = params.get('dateTo') ?? '';
      const assistant = params.get('assistant') === '1';

      this.queryControl.setValue(q);
      this.vertical.set(v);
      this.mode.set(m);
      this.filterForm.patchValue({domain, dateFrom, dateTo});
      this.assistantOpen.set(assistant);

      void this.executeSearch();
      if (assistant && q.trim()) {
        void this.runAssistant();
      }
    });
  }

  async executeSearch(cursor: string | null = null): Promise<void> {
    if (cursor) {
      this.loadingMore.set(true);
    } else {
      this.loading.set(true);
      this.errorMessage.set(null);
    }

    try {
      const {domain, dateFrom, dateTo} = this.filterForm.getRawValue();
      const res = await this.api.search({
        q: this.queryControl.value.trim(),
        vertical: this.vertical(),
        mode: this.mode(),
        domain: domain || undefined,
        dateFrom: dateFrom || undefined,
        dateTo: dateTo || undefined,
        cursor,
        limit: 8,
      });
      this.searchResponse.set(res);
      if (cursor) {
        this.hits.update((prev) => [...prev, ...res.results]);
      } else {
        this.hits.set(res.results);
      }
      this.nextCursor.set(res.next_cursor);
    } catch {
      this.errorMessage.set('Erreur lors de la communication avec le moteur de recherche Éclair.');
    } finally {
      this.loading.set(false);
      this.loadingMore.set(false);
    }
  }

  loadMore(): void {
    const c = this.nextCursor();
    if (c) void this.executeSearch(c);
  }

  submitNewSearch(): void {
    this.assistantResponse.set(null);
    void this.router.navigate(['/recherche'], {
      queryParams: {
        q: this.queryControl.value.trim(),
        vertical: this.vertical(),
        mode: this.mode(),
        domain: this.filterForm.value.domain || undefined,
        dateFrom: this.filterForm.value.dateFrom || undefined,
        dateTo: this.filterForm.value.dateTo || undefined,
        ...(this.assistantOpen() ? {assistant: '1'} : {}),
      },
    });
  }

  switchVertical(v: SearchVertical): void {
    this.vertical.set(v);
    this.submitNewSearch();
  }

  switchMode(m: SearchMode): void {
    this.mode.set(m);
    this.submitNewSearch();
  }

  applyFilters(): void {
    this.submitNewSearch();
  }

  resetFilters(): void {
    this.filterForm.reset({domain: '', dateFrom: '', dateTo: ''});
    this.submitNewSearch();
  }

  useSuggestion(text: string): void {
    this.queryControl.setValue(text);
    this.submitNewSearch();
  }

  toggleAssistant(): void {
    const next = !this.assistantOpen();
    this.assistantOpen.set(next);
    if (next && this.queryControl.value.trim() && !this.assistantResponse()) {
      void this.runAssistant();
    }
  }

  async runAssistant(): Promise<void> {
    const q = this.queryControl.value.trim();
    if (!q) return;
    this.assistantLoading.set(true);
    try {
      const res = await this.api.askAssistant(q);
      this.assistantResponse.set(res);
    } finally {
      this.assistantLoading.set(false);
    }
  }

  isSaved(documentId: string): boolean {
    return this.api.savedResults().some((s) => s.document_id === documentId);
  }

  async saveHit(hit: SearchHit): Promise<void> {
    if (!this.api.isSignedIn()) {
      this.accountModalOpen.set(true);
      return;
    }
    const existing = this.api
      .savedResults()
      .find((s) => s.document_id === hit.document_id);
    if (existing) {
      await this.api.removeSavedResult(existing.saved_id);
    } else {
      await this.api.saveResult({
        document_id: hit.document_id,
        title: hit.title,
        source_url: hit.source_url,
        domain: hit.domain,
        snippet: hit.snippet,
      });
    }
  }

  openReport(hit: SearchHit): void {
    this.reportStatus.set(null);
    this.reportTarget.set(hit);
  }

  async submitReport(): Promise<void> {
    const target = this.reportTarget();
    if (!target) return;
    const {reason, details} = this.reportForm.getRawValue();
    await this.api.submitAbuseReport({
      document_id: target.document_id,
      source_url: target.source_url,
      reason,
      details,
    });
    this.reportStatus.set('Signalement enregistré et transmis à l’équipe d’administration.');
    this.reportForm.patchValue({details: ''});
  }

  openDocument(docId: string): void {
    void this.router.navigate(['/source', docId]);
  }

  splitSnippet(hit: SearchHit): SnippetPart[] {
    if (!hit.highlight_terms || hit.highlight_terms.length === 0) {
      return [{text: hit.snippet, highlighted: false}];
    }
    const termSet = new Set(hit.highlight_terms.map((t) => t.toLowerCase()));
    const tokens = hit.snippet.split(/(\s+|[.,;:!?()«»"']+)/);
    return tokens.map((tok) => ({
      text: tok,
      highlighted: termSet.has(tok.toLowerCase()),
    }));
  }

  formatDate(iso: string): string {
    try {
      return new Intl.DateTimeFormat('fr-FR', {
        day: 'numeric',
        month: 'long',
        year: 'numeric',
      }).format(new Date(iso));
    } catch {
      return iso;
    }
  }

  formatContentType(ct: string): string {
    switch (ct) {
      case 'text/html':
        return 'Page web';
      case 'text/markdown':
        return 'Markdown';
      case 'text/plain':
        return 'Texte brut';
      case 'application/pdf':
        return 'Document PDF';
      case 'image/jpeg':
        return 'Image';
      case 'application/geo+json':
        return 'Fiche de lieu';
      default:
        return ct;
    }
  }

  projectLon(lon: number): number {
    // Map France longitude [-5..9] -> [45..215]
    return Math.round(45 + ((lon + 5) / 14) * 170);
  }

  projectLat(lat: number): number {
    // Map France latitude [41..51] -> [195..25]
    return Math.round(195 - ((lat - 41) / 10) * 170);
  }
}
