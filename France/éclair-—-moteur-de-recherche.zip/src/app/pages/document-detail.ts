import {ChangeDetectionStrategy, Component, OnInit, inject, signal} from '@angular/core';
import {MatIconModule} from '@angular/material/icon';
import {ActivatedRoute, RouterLink} from '@angular/router';
import {DocumentRecord} from '../../shared/eclair.types';
import {EclairEmblem} from '../components/eclair-emblem';
import {AccountModal} from '../components/voice-image-modals';
import {EclairApi} from '../services/eclair-api';

@Component({
  changeDetection: ChangeDetectionStrategy.OnPush,
  selector: 'app-document-detail-page',
  imports: [RouterLink, MatIconModule, EclairEmblem, AccountModal],
  template: `
    <div class="min-h-screen bg-[#F8F9FB] text-[#0B1E46]">
      <header class="border-b border-[#0B1E46]/10 bg-white">
        <div class="mx-auto flex h-16 max-w-[1040px] items-center justify-between gap-4 px-4 sm:px-6">
          <div class="flex items-center gap-4">
            <a routerLink="/" class="flex items-center gap-2 whitespace-nowrap">
              <app-eclair-emblem size="sm" />
              <span class="font-display-serif text-xl font-semibold text-[#0B1E46]">Éclair</span>
            </a>
            <span class="text-[#0B1E46]/30" aria-hidden="true">/</span>
            <a routerLink="/recherche" class="text-xs font-medium text-[#114AC4] hover:underline whitespace-nowrap">
              Retour aux résultats
            </a>
          </div>
          <button
            type="button"
            (click)="accountModalOpen.set(true)"
            class="inline-flex h-9 items-center gap-1.5 rounded-xl border border-[#0B1E46]/15 bg-white px-3 text-xs font-medium text-[#0B1E46]"
          >
            <mat-icon class="text-base text-[#114AC4]">account_circle</mat-icon>
            <span>{{ api.isSignedIn() ? api.userProfile()?.display_name : 'Se connecter' }}</span>
          </button>
        </div>
      </header>

      <main class="mx-auto max-w-[900px] px-4 py-8 sm:px-6">
        @if (loading()) {
          <div class="h-48 animate-pulse rounded-2xl border border-[#0B1E46]/10 bg-white"></div>
        } @else if (errorText()) {
          <div class="rounded-2xl border border-[#C93428]/30 bg-white p-6 text-sm text-[#8C1D14]">
            {{ errorText() }}
          </div>
        } @else if (doc(); as d) {
          <article class="rounded-2xl border border-[#E6D5B3] bg-white p-6 sm:p-8 shadow-sm">
            <div class="flex flex-wrap items-center gap-2 text-xs text-[#0B1E46]/65">
              <span class="font-semibold text-[#0B1E46]">{{ d.source_name }}</span>
              <span aria-hidden="true">·</span>
              <span class="font-mono-tabular">{{ d.domain }}</span>
              @if (d.published_at) {
                <span aria-hidden="true">·</span>
                <span>Publié le {{ d.published_at }}</span>
              }
              <span aria-hidden="true">·</span>
              <span>{{ d.content_type }}</span>
            </div>

            <h1 class="mt-3 font-display-serif text-2xl font-semibold text-[#0B1E46] sm:text-3xl">
              {{ d.title }}
            </h1>

            @if (d.image_metadata; as img) {
              <figure class="mt-6 overflow-hidden rounded-xl border border-[#0B1E46]/10">
                <img
                  [src]="img.asset_url"
                  [alt]="img.alt_text"
                  referrerpolicy="no-referrer"
                  class="max-h-[460px] w-full object-cover"
                />
                <figcaption class="bg-[#F8F9FB] px-4 py-2.5 text-xs text-[#0B1E46]/75">
                  {{ img.credit }} · {{ img.license }} · {{ img.dimensions }}
                </figcaption>
              </figure>
            }

            @if (d.place_metadata; as pm) {
              <div class="mt-5 rounded-xl border border-[#0B1E46]/10 bg-[#F8F9FB] p-4 text-xs text-[#0B1E46]/85">
                <div class="font-semibold text-[#0B1E46]">{{ pm.city }} — {{ pm.region }}</div>
                <div class="mt-1">{{ pm.address }}</div>
                <div class="mt-1 font-mono-tabular text-[#114AC4]">
                  Coordonnées : {{ pm.latitude }}° N, {{ pm.longitude }}° E
                </div>
              </div>
            }

            <div class="mt-6 max-w-[72ch] space-y-4 text-base leading-relaxed text-[#0B1E46]/90">
              <p>{{ d.body_text }}</p>
            </div>

            <div class="mt-8 flex flex-wrap items-center justify-between gap-4 border-t border-[#0B1E46]/10 pt-5">
              <div class="space-y-1 text-xs text-[#0B1E46]/70">
                <div><strong>Droits :</strong> {{ d.rights_metadata }}</div>
                <div class="font-mono-tabular">
                  <strong>URL canonique :</strong> {{ d.canonical_url }}
                </div>
                <div class="font-mono-tabular">
                  <strong>Empreinte SHA-256 :</strong> {{ d.content_hash }} · <strong>Indexé le :</strong> {{ d.fetched_at.slice(0, 10) }}
                </div>
              </div>

              <button
                type="button"
                (click)="toggleSave(d)"
                class="eclair-btn-sapphire inline-flex items-center gap-2 rounded-xl px-4 py-2.5 text-xs font-semibold"
              >
                <mat-icon class="text-base">{{ isSaved(d.document_id) ? 'bookmark' : 'bookmark_border' }}</mat-icon>
                <span>{{ isSaved(d.document_id) ? 'Enregistré dans mon compte' : 'Enregistrer ce document' }}</span>
              </button>
            </div>
          </article>
        }
      </main>

      <app-account-modal
        [open]="accountModalOpen()"
        (closed)="accountModalOpen.set(false)"
      />
    </div>
  `,
})
export class DocumentDetailPage implements OnInit {
  private readonly route = inject(ActivatedRoute);
  readonly api = inject(EclairApi);

  readonly doc = signal<DocumentRecord | null>(null);
  readonly loading = signal(true);
  readonly errorText = signal<string | null>(null);
  readonly accountModalOpen = signal(false);

  ngOnInit(): void {
    this.route.paramMap.subscribe(async (params) => {
      const id = params.get('document_id');
      if (!id) return;
      this.loading.set(true);
      this.errorText.set(null);
      try {
        const res = await this.api.getDocument(id);
        this.doc.set(res);
      } catch {
        this.errorText.set('Impossible de charger ce document depuis l’index.');
      } finally {
        this.loading.set(false);
      }
    });
  }

  isSaved(docId: string): boolean {
    return this.api.savedResults().some((s) => s.document_id === docId);
  }

  async toggleSave(d: DocumentRecord): Promise<void> {
    if (!this.api.isSignedIn()) {
      this.accountModalOpen.set(true);
      return;
    }
    const existing = this.api
      .savedResults()
      .find((s) => s.document_id === d.document_id);
    if (existing) {
      await this.api.removeSavedResult(existing.saved_id);
    } else {
      await this.api.saveResult({
        document_id: d.document_id,
        title: d.title,
        source_url: d.source_url,
        domain: d.domain,
        snippet: d.excerpt,
      });
    }
  }
}
