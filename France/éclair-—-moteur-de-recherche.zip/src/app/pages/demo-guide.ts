import {ChangeDetectionStrategy, Component} from '@angular/core';
import {MatIconModule} from '@angular/material/icon';
import {RouterLink} from '@angular/router';
import {EclairEmblem} from '../components/eclair-emblem';

interface DemoStep {
  num: string;
  title: string;
  description: string;
  route: string;
  queryParams?: Record<string, string>;
  cta: string;
}

@Component({
  changeDetection: ChangeDetectionStrategy.OnPush,
  selector: 'app-demo-guide-page',
  imports: [RouterLink, MatIconModule, EclairEmblem],
  template: `
    <div class="min-h-screen bg-[#F8F9FB] text-[#0B1E46]">
      <header class="border-b border-[#0B1E46]/10 bg-white">
        <div class="mx-auto flex h-16 max-w-[1160px] items-center justify-between px-4 sm:px-6">
          <a routerLink="/" class="flex items-center gap-2 whitespace-nowrap">
            <app-eclair-emblem size="sm" />
            <span class="font-display-serif text-xl font-semibold text-[#0B1E46]">Éclair</span>
          </a>
          <div class="flex items-center gap-4 text-xs font-medium">
            <a routerLink="/" class="hover:text-[#114AC4]">Accueil</a>
            <a routerLink="/recherche" class="hover:text-[#114AC4]">Recherche</a>
            <a routerLink="/administration" class="hover:text-[#114AC4]">Administration</a>
          </div>
        </div>
      </header>

      <main class="mx-auto max-w-[1040px] px-4 py-10 sm:px-6">
        <div class="border-b border-[#E6D5B3] pb-6">
          <h1 class="font-display-serif text-3xl font-semibold text-[#0B1E46] sm:text-4xl">
            Démonstration reproductible — Éclair
          </h1>
          <p class="mt-2 max-w-[75ch] text-sm leading-relaxed text-[#0B1E46]/80">
            Ce parcours en douze étapes permet de vérifier de bout en bout l’interface fidèle à la maquette, le moteur lexical français BM25, la tolérance aux accents, les filtres, l’ingestion sécurisée, l’assistant sourcé et l’honnêteté face aux résultats absents ou fournisseurs indisponibles.
          </p>
        </div>

        <div class="mt-8 grid grid-cols-1 gap-4 md:grid-cols-2">
          @for (step of steps; track step.num) {
            <div class="flex flex-col justify-between rounded-2xl border border-[#0B1E46]/10 bg-white p-5">
              <div>
                <div class="font-mono-tabular text-xs font-semibold text-[#114AC4]">
                  {{ step.num }}
                </div>
                <h2 class="mt-1 font-display-serif text-lg font-semibold text-[#0B1E46]">
                  {{ step.title }}
                </h2>
                <p class="mt-2 text-xs leading-relaxed text-[#0B1E46]/75">
                  {{ step.description }}
                </p>
              </div>
              <div class="mt-4 pt-3 border-t border-[#0B1E46]/8">
                <a
                  [routerLink]="step.route"
                  [queryParams]="step.queryParams"
                  class="inline-flex items-center gap-1.5 text-xs font-semibold text-[#114AC4] hover:underline"
                >
                  <span>{{ step.cta }}</span>
                  <mat-icon class="text-sm">arrow_forward</mat-icon>
                </a>
              </div>
            </div>
          }
        </div>
      </main>
    </div>
  `,
})
export class DemoGuidePage {
  readonly steps: DemoStep[] = [
    {
      num: '01.',
      title: 'Page d’accueil fidèle à la maquette',
      description: 'Panorama parisien de la Seine, emblème saphir, barre translucide champagne et panneau inférieur des services.',
      route: '/',
      cta: 'Ouvrir l’accueil',
    },
    {
      num: '02–03.',
      title: 'Requête française et résultats BM25 réels',
      description: 'Rechercher « Les arts et les idées » dans le corpus documentaire avec extraits contextuels et pondération du titre.',
      route: '/recherche',
      queryParams: {q: 'Les arts et les idées', vertical: 'web', mode: 'local'},
      cta: 'Exécuter la requête',
    },
    {
      num: '04.',
      title: 'Recherche avec et sans accents',
      description: 'Comparer « Voyages et decouvertes » sans accents : la normalisation NFD retrouve « Voyages et découvertes » tout en préservant les accents affichés.',
      route: '/recherche',
      queryParams: {q: 'Voyages et decouvertes', vertical: 'web', mode: 'local'},
      cta: 'Tester sans accents',
    },
    {
      num: '05.',
      title: 'Filtrer par source et par date',
      description: 'Explorer l’onglet Actualités filtré par domaine (actualites.eclair.fr) et plage de publication de novembre 2026.',
      route: '/recherche',
      queryParams: {
        q: '',
        vertical: 'actualites',
        mode: 'local',
        domain: 'actualites.eclair.fr',
        dateFrom: '2026-11-01',
      },
      cta: 'Appliquer les filtres',
    },
    {
      num: '06.',
      title: 'Consulter un document sourcé',
      description: 'Ouvrir la fiche complète d’un document avec URL canonique, empreinte SHA-256 et mention des droits.',
      route: '/source/doc-grand-palais-02',
      cta: 'Ouvrir la fiche Grand Palais',
    },
    {
      num: '07.',
      title: 'Enregistrer un résultat',
      description: 'Créer un compte optionnel ou se connecter sur la page de résultats pour enregistrer et exporter ses sélections.',
      route: '/recherche',
      queryParams: {q: 'La France qui innove', vertical: 'web', mode: 'local'},
      cta: 'Tester l’enregistrement',
    },
    {
      num: '08–09.',
      title: 'Ingérer un document et le retrouver',
      description: 'Accéder à la console d’administration pour ingérer un texte, Markdown, HTML ou PDF et le retrouver immédiatement via BM25.',
      route: '/administration',
      cta: 'Ouvrir l’administration',
    },
    {
      num: '10.',
      title: 'Synthèse par l’assistant IA sourcé',
      description: 'Générer une réponse distinguant la synthèse des citations verbatim et indiquant les limites du corpus.',
      route: '/recherche',
      queryParams: {q: 'La France qui innove', vertical: 'web', mode: 'local', assistant: '1'},
      cta: 'Ouvrir l’assistant sourcé',
    },
    {
      num: '11.',
      title: 'Gérer l’absence de résultats honnêtement',
      description: 'Soumettre une requête sans correspondance : Éclair affiche un état vide transparent et une suggestion orthographique éventuelle.',
      route: '/recherche',
      queryParams: {q: 'xylophoniste antarctique inexistant', vertical: 'web', mode: 'local'},
      cta: 'Tester zéro résultat',
    },
    {
      num: '12.',
      title: 'Fournisseur Web externe indisponible sans fabrication',
      description: 'Basculer sur le mode Web externe sans identifiants : Éclair signale l’absence de fournisseur configuré sans inventer de liens.',
      route: '/recherche',
      queryParams: {q: 'Paris', vertical: 'web', mode: 'external'},
      cta: 'Tester le mode externe',
    },
  ];
}
