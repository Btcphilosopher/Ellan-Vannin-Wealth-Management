import {ChangeDetectionStrategy, Component, OnInit, inject, signal} from '@angular/core';
import {FormControl, FormGroup, ReactiveFormsModule, Validators} from '@angular/forms';
import {MatIconModule} from '@angular/material/icon';
import {RouterLink} from '@angular/router';
import {
  AbuseReport,
  ApprovedSource,
  DocumentRecord,
  DuplicateCluster,
  EvaluationRunResult,
  IngestionJob,
  SearchVertical,
} from '../../shared/eclair.types';
import {EclairEmblem} from '../components/eclair-emblem';
import {AdminOverview, EclairApi} from '../services/eclair-api';

type AdminTab = 'overview' | 'ingestion' | 'sources' | 'evaluation' | 'reports';

@Component({
  changeDetection: ChangeDetectionStrategy.OnPush,
  selector: 'app-admin-page',
  imports: [ReactiveFormsModule, RouterLink, MatIconModule, EclairEmblem],
  template: `
    <div class="min-h-screen bg-[#F8F9FB] text-[#0B1E46]">
      <header class="border-b border-[#0B1E46]/10 bg-white">
        <div class="mx-auto flex h-16 max-w-[1360px] items-center justify-between gap-4 px-4 sm:px-6">
          <div class="flex items-center gap-3">
            <a routerLink="/" class="flex items-center gap-2 whitespace-nowrap">
              <app-eclair-emblem size="sm" />
              <span class="font-display-serif text-xl font-semibold text-[#0B1E46]">Éclair</span>
            </a>
            <span class="text-[#0B1E46]/30" aria-hidden="true">/</span>
            <span class="text-sm font-semibold text-[#0B1E46]">Administration & Évaluation</span>
          </div>
          <div class="flex items-center gap-3">
            <a routerLink="/recherche" class="text-xs font-medium text-[#114AC4] hover:underline whitespace-nowrap">
              Ouvrir le moteur
            </a>
            @if (api.isAdminSignedIn()) {
              <button
                type="button"
                (click)="api.logoutAdmin()"
                class="rounded-lg border border-[#0B1E46]/15 px-3 py-1.5 text-xs font-medium hover:bg-[#0B1E46]/5"
              >
                Verrouiller
              </button>
            }
          </div>
        </div>
      </header>

      <main class="mx-auto max-w-[1360px] px-4 py-8 sm:px-6">
        @if (!api.isAdminSignedIn()) {
          <div class="mx-auto max-w-md rounded-2xl border border-[#E6D5B3] bg-white p-6 shadow-sm">
            <div class="flex items-center gap-3">
              <div class="flex h-10 w-10 items-center justify-center rounded-xl bg-[#0B1E46]/8 text-[#0B1E46]">
                <mat-icon>admin_panel_settings</mat-icon>
              </div>
              <div>
                <h1 class="font-display-serif text-xl font-semibold text-[#0B1E46]">
                  {{ needsBootstrap() ? 'Initialiser l’accès administrateur' : 'Accès administrateur' }}
                </h1>
                <p class="text-xs text-[#0B1E46]/65">
                  {{
                    needsBootstrap()
                      ? 'Aucun code serveur n’est encore enregistré. Définissez un mot de passe administrateur (8 caractères min.).'
                      : 'Saisissez votre mot de passe ou code d’accès administrateur.'
                  }}
                </p>
              </div>
            </div>

            @if (authError()) {
              <div class="mt-4 rounded-lg border border-[#C93428]/30 bg-[#C93428]/10 px-3 py-2 text-xs text-[#8C1D14]">
                {{ authError() }}
              </div>
            }

            <form [formGroup]="authForm" (ngSubmit)="submitAdminAuth()" class="mt-5 space-y-4">
              <div>
                <label for="admin-pass" class="block text-xs font-semibold">
                  {{ needsBootstrap() ? 'Nouveau mot de passe administrateur' : 'Code ou mot de passe administrateur' }}
                </label>
                <input
                  id="admin-pass"
                  type="password"
                  formControlName="passcode"
                  placeholder="••••••••"
                  class="mt-1.5 w-full rounded-xl border border-[#0B1E46]/20 bg-[#F8F9FB] px-3.5 py-2.5 text-sm"
                />
              </div>
              <button
                type="submit"
                [disabled]="authBusy()"
                class="eclair-btn-sapphire w-full rounded-xl px-4 py-2.5 text-sm font-semibold"
              >
                {{ needsBootstrap() ? 'Enregistrer et accéder' : 'Déverrouiller la console' }}
              </button>
            </form>
          </div>
        } @else {
          <!-- Admin Tabs -->
          <div class="mb-6 flex flex-wrap items-center gap-2 border-b border-[#0B1E46]/10 pb-3">
            @for (tab of tabs; track tab.id) {
              <button
                type="button"
                (click)="activeTab.set(tab.id)"
                class="inline-flex items-center gap-1.5 rounded-xl px-3.5 py-2 text-xs font-semibold transition-colors whitespace-nowrap"
                [class]="activeTab() === tab.id ? 'bg-[#0B1E46] text-white' : 'bg-white text-[#0B1E46]/75 border border-[#0B1E46]/10 hover:text-[#0B1E46]'"
              >
                <mat-icon class="text-sm">{{ tab.icon }}</mat-icon>
                <span>{{ tab.label }}</span>
              </button>
            }
          </div>

          @if (feedbackMessage()) {
            <div class="mb-5 flex items-center justify-between rounded-xl border border-[#114AC4]/25 bg-[#114AC4]/5 px-4 py-3 text-xs text-[#0B1E46]">
              <span>{{ feedbackMessage() }}</span>
              <button type="button" (click)="feedbackMessage.set(null)" class="font-semibold underline">Fermer</button>
            </div>
          }

          <!-- TAB 1: Overview & Providers -->
          @if (activeTab() === 'overview' && overview(); as ov) {
            <div class="grid grid-cols-2 gap-4 sm:grid-cols-4">
              <div class="rounded-2xl border border-[#0B1E46]/10 bg-white p-4">
                <div class="text-xs text-[#0B1E46]/65">Documents indexés</div>
                <div class="mt-1 font-mono-tabular text-2xl font-bold text-[#0B1E46]">{{ ov.indexed_documents }}</div>
              </div>
              <div class="rounded-2xl border border-[#0B1E46]/10 bg-white p-4">
                <div class="text-xs text-[#0B1E46]/65">Termes du lexique</div>
                <div class="mt-1 font-mono-tabular text-2xl font-bold text-[#0B1E46]">{{ ov.vocabulary_terms }}</div>
              </div>
              <div class="rounded-2xl border border-[#0B1E46]/10 bg-white p-4">
                <div class="text-xs text-[#0B1E46]/65">Sources approuvées</div>
                <div class="mt-1 font-mono-tabular text-2xl font-bold text-[#0B1E46]">{{ ov.sources_count }}</div>
              </div>
              <div class="rounded-2xl border border-[#0B1E46]/10 bg-white p-4">
                <div class="text-xs text-[#0B1E46]/65">Signalements ouverts</div>
                <div class="mt-1 font-mono-tabular text-2xl font-bold text-[#C93428]">{{ ov.open_abuse_reports }}</div>
              </div>
            </div>

            <div class="mt-6 grid grid-cols-1 gap-6 lg:grid-cols-2">
              <div class="rounded-2xl border border-[#0B1E46]/10 bg-white p-5">
                <h2 class="font-display-serif text-lg font-semibold">Adaptateurs configurés (côté serveur)</h2>
                <div class="mt-4 divide-y divide-[#0B1E46]/8 text-sm">
                  <div class="flex items-center justify-between py-2.5">
                    <span>Index lexical français (BM25)</span>
                    <span class="font-mono-tabular text-xs font-semibold text-emerald-700">Actif</span>
                  </div>
                  <div class="flex items-center justify-between py-2.5">
                    <span>Adaptateur OpenSearch</span>
                    <span class="font-mono-tabular text-xs" [class]="ov.providers.opensearch.configured ? 'text-emerald-700 font-semibold' : 'text-[#0B1E46]/60'">
                      {{ ov.providers.opensearch.configured ? 'Configuré' : 'Non configuré (repli local)' }}
                    </span>
                  </div>
                  <div class="flex items-center justify-between py-2.5">
                    <span>Fournisseur Web externe</span>
                    <span class="font-mono-tabular text-xs" [class]="ov.providers.external_web.configured ? 'text-emerald-700 font-semibold' : 'text-[#0B1E46]/60'">
                      {{ ov.providers.external_web.configured ? 'Configuré' : 'Non configuré' }}
                    </span>
                  </div>
                  <div class="flex items-center justify-between py-2.5">
                    <span>Assistant IA ({{ ov.providers.gemini_assistant.model }})</span>
                    <span class="font-mono-tabular text-xs" [class]="ov.providers.gemini_assistant.configured ? 'text-emerald-700 font-semibold' : 'text-[#0B1E46]/60'">
                      {{ ov.providers.gemini_assistant.configured ? 'Configuré' : 'Clé serveur absente' }}
                    </span>
                  </div>
                </div>
              </div>

              <div class="rounded-2xl border border-[#0B1E46]/10 bg-white p-5">
                <h2 class="font-display-serif text-lg font-semibold">Maintenance de l’index</h2>
                <p class="mt-2 text-xs leading-relaxed text-[#0B1E46]/75">
                  Reconstruisez l’index inversé BM25 et le dictionnaire de suggestions orthographiques après des ajouts ou retraits de documents.
                </p>
                <button
                  type="button"
                  (click)="triggerRebuild()"
                  class="eclair-btn-sapphire mt-4 inline-flex items-center gap-2 rounded-xl px-4 py-2.5 text-xs font-semibold"
                >
                  <mat-icon class="text-base">refresh</mat-icon>
                  <span>Reconstruire l’index BM25</span>
                </button>
              </div>
            </div>
          }

          <!-- TAB 2: Ingestion & Bounded Crawler -->
          @if (activeTab() === 'ingestion') {
            <div class="grid grid-cols-1 gap-6 lg:grid-cols-12">
              <div class="rounded-2xl border border-[#0B1E46]/10 bg-white p-5 lg:col-span-5">
                <h2 class="font-display-serif text-lg font-semibold">Ingérer un document ou explorer une URL</h2>
                <form [formGroup]="ingestForm" (ngSubmit)="submitIngestion()" class="mt-4 space-y-3 text-xs">
                  <div>
                    <label for="ing-kind" class="block font-semibold">Mode d’ingestion</label>
                    <select id="ing-kind" formControlName="kind" class="mt-1 w-full rounded-xl border border-[#0B1E46]/20 bg-[#F8F9FB] px-3 py-2">
                      <option value="upload_text">Texte brut français</option>
                      <option value="upload_markdown">Document Markdown</option>
                      <option value="upload_html">HTML brut (nettoyé sans exécution de scripts)</option>
                      <option value="upload_pdf">Fichier PDF textuel approuvé</option>
                      <option value="crawl">Collecte bornée d’URL autorisée (SSRF + robots.txt)</option>
                    </select>
                  </div>

                  <div>
                    <label for="ing-url" class="block font-semibold">URL source (ou URL cible pour collecte)</label>
                    <input
                      id="ing-url"
                      type="text"
                      formControlName="target_url"
                      placeholder="https://patrimoine-idees.eclair.fr/articles/nouvel-article"
                      class="mt-1 w-full rounded-xl border border-[#0B1E46]/20 px-3 py-2"
                    />
                  </div>

                  @if (ingestForm.value.kind !== 'crawl') {
                    <div>
                      <label for="ing-title" class="block font-semibold">Titre du document</label>
                      <input
                        id="ing-title"
                        type="text"
                        formControlName="title"
                        placeholder="Ex. : Architecture solaire et verrières patrimoniales"
                        class="mt-1 w-full rounded-xl border border-[#0B1E46]/20 px-3 py-2"
                      />
                    </div>
                  }

                  @if (ingestForm.value.kind === 'upload_pdf') {
                    <div>
                      <label for="ing-pdf" class="block font-semibold">Sélectionner un PDF (max. 2 Mo)</label>
                      <input
                        id="ing-pdf"
                        type="file"
                        accept="application/pdf"
                        (change)="onPdfSelected($event)"
                        class="mt-1 w-full rounded-xl border border-dashed border-[#0B1E46]/25 p-2"
                      />
                    </div>
                  } @else if (ingestForm.value.kind !== 'crawl') {
                    <div>
                      <label for="ing-content" class="block font-semibold">Contenu textuel / HTML / Markdown</label>
                      <textarea
                        id="ing-content"
                        rows="5"
                        formControlName="content"
                        placeholder="Saisissez ou collez le contenu français à indexer…"
                        class="mt-1 w-full rounded-xl border border-[#0B1E46]/20 px-3 py-2"
                      ></textarea>
                    </div>
                  }

                  <div class="grid grid-cols-2 gap-3">
                    <div>
                      <label for="ing-source" class="block font-semibold">Nom de la source</label>
                      <input
                        id="ing-source"
                        type="text"
                        formControlName="source_name"
                        class="mt-1 w-full rounded-xl border border-[#0B1E46]/20 px-3 py-2"
                      />
                    </div>
                    <div>
                      <label for="ing-vert" class="block font-semibold">Verticale</label>
                      <select id="ing-vert" formControlName="vertical" class="mt-1 w-full rounded-xl border border-[#0B1E46]/20 px-3 py-2">
                        <option value="web">Web</option>
                        <option value="savoirs">Savoirs</option>
                        <option value="actualites">Actualités</option>
                      </select>
                    </div>
                  </div>

                  <div>
                    <label for="ing-rights" class="block font-semibold">Mention des droits</label>
                    <input
                      id="ing-rights"
                      type="text"
                      formControlName="rights_metadata"
                      class="mt-1 w-full rounded-xl border border-[#0B1E46]/20 px-3 py-2"
                    />
                  </div>

                  <button
                    type="submit"
                    [disabled]="ingestBusy()"
                    class="eclair-btn-sapphire w-full rounded-xl px-4 py-2.5 text-xs font-semibold"
                  >
                    {{ ingestBusy() ? 'Traitement en cours…' : 'Lancer l’ingestion et indexer' }}
                  </button>
                </form>
              </div>

              <div class="rounded-2xl border border-[#0B1E46]/10 bg-white p-5 lg:col-span-7">
                <h2 class="font-display-serif text-lg font-semibold">Journal des tâches d’ingestion et d’erreurs</h2>
                @if (jobs().length === 0) {
                  <p class="mt-4 text-xs text-[#0B1E46]/65">
                    Aucune tâche exécutée dans cette session pour le moment. Utilisez le formulaire ci-contre pour ingérer un document ou tester la protection SSRF (ex. : http://127.0.0.1/test).
                  </p>
                } @else {
                  <div class="mt-4 overflow-x-auto">
                    <table class="w-full text-left text-xs">
                      <thead class="border-b border-[#0B1E46]/10 text-[#0B1E46]/65">
                        <tr>
                          <th class="py-2 pr-3">Tâche</th>
                          <th class="py-2 pr-3">Type</th>
                          <th class="py-2 pr-3">Statut</th>
                          <th class="py-2">Détail</th>
                        </tr>
                      </thead>
                      <tbody class="divide-y divide-[#0B1E46]/8">
                        @for (job of jobs(); track job.job_id) {
                          <tr>
                            <td class="py-2.5 pr-3 font-mono-tabular">{{ job.job_id }}</td>
                            <td class="py-2.5 pr-3">{{ job.kind }}</td>
                            <td class="py-2.5 pr-3 font-semibold" [class]="job.status === 'completed' ? 'text-emerald-700' : 'text-[#C93428]'">
                              {{ job.status }}
                            </td>
                            <td class="py-2.5 text-[#0B1E46]/75">
                              @if (job.error_message) {
                                {{ job.error_message }}
                              } @else if (job.document_id) {
                                <a [routerLink]="['/source', job.document_id]" class="text-[#114AC4] hover:underline">
                                  Document {{ job.document_id }}
                                </a>
                              }
                            </td>
                          </tr>
                        }
                      </tbody>
                    </table>
                  </div>
                }
              </div>
            </div>
          }

          <!-- TAB 3: Sources, Documents & Duplicates -->
          @if (activeTab() === 'sources') {
            <div class="grid grid-cols-1 gap-6 lg:grid-cols-12">
              <div class="rounded-2xl border border-[#0B1E46]/10 bg-white p-5 lg:col-span-5">
                <h2 class="font-display-serif text-lg font-semibold">Ajouter une source approuvée</h2>
                <form [formGroup]="sourceForm" (ngSubmit)="submitSource()" class="mt-4 space-y-3 text-xs">
                  <div>
                    <label for="src-name" class="block font-semibold">Nom éditorial</label>
                    <input id="src-name" type="text" formControlName="name" class="mt-1 w-full rounded-xl border border-[#0B1E46]/20 px-3 py-2" />
                  </div>
                  <div>
                    <label for="src-url" class="block font-semibold">URL de base (HTTPS)</label>
                    <input id="src-url" type="text" formControlName="base_url" placeholder="https://sciences.exemple.fr" class="mt-1 w-full rounded-xl border border-[#0B1E46]/20 px-3 py-2" />
                  </div>
                  <div>
                    <label for="src-paths" class="block font-semibold">Préfixes de chemins autorisés (séparés par virgule)</label>
                    <input id="src-paths" type="text" formControlName="paths" class="mt-1 w-full rounded-xl border border-[#0B1E46]/20 px-3 py-2" />
                  </div>
                  <button type="submit" class="eclair-btn-sapphire rounded-xl px-4 py-2 text-xs font-semibold">
                    Ajouter à la liste blanche
                  </button>
                </form>

                <h3 class="mt-6 text-sm font-semibold">Doublons détectés ({{ duplicates().length }})</h3>
                @if (duplicates().length === 0) {
                  <p class="mt-2 text-xs text-[#0B1E46]/65">Aucun doublon ignoré enregistré.</p>
                } @else {
                  <ul class="mt-2 space-y-2 text-xs">
                    @for (dup of duplicates(); track dup.content_hash) {
                      <li class="rounded-xl border border-[#0B1E46]/10 p-3">
                        <div class="font-semibold">{{ dup.title }}</div>
                        <div class="font-mono-tabular text-[11px] text-[#0B1E46]/60">{{ dup.content_hash }}</div>
                      </li>
                    }
                  </ul>
                }
              </div>

              <div class="rounded-2xl border border-[#0B1E46]/10 bg-white p-5 lg:col-span-7">
                <h2 class="font-display-serif text-lg font-semibold">Corpus indexé et gestion des retraits ({{ documents().length }})</h2>
                <div class="mt-4 max-h-[520px] overflow-y-auto divide-y divide-[#0B1E46]/8 text-xs">
                  @for (doc of documents(); track doc.document_id) {
                    <div class="flex items-center justify-between gap-3 py-2.5">
                      <div class="min-w-0">
                        <div class="truncate font-semibold text-[#0B1E46]">{{ doc.title }}</div>
                        <div class="text-[#0B1E46]/60">
                          {{ doc.domain }} · {{ doc.vertical }} ·
                          <span [class]="doc.index_status === 'indexed' ? 'text-emerald-700' : 'text-[#C93428]'">
                            {{ doc.index_status }}
                          </span>
                        </div>
                      </div>
                      @if (doc.index_status === 'indexed') {
                        <button
                          type="button"
                          (click)="removeDoc(doc.document_id)"
                          class="shrink-0 rounded-lg border border-[#C93428]/30 px-2.5 py-1 text-[11px] font-medium text-[#C93428] hover:bg-[#C93428]/10"
                        >
                          Retirer
                        </button>
                      }
                    </div>
                  }
                </div>
              </div>
            </div>
          }

          <!-- TAB 4: Search Quality Evaluation -->
          @if (activeTab() === 'evaluation') {
            <div class="rounded-2xl border border-[#0B1E46]/10 bg-white p-6">
              <div class="flex flex-wrap items-center justify-between gap-4 border-b border-[#0B1E46]/10 pb-4">
                <div>
                  <h2 class="font-display-serif text-xl font-semibold">Évaluation de pertinence en langue française</h2>
                  <p class="mt-1 text-xs text-[#0B1E46]/70">
                    Banc d’essai synthétique distinct de la satisfaction utilisateur réelle : requêtes navigationnelles, informationnelles, avec/sans accents, exactes, ambiguës et sans résultat.
                  </p>
                </div>
                <button
                  type="button"
                  (click)="executeEvaluation()"
                  class="eclair-btn-sapphire inline-flex items-center gap-2 rounded-xl px-4 py-2.5 text-xs font-semibold"
                >
                  <mat-icon class="text-base">play_arrow</mat-icon>
                  <span>Exécuter l’évaluation</span>
                </button>
              </div>

              @if (evaluation(); as ev) {
                <div class="mt-5 grid grid-cols-2 gap-4 sm:grid-cols-5">
                  <div class="rounded-xl border border-[#0B1E46]/10 bg-[#F8F9FB] p-3">
                    <div class="text-[11px] text-[#0B1E46]/65">MRR&#64;5</div>
                    <div class="mt-1 font-mono-tabular text-xl font-bold text-[#114AC4]">{{ ev.mrr_at_5 }}</div>
                  </div>
                  <div class="rounded-xl border border-[#0B1E46]/10 bg-[#F8F9FB] p-3">
                    <div class="text-[11px] text-[#0B1E46]/65">Rappel&#64;5</div>
                    <div class="mt-1 font-mono-tabular text-xl font-bold text-[#0B1E46]">{{ ev.recall_at_5 }}</div>
                  </div>
                  <div class="rounded-xl border border-[#0B1E46]/10 bg-[#F8F9FB] p-3">
                    <div class="text-[11px] text-[#0B1E46]/65">Parité accents</div>
                    <div class="mt-1 font-mono-tabular text-xl font-bold text-[#0B1E46]">{{ ev.accent_parity_rate * 100 }} %</div>
                  </div>
                  <div class="rounded-xl border border-[#0B1E46]/10 bg-[#F8F9FB] p-3">
                    <div class="text-[11px] text-[#0B1E46]/65">Latence p50 / p95</div>
                    <div class="mt-1 font-mono-tabular text-xl font-bold text-[#0B1E46]">{{ ev.p50_latency_ms }} / {{ ev.p95_latency_ms }} ms</div>
                  </div>
                  <div class="rounded-xl border border-[#0B1E46]/10 bg-[#F8F9FB] p-3">
                    <div class="text-[11px] text-[#0B1E46]/65">Sources / Échecs</div>
                    <div class="mt-1 font-mono-tabular text-xl font-bold text-[#0B1E46]">{{ ev.source_count }} / {{ ev.failed_document_count }}</div>
                  </div>
                </div>

                <div class="mt-5 overflow-x-auto">
                  <table class="w-full text-left text-xs">
                    <thead class="border-b border-[#0B1E46]/10 text-[#0B1E46]/65">
                      <tr>
                        <th class="py-2 pr-3">Requête</th>
                        <th class="py-2 pr-3">Catégorie</th>
                        <th class="py-2 pr-3">MRR</th>
                        <th class="py-2 pr-3">Rappel</th>
                        <th class="py-2 pr-3">Latence</th>
                        <th class="py-2">Verdict</th>
                      </tr>
                    </thead>
                    <tbody class="divide-y divide-[#0B1E46]/8">
                      @for (row of ev.results; track row.id) {
                        <tr>
                          <td class="py-2.5 pr-3 font-medium">{{ row.query }}</td>
                          <td class="py-2.5 pr-3">{{ row.category }}</td>
                          <td class="py-2.5 pr-3 font-mono-tabular">{{ row.reciprocal_rank }}</td>
                          <td class="py-2.5 pr-3 font-mono-tabular">{{ row.recall_at_5 }}</td>
                          <td class="py-2.5 pr-3 font-mono-tabular">{{ row.latency_ms }} ms</td>
                          <td class="py-2.5 font-semibold" [class]="row.passed ? 'text-emerald-700' : 'text-[#C93428]'">
                            {{ row.passed ? 'Conforme' : 'Écart' }}
                          </td>
                        </tr>
                      }
                    </tbody>
                  </table>
                </div>
              }
            </div>
          }

          <!-- TAB 5: Abuse Reports -->
          @if (activeTab() === 'reports') {
            <div class="rounded-2xl border border-[#0B1E46]/10 bg-white p-6">
              <h2 class="font-display-serif text-xl font-semibold">Signalements et demandes de retrait</h2>
              @if (reports().length === 0) {
                <p class="mt-3 text-xs text-[#0B1E46]/65">Aucun signalement reçu.</p>
              } @else {
                <div class="mt-4 space-y-3">
                  @for (rep of reports(); track rep.report_id) {
                    <div class="flex flex-wrap items-center justify-between gap-4 rounded-xl border border-[#0B1E46]/10 p-4 text-xs">
                      <div>
                        <div class="font-semibold text-[#0B1E46]">{{ rep.reason }} · Statut : {{ rep.status }}</div>
                        <div class="mt-1 font-mono-tabular text-[#0B1E46]/70">{{ rep.source_url }}</div>
                        @if (rep.details) {
                          <p class="mt-1 text-[#0B1E46]/80">{{ rep.details }}</p>
                        }
                      </div>
                      @if (rep.status === 'open') {
                        <div class="flex gap-2">
                          <button
                            type="button"
                            (click)="handleReport(rep.report_id, 'resolved')"
                            class="rounded-lg border border-[#0B1E46]/20 px-3 py-1.5 font-medium"
                          >
                            Classer sans retrait
                          </button>
                          <button
                            type="button"
                            (click)="handleReport(rep.report_id, 'removed')"
                            class="rounded-lg bg-[#C93428] px-3 py-1.5 font-semibold text-white"
                          >
                            Retirer de l’index
                          </button>
                        </div>
                      }
                    </div>
                  }
                </div>
              }
            </div>
          }
        }
      </main>
    </div>
  `,
})
export class AdminPage implements OnInit {
  readonly api = inject(EclairApi);

  readonly needsBootstrap = signal(false);
  readonly authBusy = signal(false);
  readonly authError = signal<string | null>(null);
  readonly activeTab = signal<AdminTab>('overview');
  readonly feedbackMessage = signal<string | null>(null);

  readonly overview = signal<AdminOverview | null>(null);
  readonly sources = signal<ApprovedSource[]>([]);
  readonly documents = signal<DocumentRecord[]>([]);
  readonly duplicates = signal<DuplicateCluster[]>([]);
  readonly jobs = signal<IngestionJob[]>([]);
  readonly evaluation = signal<EvaluationRunResult | null>(null);
  readonly reports = signal<AbuseReport[]>([]);
  readonly ingestBusy = signal(false);

  private pdfBase64: string | null = null;

  readonly authForm = new FormGroup({
    passcode: new FormControl('', {nonNullable: true, validators: [Validators.required]}),
  });

  readonly ingestForm = new FormGroup({
    kind: new FormControl<IngestionJob['kind']>('upload_text', {nonNullable: true}),
    target_url: new FormControl('', {nonNullable: true}),
    title: new FormControl('', {nonNullable: true}),
    content: new FormControl('', {nonNullable: true}),
    source_name: new FormControl('Rédaction Éclair', {nonNullable: true}),
    vertical: new FormControl<SearchVertical>('savoirs', {nonNullable: true}),
    rights_metadata: new FormControl('Licence ouverte Etalab 2.0', {nonNullable: true}),
  });

  readonly sourceForm = new FormGroup({
    name: new FormControl('', {nonNullable: true}),
    base_url: new FormControl('', {nonNullable: true}),
    paths: new FormControl('/articles/, /dossiers/', {nonNullable: true}),
  });

  readonly tabs: {id: AdminTab; label: string; icon: string}[] = [
    {id: 'overview', label: 'Vue d’ensemble & Adaptateurs', icon: 'dashboard'},
    {id: 'ingestion', label: 'Ingestion & Collecte', icon: 'cloud_upload'},
    {id: 'sources', label: 'Sources & Doublons', icon: 'verified'},
    {id: 'evaluation', label: 'Évaluation & Qualité', icon: 'analytics'},
    {id: 'reports', label: 'Signalements', icon: 'flag'},
  ];

  async ngOnInit(): Promise<void> {
    if (this.api.isAdminSignedIn()) {
      await this.loadAllAdminData();
      return;
    }
    const status = await this.api.getAdminAuthStatus();
    this.needsBootstrap.set(status.needs_bootstrap);
  }

  async submitAdminAuth(): Promise<void> {
    this.authError.set(null);
    const passcode = this.authForm.controls.passcode.value.trim();
    if (!passcode) return;
    this.authBusy.set(true);
    try {
      if (this.needsBootstrap()) {
        await this.api.bootstrapAdmin(passcode);
        this.needsBootstrap.set(false);
      } else {
        await this.api.loginAdmin(passcode);
      }
      this.authForm.reset();
      await this.loadAllAdminData();
    } catch (err: unknown) {
      const msg = (err as {error?: {error?: string}})?.error?.error;
      this.authError.set(msg || 'Authentification administrateur refusée.');
    } finally {
      this.authBusy.set(false);
    }
  }

  async loadAllAdminData(): Promise<void> {
    const [ov, src, docs, dups, jobsRes, reps] = await Promise.all([
      this.api.getAdminOverview(),
      this.api.getSources(),
      this.api.getAdminDocuments(),
      this.api.getDuplicates(),
      this.api.getJobs(),
      this.api.getAbuseReports(),
    ]);
    this.overview.set(ov);
    this.sources.set(src.sources);
    this.documents.set(docs.documents);
    this.duplicates.set(dups.duplicates);
    this.jobs.set(jobsRes.jobs);
    this.reports.set(reps.reports);
  }

  async triggerRebuild(): Promise<void> {
    const res = await this.api.rebuildIndex();
    this.feedbackMessage.set(
      `Index BM25 reconstruit : ${res.indexed_count} documents actifs, ${res.vocabulary_size} termes indexés.`,
    );
    await this.loadAllAdminData();
  }

  onPdfSelected(event: Event): void {
    const file = (event.target as HTMLInputElement).files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      const result = String(reader.result ?? '');
      this.pdfBase64 = result.includes(',') ? result.split(',')[1] : result;
    };
    reader.readAsDataURL(file);
  }

  async submitIngestion(): Promise<void> {
    this.ingestBusy.set(true);
    this.feedbackMessage.set(null);
    const raw = this.ingestForm.getRawValue();
    try {
      const res = await this.api.createIngestionJob({
        kind: raw.kind,
        target_url: raw.target_url || undefined,
        title: raw.title || undefined,
        content: raw.content || undefined,
        pdf_base64: raw.kind === 'upload_pdf' ? (this.pdfBase64 ?? undefined) : undefined,
        source_name: raw.source_name,
        vertical: raw.vertical,
        rights_metadata: raw.rights_metadata,
      });
      this.feedbackMessage.set(
        res.job.status === 'completed'
          ? `Document indexé avec succès (${res.document?.document_id}). Vous pouvez dès maintenant le rechercher.`
          : `Tâche terminée avec le statut : ${res.job.status}.`,
      );
      this.ingestForm.patchValue({title: '', content: '', target_url: ''});
      await this.loadAllAdminData();
    } catch (err: unknown) {
      const msg = (err as {error?: {error?: string}})?.error?.error;
      this.feedbackMessage.set(msg || 'La tâche d’ingestion a échoué.');
      await this.loadAllAdminData();
    } finally {
      this.ingestBusy.set(false);
    }
  }

  async submitSource(): Promise<void> {
    const raw = this.sourceForm.getRawValue();
    if (!raw.base_url.trim()) return;
    try {
      await this.api.addSource({
        name: raw.name.trim() || raw.base_url.trim(),
        base_url: raw.base_url.trim(),
        allowed_paths: raw.paths
          .split(',')
          .map((p) => p.trim())
          .filter(Boolean),
        vertical: 'web',
        rights_default: 'Source approuvée par l’administrateur',
        crawl_delay_ms: 1000,
        max_depth: 1,
      });
      this.sourceForm.reset({name: '', base_url: '', paths: '/articles/'});
      this.feedbackMessage.set('Nouvelle source approuvée ajoutée à la liste blanche.');
      await this.loadAllAdminData();
    } catch (err: unknown) {
      const msg = (err as {error?: {error?: string}})?.error?.error;
      this.feedbackMessage.set(msg || 'Impossible d’ajouter cette source.');
    }
  }

  async removeDoc(docId: string): Promise<void> {
    await this.api.deleteDocument(docId);
    this.feedbackMessage.set(`Document ${docId} retiré de l’index.`);
    await this.loadAllAdminData();
  }

  async executeEvaluation(): Promise<void> {
    const res = await this.api.runEvaluation();
    this.evaluation.set(res);
  }

  async handleReport(reportId: string, action: 'resolved' | 'removed'): Promise<void> {
    await this.api.resolveAbuseReport(reportId, action);
    this.feedbackMessage.set('Signalement mis à jour.');
    await this.loadAllAdminData();
  }
}
