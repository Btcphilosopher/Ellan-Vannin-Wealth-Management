import {ChangeDetectionStrategy, Component, inject, signal} from '@angular/core';
import {FormControl, ReactiveFormsModule} from '@angular/forms';
import {MatIconModule} from '@angular/material/icon';
import {Router, RouterLink} from '@angular/router';
import {SearchMode, SearchVertical, SuggestionItem} from '../../shared/eclair.types';
import {EclairEmblem} from '../components/eclair-emblem';
import {AccountModal, ImageModal, VoiceModal} from '../components/voice-image-modals';
import {EclairApi} from '../services/eclair-api';

interface ServiceTile {
  label: string;
  subtitle: string;
  icon: string;
  query: string;
  vertical: SearchVertical;
  assistant?: boolean;
}

@Component({
  changeDetection: ChangeDetectionStrategy.OnPush,
  selector: 'app-home-page',
  imports: [
    ReactiveFormsModule,
    RouterLink,
    MatIconModule,
    EclairEmblem,
    VoiceModal,
    ImageModal,
    AccountModal,
  ],
  template: `
    <div class="relative flex min-h-screen flex-col justify-between overflow-x-hidden bg-[#07142E] text-[#F8F9FB]">
      <!-- Full-screen Parisian Seine Panorama -->
      <div class="pointer-events-none fixed inset-0 z-0">
        <img
          src="/src/assets/images/paris_seine_panorama_1795854490474.jpg"
          alt="Panorama de Paris sur la Seine au soleil couchant"
          referrerpolicy="no-referrer"
          class="h-full w-full object-cover object-center"
        />
        <!-- Measured Scrim for WCAG AA Contrast -->
        <div
          class="absolute inset-0"
          style="background: linear-gradient(180deg, rgba(7,20,46,0.68) 0%, rgba(11,30,70,0.42) 38%, rgba(11,30,70,0.22) 64%, rgba(7,20,46,0.82) 100%);"
        ></div>
      </div>

      <!-- Top Translucent Navigation -->
      <header class="eclair-glass-nav relative z-30">
        <div class="mx-auto flex h-16 max-w-[1440px] items-center justify-between gap-4 px-4 sm:px-8">
          <!-- Zone 1: Brand -->
          <a
            routerLink="/"
            class="flex shrink-0 items-center gap-2.5 whitespace-nowrap focus-visible:outline-2 focus-visible:outline-offset-4 focus-visible:outline-[#E6D5B3]"
          >
            <app-eclair-emblem size="sm" />
            <span class="font-display-serif text-xl font-semibold tracking-tight text-white">
              Éclair
            </span>
          </a>

          <!-- Zone 2: Vertical Nav Links (Desktop) -->
          <nav
            aria-label="Univers de recherche"
            class="hidden items-center gap-6 text-sm font-medium text-white/85 md:flex"
          >
            @for (tab of headerVerticals; track tab.id) {
              <button
                type="button"
                (click)="selectVertical(tab.id)"
                class="relative py-2 whitespace-nowrap shrink-0 transition-colors hover:text-white focus-visible:outline-2 focus-visible:outline-offset-4 focus-visible:outline-[#E6D5B3]"
                [class.text-white]="activeVertical() === tab.id"
                [class.font-semibold]="activeVertical() === tab.id"
              >
                {{ tab.label }}
                @if (activeVertical() === tab.id) {
                  <span
                    class="absolute right-0 bottom-0 left-0 h-0.5 rounded-full bg-[#E6D5B3]"
                    aria-hidden="true"
                  ></span>
                }
              </button>
            }
          </nav>

          <!-- Zone 3: Right Controls -->
          <div class="flex shrink-0 items-center gap-3">
            <span class="hidden text-xs font-medium text-white/85 sm:inline whitespace-nowrap">
              Français
            </span>

            <div class="relative">
              <button
                type="button"
                (click)="appsMenuOpen.set(!appsMenuOpen())"
                class="flex h-10 w-10 items-center justify-center rounded-xl text-white/85 transition-colors hover:bg-white/10 hover:text-white focus-visible:outline-2 focus-visible:outline-[#E6D5B3]"
                aria-label="Outils Éclair : Administration et Démonstration"
                [attr.aria-expanded]="appsMenuOpen()"
              >
                <mat-icon>apps</mat-icon>
              </button>

              @if (appsMenuOpen()) {
                <div
                  class="absolute right-0 mt-2 w-72 rounded-2xl border border-[#E6D5B3]/50 bg-[#0B1E46]/95 p-2 text-sm text-white shadow-2xl backdrop-blur-xl"
                >
                  <a
                    routerLink="/demonstration"
                    (click)="appsMenuOpen.set(false)"
                    class="flex items-center gap-3 rounded-xl px-3 py-2.5 hover:bg-white/10"
                  >
                    <mat-icon class="text-[#E6D5B3]">playlist_add_check</mat-icon>
                    <div>
                      <div class="font-medium">Démonstration guidée</div>
                      <div class="text-xs text-white/70">Parcours reproductible en 12 points</div>
                    </div>
                  </a>
                  <a
                    routerLink="/administration"
                    (click)="appsMenuOpen.set(false)"
                    class="flex items-center gap-3 rounded-xl px-3 py-2.5 hover:bg-white/10"
                  >
                    <mat-icon class="text-[#E6D5B3]">admin_panel_settings</mat-icon>
                    <div>
                      <div class="font-medium">Administration & Évaluation</div>
                      <div class="text-xs text-white/70">Sources, ingestion, BM25 et métriques</div>
                    </div>
                  </a>
                  <a
                    routerLink="/confidentialite"
                    (click)="appsMenuOpen.set(false)"
                    class="flex items-center gap-3 rounded-xl px-3 py-2.5 hover:bg-white/10"
                  >
                    <mat-icon class="text-[#E6D5B3]">shield</mat-icon>
                    <div>
                      <div class="font-medium">Confidentialité & Portée</div>
                      <div class="text-xs text-white/70">Journalisation, rétention et fournisseurs</div>
                    </div>
                  </a>
                </div>
              }
            </div>

            <button
              type="button"
              (click)="accountModalOpen.set(true)"
              class="inline-flex h-10 items-center gap-2 rounded-xl border border-[#E6D5B3]/45 bg-white/10 px-3.5 text-xs font-medium text-white transition-colors hover:bg-white/20 whitespace-nowrap shrink-0"
            >
              <mat-icon class="text-base">account_circle</mat-icon>
              <span>{{ api.isSignedIn() ? api.userProfile()?.display_name : 'Se connecter' }}</span>
            </button>

            <button
              type="button"
              (click)="mobileMenuOpen.set(!mobileMenuOpen())"
              class="flex h-10 w-10 items-center justify-center rounded-xl text-white hover:bg-white/10 md:hidden"
              aria-label="Ouvrir le menu de navigation"
              [attr.aria-expanded]="mobileMenuOpen()"
            >
              <mat-icon>{{ mobileMenuOpen() ? 'close' : 'menu' }}</mat-icon>
            </button>
          </div>
        </div>

        <!-- Mobile Collapsed Navigation -->
        @if (mobileMenuOpen()) {
          <div class="border-t border-[#E6D5B3]/25 bg-[#07142E]/95 px-4 py-3 md:hidden">
            <div class="grid grid-cols-2 gap-2">
              @for (tab of headerVerticals; track tab.id) {
                <button
                  type="button"
                  (click)="selectVertical(tab.id); mobileMenuOpen.set(false)"
                  class="flex items-center justify-between rounded-xl px-3 py-2.5 text-left text-sm font-medium text-white hover:bg-white/10"
                  [class.bg-white/15]="activeVertical() === tab.id"
                >
                  <span>{{ tab.label }}</span>
                  <mat-icon class="text-base text-[#E6D5B3]">chevron_right</mat-icon>
                </button>
              }
            </div>
          </div>
        }
      </header>

      <!-- Main Hero Search Area -->
      <main class="relative z-20 mx-auto flex w-full max-w-[1040px] flex-1 flex-col items-center justify-center px-4 py-10 sm:px-6 lg:py-14">
        <!-- Brand Lockup -->
        <div class="flex flex-col items-center text-center">
          <div class="flex items-center justify-center gap-3.5">
            <app-eclair-emblem size="lg" />
            <h1
              class="font-display-serif font-semibold tracking-tight text-white drop-shadow-[0_4px_20px_rgba(7,20,46,0.6)]"
              style="font-size: clamp(2.65rem, 5vw, 4.1rem); line-height: 1.05;"
            >
              éclair
            </h1>
          </div>

          <!-- Subtle French Tricolor Accent Rule -->
          <div class="mt-2.5 flex h-[3px] w-16 overflow-hidden rounded-full shadow-sm" aria-hidden="true">
            <span class="flex-1 bg-[#114AC4]"></span>
            <span class="flex-1 bg-[#F8F9FB]"></span>
            <span class="flex-1 bg-[#C93428]"></span>
          </div>

          <p class="mt-4 max-w-xl text-base font-medium tracking-wide text-white/95 drop-shadow-[0_2px_10px_rgba(7,20,46,0.75)] sm:text-lg">
            L’esprit libre. Le monde ouvert.
          </p>
        </div>

        <!-- Frosted Glass Search Form -->
        <div class="relative mt-8 w-full max-w-[780px]">
          <form
            (ngSubmit)="submitSearch()"
            class="eclair-glass-search flex items-center gap-2 rounded-full p-2 pl-4 sm:pl-6"
            role="search"
            aria-label="Recherche Éclair"
          >
            <mat-icon class="shrink-0 text-[#0B1E46]/60">search</mat-icon>
            <label for="home-search-input" class="sr-only">Que souhaitez-vous découvrir ?</label>
            <input
              id="home-search-input"
              type="text"
              [formControl]="searchControl"
              (input)="onQueryInput()"
              (focus)="suggestionsOpen.set(true)"
              (keydown.escape)="suggestionsOpen.set(false)"
              placeholder="Que souhaitez-vous découvrir ?"
              autocomplete="off"
              class="min-w-0 flex-1 bg-transparent py-2.5 text-base font-medium text-[#0B1E46] placeholder:text-[#0B1E46]/55 focus:outline-none sm:text-[17px]"
            />

            <button
              type="button"
              (click)="voiceModalOpen.set(true)"
              class="flex h-11 w-11 shrink-0 items-center justify-center rounded-full text-[#0B1E46]/70 transition-colors hover:bg-[#0B1E46]/8 hover:text-[#114AC4] focus-visible:outline-2 focus-visible:outline-[#114AC4]"
              aria-label="Recherche vocale (sur autorisation)"
              title="Recherche vocale"
            >
              <mat-icon>mic</mat-icon>
            </button>

            <button
              type="button"
              (click)="imageModalOpen.set(true)"
              class="flex h-11 w-11 shrink-0 items-center justify-center rounded-full text-[#0B1E46]/70 transition-colors hover:bg-[#0B1E46]/8 hover:text-[#114AC4] focus-visible:outline-2 focus-visible:outline-[#114AC4]"
              aria-label="Recherche par image"
              title="Recherche par image"
            >
              <mat-icon>photo_camera</mat-icon>
            </button>

            <button
              type="submit"
              class="eclair-btn-sapphire inline-flex h-11 shrink-0 items-center gap-2 rounded-full px-5 text-sm font-semibold whitespace-nowrap sm:px-7 sm:text-[15px]"
            >
              <span>Rechercher</span>
            </button>
          </form>

          <!-- Autocomplete Suggestions Dropdown -->
          @if (suggestionsOpen() && suggestions().length > 0) {
            <div
              class="absolute right-4 left-4 z-40 mt-2 overflow-hidden rounded-2xl border border-[#E6D5B3]/70 bg-[#F8F9FB] py-1.5 text-[#0B1E46] shadow-2xl"
              role="listbox"
              aria-label="Suggestions de recherche"
            >
              @for (item of suggestions(); track item.text) {
                <button
                  type="button"
                  (click)="pickSuggestion(item)"
                  class="flex w-full items-center justify-between gap-3 px-4 py-2.5 text-left text-sm transition-colors hover:bg-[#114AC4]/8"
                >
                  <div class="flex min-w-0 items-center gap-3">
                    <mat-icon class="shrink-0 text-base text-[#114AC4]">
                      {{ item.kind === 'spelling' ? 'spellcheck' : 'search' }}
                    </mat-icon>
                    <span class="truncate font-medium">
                      @if (item.kind === 'spelling') {
                        <span class="mr-1.5 text-xs font-normal text-[#0B1E46]/65">Essayez plutôt :</span>
                      }
                      {{ item.text }}
                    </span>
                  </div>
                  @if (item.source_hint) {
                    <span class="hidden shrink-0 text-xs text-[#0B1E46]/55 sm:inline">
                      {{ item.source_hint }}
                    </span>
                  }
                </button>
              }
            </div>
          }

          <!-- Honest Search Mode Toggle -->
          <div class="mt-4 flex flex-wrap items-center justify-center gap-3 text-xs text-white/90">
            <div class="inline-flex items-center rounded-full border border-[#E6D5B3]/35 bg-[#07142E]/65 p-1 backdrop-blur-md">
              <button
                type="button"
                (click)="searchMode.set('local')"
                class="rounded-full px-3.5 py-1.5 font-medium transition-colors whitespace-nowrap"
                [class]="searchMode() === 'local' ? 'bg-[#114AC4] text-white' : 'text-white/80 hover:text-white'"
              >
                Corpus local
              </button>
              <button
                type="button"
                (click)="searchMode.set('external')"
                class="rounded-full px-3.5 py-1.5 font-medium transition-colors whitespace-nowrap"
                [class]="searchMode() === 'external' ? 'bg-[#C93428] text-white' : 'text-white/80 hover:text-white'"
              >
                Web externe
              </button>
            </div>
            <span class="text-white/85 drop-shadow">
              @if (searchMode() === 'local') {
                Mode actif : index français vérifiable (26 documents et médias autorisés)
              } @else {
                Mode actif : adaptateur Web externe (requiert des identifiants configurés)
              }
            </span>
          </div>
        </div>

        <!-- Suggested Searches -->
        <div class="mt-6 flex flex-wrap items-center justify-center gap-3" aria-label="Recherches suggérées">
          @for (prompt of suggestedQueries; track prompt.query) {
            <button
              type="button"
              (click)="runSuggestedQuery(prompt.query)"
              class="eclair-glass-chip inline-flex items-center gap-2 rounded-full px-4 py-2 text-xs font-medium text-white transition-colors hover:border-[#E6D5B3] hover:bg-[#0B1E46]/75 sm:text-sm whitespace-nowrap"
            >
              <mat-icon class="text-base text-[#E6D5B3]">{{ prompt.icon }}</mat-icon>
              <span>{{ prompt.label }}</span>
            </button>
          }
        </div>
      </main>

      <!-- Lower Floating Service Panel -->
      <section
        aria-label="Services et perspectives Éclair"
        class="eclair-glass-dock relative z-20 w-full"
      >
        <div class="mx-auto max-w-[1440px] px-4 py-4 sm:px-8">
          <div class="grid grid-cols-1 items-center gap-4 lg:grid-cols-12">
            <!-- 5 Service Links -->
            <div class="grid grid-cols-2 gap-2 sm:grid-cols-5 lg:col-span-8">
              @for (svc of serviceTiles; track svc.label) {
                <button
                  type="button"
                  (click)="openService(svc)"
                  class="group flex flex-col items-center justify-center rounded-xl border border-transparent px-3 py-3 text-center transition-colors hover:border-[#E6D5B3]/35 hover:bg-white/8 focus-visible:outline-2 focus-visible:outline-[#E6D5B3]"
                >
                  <div class="flex h-10 w-10 items-center justify-center rounded-xl bg-[#114AC4]/25 text-[#8FD3FF] transition-colors group-hover:bg-[#114AC4]/45 group-hover:text-white">
                    <mat-icon>{{ svc.icon }}</mat-icon>
                  </div>
                  <span class="mt-2 text-sm font-semibold text-white whitespace-nowrap">
                    {{ svc.label }}
                  </span>
                  <span class="mt-0.5 text-[11px] text-white/70">
                    {{ svc.subtitle }}
                  </span>
                </button>
              }
            </div>

            <!-- Warm Architectural Promotional Card -->
            <div class="relative overflow-hidden rounded-2xl border border-[#E6D5B3]/45 bg-[#0B1E46] lg:col-span-4">
              <img
                src="/src/assets/images/eclair_architecture_promo_1795854491902.jpg"
                alt="Pavillon architectural français en verre et pierre au crépuscule"
                referrerpolicy="no-referrer"
                class="h-32 w-full object-cover object-center opacity-80 sm:h-36"
              />
              <div
                class="absolute inset-0 flex items-center justify-between gap-4 p-4 sm:p-5"
                style="background: linear-gradient(90deg, rgba(7,20,46,0.92) 0%, rgba(7,20,46,0.68) 58%, rgba(7,20,46,0.28) 100%);"
              >
                <div class="min-w-0">
                  <h2 class="font-display-serif text-base font-semibold text-white sm:text-lg">
                    Éclair, de nouvelles perspectives.
                  </h2>
                  <p class="mt-1 text-xs text-white/80">
                    Explorez le corpus vérifiable et nos outils d’analyse.
                  </p>
                </div>
                <a
                  routerLink="/demonstration"
                  class="eclair-btn-sapphire inline-flex shrink-0 items-center gap-1.5 rounded-full px-4 py-2 text-xs font-semibold whitespace-nowrap sm:text-sm"
                >
                  <span>Découvrir</span>
                  <mat-icon class="text-base">arrow_forward</mat-icon>
                </a>
              </div>
            </div>
          </div>

          <!-- Quiet Editorial Footer -->
          <footer class="mt-3 flex flex-wrap items-center justify-between gap-3 border-t border-[#E6D5B3]/15 pt-3 text-xs text-white/65">
            <span>Éclair — Moteur de recherche documentaire en langue française</span>
            <div class="flex flex-wrap items-center gap-4">
              <a routerLink="/recherche" [queryParams]="{q: ''}" class="hover:text-white">Explorer l’index</a>
              <a routerLink="/confidentialite" class="hover:text-white">Confidentialité & portée</a>
              <a routerLink="/administration" class="hover:text-white">Administration</a>
            </div>
          </footer>
        </div>
      </section>

      <app-voice-modal
        [open]="voiceModalOpen()"
        (closed)="voiceModalOpen.set(false)"
        (searchSubmitted)="onModalSearch($event)"
      />
      <app-image-modal
        [open]="imageModalOpen()"
        (closed)="imageModalOpen.set(false)"
        (hitSelected)="onImageHitSelected($event)"
      />
      <app-account-modal
        [open]="accountModalOpen()"
        (closed)="accountModalOpen.set(false)"
      />
    </div>
  `,
})
export class HomePage {
  private readonly router = inject(Router);
  readonly api = inject(EclairApi);

  readonly searchControl = new FormControl('', {nonNullable: true});
  readonly activeVertical = signal<SearchVertical>('web');
  readonly searchMode = signal<SearchMode>('local');
  readonly suggestions = signal<SuggestionItem[]>([]);
  readonly suggestionsOpen = signal(false);

  readonly mobileMenuOpen = signal(false);
  readonly appsMenuOpen = signal(false);
  readonly voiceModalOpen = signal(false);
  readonly imageModalOpen = signal(false);
  readonly accountModalOpen = signal(false);

  readonly headerVerticals: {id: SearchVertical; label: string}[] = [
    {id: 'web', label: 'Web'},
    {id: 'images', label: 'Images'},
    {id: 'actualites', label: 'Actualités'},
    {id: 'savoirs', label: 'Savoirs'},
    {id: 'cartes', label: 'Cartes'},
  ];

  readonly suggestedQueries = [
    {
      label: 'Les arts et les idées.',
      query: 'Les arts et les idées',
      icon: 'palette',
    },
    {
      label: 'La France qui innove.',
      query: 'La France qui innove',
      icon: 'rocket_launch',
    },
    {
      label: 'Voyages et découvertes.',
      query: 'Voyages et découvertes',
      icon: 'explore',
    },
  ];

  readonly serviceTiles: ServiceTile[] = [
    {
      label: 'Assistant IA',
      subtitle: 'Synthèse sourcée',
      icon: 'auto_awesome',
      query: 'La France qui innove',
      vertical: 'web',
      assistant: true,
    },
    {
      label: 'Culture',
      subtitle: 'Patrimoine & idées',
      icon: 'museum',
      query: 'Les arts et les idées',
      vertical: 'savoirs',
    },
    {
      label: 'Sciences',
      subtitle: 'Recherche & photonique',
      icon: 'science',
      query: 'photonique calcul quantique',
      vertical: 'savoirs',
    },
    {
      label: 'Voyages',
      subtitle: 'Territoires & horizons',
      icon: 'explore',
      query: 'Voyages et découvertes',
      vertical: 'web',
    },
    {
      label: 'Cartes',
      subtitle: 'Lieux & repères',
      icon: 'location_on',
      query: '',
      vertical: 'cartes',
    },
  ];

  private suggestTimer: ReturnType<typeof setTimeout> | null = null;

  selectVertical(vertical: SearchVertical): void {
    this.activeVertical.set(vertical);
    if (vertical !== 'web') {
      void this.router.navigate(['/recherche'], {
        queryParams: {
          q: this.searchControl.value.trim(),
          vertical,
          mode: this.searchMode(),
        },
      });
    }
  }

  onQueryInput(): void {
    const val = this.searchControl.value.trim();
    if (this.suggestTimer) clearTimeout(this.suggestTimer);
    if (!val) {
      this.suggestions.set([]);
      return;
    }
    this.suggestTimer = setTimeout(async () => {
      try {
        const res = await this.api.getSuggestions(val);
        this.suggestions.set(res.suggestions);
        this.suggestionsOpen.set(true);
      } catch {
        this.suggestions.set([]);
      }
    }, 150);
  }

  pickSuggestion(item: SuggestionItem): void {
    this.searchControl.setValue(item.text);
    this.suggestionsOpen.set(false);
    this.submitSearch();
  }

  runSuggestedQuery(query: string): void {
    this.searchControl.setValue(query);
    this.submitSearch();
  }

  openService(svc: ServiceTile): void {
    void this.router.navigate(['/recherche'], {
      queryParams: {
        q: svc.query,
        vertical: svc.vertical,
        mode: this.searchMode(),
        ...(svc.assistant ? {assistant: '1'} : {}),
      },
    });
  }

  onModalSearch(text: string): void {
    this.searchControl.setValue(text);
    this.submitSearch();
  }

  onImageHitSelected(docId: string): void {
    void this.router.navigate(['/source', docId]);
  }

  submitSearch(): void {
    this.suggestionsOpen.set(false);
    void this.router.navigate(['/recherche'], {
      queryParams: {
        q: this.searchControl.value.trim(),
        vertical: this.activeVertical(),
        mode: this.searchMode(),
      },
    });
  }
}
