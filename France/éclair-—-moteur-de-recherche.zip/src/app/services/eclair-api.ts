import {HttpClient, HttpHeaders, HttpParams} from '@angular/common/http';
import {Injectable, computed, inject, signal} from '@angular/core';
import {firstValueFrom} from 'rxjs';
import {
  AbuseReport,
  ApprovedSource,
  AssistantResponse,
  DocumentRecord,
  DuplicateCluster,
  EvaluationRunResult,
  IngestionJob,
  SavedResult,
  SearchMode,
  SearchResponse,
  SearchVertical,
  SuggestionsResponse,
  UserPreferences,
  UserProfile,
} from '../../shared/eclair.types';

export interface AdminOverview {
  indexed_documents: number;
  removed_documents: number;
  vocabulary_terms: number;
  sources_count: number;
  jobs_count: number;
  duplicates_count: number;
  open_abuse_reports: number;
  providers: {
    local_bm25: {configured: boolean; engine: string};
    opensearch: {configured: boolean; endpoint_set: boolean};
    external_web: {configured: boolean};
    gemini_assistant: {configured: boolean; model: string};
  };
}

export interface ImageSearchResponse {
  supported_visual_embedding: boolean;
  query_used?: string;
  retention_notice: string;
  results: SearchResponse['results'];
}

@Injectable({providedIn: 'root'})
export class EclairApi {
  private readonly http = inject(HttpClient);

  // In-memory session state only (never localStorage/sessionStorage)
  readonly userToken = signal<string | null>(null);
  readonly userProfile = signal<UserProfile | null>(null);
  readonly savedResults = signal<SavedResult[]>([]);
  readonly adminToken = signal<string | null>(null);

  readonly isSignedIn = computed(() => Boolean(this.userToken() && this.userProfile()));
  readonly isAdminSignedIn = computed(() => Boolean(this.adminToken()));

  private userHeaders(): HttpHeaders {
    const token = this.userToken();
    return token ? new HttpHeaders({Authorization: `Bearer ${token}`}) : new HttpHeaders();
  }

  private adminHeaders(): HttpHeaders {
    const token = this.adminToken();
    return token ? new HttpHeaders({Authorization: `Bearer ${token}`}) : new HttpHeaders();
  }

  search(params: {
    q: string;
    vertical: SearchVertical;
    mode: SearchMode;
    domain?: string;
    dateFrom?: string;
    dateTo?: string;
    cursor?: string | null;
    limit?: number;
  }): Promise<SearchResponse> {
    let httpParams = new HttpParams()
      .set('q', params.q)
      .set('vertical', params.vertical)
      .set('mode', params.mode)
      .set('limit', String(params.limit ?? 10));

    if (params.domain) httpParams = httpParams.set('domain', params.domain);
    if (params.dateFrom) httpParams = httpParams.set('dateFrom', params.dateFrom);
    if (params.dateTo) httpParams = httpParams.set('dateTo', params.dateTo);
    if (params.cursor) httpParams = httpParams.set('cursor', params.cursor);

    return firstValueFrom(
      this.http.get<SearchResponse>('/v1/search', {
        params: httpParams,
        headers: this.userHeaders(),
      }),
    );
  }

  getSuggestions(q: string): Promise<SuggestionsResponse> {
    const params = new HttpParams().set('q', q);
    return firstValueFrom(
      this.http.get<SuggestionsResponse>('/v1/search/suggestions', {params}),
    );
  }

  getDocument(documentId: string): Promise<DocumentRecord> {
    return firstValueFrom(
      this.http.get<DocumentRecord>(`/v1/documents/${encodeURIComponent(documentId)}`),
    );
  }

  askAssistant(query: string): Promise<AssistantResponse> {
    return firstValueFrom(
      this.http.post<AssistantResponse>('/v1/assistant/answers', {query}),
    );
  }

  searchByImageMetadata(payload: {
    filename: string;
    mimeType: string;
    sizeBytes: number;
    keywords: string;
  }): Promise<ImageSearchResponse> {
    return firstValueFrom(
      this.http.post<ImageSearchResponse>('/v1/search/image', payload),
    );
  }

  // --- Accounts & Saved Results ---

  async register(email: string, password: string, displayName: string): Promise<UserProfile> {
    const res = await firstValueFrom(
      this.http.post<{token: string; profile: UserProfile}>('/v1/auth/register', {
        email,
        password,
        display_name: displayName,
      }),
    );
    this.userToken.set(res.token);
    this.userProfile.set(res.profile);
    await this.loadSavedResults();
    return res.profile;
  }

  async login(email: string, password: string): Promise<UserProfile> {
    const res = await firstValueFrom(
      this.http.post<{token: string; profile: UserProfile}>('/v1/auth/login', {
        email,
        password,
      }),
    );
    this.userToken.set(res.token);
    this.userProfile.set(res.profile);
    await this.loadSavedResults();
    return res.profile;
  }

  logout(): void {
    this.userToken.set(null);
    this.userProfile.set(null);
    this.savedResults.set([]);
  }

  async loadSavedResults(): Promise<SavedResult[]> {
    if (!this.userToken()) return [];
    const res = await firstValueFrom(
      this.http.get<{items: SavedResult[]}>('/v1/me/saved-results', {
        headers: this.userHeaders(),
      }),
    );
    this.savedResults.set(res.items);
    return res.items;
  }

  async saveResult(input: {
    document_id: string;
    title: string;
    source_url: string;
    domain: string;
    snippet: string;
    collection?: string;
  }): Promise<SavedResult> {
    const res = await firstValueFrom(
      this.http.post<{item: SavedResult}>('/v1/me/saved-results', input, {
        headers: this.userHeaders(),
      }),
    );
    await this.loadSavedResults();
    return res.item;
  }

  async removeSavedResult(savedId: string): Promise<void> {
    await firstValueFrom(
      this.http.delete(`/v1/me/saved-results/${encodeURIComponent(savedId)}`, {
        headers: this.userHeaders(),
      }),
    );
    this.savedResults.update((items) => items.filter((i) => i.saved_id !== savedId));
  }

  async updatePreferences(prefs: Partial<UserPreferences>): Promise<UserPreferences> {
    const res = await firstValueFrom(
      this.http.patch<{preferences: UserPreferences}>('/v1/me/preferences', prefs, {
        headers: this.userHeaders(),
      }),
    );
    this.userProfile.update((p) => (p ? {...p, preferences: res.preferences} : null));
    return res.preferences;
  }

  exportMyData(): Promise<Record<string, unknown>> {
    return firstValueFrom(
      this.http.get<Record<string, unknown>>('/v1/me/export', {
        headers: this.userHeaders(),
      }),
    );
  }

  async deleteMyAccount(): Promise<void> {
    await firstValueFrom(
      this.http.delete('/v1/me/account', {
        headers: this.userHeaders(),
      }),
    );
    this.logout();
  }

  submitAbuseReport(input: {
    document_id?: string;
    source_url: string;
    reason: string;
    details: string;
  }): Promise<{report: AbuseReport}> {
    return firstValueFrom(
      this.http.post<{report: AbuseReport}>('/v1/abuse-reports', input),
    );
  }

  // --- Admin APIs ---

  getAdminAuthStatus(): Promise<{
    configured_via_env: boolean;
    needs_bootstrap: boolean;
  }> {
    return firstValueFrom(
      this.http.get<{configured_via_env: boolean; needs_bootstrap: boolean}>(
        '/admin/v1/auth/status',
      ),
    );
  }

  async bootstrapAdmin(password: string): Promise<void> {
    const res = await firstValueFrom(
      this.http.post<{token: string}>('/admin/v1/auth/bootstrap', {password}),
    );
    this.adminToken.set(res.token);
  }

  async loginAdmin(passcode: string): Promise<void> {
    const res = await firstValueFrom(
      this.http.post<{token: string}>('/admin/v1/auth/login', {passcode}),
    );
    this.adminToken.set(res.token);
  }

  logoutAdmin(): void {
    this.adminToken.set(null);
  }

  getAdminOverview(): Promise<AdminOverview> {
    return firstValueFrom(
      this.http.get<AdminOverview>('/admin/v1/overview', {
        headers: this.adminHeaders(),
      }),
    );
  }

  getSources(): Promise<{sources: ApprovedSource[]}> {
    return firstValueFrom(
      this.http.get<{sources: ApprovedSource[]}>('/admin/v1/sources', {
        headers: this.adminHeaders(),
      }),
    );
  }

  addSource(payload: {
    name: string;
    base_url: string;
    allowed_paths: string[];
    vertical: SearchVertical;
    rights_default: string;
    crawl_delay_ms: number;
    max_depth: number;
  }): Promise<{source: ApprovedSource}> {
    return firstValueFrom(
      this.http.post<{source: ApprovedSource}>('/admin/v1/sources', payload, {
        headers: this.adminHeaders(),
      }),
    );
  }

  getAdminDocuments(): Promise<{documents: DocumentRecord[]}> {
    return firstValueFrom(
      this.http.get<{documents: DocumentRecord[]}>('/admin/v1/documents', {
        headers: this.adminHeaders(),
      }),
    );
  }

  deleteDocument(documentId: string): Promise<{removed: boolean}> {
    return firstValueFrom(
      this.http.delete<{removed: boolean}>(
        `/admin/v1/documents/${encodeURIComponent(documentId)}`,
        {headers: this.adminHeaders()},
      ),
    );
  }

  getDuplicates(): Promise<{duplicates: DuplicateCluster[]}> {
    return firstValueFrom(
      this.http.get<{duplicates: DuplicateCluster[]}>('/admin/v1/duplicates', {
        headers: this.adminHeaders(),
      }),
    );
  }

  getJobs(): Promise<{jobs: IngestionJob[]}> {
    return firstValueFrom(
      this.http.get<{jobs: IngestionJob[]}>('/admin/v1/jobs', {
        headers: this.adminHeaders(),
      }),
    );
  }

  createIngestionJob(payload: {
    kind: IngestionJob['kind'];
    target_url?: string;
    title?: string;
    content?: string;
    pdf_base64?: string;
    source_name?: string;
    vertical?: SearchVertical;
    rights_metadata?: string;
  }): Promise<{job: IngestionJob; document?: DocumentRecord}> {
    return firstValueFrom(
      this.http.post<{job: IngestionJob; document?: DocumentRecord}>(
        '/admin/v1/ingestion-jobs',
        payload,
        {headers: this.adminHeaders()},
      ),
    );
  }

  rebuildIndex(): Promise<{rebuilt: boolean; indexed_count: number; vocabulary_size: number}> {
    return firstValueFrom(
      this.http.post<{rebuilt: boolean; indexed_count: number; vocabulary_size: number}>(
        '/admin/v1/index-rebuilds',
        {},
        {headers: this.adminHeaders()},
      ),
    );
  }

  runEvaluation(): Promise<EvaluationRunResult> {
    return firstValueFrom(
      this.http.post<EvaluationRunResult>(
        '/admin/v1/evaluation/run',
        {},
        {headers: this.adminHeaders()},
      ),
    );
  }

  getAbuseReports(): Promise<{reports: AbuseReport[]}> {
    return firstValueFrom(
      this.http.get<{reports: AbuseReport[]}>('/admin/v1/abuse-reports', {
        headers: this.adminHeaders(),
      }),
    );
  }

  resolveAbuseReport(
    reportId: string,
    action: 'resolved' | 'removed',
  ): Promise<{updated: boolean}> {
    return firstValueFrom(
      this.http.patch<{updated: boolean}>(
        `/admin/v1/abuse-reports/${encodeURIComponent(reportId)}`,
        {action},
        {headers: this.adminHeaders()},
      ),
    );
  }
}
