import {ChangeDetectionStrategy, Component, inject, input, output, signal} from '@angular/core';
import {FormControl, FormGroup, ReactiveFormsModule, Validators} from '@angular/forms';
import {MatIconModule} from '@angular/material/icon';
import {EclairApi, ImageSearchResponse} from '../services/eclair-api';
import {SearchHit} from '../../shared/eclair.types';

interface SpeechRecognitionAlternative {
  transcript: string;
}

interface SpeechRecognitionResult {
  0: SpeechRecognitionAlternative;
}

interface SpeechRecognitionEventLike {
  results: ArrayLike<SpeechRecognitionResult>;
}

interface SpeechRecognitionLike {
  lang: string;
  interimResults: boolean;
  maxAlternatives: number;
  onresult: ((ev: SpeechRecognitionEventLike) => void) | null;
  onerror: ((ev: {error?: string}) => void) | null;
  onend: (() => void) | null;
  start(): void;
  stop(): void;
}

@Component({
  changeDetection: ChangeDetectionStrategy.OnPush,
  selector: 'app-voice-modal',
  imports: [ReactiveFormsModule, MatIconModule],
  template: `
    @if (open()) {
      <div
        class="fixed inset-0 z-50 flex items-center justify-center bg-[#07142E]/70 p-4 backdrop-blur-sm"
        role="dialog"
        aria-modal="true"
        aria-labelledby="voice-modal-title"
      >
        <div class="w-full max-w-lg rounded-2xl border border-[#E6D5B3]/60 bg-[#F8F9FB] p-6 text-[#0B1E46] shadow-2xl">
          <div class="flex items-start justify-between gap-4 border-b border-[#0B1E46]/10 pb-4">
            <div class="flex items-center gap-3">
              <div class="flex h-10 w-10 items-center justify-center rounded-xl bg-[#114AC4]/10 text-[#114AC4]">
                <mat-icon>mic</mat-icon>
              </div>
              <div>
                <h2 id="voice-modal-title" class="font-display-serif text-xl font-semibold text-[#0B1E46]">
                  Recherche vocale Éclair
                </h2>
                <p class="text-xs text-[#0B1E46]/70">
                  Capture soumise à votre autorisation explicite.
                </p>
              </div>
            </div>
            <button
              type="button"
              (click)="closeModal()"
              class="flex h-10 w-10 items-center justify-center rounded-lg text-[#0B1E46]/70 hover:bg-[#0B1E46]/5 hover:text-[#0B1E46]"
              aria-label="Fermer la fenêtre vocale"
            >
              <mat-icon>close</mat-icon>
            </button>
          </div>

          <div class="mt-5 space-y-4">
            <div class="rounded-xl border border-[#0B1E46]/10 bg-white p-4 text-sm text-[#0B1E46]/85">
              <p class="font-medium text-[#0B1E46]">
                Confidentialité et contrôle du microphone
              </p>
              <p class="mt-1 text-xs leading-relaxed text-[#0B1E46]/70">
                Le microphone n’est jamais activé automatiquement. La reconnaissance vocale utilise l’API du navigateur pour transcrire votre phrase localement ; vous pouvez relire et modifier le texte avant de lancer la recherche.
              </p>
            </div>

            @if (statusText()) {
              <div class="flex items-center gap-2 rounded-lg border border-[#114AC4]/25 bg-[#114AC4]/5 px-3 py-2 text-xs text-[#0B1E46]">
                <mat-icon class="text-base text-[#114AC4]">graphic_eq</mat-icon>
                <span>{{ statusText() }}</span>
              </div>
            }

            @if (errorText()) {
              <div class="rounded-lg border border-[#C93428]/30 bg-[#C93428]/10 px-3 py-2 text-xs text-[#8C1D14]">
                {{ errorText() }}
              </div>
            }

            <div class="flex flex-wrap items-center gap-3">
              @if (!recording()) {
                <button
                  type="button"
                  (click)="requestPermissionAndRecord()"
                  class="eclair-btn-sapphire inline-flex items-center gap-2 rounded-xl px-4 py-2.5 text-sm font-medium whitespace-nowrap"
                >
                  <mat-icon class="text-base">mic</mat-icon>
                  <span>Autoriser le microphone et dicter</span>
                </button>
              } @else {
                <button
                  type="button"
                  (click)="stopRecording()"
                  class="inline-flex items-center gap-2 rounded-xl bg-[#C93428] px-4 py-2.5 text-sm font-medium text-white hover:bg-[#a9291f] whitespace-nowrap"
                >
                  <mat-icon class="text-base">stop</mat-icon>
                  <span>Arrêter l’écoute</span>
                </button>
              }
            </div>

            <div class="border-t border-[#0B1E46]/10 pt-4">
              <label for="voice-transcript" class="block text-xs font-semibold text-[#0B1E46]">
                Vérifier ou saisir votre requête (repli clavier disponible)
              </label>
              <input
                id="voice-transcript"
                type="text"
                [formControl]="transcriptControl"
                placeholder="Ex. : La France qui innove"
                class="mt-2 w-full rounded-xl border border-[#0B1E46]/20 bg-white px-3.5 py-2.5 text-sm text-[#0B1E46] focus:border-[#114AC4] focus:outline-none"
              />
            </div>
          </div>

          <div class="mt-6 flex justify-end gap-3">
            <button
              type="button"
              (click)="closeModal()"
              class="rounded-xl border border-[#0B1E46]/15 px-4 py-2 text-sm font-medium text-[#0B1E46] hover:bg-[#0B1E46]/5"
            >
              Annuler
            </button>
            <button
              type="button"
              [disabled]="!transcriptControl.value.trim()"
              (click)="submitTranscript()"
              class="eclair-btn-sapphire inline-flex items-center gap-2 rounded-xl px-5 py-2 text-sm font-medium disabled:opacity-50"
            >
              <mat-icon class="text-base">search</mat-icon>
              <span>Rechercher ce texte</span>
            </button>
          </div>
        </div>
      </div>
    }
  `,
})
export class VoiceModal {
  readonly open = input<boolean>(false);
  readonly closed = output<void>();
  readonly searchSubmitted = output<string>();

  readonly recording = signal(false);
  readonly statusText = signal<string | null>(null);
  readonly errorText = signal<string | null>(null);
  readonly transcriptControl = new FormControl('', {nonNullable: true});

  private recognition: SpeechRecognitionLike | null = null;

  async requestPermissionAndRecord(): Promise<void> {
    this.errorText.set(null);
    this.statusText.set('Demande d’autorisation d’accès au microphone…');

    if (typeof navigator !== 'undefined' && navigator.mediaDevices?.getUserMedia) {
      try {
        const stream = await navigator.mediaDevices.getUserMedia({audio: true});
        for (const track of stream.getTracks()) {
          track.stop();
        }
      } catch {
        this.statusText.set(null);
        this.errorText.set(
          'Accès au microphone refusé ou indisponible. Vous pouvez saisir votre requête manuellement ci-dessous.',
        );
        return;
      }
    }

    const win = window as unknown as {
      SpeechRecognition?: new () => SpeechRecognitionLike;
      webkitSpeechRecognition?: new () => SpeechRecognitionLike;
    };
    const RecCtor = win.SpeechRecognition || win.webkitSpeechRecognition;

    if (!RecCtor) {
      this.statusText.set(null);
      this.errorText.set(
        'La transcription vocale native n’est pas prise en charge par ce navigateur. Utilisez la zone de saisie ci-dessous.',
      );
      return;
    }

    const rec = new RecCtor();
    rec.lang = 'fr-FR';
    rec.interimResults = false;
    rec.maxAlternatives = 1;

    rec.onresult = (event) => {
      const text = event.results[0]?.[0]?.transcript ?? '';
      if (text) {
        this.transcriptControl.setValue(text);
        this.statusText.set('Transcription prête pour relecture.');
      }
    };
    rec.onerror = () => {
      this.errorText.set(
        'Erreur lors de la reconnaissance vocale. Vous pouvez corriger ou saisir le texte manuellement.',
      );
      this.recording.set(false);
    };
    rec.onend = () => {
      this.recording.set(false);
    };

    this.recognition = rec;
    this.recording.set(true);
    this.statusText.set('Écoute active en français… Parlez distinctement.');
    rec.start();
  }

  stopRecording(): void {
    this.recognition?.stop();
    this.recording.set(false);
    this.statusText.set('Écoute interrompue. Relisez la transcription.');
  }

  submitTranscript(): void {
    const val = this.transcriptControl.value.trim();
    if (!val) return;
    this.stopRecording();
    this.searchSubmitted.emit(val);
    this.closed.emit();
  }

  closeModal(): void {
    if (this.recording()) {
      this.recognition?.stop();
      this.recording.set(false);
    }
    this.closed.emit();
  }
}

@Component({
  changeDetection: ChangeDetectionStrategy.OnPush,
  selector: 'app-image-modal',
  imports: [ReactiveFormsModule, MatIconModule],
  template: `
    @if (open()) {
      <div
        class="fixed inset-0 z-50 flex items-center justify-center bg-[#07142E]/70 p-4 backdrop-blur-sm"
        role="dialog"
        aria-modal="true"
        aria-labelledby="image-modal-title"
      >
        <div class="w-full max-w-xl rounded-2xl border border-[#E6D5B3]/60 bg-[#F8F9FB] p-6 text-[#0B1E46] shadow-2xl">
          <div class="flex items-start justify-between gap-4 border-b border-[#0B1E46]/10 pb-4">
            <div class="flex items-center gap-3">
              <div class="flex h-10 w-10 items-center justify-center rounded-xl bg-[#114AC4]/10 text-[#114AC4]">
                <mat-icon>photo_camera</mat-icon>
              </div>
              <div>
                <h2 id="image-modal-title" class="font-display-serif text-xl font-semibold text-[#0B1E46]">
                  Recherche par image & métadonnées
                </h2>
                <p class="text-xs text-[#0B1E46]/70">
                  Traitement transparent sans conservation de vos fichiers.
                </p>
              </div>
            </div>
            <button
              type="button"
              (click)="closed.emit()"
              class="flex h-10 w-10 items-center justify-center rounded-lg text-[#0B1E46]/70 hover:bg-[#0B1E46]/5"
              aria-label="Fermer la recherche par image"
            >
              <mat-icon>close</mat-icon>
            </button>
          </div>

          <div class="mt-4 space-y-4">
            <div class="rounded-xl border border-[#0B1E46]/10 bg-white p-4 text-xs leading-relaxed text-[#0B1E46]/80">
              <strong class="block text-[#0B1E46]">Finalité et rétention :</strong>
              Aucun fichier sélectionné n’est téléversé automatiquement ni stocké après la requête. L’adaptateur visuel actuel effectue une correspondance sur les mots-clés descriptifs et métadonnées des images autorisées de la Photothèque Éclair (la similarité pixel-à-pixel par réseau neuronal est désactivée).
            </div>

            <div>
              <label for="image-file-input" class="block text-xs font-semibold text-[#0B1E46]">
                1. Sélectionner une image locale (JPEG, PNG ou WebP, max. 5 Mo)
              </label>
              <input
                id="image-file-input"
                type="file"
                accept="image/jpeg,image/png,image/webp"
                (change)="onFileSelected($event)"
                class="mt-2 block w-full rounded-xl border border-dashed border-[#0B1E46]/25 bg-white px-3 py-2.5 text-xs text-[#0B1E46]"
              />
            </div>

            <div>
              <label for="image-keywords-input" class="block text-xs font-semibold text-[#0B1E46]">
                2. Mots-clés descriptifs (ex. : Provence, Grand Palais, Paris, laboratoire)
              </label>
              <input
                id="image-keywords-input"
                type="text"
                [formControl]="keywordsControl"
                placeholder="Décrivez le sujet de l’image recherchée"
                class="mt-1.5 w-full rounded-xl border border-[#0B1E46]/20 bg-white px-3.5 py-2.5 text-sm text-[#0B1E46] focus:border-[#114AC4] focus:outline-none"
              />
            </div>

            @if (errorText()) {
              <div class="rounded-lg border border-[#C93428]/30 bg-[#C93428]/10 px-3 py-2 text-xs text-[#8C1D14]">
                {{ errorText() }}
              </div>
            }

            @if (response(); as res) {
              <div class="space-y-3 rounded-xl border border-[#0B1E46]/10 bg-white p-4">
                <p class="text-xs text-[#0B1E46]/75">{{ res.retention_notice }}</p>
                @if (res.results.length === 0) {
                  <p class="text-xs font-medium text-[#0B1E46]">
                    Aucune image autorisée ne correspond aux mots-clés fournis.
                  </p>
                } @else {
                  <div class="grid grid-cols-1 gap-3 sm:grid-cols-2">
                    @for (hit of res.results; track hit.document_id) {
                      <button
                        type="button"
                        (click)="openImageHit(hit)"
                        class="flex items-center gap-3 rounded-xl border border-[#0B1E46]/10 p-2 text-left hover:border-[#114AC4]/40"
                      >
                        @if (hit.image_metadata; as img) {
                          <img
                            [src]="img.asset_url"
                            [alt]="img.alt_text"
                            referrerpolicy="no-referrer"
                            class="h-14 w-16 shrink-0 rounded-lg object-cover"
                          />
                        }
                        <div class="min-w-0">
                          <div class="truncate text-xs font-semibold text-[#0B1E46]">
                            {{ hit.title }}
                          </div>
                          <div class="truncate text-[11px] text-[#0B1E46]/65">
                            {{ hit.image_metadata?.credit }}
                          </div>
                        </div>
                      </button>
                    }
                  </div>
                }
              </div>
            }
          </div>

          <div class="mt-6 flex justify-end gap-3">
            <button
              type="button"
              (click)="closed.emit()"
              class="rounded-xl border border-[#0B1E46]/15 px-4 py-2 text-sm font-medium text-[#0B1E46] hover:bg-[#0B1E46]/5"
            >
              Fermer
            </button>
            <button
              type="button"
              [disabled]="loading()"
              (click)="runImageSearch()"
              class="eclair-btn-sapphire inline-flex items-center gap-2 rounded-xl px-5 py-2 text-sm font-medium disabled:opacity-50"
            >
              <mat-icon class="text-base">image_search</mat-icon>
              <span>{{ loading() ? 'Analyse en cours…' : 'Rechercher par métadonnées' }}</span>
            </button>
          </div>
        </div>
      </div>
    }
  `,
})
export class ImageModal {
  private readonly api = inject(EclairApi);

  readonly open = input<boolean>(false);
  readonly closed = output<void>();
  readonly hitSelected = output<string>();

  readonly keywordsControl = new FormControl('', {nonNullable: true});
  readonly loading = signal(false);
  readonly errorText = signal<string | null>(null);
  readonly response = signal<ImageSearchResponse | null>(null);

  private selectedFileMeta: {filename: string; mimeType: string; sizeBytes: number} | null =
    null;

  onFileSelected(event: Event): void {
    this.errorText.set(null);
    const inputEl = event.target as HTMLInputElement;
    const file = inputEl.files?.[0];
    if (!file) return;

    const allowed = ['image/jpeg', 'image/png', 'image/webp'];
    if (!allowed.includes(file.type)) {
      this.errorText.set('Format non valide : veuillez choisir un fichier JPEG, PNG ou WebP.');
      return;
    }
    if (file.size > 5 * 1024 * 1024) {
      this.errorText.set('Fichier supérieur à la limite autorisée de 5 Mo.');
      return;
    }

    this.selectedFileMeta = {
      filename: file.name,
      mimeType: file.type,
      sizeBytes: file.size,
    };

    if (!this.keywordsControl.value.trim()) {
      const cleaned = file.name
        .replace(/\.[a-z0-9]+$/i, '')
        .replace(/[-_]+/g, ' ')
        .trim();
      this.keywordsControl.setValue(cleaned);
    }
  }

  async runImageSearch(): Promise<void> {
    this.errorText.set(null);
    const keywords = this.keywordsControl.value.trim();
    if (!this.selectedFileMeta && !keywords) {
      this.errorText.set('Sélectionnez une image ou indiquez des mots-clés descriptifs.');
      return;
    }

    this.loading.set(true);
    try {
      const meta = this.selectedFileMeta ?? {
        filename: `${keywords}.jpg`,
        mimeType: 'image/jpeg',
        sizeBytes: 1024,
      };
      const res = await this.api.searchByImageMetadata({
        ...meta,
        keywords,
      });
      this.response.set(res);
    } catch {
      this.errorText.set('Impossible d’interroger l’adaptateur de recherche visuelle.');
    } finally {
      this.loading.set(false);
    }
  }

  openImageHit(hit: SearchHit): void {
    this.hitSelected.emit(hit.document_id);
    this.closed.emit();
  }
}

@Component({
  changeDetection: ChangeDetectionStrategy.OnPush,
  selector: 'app-account-modal',
  imports: [ReactiveFormsModule, MatIconModule],
  template: `
    @if (open()) {
      <div
        class="fixed inset-0 z-50 flex items-center justify-center bg-[#07142E]/70 p-4 backdrop-blur-sm"
        role="dialog"
        aria-modal="true"
        aria-labelledby="account-modal-title"
      >
        <div class="max-h-[90vh] w-full max-w-xl overflow-y-auto rounded-2xl border border-[#E6D5B3]/60 bg-[#F8F9FB] p-6 text-[#0B1E46] shadow-2xl">
          <div class="flex items-start justify-between gap-4 border-b border-[#0B1E46]/10 pb-4">
            <div>
              <h2 id="account-modal-title" class="font-display-serif text-xl font-semibold text-[#0B1E46]">
                {{ api.isSignedIn() ? 'Espace personnel Éclair' : 'Connexion optionnelle Éclair' }}
              </h2>
              <p class="text-xs text-[#0B1E46]/70">
                La recherche anonyme fonctionne sans compte. Un compte permet de conserver vos résultats et préférences.
              </p>
            </div>
            <button
              type="button"
              (click)="closed.emit()"
              class="flex h-10 w-10 items-center justify-center rounded-lg text-[#0B1E46]/70 hover:bg-[#0B1E46]/5"
              aria-label="Fermer la fenêtre de compte"
            >
              <mat-icon>close</mat-icon>
            </button>
          </div>

          @if (errorText()) {
            <div class="mt-4 rounded-lg border border-[#C93428]/30 bg-[#C93428]/10 px-3 py-2 text-xs text-[#8C1D14]">
              {{ errorText() }}
            </div>
          }

          @if (!api.isSignedIn()) {
            <div class="mt-4 flex gap-2 rounded-xl bg-[#0B1E46]/5 p-1">
              <button
                type="button"
                (click)="authMode.set('login')"
                [class]="authMode() === 'login' ? 'flex-1 rounded-lg bg-white py-2 text-xs font-semibold text-[#0B1E46] shadow-sm' : 'flex-1 rounded-lg py-2 text-xs font-medium text-[#0B1E46]/70'"
              >
                Se connecter
              </button>
              <button
                type="button"
                (click)="authMode.set('register')"
                [class]="authMode() === 'register' ? 'flex-1 rounded-lg bg-white py-2 text-xs font-semibold text-[#0B1E46] shadow-sm' : 'flex-1 rounded-lg py-2 text-xs font-medium text-[#0B1E46]/70'"
              >
                Créer un compte
              </button>
            </div>

            <form [formGroup]="authForm" (ngSubmit)="submitAuth()" class="mt-4 space-y-3">
              @if (authMode() === 'register') {
                <div>
                  <label for="acc-name" class="block text-xs font-semibold text-[#0B1E46]">Nom affiché</label>
                  <input
                    id="acc-name"
                    type="text"
                    formControlName="displayName"
                    placeholder="Camille Laurent"
                    class="mt-1 w-full rounded-xl border border-[#0B1E46]/20 bg-white px-3.5 py-2 text-sm text-[#0B1E46]"
                  />
                </div>
              }
              <div>
                <label for="acc-email" class="block text-xs font-semibold text-[#0B1E46]">Adresse courriel</label>
                <input
                  id="acc-email"
                  type="email"
                  formControlName="email"
                  placeholder="camille@exemple.fr"
                  class="mt-1 w-full rounded-xl border border-[#0B1E46]/20 bg-white px-3.5 py-2 text-sm text-[#0B1E46]"
                />
              </div>
              <div>
                <label for="acc-password" class="block text-xs font-semibold text-[#0B1E46]">Mot de passe (8 caractères min.)</label>
                <input
                  id="acc-password"
                  type="password"
                  formControlName="password"
                  placeholder="••••••••"
                  class="mt-1 w-full rounded-xl border border-[#0B1E46]/20 bg-white px-3.5 py-2 text-sm text-[#0B1E46]"
                />
              </div>
              <div class="pt-2">
                <button
                  type="submit"
                  [disabled]="busy()"
                  class="eclair-btn-sapphire w-full rounded-xl px-4 py-2.5 text-sm font-medium"
                >
                  {{ authMode() === 'login' ? 'Se connecter' : 'Créer mon compte' }}
                </button>
              </div>
            </form>
          } @else {
            @if (api.userProfile(); as profile) {
              <div class="mt-4 space-y-5">
                <div class="flex flex-wrap items-center justify-between gap-3 rounded-xl border border-[#0B1E46]/10 bg-white p-4">
                  <div>
                    <div class="text-sm font-semibold text-[#0B1E46]">{{ profile.display_name }}</div>
                    <div class="text-xs text-[#0B1E46]/65">{{ profile.email }}</div>
                  </div>
                  <button
                    type="button"
                    (click)="api.logout()"
                    class="rounded-lg border border-[#0B1E46]/15 px-3 py-1.5 text-xs font-medium text-[#0B1E46] hover:bg-[#0B1E46]/5"
                  >
                    Se déconnecter
                  </button>
                </div>

                <div class="rounded-xl border border-[#0B1E46]/10 bg-white p-4">
                  <div class="flex items-center justify-between gap-4">
                    <div>
                      <div class="text-sm font-semibold text-[#0B1E46]">Historique de recherche explicite</div>
                      <p class="text-xs text-[#0B1E46]/65">
                        Désactivé par défaut. Activez uniquement si vous souhaitez mémoriser vos requêtes dans ce compte.
                      </p>
                    </div>
                    <button
                      type="button"
                      (click)="toggleHistory(!profile.preferences.save_search_history)"
                      class="rounded-lg border border-[#0B1E46]/20 px-3 py-1.5 text-xs font-semibold"
                      [class]="profile.preferences.save_search_history ? 'bg-[#114AC4] text-white border-[#114AC4]' : 'bg-white text-[#0B1E46]'"
                    >
                      {{ profile.preferences.save_search_history ? 'Activé' : 'Désactivé' }}
                    </button>
                  </div>
                </div>

                <div>
                  <h3 class="text-sm font-semibold text-[#0B1E46]">
                    Résultats enregistrés ({{ api.savedResults().length }})
                  </h3>
                  @if (api.savedResults().length === 0) {
                    <p class="mt-2 text-xs text-[#0B1E46]/65">
                      Aucun résultat enregistré pour le moment. Cliquez sur « Enregistrer » sur n’importe quel résultat de recherche.
                    </p>
                  } @else {
                    <div class="mt-2 space-y-2">
                      @for (item of api.savedResults(); track item.saved_id) {
                        <div class="flex items-start justify-between gap-3 rounded-xl border border-[#0B1E46]/10 bg-white p-3">
                          <div class="min-w-0">
                            <div class="truncate text-sm font-medium text-[#0B1E46]">{{ item.title }}</div>
                            <div class="text-xs text-[#0B1E46]/60">{{ item.domain }} · {{ item.collection }}</div>
                          </div>
                          <button
                            type="button"
                            (click)="api.removeSavedResult(item.saved_id)"
                            class="shrink-0 rounded-lg p-1.5 text-[#C93428] hover:bg-[#C93428]/10"
                            aria-label="Supprimer ce résultat enregistré"
                          >
                            <mat-icon class="text-base">delete_outline</mat-icon>
                          </button>
                        </div>
                      }
                    </div>
                  }
                </div>

                <div class="flex flex-wrap items-center justify-between gap-3 border-t border-[#0B1E46]/10 pt-4">
                  <button
                    type="button"
                    (click)="downloadExport()"
                    class="inline-flex items-center gap-1.5 rounded-lg border border-[#0B1E46]/20 bg-white px-3 py-2 text-xs font-medium text-[#0B1E46] hover:bg-[#0B1E46]/5"
                  >
                    <mat-icon class="text-base">download</mat-icon>
                    <span>Exporter mes données (JSON)</span>
                  </button>
                  <button
                    type="button"
                    (click)="deleteAccount()"
                    class="inline-flex items-center gap-1.5 rounded-lg border border-[#C93428]/30 bg-[#C93428]/5 px-3 py-2 text-xs font-medium text-[#C93428] hover:bg-[#C93428]/10"
                  >
                    <mat-icon class="text-base">person_remove</mat-icon>
                    <span>Supprimer mon compte</span>
                  </button>
                </div>
              </div>
            }
          }
        </div>
      </div>
    }
  `,
})
export class AccountModal {
  readonly api = inject(EclairApi);

  readonly open = input<boolean>(false);
  readonly closed = output<void>();

  readonly authMode = signal<'login' | 'register'>('login');
  readonly busy = signal(false);
  readonly errorText = signal<string | null>(null);

  readonly authForm = new FormGroup({
    displayName: new FormControl('', {nonNullable: true}),
    email: new FormControl('', {nonNullable: true, validators: [Validators.required]}),
    password: new FormControl('', {nonNullable: true, validators: [Validators.required]}),
  });

  async submitAuth(): Promise<void> {
    this.errorText.set(null);
    const {email, password, displayName} = this.authForm.getRawValue();
    this.busy.set(true);
    try {
      if (this.authMode() === 'login') {
        await this.api.login(email, password);
      } else {
        await this.api.register(email, password, displayName);
      }
      this.authForm.reset();
    } catch (err: unknown) {
      const msg = (err as {error?: {error?: string}})?.error?.error;
      this.errorText.set(msg || 'Impossible de valider votre authentification.');
    } finally {
      this.busy.set(false);
    }
  }

  async toggleHistory(nextVal: boolean): Promise<void> {
    await this.api.updatePreferences({save_search_history: nextVal});
  }

  async downloadExport(): Promise<void> {
    const data = await this.api.exportMyData();
    const blob = new Blob([JSON.stringify(data, null, 2)], {
      type: 'application/json',
    });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'eclair-export-donnees.json';
    a.click();
    URL.revokeObjectURL(url);
  }

  async deleteAccount(): Promise<void> {
    await this.api.deleteMyAccount();
    this.closed.emit();
  }
}
