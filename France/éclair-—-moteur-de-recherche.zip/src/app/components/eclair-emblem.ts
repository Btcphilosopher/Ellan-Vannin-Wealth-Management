import {ChangeDetectionStrategy, Component, computed, input} from '@angular/core';

@Component({
  changeDetection: ChangeDetectionStrategy.OnPush,
  selector: 'app-eclair-emblem',
  template: `
    <svg
      [attr.width]="pixelSize()"
      [attr.height]="pixelSize()"
      viewBox="0 0 64 64"
      fill="none"
      aria-hidden="true"
      class="shrink-0 drop-shadow-[0_6px_14px_rgba(11,30,70,0.35)]"
    >
      <defs>
        <linearGradient id="eclairSapphireWing" x1="8" y1="6" x2="56" y2="58" gradientUnits="userSpaceOnUse">
          <stop offset="0%" stop-color="#8FD3FF" />
          <stop offset="32%" stop-color="#1E73FF" />
          <stop offset="72%" stop-color="#0B3EA8" />
          <stop offset="100%" stop-color="#071B4D" />
        </linearGradient>
        <linearGradient id="eclairFeatherRim" x1="14" y1="8" x2="48" y2="52" gradientUnits="userSpaceOnUse">
          <stop offset="0%" stop-color="#FFFFFF" stop-opacity="0.95" />
          <stop offset="45%" stop-color="#E6D5B3" stop-opacity="0.8" />
          <stop offset="100%" stop-color="#6EB7FF" stop-opacity="0.35" />
        </linearGradient>
      </defs>
      <!-- Sweeping sapphire feather / E-wing silhouette -->
      <path
        d="M54 11C39 11 25 17 17 27C13 32 10 41 9 53C19 46 29 44 43 44L47 36C36 36 28 37 22 40C24 35 28 32 35 30L49 27L52 20L31 23C36 18 44 15 54 14L54 11Z"
        fill="url(#eclairSapphireWing)"
        stroke="url(#eclairFeatherRim)"
        stroke-width="1.5"
        stroke-linejoin="round"
      />
      <!-- Luminous spine highlight -->
      <path
        d="M12 49C18 35 29 22 49 13"
        stroke="#FFFFFF"
        stroke-opacity="0.72"
        stroke-width="1.4"
        stroke-linecap="round"
      />
    </svg>
  `,
})
export class EclairEmblem {
  readonly size = input<'sm' | 'md' | 'lg'>('md');
  readonly pixelSize = computed(() => {
    switch (this.size()) {
      case 'sm':
        return 26;
      case 'lg':
        return 56;
      default:
        return 36;
    }
  });
}
