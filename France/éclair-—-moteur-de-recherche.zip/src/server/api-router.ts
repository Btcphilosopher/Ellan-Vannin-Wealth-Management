import {randomBytes} from 'node:crypto';
import express, {NextFunction, Request, Response, Router} from 'express';
import {
  IngestionJob,
  SearchMode,
  SearchVertical,
} from '../shared/eclair.types';
import {GeminiGroundedAssistantAdapter} from './assistant/grounded-assistant';
import {
  crawlBoundedUrl,
  extractHtmlContent,
  extractMarkdownContent,
  extractPdfTextSafe,
} from './ingestion/crawler';
import {ExternalWebSearchAdapter} from './search/bm25-engine';
import {EclairStore} from './store/eclair-store';

export function createEclairApiRouter(store: EclairStore): Router {
  const router = Router();
  const externalAdapter = new ExternalWebSearchAdapter();
  const assistantAdapter = new GeminiGroundedAssistantAdapter();

  router.use(express.json({limit: '3mb'}));

  // Simple sliding-window rate limiter for expensive endpoints
  const rateBuckets = new Map<string, number[]>();
  function rateLimit(maxPerMinute: number) {
    return (req: Request, res: Response, next: NextFunction) => {
      const key = `${req.ip ?? 'local'}:${req.path}`;
      const now = Date.now();
      const windowStart = now - 60_000;
      const entries = (rateBuckets.get(key) ?? []).filter((t) => t > windowStart);
      if (entries.length >= maxPerMinute) {
        res.status(429).json({
          error:
            'Trop de requêtes sur un intervalle court. Merci de patienter quelques instants.',
        });
        return;
      }
      entries.push(now);
      rateBuckets.set(key, entries);
      next();
    };
  }

  function requireUser(req: Request, res: Response, next: NextFunction) {
    const session = store.verifySession(req.header('authorization'), 'user');
    if (!session?.userId) {
      res.status(401).json({error: 'Authentification utilisateur requise.'});
      return;
    }
    res.locals['userId'] = session.userId;
    next();
  }

  function requireAdmin(req: Request, res: Response, next: NextFunction) {
    const session = store.verifySession(req.header('authorization'), 'admin');
    if (!session) {
      res.status(401).json({error: 'Accès administrateur requis.'});
      return;
    }
    next();
  }

  // --- Search APIs ---

  router.get('/v1/search', async (req, res) => {
    const q = String(req.query['q'] ?? '').slice(0, 240);
    const verticalRaw = String(req.query['vertical'] ?? 'web');
    const vertical: SearchVertical = (
      ['web', 'images', 'actualites', 'savoirs', 'cartes'] as const
    ).includes(verticalRaw as SearchVertical)
      ? (verticalRaw as SearchVertical)
      : 'web';
    const mode: SearchMode =
      req.query['mode'] === 'external' ? 'external' : 'local';
    const domain = req.query['domain']
      ? String(req.query['domain']).slice(0, 120)
      : undefined;
    const dateFrom = req.query['dateFrom']
      ? String(req.query['dateFrom']).slice(0, 10)
      : undefined;
    const dateTo = req.query['dateTo']
      ? String(req.query['dateTo']).slice(0, 10)
      : undefined;
    const cursor = req.query['cursor'] ? String(req.query['cursor']) : null;
    const limit = Math.min(Math.max(Number(req.query['limit'] ?? 10) || 10, 1), 25);

    // Optional opt-in search history if authenticated
    const userSession = store.verifySession(req.header('authorization'), 'user');
    if (userSession?.userId && q.trim()) {
      store.recordSearchHistoryIfEnabled(userSession.userId, q, vertical);
    }

    if (mode === 'external') {
      const extResult = await externalAdapter.search({
        q,
        vertical,
        mode,
        domain,
        dateFrom,
        dateTo,
        cursor,
        limit,
      });
      res.json(extResult);
      return;
    }

    const localResult = store.bm25.search({
      q,
      vertical,
      mode: 'local',
      domain,
      dateFrom,
      dateTo,
      cursor,
      limit,
    });
    res.json(localResult);
  });

  router.get('/v1/search/suggestions', (req, res) => {
    const q = String(req.query['q'] ?? '').slice(0, 160);
    res.json(store.bm25.suggest(q, 6));
  });

  router.post('/v1/search/image', rateLimit(20), (req, res) => {
    const body = req.body as {
      filename?: string;
      mimeType?: string;
      sizeBytes?: number;
      keywords?: string;
    };

    const allowedMimes = ['image/jpeg', 'image/png', 'image/webp'];
    if (!body.mimeType || !allowedMimes.includes(body.mimeType)) {
      res.status(400).json({
        error: 'Format d’image non pris en charge (JPEG, PNG ou WebP uniquement).',
      });
      return;
    }
    if (!body.sizeBytes || body.sizeBytes > 5 * 1024 * 1024) {
      res.status(400).json({
        error: 'Taille de fichier invalide ou supérieure à 5 Mo.',
      });
      return;
    }

    const hintQuery =
      body.keywords?.trim() ||
      (body.filename ?? '')
        .replace(/\.[a-z0-9]+$/i, '')
        .replace(/[-_]+/g, ' ')
        .trim();

    if (!hintQuery) {
      res.json({
        supported_visual_embedding: false,
        retention_notice:
          'Aucune image n’est conservée sur le serveur. L’adaptateur visuel actuel effectue une correspondance sur mots-clés descriptifs et métadonnées autorisées uniquement.',
        results: [],
      });
      return;
    }

    const hits = store.bm25.search({
      q: hintQuery,
      vertical: 'images',
      limit: 6,
    });

    res.json({
      supported_visual_embedding: false,
      query_used: hintQuery,
      retention_notice:
        'Traitement éphémère en mémoire : le fichier sélectionné n’est ni stocké ni indexé. Recherche par métadonnées autorisées (aucun modèle d’empreinte visuelle externe configuré).',
      results: hits.results,
    });
  });

  router.get('/v1/documents/:document_id', (req, res) => {
    const doc = store.getDocumentById(req.params['document_id']);
    if (!doc || doc.index_status === 'removed') {
      res.status(404).json({error: 'Document introuvable ou retiré de l’index.'});
      return;
    }
    res.json(doc);
  });

  // --- Grounded Assistant API ---

  router.post('/v1/assistant/answers', rateLimit(15), async (req, res) => {
    const body = req.body as {query?: string};
    const query = String(body?.query ?? '').slice(0, 300);
    const answer = await assistantAdapter.answer(
      query,
      store.bm25,
      store.getDocuments(),
    );
    res.json(answer);
  });

  // --- User Accounts, Saved Results & Privacy ---

  router.post('/v1/auth/register', rateLimit(15), (req, res) => {
    const body = req.body as {
      email?: string;
      password?: string;
      display_name?: string;
    };
    const result = store.registerUser(
      String(body?.email ?? ''),
      String(body?.password ?? ''),
      String(body?.display_name ?? ''),
    );
    if (!result.ok) {
      res.status(400).json({error: result.error});
      return;
    }
    res.status(201).json({token: result.token, profile: result.profile});
  });

  router.post('/v1/auth/login', rateLimit(20), (req, res) => {
    const body = req.body as {email?: string; password?: string};
    const result = store.loginUser(
      String(body?.email ?? ''),
      String(body?.password ?? ''),
    );
    if (!result.ok) {
      res.status(401).json({error: result.error});
      return;
    }
    res.json({token: result.token, profile: result.profile});
  });

  router.get('/v1/me/profile', requireUser, (_req, res) => {
    const user = store.getUserById(String(res.locals['userId']));
    if (!user) {
      res.status(404).json({error: 'Compte introuvable.'});
      return;
    }
    res.json({
      user_id: user.user_id,
      email: user.email,
      display_name: user.display_name,
      preferences: user.preferences,
    });
  });

  router.patch('/v1/me/preferences', requireUser, (req, res) => {
    const body = req.body as {
      save_search_history?: boolean;
      default_mode?: SearchMode;
    };
    const updated = store.updateUserPreferences(
      String(res.locals['userId']),
      {
        ...(typeof body.save_search_history === 'boolean'
          ? {save_search_history: body.save_search_history}
          : {}),
        ...(body.default_mode === 'local' || body.default_mode === 'external'
          ? {default_mode: body.default_mode}
          : {}),
      },
    );
    res.json({preferences: updated});
  });

  router.get('/v1/me/saved-results', requireUser, (_req, res) => {
    const items = store.getSavedResults(String(res.locals['userId']));
    res.json({items});
  });

  router.post('/v1/me/saved-results', requireUser, (req, res) => {
    const body = req.body as {
      document_id?: string;
      title?: string;
      source_url?: string;
      domain?: string;
      snippet?: string;
      collection?: string;
    };
    if (!body.document_id || !body.title || !body.source_url) {
      res.status(400).json({error: 'Champs requis manquants pour l’enregistrement.'});
      return;
    }
    const created = store.addSavedResult(String(res.locals['userId']), {
      document_id: String(body.document_id),
      title: String(body.title),
      source_url: String(body.source_url),
      domain: String(body.domain ?? ''),
      snippet: String(body.snippet ?? ''),
      collection: body.collection ? String(body.collection) : undefined,
    });
    res.status(201).json({item: created});
  });

  router.delete('/v1/me/saved-results/:saved_id', requireUser, (req, res) => {
    const deleted = store.deleteSavedResult(
      String(res.locals['userId']),
      String(req.params['saved_id']),
    );
    if (!deleted) {
      res.status(404).json({error: 'Élément enregistré introuvable.'});
      return;
    }
    res.json({deleted: true});
  });

  router.get('/v1/me/history', requireUser, (_req, res) => {
    const user = store.getUserById(String(res.locals['userId']));
    res.json({history: user?.history ?? []});
  });

  router.get('/v1/me/export', requireUser, (_req, res) => {
    const data = store.exportUserData(String(res.locals['userId']));
    res.json(data);
  });

  router.delete('/v1/me/account', requireUser, (_req, res) => {
    const deleted = store.deleteUserAccount(String(res.locals['userId']));
    res.json({deleted});
  });

  // --- Abuse Reports ---

  router.post('/v1/abuse-reports', rateLimit(10), (req, res) => {
    const body = req.body as {
      document_id?: string;
      source_url?: string;
      reason?: string;
      details?: string;
    };
    if (!body.source_url || !body.reason) {
      res.status(400).json({error: 'URL source et motif requis.'});
      return;
    }
    const report = store.createAbuseReport({
      document_id: body.document_id ? String(body.document_id) : undefined,
      source_url: String(body.source_url).slice(0, 400),
      reason: String(body.reason).slice(0, 120),
      details: String(body.details ?? '').slice(0, 1000),
    });
    res.status(201).json({report});
  });

  // --- Admin Auth & Operations ---

  router.get('/admin/v1/auth/status', (_req, res) => {
    res.json(store.getAdminAuthStatus());
  });

  router.post('/admin/v1/auth/bootstrap', rateLimit(10), (req, res) => {
    const body = req.body as {password?: string};
    const result = store.bootstrapAdminPassword(String(body?.password ?? ''));
    if (!result.ok) {
      res.status(400).json({error: result.error});
      return;
    }
    res.status(201).json({token: result.token});
  });

  router.post('/admin/v1/auth/login', rateLimit(15), (req, res) => {
    const body = req.body as {passcode?: string};
    const result = store.loginAdmin(String(body?.passcode ?? ''));
    if (!result.ok) {
      res.status(401).json({error: result.error});
      return;
    }
    res.json({token: result.token});
  });

  router.get('/admin/v1/overview', requireAdmin, (_req, res) => {
    const docs = store.getDocuments();
    const indexed = docs.filter((d) => d.index_status === 'indexed').length;
    const removed = docs.filter((d) => d.index_status === 'removed').length;
    res.json({
      indexed_documents: indexed,
      removed_documents: removed,
      vocabulary_terms: store.bm25.getVocabularySize(),
      sources_count: store.getSources().length,
      jobs_count: store.getJobs().length,
      duplicates_count: store.getDuplicates().length,
      open_abuse_reports: store
        .getAbuseReports()
        .filter((r) => r.status === 'open').length,
      providers: {
        local_bm25: {configured: true, engine: 'LocalFrenchBm25Index'},
        opensearch: {
          configured: Boolean(process.env['OPENSEARCH_URL']?.trim()),
          endpoint_set: Boolean(process.env['OPENSEARCH_URL']?.trim()),
        },
        external_web: {
          configured: Boolean(
            process.env['EXTERNAL_WEB_SEARCH_URL']?.trim() &&
              process.env['EXTERNAL_WEB_SEARCH_API_KEY']?.trim(),
          ),
        },
        gemini_assistant: {
          configured: Boolean(
            process.env['GEMINI_API_KEY']?.trim() &&
              process.env['GEMINI_API_KEY'] !== 'MY_GEMINI_API_KEY',
          ),
          model: 'gemini-4-hydrogen',
        },
      },
    });
  });

  router.get('/admin/v1/sources', requireAdmin, (_req, res) => {
    res.json({sources: store.getSources()});
  });

  router.post('/admin/v1/sources', requireAdmin, (req, res) => {
    const body = req.body as {
      name?: string;
      base_url?: string;
      allowed_paths?: string[];
      vertical?: SearchVertical;
      rights_default?: string;
      crawl_delay_ms?: number;
      max_depth?: number;
    };
    let parsedUrl: URL;
    try {
      parsedUrl = new URL(String(body.base_url ?? '').trim());
    } catch {
      res.status(400).json({error: 'URL de base invalide.'});
      return;
    }
    if (parsedUrl.protocol !== 'https:' && parsedUrl.protocol !== 'http:') {
      res.status(400).json({error: 'Protocole HTTP ou HTTPS requis.'});
      return;
    }
    const created = store.addSource({
      name: String(body.name ?? parsedUrl.hostname).trim(),
      base_url: parsedUrl.origin,
      domain: parsedUrl.hostname.toLowerCase(),
      allowed_paths: Array.isArray(body.allowed_paths)
        ? body.allowed_paths.map((p) => String(p).trim()).filter(Boolean)
        : ['/'],
      vertical: body.vertical ?? 'web',
      rights_default:
        String(body.rights_default ?? '').trim() ||
        'Source autorisée par l’administrateur Éclair',
      crawl_delay_ms: Math.max(500, Number(body.crawl_delay_ms ?? 1000)),
      max_depth: Math.min(3, Math.max(1, Number(body.max_depth ?? 1))),
      enabled: true,
    });
    res.status(201).json({source: created});
  });

  router.get('/admin/v1/documents', requireAdmin, (_req, res) => {
    res.json({documents: store.getDocuments()});
  });

  router.delete('/admin/v1/documents/:document_id', requireAdmin, (req, res) => {
    const ok = store.removeDocument(String(req.params['document_id']));
    if (!ok) {
      res.status(404).json({error: 'Document introuvable.'});
      return;
    }
    res.json({removed: true});
  });

  router.get('/admin/v1/duplicates', requireAdmin, (_req, res) => {
    res.json({duplicates: store.getDuplicates()});
  });

  router.get('/admin/v1/jobs', requireAdmin, (_req, res) => {
    res.json({jobs: store.getJobs()});
  });

  router.get('/admin/v1/ingestion-jobs/:job_id', requireAdmin, (req, res) => {
    const job = store.getJob(String(req.params['job_id']));
    if (!job) {
      res.status(404).json({error: 'Tâche d’ingestion introuvable.'});
      return;
    }
    res.json({job});
  });

  router.post(
    '/admin/v1/ingestion-jobs',
    requireAdmin,
    rateLimit(20),
    async (req, res) => {
      const body = req.body as {
        kind?: IngestionJob['kind'];
        target_url?: string;
        title?: string;
        content?: string;
        pdf_base64?: string;
        source_name?: string;
        vertical?: SearchVertical;
        rights_metadata?: string;
        published_at?: string;
      };

      const jobId = `job-${Date.now().toString(36)}-${randomBytes(3).toString('hex')}`;
      const createdAt = new Date().toISOString();
      const kind = body.kind ?? 'upload_text';
      const vertical = body.vertical ?? 'web';
      const rights =
        body.rights_metadata?.trim() || 'Document approuvé — Corpus Éclair';
      const sourceName =
        body.source_name?.trim() || 'Ingestion administrative Éclair';

      if (kind === 'crawl') {
        const targetUrl = String(body.target_url ?? '').trim();
        const crawlRes = await crawlBoundedUrl(targetUrl, store.getSources());
        if (!crawlRes.ok || !crawlRes.bodyText || !crawlRes.title) {
          const failedJob: IngestionJob = {
            job_id: jobId,
            kind: 'crawl',
            target_url: targetUrl,
            source_name: sourceName,
            status: crawlRes.status === 'completed' ? 'failed' : crawlRes.status,
            error_message: crawlRes.error ?? 'Échec de collecte.',
            created_at: createdAt,
            finished_at: new Date().toISOString(),
          };
          store.recordJob(failedJob);
          res.status(crawlRes.status === 'blocked_ssrf' ? 403 : 422).json({
            job: failedJob,
            error: failedJob.error_message,
          });
          return;
        }

        const ing = store.ingestDocument({
          title: crawlRes.title,
          body_text: crawlRes.bodyText,
          source_url: targetUrl,
          canonical_url: crawlRes.canonicalUrl ?? targetUrl,
          source_name: crawlRes.source?.name ?? sourceName,
          content_type: crawlRes.contentType ?? 'text/html',
          vertical: crawlRes.source?.vertical ?? vertical,
          rights_metadata: crawlRes.source?.rights_default ?? rights,
          raw_content: crawlRes.rawContent,
          crawl_provenance: {...crawlRes.provenance!, job_id: jobId},
        });

        const job: IngestionJob = {
          job_id: jobId,
          kind: 'crawl',
          target_url: targetUrl,
          source_name: crawlRes.source?.name ?? sourceName,
          status:
            ing.status === 'duplicate_skipped'
              ? 'duplicate_skipped'
              : 'completed',
          document_id: ing.document?.document_id ?? ing.duplicate_of,
          created_at: createdAt,
          finished_at: new Date().toISOString(),
          provenance: crawlRes.provenance as unknown as Record<string, unknown>,
        };
        store.recordJob(job);
        res.status(201).json({job, document: ing.document});
        return;
      }

      // Direct document ingestion (HTML, Markdown, Plain Text, or PDF base64)
      let title = String(body.title ?? '').trim();
      let bodyText = String(body.content ?? '').trim();
      let contentType: 'text/plain' | 'text/html' | 'text/markdown' | 'application/pdf' =
        'text/plain';
      let rawContent = bodyText;

      if (kind === 'upload_html') {
        contentType = 'text/html';
        const extracted = extractHtmlContent(
          bodyText,
          body.target_url || 'https://patrimoine-idees.eclair.fr/articles/import',
        );
        title = title || extracted.title;
        bodyText = extracted.bodyText;
      } else if (kind === 'upload_markdown') {
        contentType = 'text/markdown';
        const extracted = extractMarkdownContent(bodyText);
        title = title || extracted.title;
        bodyText = extracted.bodyText;
      } else if (kind === 'upload_pdf') {
        contentType = 'application/pdf';
        const buf = Buffer.from(String(body.pdf_base64 ?? ''), 'base64');
        const pdfRes = extractPdfTextSafe(buf);
        if (!pdfRes.ok || !pdfRes.bodyText) {
          const failedJob: IngestionJob = {
            job_id: jobId,
            kind: 'upload_pdf',
            source_name: sourceName,
            status: 'failed',
            error_message: pdfRes.error,
            created_at: createdAt,
            finished_at: new Date().toISOString(),
          };
          store.recordJob(failedJob);
          res.status(422).json({job: failedJob, error: pdfRes.error});
          return;
        }
        title = title || pdfRes.title || 'Document PDF';
        bodyText = pdfRes.bodyText;
        rawContent = pdfRes.bodyText;
      }

      if (!title || !bodyText) {
        res.status(400).json({error: 'Titre et contenu documentaire requis.'});
        return;
      }

      const sourceUrl =
        body.target_url?.trim() ||
        `https://patrimoine-idees.eclair.fr/articles/${Date.now().toString(36)}`;
      const ing = store.ingestDocument({
        title,
        body_text: bodyText,
        source_url: sourceUrl,
        canonical_url: sourceUrl,
        source_name: sourceName,
        content_type: contentType,
        vertical,
        rights_metadata: rights,
        published_at: body.published_at ?? new Date().toISOString().slice(0, 10),
        raw_content: rawContent,
      });

      const job: IngestionJob = {
        job_id: jobId,
        kind,
        target_url: sourceUrl,
        source_name: sourceName,
        status:
          ing.status === 'duplicate_skipped' ? 'duplicate_skipped' : 'completed',
        document_id: ing.document?.document_id ?? ing.duplicate_of,
        created_at: createdAt,
        finished_at: new Date().toISOString(),
      };
      store.recordJob(job);
      res.status(201).json({job, document: ing.document});
    },
  );

  router.post('/admin/v1/index-rebuilds', requireAdmin, (_req, res) => {
    const summary = store.rebuildIndex();
    res.json({rebuilt: true, ...summary});
  });

  router.post('/admin/v1/evaluation/run', requireAdmin, (_req, res) => {
    const result = store.runEvaluation();
    res.json(result);
  });

  router.get('/admin/v1/abuse-reports', requireAdmin, (_req, res) => {
    res.json({reports: store.getAbuseReports()});
  });

  router.patch('/admin/v1/abuse-reports/:report_id', requireAdmin, (req, res) => {
    const body = req.body as {action?: 'resolved' | 'removed'};
    const action = body.action === 'removed' ? 'removed' : 'resolved';
    const ok = store.resolveAbuseReport(String(req.params['report_id']), action);
    if (!ok) {
      res.status(404).json({error: 'Signalement introuvable.'});
      return;
    }
    res.json({updated: true, action});
  });

  return router;
}
