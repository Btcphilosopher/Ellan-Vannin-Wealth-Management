import {mkdtempSync, rmSync} from 'node:fs';
import {tmpdir} from 'node:os';
import {join} from 'node:path';
import express from 'express';
import {afterAll, beforeAll, describe, expect, it} from 'vitest';
import {createEclairApiRouter} from './api-router';
import {GeminiGroundedAssistantAdapter} from './assistant/grounded-assistant';
import {
  extractHtmlContent,
  extractPdfTextSafe,
  isDisallowedByRobotsTxt,
  isPrivateOrReservedIp,
  validateUrlForCrawl,
} from './ingestion/crawler';
import {SEED_SOURCES} from './corpus/seed-corpus';
import {ExternalWebSearchAdapter} from './search/bm25-engine';
import {
  normalizeFrenchText,
  parseFrenchQuery,
  stripAccents,
} from './search/french-nlp';
import {EclairStore} from './store/eclair-store';

describe('Éclair — NLP français, BM25, sécurité SSRF et intégrité API', () => {
  let tempDir: string;
  let store: EclairStore;
  let baseUrl: string;
  let server: ReturnType<express.Express['listen']>;

  beforeAll(async () => {
    tempDir = mkdtempSync(join(tmpdir(), 'eclair-test-'));
    store = new EclairStore(tempDir);

    const app = express();
    app.use(createEclairApiRouter(store));
    await new Promise<void>((resolve) => {
      server = app.listen(0, '127.0.0.1', () => {
        const addr = server.address();
        if (addr && typeof addr === 'object') {
          baseUrl = `http://127.0.0.1:${addr.port}`;
        }
        resolve();
      });
    });
  });

  afterAll(async () => {
    await new Promise<void>((resolve) => server.close(() => resolve()));
    rmSync(tempDir, {recursive: true, force: true});
  });

  it('normalise les accents, ligatures et apostrophes françaises', () => {
    expect(stripAccents('Découvertes à l’œuvre')).toBe("Decouvertes a l’oeuvre");
    expect(normalizeFrenchText("L'innovation d'aujourd'hui")).toBe(
      'innovation hui',
    );
    const parsed = parseFrenchQuery('"La France qui innove"');
    expect(parsed.phrases).toContain('la france qui innove');
  });

  it('retourne les mêmes meilleurs résultats avec et sans accents tout en préservant les accents affichés', () => {
    const withAccents = store.bm25.search({
      q: 'Voyages et découvertes en Provence',
      vertical: 'web',
    });
    const withoutAccents = store.bm25.search({
      q: 'Voyages et decouvertes en Provence',
      vertical: 'web',
    });
    expect(withAccents.results.length).toBeGreaterThan(0);
    expect(withAccents.results[0].document_id).toBe(
      withoutAccents.results[0].document_id,
    );
    expect(withoutAccents.results[0].title).toContain('découvertes');
  });

  it('distingue la suggestion orthographique sans remplacer silencieusement la requête', () => {
    const res = store.bm25.search({
      q: 'photoniqe',
      vertical: 'web',
    });
    expect(res.did_not_replace_query).toBe(true);
    expect(res.query).toBe('photoniqe');
    expect(res.spelling_suggestion).toBe('photonique');
  });

  it('bloque les adresses privées, loopback, métadonnées cloud et domaines hors liste blanche (SSRF)', async () => {
    expect(isPrivateOrReservedIp('127.0.0.1')).toBe(true);
    expect(isPrivateOrReservedIp('169.254.169.254')).toBe(true);
    expect(isPrivateOrReservedIp('10.12.0.5')).toBe(true);
    expect(isPrivateOrReservedIp('192.168.1.10')).toBe(true);
    expect(isPrivateOrReservedIp('8.8.8.8')).toBe(false);

    const localCheck = await validateUrlForCrawl(
      'http://127.0.0.1:8080/admin',
      SEED_SOURCES,
      {skipDnsLookup: true},
    );
    expect(localCheck.ok).toBe(false);

    const metaCheck = await validateUrlForCrawl(
      'http://169.254.169.254/latest/meta-data/',
      SEED_SOURCES,
      {skipDnsLookup: true},
    );
    expect(metaCheck.ok).toBe(false);

    const unapprovedCheck = await validateUrlForCrawl(
      'https://domaine-non-approuve.exemple.fr/page',
      SEED_SOURCES,
      {skipDnsLookup: true},
    );
    expect(unapprovedCheck.ok).toBe(false);

    const robots = isDisallowedByRobotsTxt(
      'User-agent: *\nDisallow: /prive/\nCrawl-delay: 2',
      '/prive/secret',
    );
    expect(robots.disallowed).toBe(true);
    expect(robots.crawlDelayMs).toBe(2000);
  });

  it('supprime les scripts HTML lors de l’extraction et rejette les doublons par hachage', () => {
    const extracted = extractHtmlContent(
      '<html><head><title>Essai HTML</title><script>alert(1)</script></head><body><p>Texte propre sur la Seine.</p></body></html>',
      'https://patrimoine-idees.eclair.fr/articles/essai',
    );
    expect(extracted.title).toBe('Essai HTML');
    expect(extracted.bodyText).toBe('Texte propre sur la Seine.');
    expect(extracted.bodyText).not.toContain('alert');

    const first = store.ingestDocument({
      title: 'Essai HTML',
      body_text: extracted.bodyText,
      source_url: 'https://patrimoine-idees.eclair.fr/articles/essai',
      canonical_url: 'https://patrimoine-idees.eclair.fr/articles/essai',
      source_name: 'Test',
      content_type: 'text/html',
      vertical: 'web',
      rights_metadata: 'CC BY 4.0',
    });
    expect(first.status).toBe('indexed');

    const dup = store.ingestDocument({
      title: 'Essai HTML',
      body_text: extracted.bodyText,
      source_url: 'https://patrimoine-idees.eclair.fr/articles/essai-copie',
      canonical_url: 'https://patrimoine-idees.eclair.fr/articles/essai-copie',
      source_name: 'Test',
      content_type: 'text/html',
      vertical: 'web',
      rights_metadata: 'CC BY 4.0',
    });
    expect(dup.status).toBe('duplicate_skipped');
  });

  it('extrait le texte des PDF valides et rejette les PDF chiffrés ou invalides', () => {
    const invalid = extractPdfTextSafe(Buffer.from('not-a-pdf'));
    expect(invalid.ok).toBe(false);

    const encrypted = extractPdfTextSafe(Buffer.from('%PDF-1.4 /Encrypt'));
    expect(encrypted.ok).toBe(false);

    const valid = extractPdfTextSafe(
      Buffer.from('%PDF-1.4\n/Title (Rapport Loire)\n(Patrimoine fluvial de la Loire) Tj'),
    );
    expect(valid.ok).toBe(true);
    expect(valid.title).toBe('Rapport Loire');
    expect(valid.bodyText).toContain('Patrimoine fluvial de la Loire');
  });

  it('ne fabrique jamais de résultats lorsque le fournisseur Web externe est absent ou en délai expiré', async () => {
    const adapter = new ExternalWebSearchAdapter();
    const prevUrl = process.env['EXTERNAL_WEB_SEARCH_URL'];
    delete process.env['EXTERNAL_WEB_SEARCH_URL'];

    const res = await adapter.search({q: 'Paris', vertical: 'web', mode: 'external'});
    expect(res.provider_status.available).toBe(false);
    expect(res.provider_status.error_code).toBe('MISSING_CREDENTIALS');
    expect(res.results).toEqual([]);

    if (prevUrl) process.env['EXTERNAL_WEB_SEARCH_URL'] = prevUrl;
  });

  it('retourne une réponse honnête de preuves insuffisantes pour l’assistant sur requête hors corpus', async () => {
    const assistant = new GeminiGroundedAssistantAdapter();
    const res = await assistant.answer(
      'xylophoniste antarctique inexistant',
      store.bm25,
      store.getDocuments(),
    );
    expect(res.status).toBe('insufficient_evidence');
    expect(res.citations).toEqual([]);
  });

  it('protège les routes utilisateur/admin et permet l’ingestion + recherche de bout en bout via HTTP', async () => {
    const unauthSaved = await fetch(`${baseUrl}/v1/me/saved-results`);
    expect(unauthSaved.status).toBe(401);

    const unauthAdmin = await fetch(`${baseUrl}/admin/v1/overview`);
    expect(unauthAdmin.status).toBe(401);

    // Bootstrap admin and ingest a new document
    const bootRes = await fetch(`${baseUrl}/admin/v1/auth/bootstrap`, {
      method: 'POST',
      headers: {'Content-Type': 'application/json'},
      body: JSON.stringify({password: 'EclairTestPass123!'}),
    });
    expect(bootRes.status).toBe(201);
    const {token: adminToken} = (await bootRes.json()) as {token: string};

    const ingestRes = await fetch(`${baseUrl}/admin/v1/ingestion-jobs`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${adminToken}`,
      },
      body: JSON.stringify({
        kind: 'upload_markdown',
        title: 'Observatoire astronomique du Pic du Midi',
        content: '# Pic du Midi\nLe coronographe solaire de Lyot observe la couronne depuis les Pyrénées.',
        source_name: 'Cahiers Pyrénéens',
        vertical: 'savoirs',
        rights_metadata: 'CC BY 4.0',
      }),
    });
    expect(ingestRes.status).toBe(201);

    // Search for the newly ingested document
    const searchRes = await fetch(
      `${baseUrl}/v1/search?q=${encodeURIComponent('coronographe solaire Pyrénées')}&vertical=savoirs&mode=local`,
    );
    expect(searchRes.status).toBe(200);
    const searchBody = (await searchRes.json()) as {
      results: {title: string}[];
    };
    expect(searchBody.results[0]?.title).toContain('Pic du Midi');

    // Run evaluation suite
    const evalRes = await fetch(`${baseUrl}/admin/v1/evaluation/run`, {
      method: 'POST',
      headers: {Authorization: `Bearer ${adminToken}`},
    });
    expect(evalRes.status).toBe(200);
    const evalBody = (await evalRes.json()) as {
      mrr_at_5: number;
      accent_parity_rate: number;
      no_result_accuracy: number;
    };
    expect(evalBody.mrr_at_5).toBeGreaterThan(0.8);
    expect(evalBody.accent_parity_rate).toBe(1);
    expect(evalBody.no_result_accuracy).toBe(1);
  });
});
