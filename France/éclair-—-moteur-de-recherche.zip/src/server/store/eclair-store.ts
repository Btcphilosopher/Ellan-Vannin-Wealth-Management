import {createHash, randomBytes, scryptSync, timingSafeEqual} from 'node:crypto';
import {existsSync, mkdirSync, readFileSync, writeFileSync} from 'node:fs';
import {join, resolve, sep} from 'node:path';
import {
  AbuseReport,
  ApprovedSource,
  DocumentRecord,
  DuplicateCluster,
  EvaluationQueryResult,
  EvaluationRunResult,
  IngestionJob,
  SavedResult,
  SearchHistoryItem,
  SearchVertical,
  UserPreferences,
  UserProfile,
} from '../../shared/eclair.types';
import {
  FRENCH_EVALUATION_BENCHMARK,
  SEED_CORPUS,
  SEED_SOURCES,
} from '../corpus/seed-corpus';
import {LocalFrenchBm25Index} from '../search/bm25-engine';

interface StoredUser {
  user_id: string;
  email: string;
  display_name: string;
  password_hash: string;
  preferences: UserPreferences;
  saved_results: SavedResult[];
  history: SearchHistoryItem[];
}

interface PersistedState {
  documents: DocumentRecord[];
  sources: ApprovedSource[];
  jobs: IngestionJob[];
  duplicates: DuplicateCluster[];
  abuse_reports: AbuseReport[];
  users: StoredUser[];
  admin_password_hash: string | null;
}

interface SessionRecord {
  token: string;
  kind: 'user' | 'admin';
  userId?: string;
  expiresAt: number;
}

export class EclairStore {
  private readonly dataDir: string;
  private readonly rawDir: string;
  private readonly storePath: string;
  private state: PersistedState;
  private sessions = new Map<string, SessionRecord>();
  readonly bm25 = new LocalFrenchBm25Index();

  constructor(baseDir = join(process.cwd(), '.data')) {
    this.dataDir = resolve(baseDir);
    this.rawDir = resolve(this.dataDir, 'raw');
    this.storePath = resolve(this.dataDir, 'eclair-store.json');

    mkdirSync(this.rawDir, {recursive: true});
    this.state = this.loadOrSeed();
    this.bm25.rebuild(this.state.documents);
  }

  private loadOrSeed(): PersistedState {
    if (existsSync(this.storePath)) {
      try {
        const raw = readFileSync(this.storePath, 'utf8');
        const parsed = JSON.parse(raw) as PersistedState;
        if (Array.isArray(parsed.documents) && Array.isArray(parsed.sources)) {
          return parsed;
        }
      } catch {
        // Fallback to clean seed if file is corrupted
      }
    }
    const initial: PersistedState = {
      documents: [...SEED_CORPUS],
      sources: [...SEED_SOURCES],
      jobs: [],
      duplicates: [],
      abuse_reports: [],
      users: [],
      admin_password_hash: null,
    };
    this.persistState(initial);
    return initial;
  }

  private persistState(nextState: PersistedState = this.state): void {
    writeFileSync(this.storePath, JSON.stringify(nextState, null, 2), 'utf8');
  }

  private saveRawRepresentation(docId: string, rawContent: string): string {
    const safeName = docId.replace(/[^a-zA-Z0-9_-]/g, '_') + '.raw';
    const targetPath = resolve(this.rawDir, safeName);
    if (!targetPath.startsWith(this.rawDir + sep)) {
      throw new Error('Chemin de stockage brut invalide.');
    }
    writeFileSync(targetPath, rawContent, 'utf8');
    return safeName;
  }

  // --- Documents & Index ---

  getDocuments(): DocumentRecord[] {
    return this.state.documents;
  }

  getDocumentById(documentId: string): DocumentRecord | undefined {
    return this.state.documents.find((d) => d.document_id === documentId);
  }

  rebuildIndex(): {indexed_count: number; vocabulary_size: number} {
    this.bm25.rebuild(this.state.documents);
    return {
      indexed_count: this.state.documents.filter((d) => d.index_status === 'indexed')
        .length,
      vocabulary_size: this.bm25.getVocabularySize(),
    };
  }

  ingestDocument(input: {
    title: string;
    body_text: string;
    source_url: string;
    canonical_url: string;
    source_name: string;
    content_type: DocumentRecord['content_type'];
    vertical: SearchVertical;
    rights_metadata: string;
    published_at?: string | null;
    raw_content?: string;
    crawl_provenance?: DocumentRecord['crawl_provenance'];
  }): {
    status: 'indexed' | 'duplicate_skipped';
    document?: DocumentRecord;
    duplicate_of?: string;
  } {
    const contentHash = createHash('sha256')
      .update(`${input.title.trim()}\n${input.body_text.trim()}`)
      .digest('hex')
      .slice(0, 24);

    const existing = this.state.documents.find(
      (d) =>
        d.index_status === 'indexed' &&
        (d.content_hash === contentHash || d.canonical_url === input.canonical_url),
    );

    if (existing) {
      let cluster = this.state.duplicates.find((c) => c.content_hash === contentHash);
      if (!cluster) {
        cluster = {
          content_hash: contentHash,
          canonical_urls: [existing.canonical_url],
          document_ids: [existing.document_id],
          title: existing.title,
        };
        this.state.duplicates.unshift(cluster);
      }
      if (!cluster.canonical_urls.includes(input.canonical_url)) {
        cluster.canonical_urls.push(input.canonical_url);
      }
      this.persistState();
      return {
        status: 'duplicate_skipped',
        duplicate_of: existing.document_id,
      };
    }

    const docId = `doc-${Date.now().toString(36)}-${randomBytes(3).toString('hex')}`;
    let domain = 'corpus.eclair.fr';
    try {
      domain = new URL(input.source_url).hostname;
    } catch {
      domain = 'corpus.eclair.fr';
    }

    const nowIso = new Date().toISOString();
    let rawRef: string | undefined;
    if (input.raw_content) {
      rawRef = this.saveRawRepresentation(docId, input.raw_content);
    }

    const doc: DocumentRecord = {
      document_id: docId,
      source_url: input.source_url,
      canonical_url: input.canonical_url,
      title: input.title.trim(),
      language: 'fr',
      body_text: input.body_text.trim(),
      content_type: input.content_type,
      published_at: input.published_at ?? nowIso.slice(0, 10),
      modified_at: nowIso.slice(0, 10),
      fetched_at: nowIso,
      content_hash: contentHash,
      source_name: input.source_name.trim(),
      rights_metadata: input.rights_metadata.trim(),
      index_status: 'indexed',
      vertical: input.vertical,
      domain,
      excerpt:
        input.body_text.trim().slice(0, 190) +
        (input.body_text.trim().length > 190 ? '…' : ''),
      raw_representation_ref: rawRef,
      crawl_provenance: input.crawl_provenance,
    };

    this.state.documents.unshift(doc);
    this.bm25.rebuild(this.state.documents);
    this.persistState();
    return {status: 'indexed', document: doc};
  }

  removeDocument(documentId: string): boolean {
    const doc = this.state.documents.find((d) => d.document_id === documentId);
    if (!doc) return false;
    doc.index_status = 'removed';
    this.bm25.rebuild(this.state.documents);
    this.persistState();
    return true;
  }

  // --- Sources & Jobs ---

  getSources(): ApprovedSource[] {
    return this.state.sources;
  }

  addSource(
    source: Omit<ApprovedSource, 'source_id' | 'created_at'>,
  ): ApprovedSource {
    const created: ApprovedSource = {
      ...source,
      source_id: `src-${randomBytes(4).toString('hex')}`,
      created_at: new Date().toISOString(),
    };
    this.state.sources.unshift(created);
    this.persistState();
    return created;
  }

  getJobs(): IngestionJob[] {
    return this.state.jobs;
  }

  getJob(jobId: string): IngestionJob | undefined {
    return this.state.jobs.find((j) => j.job_id === jobId);
  }

  recordJob(job: IngestionJob): void {
    this.state.jobs.unshift(job);
    if (this.state.jobs.length > 100) {
      this.state.jobs = this.state.jobs.slice(0, 100);
    }
    this.persistState();
  }

  getDuplicates(): DuplicateCluster[] {
    return this.state.duplicates;
  }

  // --- Abuse Reports ---

  getAbuseReports(): AbuseReport[] {
    return this.state.abuse_reports;
  }

  createAbuseReport(input: {
    document_id?: string;
    source_url: string;
    reason: string;
    details: string;
  }): AbuseReport {
    const report: AbuseReport = {
      report_id: `rep-${randomBytes(4).toString('hex')}`,
      document_id: input.document_id,
      source_url: input.source_url,
      reason: input.reason,
      details: input.details,
      status: 'open',
      created_at: new Date().toISOString(),
    };
    this.state.abuse_reports.unshift(report);
    this.persistState();
    return report;
  }

  resolveAbuseReport(reportId: string, action: 'resolved' | 'removed'): boolean {
    const rep = this.state.abuse_reports.find((r) => r.report_id === reportId);
    if (!rep) return false;
    rep.status = action;
    if (action === 'removed' && rep.document_id) {
      this.removeDocument(rep.document_id);
    } else {
      this.persistState();
    }
    return true;
  }

  // --- Evaluation Benchmark ---

  runEvaluation(): EvaluationRunResult {
    const results: EvaluationQueryResult[] = [];
    let mrrSum = 0;
    let recallSum = 0;
    let zeroResultPassed = 0;
    let zeroResultTotal = 0;
    const latencies: number[] = [];

    for (const bench of FRENCH_EVALUATION_BENCHMARK) {
      const resp = this.bm25.search({
        q: bench.query,
        vertical: 'web',
        limit: 5,
      });
      latencies.push(resp.elapsed_ms);
      const topIds = resp.results.map((r) => r.document_id);

      let rr = 0;
      let recall = 1;
      let passed = false;

      if (bench.expect_zero_results) {
        zeroResultTotal += 1;
        passed = topIds.length === 0;
        if (passed) {
          zeroResultPassed += 1;
          rr = 1;
          recall = 1;
        } else {
          rr = 0;
          recall = 0;
        }
      } else {
        for (let i = 0; i < topIds.length; i++) {
          if (bench.expected_doc_ids.includes(topIds[i])) {
            rr = 1 / (i + 1);
            break;
          }
        }
        const hits = bench.expected_doc_ids.filter((id) => topIds.includes(id));
        recall =
          bench.expected_doc_ids.length > 0
            ? hits.length / bench.expected_doc_ids.length
            : 1;
        passed = rr > 0;
      }

      mrrSum += rr;
      recallSum += recall;

      results.push({
        id: bench.id,
        query: bench.query,
        category: bench.category,
        expected_doc_ids: bench.expected_doc_ids,
        top_doc_ids: topIds,
        reciprocal_rank: Number(rr.toFixed(3)),
        recall_at_5: Number(recall.toFixed(3)),
        latency_ms: resp.elapsed_ms,
        passed,
      });
    }

    const acc = results.find((r) => r.category === 'accented');
    const unacc = results.find((r) => r.category === 'unaccented');
    const accentParity =
      acc && unacc && acc.top_doc_ids[0] && acc.top_doc_ids[0] === unacc.top_doc_ids[0]
        ? 1
        : 0;

    latencies.sort((a, b) => a - b);
    const p50 = latencies[Math.floor(latencies.length * 0.5)] ?? 1;
    const p95 = latencies[Math.floor(latencies.length * 0.95)] ?? p50;

    return {
      run_id: `eval-${Date.now().toString(36)}`,
      executed_at: new Date().toISOString(),
      dataset_label: 'Jeu de référence français synthétique (7 requêtes étiquetées)',
      total_queries: results.length,
      mrr_at_5: Number((mrrSum / Math.max(1, results.length)).toFixed(3)),
      recall_at_5: Number((recallSum / Math.max(1, results.length)).toFixed(3)),
      accent_parity_rate: accentParity,
      no_result_accuracy:
        zeroResultTotal > 0 ? zeroResultPassed / zeroResultTotal : 1,
      p50_latency_ms: p50,
      p95_latency_ms: p95,
      indexed_document_count: this.state.documents.filter(
        (d) => d.index_status === 'indexed',
      ).length,
      failed_document_count: this.state.jobs.filter(
        (j) => j.status === 'failed' || j.status === 'blocked_ssrf',
      ).length,
      source_count: this.state.sources.filter((s) => s.enabled).length,
      results,
    };
  }

  // --- Accounts, Sessions, Saved Results & Privacy ---

  private hashPassword(password: string): string {
    const salt = randomBytes(16).toString('hex');
    const derived = scryptSync(password, salt, 64).toString('hex');
    return `${salt}:${derived}`;
  }

  private verifyPassword(password: string, storedHash: string): boolean {
    const [salt, key] = storedHash.split(':');
    if (!salt || !key) return false;
    const derived = scryptSync(password, salt, 64);
    const keyBuf = Buffer.from(key, 'hex');
    if (derived.length !== keyBuf.length) return false;
    return timingSafeEqual(derived, keyBuf);
  }

  private createSession(kind: 'user' | 'admin', userId?: string): string {
    const token = randomBytes(32).toString('hex');
    this.sessions.set(token, {
      token,
      kind,
      userId,
      expiresAt: Date.now() + 1000 * 60 * 60 * 12,
    });
    return token;
  }

  verifySession(
    authHeader: string | undefined,
    expectedKind?: 'user' | 'admin',
  ): SessionRecord | null {
    if (!authHeader || !authHeader.startsWith('Bearer ')) return null;
    const token = authHeader.slice(7).trim();
    const rec = this.sessions.get(token);
    if (!rec) return null;
    if (Date.now() > rec.expiresAt) {
      this.sessions.delete(token);
      return null;
    }
    if (expectedKind && rec.kind !== expectedKind) return null;
    return rec;
  }

  registerUser(
    email: string,
    password: string,
    displayName: string,
  ): {ok: boolean; error?: string; token?: string; profile?: UserProfile} {
    const cleanEmail = email.trim().toLowerCase();
    if (!cleanEmail.includes('@') || password.length < 8) {
      return {
        ok: false,
        error: 'Adresse courriel invalide ou mot de passe trop court (8 caractères minimum).',
      };
    }
    if (this.state.users.some((u) => u.email === cleanEmail)) {
      return {ok: false, error: 'Un compte existe déjà avec cette adresse.'};
    }

    const user: StoredUser = {
      user_id: `usr-${randomBytes(4).toString('hex')}`,
      email: cleanEmail,
      display_name: displayName.trim() || cleanEmail.split('@')[0],
      password_hash: this.hashPassword(password),
      preferences: {
        save_search_history: false,
        default_mode: 'local',
        language: 'fr',
      },
      saved_results: [],
      history: [],
    };
    this.state.users.push(user);
    this.persistState();

    const token = this.createSession('user', user.user_id);
    return {
      ok: true,
      token,
      profile: {
        user_id: user.user_id,
        email: user.email,
        display_name: user.display_name,
        preferences: user.preferences,
      },
    };
  }

  loginUser(
    email: string,
    password: string,
  ): {ok: boolean; error?: string; token?: string; profile?: UserProfile} {
    const cleanEmail = email.trim().toLowerCase();
    const user = this.state.users.find((u) => u.email === cleanEmail);
    if (!user || !this.verifyPassword(password, user.password_hash)) {
      return {ok: false, error: 'Identifiants incorrects.'};
    }
    const token = this.createSession('user', user.user_id);
    return {
      ok: true,
      token,
      profile: {
        user_id: user.user_id,
        email: user.email,
        display_name: user.display_name,
        preferences: user.preferences,
      },
    };
  }

  getUserById(userId: string): StoredUser | undefined {
    return this.state.users.find((u) => u.user_id === userId);
  }

  getSavedResults(userId: string): SavedResult[] {
    return this.getUserById(userId)?.saved_results ?? [];
  }

  addSavedResult(
    userId: string,
    input: {
      document_id: string;
      title: string;
      source_url: string;
      domain: string;
      snippet: string;
      collection?: string;
    },
  ): SavedResult | null {
    const user = this.getUserById(userId);
    if (!user) return null;
    const existing = user.saved_results.find(
      (s) => s.document_id === input.document_id,
    );
    if (existing) return existing;

    const item: SavedResult = {
      saved_id: `sav-${randomBytes(4).toString('hex')}`,
      document_id: input.document_id,
      title: input.title,
      source_url: input.source_url,
      domain: input.domain,
      snippet: input.snippet,
      collection: input.collection?.trim() || 'Lectures enregistrées',
      saved_at: new Date().toISOString(),
    };
    user.saved_results.unshift(item);
    this.persistState();
    return item;
  }

  deleteSavedResult(userId: string, savedId: string): boolean {
    const user = this.getUserById(userId);
    if (!user) return false;
    const before = user.saved_results.length;
    user.saved_results = user.saved_results.filter((s) => s.saved_id !== savedId);
    if (user.saved_results.length !== before) {
      this.persistState();
      return true;
    }
    return false;
  }

  recordSearchHistoryIfEnabled(
    userId: string,
    query: string,
    vertical: SearchVertical,
  ): void {
    const user = this.getUserById(userId);
    if (!user || !user.preferences.save_search_history || !query.trim()) return;
    user.history.unshift({
      query: query.trim(),
      vertical,
      searched_at: new Date().toISOString(),
    });
    user.history = user.history.slice(0, 50);
    this.persistState();
  }

  updateUserPreferences(
    userId: string,
    prefs: Partial<UserPreferences>,
  ): UserPreferences | null {
    const user = this.getUserById(userId);
    if (!user) return null;
    user.preferences = {
      ...user.preferences,
      ...prefs,
      language: 'fr',
    };
    this.persistState();
    return user.preferences;
  }

  exportUserData(userId: string): Record<string, unknown> | null {
    const user = this.getUserById(userId);
    if (!user) return null;
    return {
      exported_at: new Date().toISOString(),
      profile: {
        user_id: user.user_id,
        email: user.email,
        display_name: user.display_name,
        preferences: user.preferences,
      },
      saved_results: user.saved_results,
      search_history: user.history,
    };
  }

  deleteUserAccount(userId: string): boolean {
    const before = this.state.users.length;
    this.state.users = this.state.users.filter((u) => u.user_id !== userId);
    if (this.state.users.length !== before) {
      for (const [token, s] of this.sessions.entries()) {
        if (s.userId === userId) this.sessions.delete(token);
      }
      this.persistState();
      return true;
    }
    return false;
  }

  // --- Admin Auth (process.env passcode OR one-time first-run setup) ---

  getAdminAuthStatus(): {
    configured_via_env: boolean;
    needs_bootstrap: boolean;
  } {
    const envPass = process.env['ECLAIR_ADMIN_PASSCODE']?.trim();
    if (envPass) {
      return {configured_via_env: true, needs_bootstrap: false};
    }
    return {
      configured_via_env: false,
      needs_bootstrap: !this.state.admin_password_hash,
    };
  }

  bootstrapAdminPassword(password: string): {
    ok: boolean;
    error?: string;
    token?: string;
  } {
    if (process.env['ECLAIR_ADMIN_PASSCODE']?.trim()) {
      return {
        ok: false,
        error: 'Un mot de passe administrateur est déjà défini côté serveur.',
      };
    }
    if (this.state.admin_password_hash) {
      return {
        ok: false,
        error: 'L’accès administrateur a déjà été initialisé.',
      };
    }
    if (password.trim().length < 8) {
      return {
        ok: false,
        error: 'Le mot de passe administrateur doit contenir au moins 8 caractères.',
      };
    }
    this.state.admin_password_hash = this.hashPassword(password.trim());
    this.persistState();
    return {ok: true, token: this.createSession('admin')};
  }

  loginAdmin(passcode: string): {ok: boolean; error?: string; token?: string} {
    const envPass = process.env['ECLAIR_ADMIN_PASSCODE']?.trim();
    if (envPass) {
      const a = Buffer.from(passcode);
      const b = Buffer.from(envPass);
      if (a.length === b.length && timingSafeEqual(a, b)) {
        return {ok: true, token: this.createSession('admin')};
      }
      return {ok: false, error: 'Code d’accès administrateur invalide.'};
    }

    if (!this.state.admin_password_hash) {
      return {
        ok: false,
        error: 'Aucun mot de passe administrateur n’a encore été configuré.',
      };
    }
    if (!this.verifyPassword(passcode, this.state.admin_password_hash)) {
      return {ok: false, error: 'Mot de passe administrateur incorrect.'};
    }
    return {ok: true, token: this.createSession('admin')};
  }
}
