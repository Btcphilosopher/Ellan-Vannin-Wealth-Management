import dns from 'node:dns/promises';
import net from 'node:net';
import {ApprovedSource, CrawlProvenance} from '../../shared/eclair.types';

export interface SsrfValidationResult {
  ok: boolean;
  reason?: string;
  url?: URL;
  matchedSource?: ApprovedSource;
}

export function isPrivateOrReservedIp(ip: string): boolean {
  const clean = ip.replace(/^::ffff:/i, '');
  const version = net.isIP(clean);
  if (version === 0) return true;

  if (version === 4) {
    const parts = clean.split('.').map((n) => Number(n));
    const [a, b] = parts;
    if (a === 0 || a === 10 || a === 127) return true;
    if (a === 169 && b === 254) return true; // Cloud metadata / link-local
    if (a === 172 && b >= 16 && b <= 31) return true;
    if (a === 192 && b === 168) return true;
    if (a === 100 && b >= 64 && b <= 127) return true; // CGNAT
    if (a >= 224) return true; // Multicast / reserved
    return false;
  }

  // IPv6 checks
  const lower = clean.toLowerCase();
  if (lower === '::1' || lower === '::') return true;
  if (lower.startsWith('fe80:') || lower.startsWith('fc') || lower.startsWith('fd')) {
    return true;
  }
  return false;
}

export async function validateUrlForCrawl(
  rawUrl: string,
  allowlist: ApprovedSource[],
  options: {skipDnsLookup?: boolean} = {},
): Promise<SsrfValidationResult> {
  let parsed: URL;
  try {
    parsed = new URL(rawUrl.trim());
  } catch {
    return {ok: false, reason: 'URL invalide ou mal formée.'};
  }

  if (parsed.protocol !== 'https:' && parsed.protocol !== 'http:') {
    return {
      ok: false,
      reason: `Protocole refusé (${parsed.protocol}) : seuls HTTP et HTTPS sont autorisés.`,
    };
  }

  if (parsed.username || parsed.password) {
    return {
      ok: false,
      reason: 'Les identifiants intégrés dans l’URL sont interdits.',
    };
  }

  const host = parsed.hostname.toLowerCase();
  if (
    host === 'localhost' ||
    host.endsWith('.localhost') ||
    host.endsWith('.local') ||
    host.endsWith('.internal')
  ) {
    return {
      ok: false,
      reason: 'Accès bloqué (protection SSRF) : hôte local ou interne interdit.',
    };
  }

  if (net.isIP(host) && isPrivateOrReservedIp(host)) {
    return {
      ok: false,
      reason: 'Accès bloqué (protection SSRF) : adresse IP privée ou réservée.',
    };
  }

  // Must match an enabled approved source + allowed path prefix
  const matchedSource = allowlist.find((src) => {
    if (!src.enabled) return false;
    if (src.domain.toLowerCase() !== host) return false;
    if (src.allowed_paths.length === 0) return true;
    return src.allowed_paths.some((prefix) => parsed.pathname.startsWith(prefix));
  });

  if (!matchedSource) {
    return {
      ok: false,
      reason: `Domaine ou chemin non autorisé (${host}${parsed.pathname}). Ajoutez d’abord cette source dans la liste des domaines approuvés.`,
    };
  }

  if (!options.skipDnsLookup && !net.isIP(host)) {
    try {
      const records = await dns.lookup(host, {all: true});
      if (records.length === 0) {
        return {ok: false, reason: `Résolution DNS vide pour ${host}.`};
      }
      for (const rec of records) {
        if (isPrivateOrReservedIp(rec.address)) {
          return {
            ok: false,
            reason: `Accès bloqué (protection SSRF) : ${host} résout vers une adresse privée (${rec.address}).`,
          };
        }
      }
    } catch {
      return {
        ok: false,
        reason: `Impossible de résoudre le nom de domaine ${host}.`,
      };
    }
  }

  return {ok: true, url: parsed, matchedSource};
}

export function extractHtmlContent(
  rawHtml: string,
  fallbackUrl: string,
): {title: string; canonicalUrl: string; bodyText: string} {
  const titleMatch = rawHtml.match(/<title[^>]*>([\s\S]*?)<\/title>/i);
  const canonicalMatch = rawHtml.match(
    /<link[^>]+rel=["']canonical["'][^>]+href=["']([^"']+)["']/i,
  );

  // Strip head, scripts, styles, iframes, noscript, SVG, and comments strictly
  const stripped = rawHtml
    .replace(/<!--[\s\S]*?-->/g, ' ')
    .replace(/<head\b[^>]*>[\s\S]*?<\/head>/gi, ' ')
    .replace(/<script\b[^>]*>[\s\S]*?<\/script>/gi, ' ')
    .replace(/<style\b[^>]*>[\s\S]*?<\/style>/gi, ' ')
    .replace(/<noscript\b[^>]*>[\s\S]*?<\/noscript>/gi, ' ')
    .replace(/<iframe\b[^>]*>[\s\S]*?<\/iframe>/gi, ' ')
    .replace(/<[^>]+>/g, ' ');

  const decoded = decodeHtmlEntities(stripped).replace(/\s+/g, ' ').trim();
  const title = decodeHtmlEntities(titleMatch?.[1] ?? 'Document HTML sans titre')
    .replace(/\s+/g, ' ')
    .trim();

  let canonicalUrl = fallbackUrl;
  if (canonicalMatch?.[1]) {
    try {
      const resolved = new URL(canonicalMatch[1], fallbackUrl);
      if (resolved.protocol === 'https:' || resolved.protocol === 'http:') {
        canonicalUrl = resolved.toString();
      }
    } catch {
      canonicalUrl = fallbackUrl;
    }
  }

  return {title, canonicalUrl, bodyText: decoded};
}

export function extractMarkdownContent(rawMd: string): {
  title: string;
  bodyText: string;
} {
  const headingMatch = rawMd.match(/^#\s+(.+)$/m);
  const title = headingMatch?.[1]?.trim() ?? 'Note Markdown';
  const bodyText = rawMd
    .replace(/```[\s\S]*?```/g, ' ')
    .replace(/^#{1,6}\s+/gm, '')
    .replace(/\[([^\]]+)\]\([^)]+\)/g, '$1')
    .replace(/[*_`>#]/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
  return {title, bodyText};
}

export function extractPdfTextSafe(buffer: Buffer): {
  ok: boolean;
  title?: string;
  bodyText?: string;
  error?: string;
} {
  if (buffer.byteLength > 2 * 1024 * 1024) {
    return {
      ok: false,
      error: 'Fichier PDF trop volumineux (limite de sécurité : 2 Mo).',
    };
  }
  const header = buffer.subarray(0, 8).toString('latin1');
  if (!header.startsWith('%PDF-')) {
    return {
      ok: false,
      error: 'Signature PDF invalide (%PDF- attendue).',
    };
  }
  const raw = buffer.toString('latin1');
  if (raw.includes('/Encrypt')) {
    return {
      ok: false,
      error: 'PDF chiffré ou protégé : contournement interdit.',
    };
  }

  const titleMatch = raw.match(/\/Title\s*\(([^)]+)\)/);
  const segments: string[] = [];
  const tjRegex = /\(([^()\\]*(?:\\.[^()\\]*)*)\)\s*Tj/g;
  let match: RegExpExecArray | null;
  while ((match = tjRegex.exec(raw)) !== null) {
    const cleaned = match[1]
      .replace(/\\n/g, ' ')
      .replace(/\\r/g, ' ')
      .replace(/\\\(/g, '(')
      .replace(/\\\)/g, ')')
      .replace(/\\\\/g, '\\');
    if (cleaned.trim()) segments.push(cleaned.trim());
  }

  const bodyText = segments.join(' ').replace(/\s+/g, ' ').trim();
  if (!bodyText) {
    return {
      ok: false,
      error:
        'Aucun flux textuel extractible dans ce PDF (document probablement numérisé en image sans couche OCR).',
    };
  }

  return {
    ok: true,
    title: titleMatch?.[1]?.trim() || 'Document PDF extrait',
    bodyText,
  };
}

function decodeHtmlEntities(text: string): string {
  return text
    .replace(/&nbsp;/g, ' ')
    .replace(/&amp;/g, '&')
    .replace(/&lt;/g, '<')
    .replace(/&gt;/g, '>')
    .replace(/&quot;/g, '"')
    .replace(/&#39;|&apos;/g, "'")
    .replace(/&eacute;/g, 'é')
    .replace(/&egrave;/g, 'è')
    .replace(/&ecirc;/g, 'ê')
    .replace(/&agrave;/g, 'à')
    .replace(/&ccedil;/g, 'ç')
    .replace(/&rsquo;/g, '’')
    .replace(/&laquo;/g, '«')
    .replace(/&raquo;/g, '»');
}

export function isDisallowedByRobotsTxt(robotsTxt: string, path: string): {
  disallowed: boolean;
  crawlDelayMs: number;
} {
  const lines = robotsTxt.split(/\r?\n/);
  let applies = false;
  let disallowed = false;
  let crawlDelayMs = 0;

  for (const rawLine of lines) {
    const line = rawLine.split('#')[0].trim();
    if (!line) continue;
    const colonIdx = line.indexOf(':');
    if (colonIdx === -1) continue;
    const key = line.slice(0, colonIdx).trim().toLowerCase();
    const val = line.slice(colonIdx + 1).trim();

    if (key === 'user-agent') {
      applies = val === '*' || val.toLowerCase().includes('eclair');
    } else if (applies && key === 'disallow' && val) {
      if (path.startsWith(val)) {
        disallowed = true;
      }
    } else if (applies && key === 'crawl-delay') {
      const sec = Number(val);
      if (!Number.isNaN(sec) && sec > 0) {
        crawlDelayMs = Math.min(sec * 1000, 10000);
      }
    }
  }

  return {disallowed, crawlDelayMs};
}

export async function crawlBoundedUrl(
  rawUrl: string,
  allowlist: ApprovedSource[],
  options: {maxBytes?: number; timeoutMs?: number; maxRedirects?: number} = {},
): Promise<{
  ok: boolean;
  status: 'completed' | 'failed' | 'blocked_ssrf' | 'blocked_robots';
  error?: string;
  title?: string;
  canonicalUrl?: string;
  bodyText?: string;
  rawContent?: string;
  contentType?: 'text/html' | 'text/plain' | 'text/markdown';
  source?: ApprovedSource;
  provenance?: CrawlProvenance;
}> {
  const maxBytes = options.maxBytes ?? 1_500_000;
  const timeoutMs = options.timeoutMs ?? 5000;
  const maxRedirects = options.maxRedirects ?? 3;

  const initialValidation = await validateUrlForCrawl(rawUrl, allowlist);
  if (!initialValidation.ok || !initialValidation.url || !initialValidation.matchedSource) {
    return {
      ok: false,
      status: 'blocked_ssrf',
      error: initialValidation.reason ?? 'URL refusée.',
    };
  }

  let currentUrl = initialValidation.url;
  const source = initialValidation.matchedSource;
  let redirectsFollowed = 0;
  let robotsChecked = false;
  let crawlDelayMs = source.crawl_delay_ms;

  // Check robots.txt
  try {
    const robotsUrl = new URL('/robots.txt', currentUrl.origin);
    const robotsRes = await fetch(robotsUrl.toString(), {
      signal: AbortSignal.timeout(2500),
      headers: {'User-Agent': 'EclairBot/1.0 (+https://eclair.fr/bot)'},
    });
    robotsChecked = true;
    if (robotsRes.ok) {
      const robotsBody = await robotsRes.text();
      const robotsRule = isDisallowedByRobotsTxt(robotsBody, currentUrl.pathname);
      if (robotsRule.disallowed) {
        return {
          ok: false,
          status: 'blocked_robots',
          error: `Exploration refusée par robots.txt pour ${currentUrl.pathname}.`,
        };
      }
      if (robotsRule.crawlDelayMs > crawlDelayMs) {
        crawlDelayMs = robotsRule.crawlDelayMs;
      }
    }
  } catch {
    robotsChecked = true;
  }

  // Follow bounded redirects with SSRF re-validation at every hop
  for (let attempt = 0; attempt <= 1; attempt++) {
    try {
      while (redirectsFollowed <= maxRedirects) {
        const res = await fetch(currentUrl.toString(), {
          redirect: 'manual',
          signal: AbortSignal.timeout(timeoutMs),
          headers: {
            'User-Agent': 'EclairBot/1.0 (+https://eclair.fr/bot)',
            Accept: 'text/html, text/markdown, text/plain;q=0.9',
          },
        });

        if (res.status >= 300 && res.status < 400) {
          const loc = res.headers.get('location');
          if (!loc) {
            return {ok: false, status: 'failed', error: 'Redirection sans en-tête Location.'};
          }
          redirectsFollowed += 1;
          if (redirectsFollowed > maxRedirects) {
            return {
              ok: false,
              status: 'failed',
              error: `Nombre maximal de redirections atteint (${maxRedirects}).`,
            };
          }
          const nextTarget = new URL(loc, currentUrl).toString();
          const hopCheck = await validateUrlForCrawl(nextTarget, allowlist);
          if (!hopCheck.ok || !hopCheck.url) {
            return {
              ok: false,
              status: 'blocked_ssrf',
              error: `Redirection bloquée : ${hopCheck.reason}`,
            };
          }
          currentUrl = hopCheck.url;
          continue;
        }

        if (res.status === 401 || res.status === 403) {
          return {
            ok: false,
            status: 'failed',
            error: `Accès restreint (HTTP ${res.status}) : Éclair ne contourne jamais les authentifications ou péages.`,
          };
        }

        if (res.status === 503 && attempt === 0) {
          await new Promise((r) => setTimeout(r, 400));
          break;
        }

        if (!res.ok) {
          return {
            ok: false,
            status: 'failed',
            error: `Échec HTTP ${res.status} lors de la récupération.`,
          };
        }

        const contentLength = Number(res.headers.get('content-length') ?? '0');
        if (contentLength > maxBytes) {
          return {
            ok: false,
            status: 'failed',
            error: `Réponse trop volumineuse (${contentLength} octets > ${maxBytes}).`,
          };
        }

        // Stream read with hard byte cap (prevents archive bombs / oversized streams)
        const reader = res.body?.getReader();
        if (!reader) {
          return {ok: false, status: 'failed', error: 'Corps de réponse vide.'};
        }
        const chunks: Uint8Array[] = [];
        let received = 0;
        while (true) {
          const {done, value} = await reader.read();
          if (done) break;
          if (value) {
            received += value.byteLength;
            if (received > maxBytes) {
              await reader.cancel();
              return {
                ok: false,
                status: 'failed',
                error: `Flux interrompu : taille supérieure au plafond (${maxBytes} octets).`,
              };
            }
            chunks.push(value);
          }
        }

        const rawText = Buffer.concat(chunks).toString('utf8');
        const ctype = (res.headers.get('content-type') ?? '').toLowerCase();

        if (ctype.includes('markdown')) {
          const md = extractMarkdownContent(rawText);
          return {
            ok: true,
            status: 'completed',
            title: md.title,
            canonicalUrl: currentUrl.toString(),
            bodyText: md.bodyText,
            rawContent: rawText,
            contentType: 'text/markdown',
            source,
            provenance: {
              depth: 0,
              status_code: res.status,
              robots_checked: robotsChecked,
              crawl_delay_ms: crawlDelayMs,
              redirects_followed: redirectsFollowed,
            },
          };
        }

        if (ctype.includes('text/plain')) {
          return {
            ok: true,
            status: 'completed',
            title: currentUrl.pathname.split('/').pop() || currentUrl.hostname,
            canonicalUrl: currentUrl.toString(),
            bodyText: rawText.replace(/\s+/g, ' ').trim(),
            rawContent: rawText,
            contentType: 'text/plain',
            source,
            provenance: {
              depth: 0,
              status_code: res.status,
              robots_checked: robotsChecked,
              crawl_delay_ms: crawlDelayMs,
              redirects_followed: redirectsFollowed,
            },
          };
        }

        const html = extractHtmlContent(rawText, currentUrl.toString());
        return {
          ok: true,
          status: 'completed',
          title: html.title,
          canonicalUrl: html.canonicalUrl,
          bodyText: html.bodyText,
          rawContent: rawText,
          contentType: 'text/html',
          source,
          provenance: {
            depth: 0,
            status_code: res.status,
            robots_checked: robotsChecked,
            crawl_delay_ms: crawlDelayMs,
            redirects_followed: redirectsFollowed,
          },
        };
      }
    } catch (err) {
      if (attempt === 1) {
        return {
          ok: false,
          status: 'failed',
          error:
            err instanceof Error
              ? `Erreur réseau ou délai expiré : ${err.message}`
              : 'Erreur réseau lors de la collecte.',
        };
      }
    }
  }

  return {ok: false, status: 'failed', error: 'Budget de tentatives épuisé.'};
}
