const FRENCH_STOPWORDS = new Set([
  'le',
  'la',
  'les',
  'de',
  'du',
  'des',
  'un',
  'une',
  'et',
  'ou',
  'en',
  'dans',
  'pour',
  'par',
  'sur',
  'avec',
  'au',
  'aux',
  'ce',
  'cet',
  'cette',
  'ces',
  'se',
  'qui',
  'que',
  'quoi',
  'dont',
  'ne',
  'pas',
  'est',
  'sont',
  'etre',
  'avoir',
  'son',
  'sa',
  'ses',
  'leur',
  'leurs',
  'nous',
  'vous',
  'ils',
  'elles',
  'plus',
  'sans',
  'sous',
  'vers',
]);

const ELISION_PREFIXES = [
  "jusqu'",
  "lorsqu'",
  "puisqu'",
  "quoiqu'",
  "quelqu'",
  "presqu'",
  "aujourd'",
  "qu'",
  "l'",
  "d'",
  "j'",
  "m'",
  "t'",
  "s'",
  "n'",
  "c'",
];

export function stripAccents(input: string): string {
  return input
    .replace(/œ/g, 'oe')
    .replace(/Œ/g, 'OE')
    .replace(/æ/g, 'ae')
    .replace(/Æ/g, 'AE')
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '');
}

export function normalizeFrenchText(input: string): string {
  let text = stripAccents(input.toLowerCase());
  text = text.replace(/[’‘`´]/g, "'");
  for (const prefix of ELISION_PREFIXES) {
    const escaped = prefix.replace("'", "\\'");
    text = text.replace(new RegExp(`\\b${escaped}`, 'g'), ' ');
  }
  return text
    .replace(/[-–—/]/g, ' ')
    .replace(/[^a-z0-9\s]/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
}

export function stemFrenchToken(token: string): string {
  if (token.length <= 3) return token;

  let t = token;
  const suffixes = [
    'issements',
    'issement',
    'ations',
    'ation',
    'ements',
    'ement',
    'euses',
    'euse',
    'iques',
    'ique',
    'istes',
    'iste',
    'aires',
    'aire',
    'tions',
    'tion',
    'ments',
    'ment',
    'eurs',
    'eur',
    'aux',
    'eaux',
    'ant',
    'ent',
    'ees',
    'ee',
    'er',
    'ir',
    'es',
    's',
    'x',
  ];

  for (const suffix of suffixes) {
    if (t.endsWith(suffix) && t.length - suffix.length >= 3) {
      t = t.slice(0, -suffix.length);
      break;
    }
  }
  if (t.endsWith('al') === false && suffixNeedsAl(token, t)) {
    t += 'al';
  }
  return t;
}

function suffixNeedsAl(original: string, stemmed: string): boolean {
  return original.endsWith('aux') && stemmed.length >= 2 && original.length >= 5;
}

export function tokenizeFrench(
  input: string,
  options: {removeStopwords?: boolean; stem?: boolean} = {},
): string[] {
  const {removeStopwords = true, stem = true} = options;
  const normalized = normalizeFrenchText(input);
  if (!normalized) return [];

  const rawTokens = normalized.split(' ').filter((t) => t.length >= 2);
  const filtered = removeStopwords
    ? rawTokens.filter((t) => !FRENCH_STOPWORDS.has(t))
    : rawTokens;

  const effective = filtered.length > 0 ? filtered : rawTokens;
  return stem ? effective.map(stemFrenchToken) : effective;
}

export interface ParsedFrenchQuery {
  raw: string;
  normalized: string;
  phrases: string[];
  terms: string[];
  rawNormalizedTerms: string[];
  accentedTerms: string[];
}

export function parseFrenchQuery(rawQuery: string): ParsedFrenchQuery {
  const trimmed = rawQuery.trim();
  const phrases: string[] = [];
  const quoteRegex = /"([^"]+)"|«([^»]+)»/g;
  let match: RegExpExecArray | null;
  let remaining = trimmed;

  while ((match = quoteRegex.exec(trimmed)) !== null) {
    const phraseContent = (match[1] ?? match[2] ?? '').trim();
    const normPhrase = normalizeFrenchText(phraseContent);
    if (normPhrase) {
      phrases.push(normPhrase);
    }
    remaining = remaining.replace(match[0], ' ');
  }

  const normalized = normalizeFrenchText(trimmed);
  const rawNormalizedTerms = tokenizeFrench(trimmed, {
    removeStopwords: true,
    stem: false,
  });
  const terms = tokenizeFrench(trimmed, {
    removeStopwords: true,
    stem: true,
  });

  const accentedTerms = trimmed
    .toLowerCase()
    .replace(/[’‘`]/g, "'")
    .split(/[^a-zàâäéèêëîïôöùûüçœæ0-9]+/i)
    .filter((w) => w.length >= 2);

  return {
    raw: trimmed,
    normalized,
    phrases,
    terms,
    rawNormalizedTerms,
    accentedTerms,
  };
}

export function levenshtein(a: string, b: string): number {
  if (a === b) return 0;
  if (a.length === 0) return b.length;
  if (b.length === 0) return a.length;

  const prev = Array.from({length: b.length + 1}, (_, i) => i);
  const curr = new Array<number>(b.length + 1);

  for (let i = 1; i <= a.length; i++) {
    curr[0] = i;
    for (let j = 1; j <= b.length; j++) {
      const cost = a[i - 1] === b[j - 1] ? 0 : 1;
      curr[j] = Math.min(
        curr[j - 1] + 1,
        prev[j] + 1,
        prev[j - 1] + cost,
      );
    }
    for (let j = 0; j <= b.length; j++) {
      prev[j] = curr[j];
    }
  }
  return prev[b.length];
}

export function buildSnippet(
  bodyText: string,
  queryTerms: string[],
  phrases: string[],
  maxLength = 230,
): {snippet: string; highlightTerms: string[]} {
  const clean = bodyText.replace(/\s+/g, ' ').trim();
  if (!clean) return {snippet: '', highlightTerms: []};

  const sentences = clean.split(/(?<=[.!?])\s+/);
  let bestSentenceIdx = 0;
  let bestScore = -1;
  const matchedSurfaceTerms = new Set<string>();

  for (let i = 0; i < sentences.length; i++) {
    const normSentence = normalizeFrenchText(sentences[i]);
    const sentenceTokens = tokenizeFrench(sentences[i], {
      removeStopwords: false,
      stem: true,
    });
    let score = 0;
    for (const phrase of phrases) {
      if (normSentence.includes(phrase)) {
        score += 5;
      }
    }
    for (const term of queryTerms) {
      if (sentenceTokens.includes(term) || normSentence.includes(term)) {
        score += 2;
      }
    }
    if (score > bestScore) {
      bestScore = score;
      bestSentenceIdx = i;
    }
  }

  let excerpt = sentences[bestSentenceIdx] ?? clean;
  if (excerpt.length < 130 && bestSentenceIdx + 1 < sentences.length) {
    excerpt = `${excerpt} ${sentences[bestSentenceIdx + 1]}`;
  }
  if (excerpt.length > maxLength) {
    excerpt = excerpt.slice(0, maxLength - 1).replace(/\s+\S*$/, '') + '…';
  }

  const words = excerpt.split(/(\s+|[.,;:!?()«»"']+)/);
  for (const w of words) {
    const cleanW = w.trim();
    if (cleanW.length < 2) continue;
    const normW = stemFrenchToken(normalizeFrenchText(cleanW));
    if (
      queryTerms.some(
        (qt) => normW === qt || normalizeFrenchText(cleanW).includes(qt),
      )
    ) {
      matchedSurfaceTerms.add(cleanW);
    }
  }

  return {
    snippet: excerpt,
    highlightTerms: Array.from(matchedSurfaceTerms),
  };
}
