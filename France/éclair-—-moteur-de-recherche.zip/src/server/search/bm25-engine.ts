import {
  DocumentRecord,
  SearchHit,
  SearchMode,
  SearchResponse,
  SearchVertical,
  SuggestionItem,
  SuggestionsResponse,
} from '../../shared/eclair.types';
import {
  buildSnippet,
  levenshtein,
  normalizeFrenchText,
  parseFrenchQuery,
  tokenizeFrench,
} from './french-nlp';

export interface SearchQueryOptions {
  q: string;
  vertical?: SearchVertical;
  mode?: SearchMode;
  domain?: string;
  dateFrom?: string;
  dateTo?: string;
  cursor?: string | null;
  limit?: number;
}

interface IndexedDocEntry {
  doc: DocumentRecord;
  titleTokens: string[];
  sourceTokens: string[];
  bodyTokens: string[];
  titleNormalized: string;
  bodyNormalized: string;
  titleFreq: Map<string, number>;
  sourceFreq: Map<string, number>;
  bodyFreq: Map<string, number>;
}

export interface SearchAdapter {
  readonly name: string;
  search(
    options: SearchQueryOptions,
    documents: DocumentRecord[],
  ): Promise<SearchResponse>;
}

function countFrequencies(tokens: string[]): Map<string, number> {
  const map = new Map<string, number>();
  for (const t of tokens) {
    map.set(t, (map.get(t) ?? 0) + 1);
  }
  return map;
}

export class LocalFrenchBm25Index {
  private entries: IndexedDocEntry[] = [];
  private docFreq = new Map<string, number>();
  private vocabulary = new Map<string, {surface: string; count: number}>();
  private avgTitleLen = 1;
  private avgSourceLen = 1;
  private avgBodyLen = 1;

  rebuild(documents: DocumentRecord[]): void {
    const active = documents.filter((d) => d.index_status === 'indexed');
    this.entries = [];
    this.docFreq.clear();
    this.vocabulary.clear();

    let totalTitle = 0;
    let totalSource = 0;
    let totalBody = 0;

    // Deduplicate by content_hash and canonical_url at index time
    const seenHashes = new Set<string>();
    const seenCanonical = new Set<string>();

    for (const doc of active) {
      if (seenHashes.has(doc.content_hash) || seenCanonical.has(doc.canonical_url)) {
        continue;
      }
      seenHashes.add(doc.content_hash);
      seenCanonical.add(doc.canonical_url);

      const titleTokens = tokenizeFrench(doc.title, {
        removeStopwords: true,
        stem: true,
      });
      const sourceTokens = tokenizeFrench(
        `${doc.source_name} ${doc.domain} ${doc.image_metadata?.keywords.join(' ') ?? ''} ${doc.place_metadata?.city ?? ''} ${doc.place_metadata?.region ?? ''}`,
        {removeStopwords: true, stem: true},
      );
      const bodyTokens = tokenizeFrench(doc.body_text, {
        removeStopwords: true,
        stem: true,
      });

      totalTitle += titleTokens.length;
      totalSource += sourceTokens.length;
      totalBody += bodyTokens.length;

      const uniqueDocTerms = new Set([
        ...titleTokens,
        ...sourceTokens,
        ...bodyTokens,
      ]);
      for (const term of uniqueDocTerms) {
        this.docFreq.set(term, (this.docFreq.get(term) ?? 0) + 1);
      }

      // Build unstemmed French vocabulary for spelling suggestions
      const surfaceWords = `${doc.title} ${doc.body_text}`
        .split(/[^a-zàâäéèêëîïôöùûüçœæA-ZÀÂÄÉÈÊËÎÏÔÖÙÛÜÇŒÆ0-9-]+/)
        .filter((w) => w.length >= 4 && w.length <= 24);
      for (const word of surfaceWords) {
        const lower = word.toLowerCase();
        const norm = normalizeFrenchText(lower);
        if (!norm || norm.includes(' ')) continue;
        const existing = this.vocabulary.get(norm);
        if (existing) {
          existing.count += 1;
        } else {
          this.vocabulary.set(norm, {surface: lower, count: 1});
        }
      }

      this.entries.push({
        doc,
        titleTokens,
        sourceTokens,
        bodyTokens,
        titleNormalized: normalizeFrenchText(doc.title),
        bodyNormalized: normalizeFrenchText(doc.body_text),
        titleFreq: countFrequencies(titleTokens),
        sourceFreq: countFrequencies(sourceTokens),
        bodyFreq: countFrequencies(bodyTokens),
      });
    }

    const n = Math.max(1, this.entries.length);
    this.avgTitleLen = Math.max(1, totalTitle / n);
    this.avgSourceLen = Math.max(1, totalSource / n);
    this.avgBodyLen = Math.max(1, totalBody / n);
  }

  getVocabularySize(): number {
    return this.vocabulary.size;
  }

  suggest(rawQuery: string, limit = 6): SuggestionsResponse {
    const q = rawQuery.trim();
    if (!q) {
      return {query: '', suggestions: [], spelling_suggestion: null};
    }

    const normQ = normalizeFrenchText(q);
    const suggestions: SuggestionItem[] = [];
    const seen = new Set<string>();

    // Prefix / substring title suggestions
    for (const entry of this.entries) {
      if (
        entry.titleNormalized.includes(normQ) &&
        !seen.has(entry.doc.title)
      ) {
        seen.add(entry.doc.title);
        suggestions.push({
          text: entry.doc.title,
          kind: 'completion',
          source_hint: entry.doc.source_name,
        });
      }
      if (suggestions.length >= limit) break;
    }

    // Spelling check per token
    const spellingSuggestion = this.computeSpellingSuggestion(q);
    if (spellingSuggestion && !seen.has(spellingSuggestion)) {
      suggestions.unshift({
        text: spellingSuggestion,
        kind: 'spelling',
        source_hint: 'Suggestion orthographique',
      });
    }

    return {
      query: rawQuery,
      suggestions: suggestions.slice(0, limit),
      spelling_suggestion: spellingSuggestion,
    };
  }

  computeSpellingSuggestion(rawQuery: string): string | null {
    const words = rawQuery.trim().split(/\s+/).filter(Boolean);
    if (words.length === 0 || words.length > 6) return null;

    let changed = false;
    const correctedWords: string[] = [];

    for (const w of words) {
      const strippedQuotes = w.replace(/^["«]|["»]$/g, '');
      const norm = normalizeFrenchText(strippedQuotes);
      if (norm.length < 4 || this.vocabulary.has(norm)) {
        correctedWords.push(w);
        continue;
      }

      let bestMatch: {surface: string; dist: number; count: number} | null = null;
      for (const [vocabNorm, info] of this.vocabulary.entries()) {
        if (Math.abs(vocabNorm.length - norm.length) > 2) continue;
        const dist = levenshtein(norm, vocabNorm);
        if (dist > 0 && dist <= 2) {
          if (
            !bestMatch ||
            dist < bestMatch.dist ||
            (dist === bestMatch.dist && info.count > bestMatch.count)
          ) {
            bestMatch = {surface: info.surface, dist, count: info.count};
          }
        }
      }

      if (bestMatch) {
        changed = true;
        correctedWords.push(bestMatch.surface);
      } else {
        correctedWords.push(w);
      }
    }

    return changed ? correctedWords.join(' ') : null;
  }

  search(options: SearchQueryOptions): SearchResponse {
    const start = performance.now();
    const vertical: SearchVertical = options.vertical ?? 'web';
    const limit = Math.min(Math.max(options.limit ?? 10, 1), 25);
    const parsed = parseFrenchQuery(options.q);
    const offset = decodeCursor(options.cursor);

    const n = Math.max(1, this.entries.length);
    const k1 = 1.5;
    const b = 0.75;

    // Filter candidates by vertical/date/domain before scoring, but also track facets
    const verticalMatches = this.entries.filter((entry) => {
      if (vertical === 'web') {
        return (
          entry.doc.vertical === 'web' ||
          entry.doc.vertical === 'savoirs' ||
          entry.doc.vertical === 'actualites'
        );
      }
      return entry.doc.vertical === vertical;
    });

    const domainCounts = new Map<string, number>();
    const verticalCounts = new Map<SearchVertical, number>();

    const scoredAllVerticals: {entry: IndexedDocEntry; score: number}[] = [];
    const hasQuery = parsed.terms.length > 0 || parsed.phrases.length > 0;

    for (const entry of this.entries) {
      let score = 0;

      if (!hasQuery) {
        // Browse mode for a vertical (e.g. Actualités, Images, Cartes)
        score = entry.doc.published_at
          ? new Date(entry.doc.published_at).getTime() / 1e12
          : 0.1;
      } else {
        // Phrase check: all quoted phrases must appear verbatim (accent-insensitive normalized)
        let phraseOk = true;
        for (const phrase of parsed.phrases) {
          const inTitle = entry.titleNormalized.includes(phrase);
          const inBody = entry.bodyNormalized.includes(phrase);
          if (!inTitle && !inBody) {
            phraseOk = false;
            break;
          }
          score += inTitle ? 8.0 : 4.2;
        }
        if (!phraseOk) continue;

        for (const term of parsed.terms) {
          const df = this.docFreq.get(term) ?? 0;
          if (df === 0) continue;
          const idf = Math.log(1 + (n - df + 0.5) / (df + 0.5));

          const tfTitle = entry.titleFreq.get(term) ?? 0;
          const tfSource = entry.sourceFreq.get(term) ?? 0;
          const tfBody = entry.bodyFreq.get(term) ?? 0;

          if (tfTitle > 0) {
            const normTf =
              (tfTitle * (k1 + 1)) /
              (tfTitle + k1 * (1 - b + b * (entry.titleTokens.length / this.avgTitleLen)));
            score += idf * normTf * 3.2;
          }
          if (tfSource > 0) {
            const normTf =
              (tfSource * (k1 + 1)) /
              (tfSource + k1 * (1 - b + b * (entry.sourceTokens.length / this.avgSourceLen)));
            score += idf * normTf * 1.6;
          }
          if (tfBody > 0) {
            const normTf =
              (tfBody * (k1 + 1)) /
              (tfBody + k1 * (1 - b + b * (entry.bodyTokens.length / this.avgBodyLen)));
            score += idf * normTf * 1.0;
          }
        }

        if (score <= 0) continue;

        // Exact accented surface tie-breaker
        const lowerTitleAndBody = `${entry.doc.title} ${entry.doc.body_text}`.toLowerCase();
        for (const acc of parsed.accentedTerms) {
          if (lowerTitleAndBody.includes(acc)) {
            score += 0.22;
          }
        }
      }

      // Check date/domain filters
      if (options.domain && entry.doc.domain !== options.domain) {
        continue;
      }
      if (options.dateFrom && entry.doc.published_at && entry.doc.published_at < options.dateFrom) {
        continue;
      }
      if (options.dateFrom && !entry.doc.published_at) {
        continue;
      }
      if (options.dateTo && entry.doc.published_at && entry.doc.published_at > options.dateTo) {
        continue;
      }

      verticalCounts.set(
        entry.doc.vertical,
        (verticalCounts.get(entry.doc.vertical) ?? 0) + 1,
      );

      const matchesVertical =
        vertical === 'web'
          ? entry.doc.vertical === 'web' ||
            entry.doc.vertical === 'savoirs' ||
            entry.doc.vertical === 'actualites'
          : entry.doc.vertical === vertical;

      if (matchesVertical) {
        domainCounts.set(
          entry.doc.domain,
          (domainCounts.get(entry.doc.domain) ?? 0) + 1,
        );
        scoredAllVerticals.push({entry, score});
      }
    }

    // Sort by BM25 score (or newest date for Actualités browse)
    scoredAllVerticals.sort((a, b) => {
      if (!hasQuery && vertical === 'actualites') {
        const da = a.entry.doc.published_at ?? '';
        const db = b.entry.doc.published_at ?? '';
        return db.localeCompare(da);
      }
      return b.score - a.score;
    });

    const pageSlice = scoredAllVerticals.slice(offset, offset + limit);
    const hasMore = offset + limit < scoredAllVerticals.length;

    const results: SearchHit[] = pageSlice.map(({entry, score}) => {
      const {snippet, highlightTerms} = buildSnippet(
        entry.doc.body_text,
        parsed.terms,
        parsed.phrases,
      );
      return {
        document_id: entry.doc.document_id,
        title: entry.doc.title,
        source_url: entry.doc.source_url,
        canonical_url: entry.doc.canonical_url,
        domain: entry.doc.domain,
        source_name: entry.doc.source_name,
        snippet: snippet || entry.doc.excerpt,
        highlight_terms: highlightTerms,
        published_at: entry.doc.published_at,
        modified_at: entry.doc.modified_at,
        content_type: entry.doc.content_type,
        vertical: entry.doc.vertical,
        rights_metadata: entry.doc.rights_metadata,
        score: Number(score.toFixed(3)),
        image_metadata: entry.doc.image_metadata,
        place_metadata: entry.doc.place_metadata,
      };
    });

    const spellingSuggestion =
      results.length === 0 && hasQuery
        ? this.computeSpellingSuggestion(options.q)
        : null;

    const elapsedMs = Math.max(1, Math.round(performance.now() - start));

    return {
      query: options.q,
      normalized_query: parsed.normalized,
      vertical,
      mode: 'local',
      provider_status: {
        mode: 'local',
        adapter_name: 'LocalFrenchBm25Adapter',
        available: true,
        honest_notice: `Recherche exécutée sur le corpus documentaire local Éclair (${verticalMatches.length} documents indexés dans cet onglet). Ce corpus ne prétend pas couvrir l’ensemble du Web.`,
      },
      results,
      next_cursor: hasMore ? encodeCursor(offset + limit) : null,
      returned_count: results.length,
      corpus_scope_note:
        'Corpus éditorial français vérifiable (Culture, Sciences, Architecture, Voyages, Actualités, Lieux).',
      spelling_suggestion: spellingSuggestion,
      did_not_replace_query: true,
      facets: {
        domains: Array.from(domainCounts.entries()).map(([domain, count]) => ({
          domain,
          count,
        })),
        verticals: Array.from(verticalCounts.entries()).map(([v, count]) => ({
          vertical: v,
          count,
        })),
      },
      elapsed_ms: elapsedMs,
    };
  }
}

export class ExternalWebSearchAdapter implements SearchAdapter {
  readonly name = 'ExternalWebProviderAdapter';

  async search(options: SearchQueryOptions): Promise<SearchResponse> {
    const start = performance.now();
    const endpoint = process.env['EXTERNAL_WEB_SEARCH_URL']?.trim();
    const apiKey = process.env['EXTERNAL_WEB_SEARCH_API_KEY']?.trim();
    const vertical = options.vertical ?? 'web';
    const parsed = parseFrenchQuery(options.q);

    if (!endpoint || !apiKey) {
      return {
        query: options.q,
        normalized_query: parsed.normalized,
        vertical,
        mode: 'external',
        provider_status: {
          mode: 'external',
          adapter_name: this.name,
          available: false,
          error_code: 'MISSING_CREDENTIALS',
          honest_notice:
            'Aucun fournisseur Web externe autorisé n’est configuré (EXTERNAL_WEB_SEARCH_URL / EXTERNAL_WEB_SEARCH_API_KEY absents). Éclair ne fabrique jamais de résultats simulés : basculez sur le Corpus local pour rechercher dans la collection indexée.',
        },
        results: [],
        next_cursor: null,
        returned_count: 0,
        corpus_scope_note: 'Fournisseur Web externe non configuré.',
        spelling_suggestion: null,
        did_not_replace_query: true,
        facets: {domains: [], verticals: []},
        elapsed_ms: Math.max(1, Math.round(performance.now() - start)),
      };
    }

    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), 4000);
    try {
      const target = new URL(endpoint);
      target.searchParams.set('q', options.q);
      target.searchParams.set('lang', 'fr');
      target.searchParams.set('vertical', vertical);

      const response = await fetch(target.toString(), {
        headers: {
          Authorization: `Bearer ${apiKey}`,
          Accept: 'application/json',
        },
        signal: controller.signal,
      });

      if (!response.ok) {
        return {
          query: options.q,
          normalized_query: parsed.normalized,
          vertical,
          mode: 'external',
          provider_status: {
            mode: 'external',
            adapter_name: this.name,
            available: false,
            error_code: 'PROVIDER_ERROR',
            honest_notice: `Le fournisseur Web externe a répondu avec le statut HTTP ${response.status}. Aucun résultat n’a été simulé.`,
          },
          results: [],
          next_cursor: null,
          returned_count: 0,
          corpus_scope_note: 'Fournisseur Web externe indisponible.',
          spelling_suggestion: null,
          did_not_replace_query: true,
          facets: {domains: [], verticals: []},
          elapsed_ms: Math.max(1, Math.round(performance.now() - start)),
        };
      }

      const payload = (await response.json()) as {
        results?: {
          title?: string;
          url?: string;
          snippet?: string;
          published_at?: string;
        }[];
      };
      const mapped: SearchHit[] = (payload.results ?? [])
        .filter((item) => item.title && item.url)
        .slice(0, options.limit ?? 10)
        .map((item, idx) => {
          const urlObj = new URL(item.url!);
          return {
            document_id: `ext-${idx}-${urlObj.hostname}`,
            title: item.title!,
            source_url: item.url!,
            canonical_url: item.url!,
            domain: urlObj.hostname,
            source_name: urlObj.hostname,
            snippet: item.snippet ?? '',
            highlight_terms: [],
            published_at: item.published_at ?? null,
            modified_at: null,
            content_type: 'text/html',
            vertical,
            rights_metadata: 'Résultat issu d’un fournisseur Web externe autorisé',
            score: 1 - idx * 0.05,
          };
        });

      return {
        query: options.q,
        normalized_query: parsed.normalized,
        vertical,
        mode: 'external',
        provider_status: {
          mode: 'external',
          adapter_name: this.name,
          available: true,
          honest_notice: `Résultats transmis par le fournisseur Web externe autorisé (${endpoint}).`,
        },
        results: mapped,
        next_cursor: null,
        returned_count: mapped.length,
        corpus_scope_note: 'Mode Web externe actif.',
        spelling_suggestion: null,
        did_not_replace_query: true,
        facets: {domains: [], verticals: []},
        elapsed_ms: Math.max(1, Math.round(performance.now() - start)),
      };
    } catch (err) {
      const isAbort = err instanceof Error && err.name === 'AbortError';
      return {
        query: options.q,
        normalized_query: parsed.normalized,
        vertical,
        mode: 'external',
        provider_status: {
          mode: 'external',
          adapter_name: this.name,
          available: false,
          error_code: isAbort ? 'PROVIDER_TIMEOUT' : 'PROVIDER_ERROR',
          honest_notice: isAbort
            ? 'Le fournisseur Web externe a dépassé le délai maximal de réponse (4 s). Aucun résultat n’a été fabriqué.'
            : 'Impossible de joindre le fournisseur Web externe configuré. Aucun résultat n’a été fabriqué.',
        },
        results: [],
        next_cursor: null,
        returned_count: 0,
        corpus_scope_note: 'Échec de connexion au fournisseur Web externe.',
        spelling_suggestion: null,
        did_not_replace_query: true,
        facets: {domains: [], verticals: []},
        elapsed_ms: Math.max(1, Math.round(performance.now() - start)),
      };
    } finally {
      clearTimeout(timer);
    }
  }
}

function encodeCursor(offset: number): string {
  return Buffer.from(JSON.stringify({offset}), 'utf8').toString('base64url');
}

function decodeCursor(cursor?: string | null): number {
  if (!cursor) return 0;
  try {
    const parsed = JSON.parse(
      Buffer.from(cursor, 'base64url').toString('utf8'),
    ) as {offset?: number};
    return typeof parsed.offset === 'number' && parsed.offset >= 0
      ? Math.floor(parsed.offset)
      : 0;
  } catch {
    return 0;
  }
}
