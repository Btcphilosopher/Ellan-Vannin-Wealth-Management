# Éclair — Documentation API & Matrice des capacités

## 1. Endpoints implémentés dans le runtime actif (`src/server.ts`)

### Recherche & Documents
- `GET /v1/search?q=&vertical=web|images|actualites|savoirs|cartes&mode=local|external&domain=&dateFrom=&dateTo=&cursor=&limit=`
- `GET /v1/search/suggestions?q=`
- `POST /v1/search/image` — Adaptateur de recherche visuelle par métadonnées autorisées (validation MIME JPEG/PNG/WebP, limite 5 Mo, zéro conservation).
- `GET /v1/documents/{document_id}`

### Assistant documentaire sourcé
- `POST /v1/assistant/answers` — Synthèse ancrée sur les documents récupérés (`gemini-4-hydrogen` via `@google/genai` côté serveur), avec séparation stricte entre citations exactes et résumé, note d'incertitude, gestion de preuves insuffisantes et absence de fabrication si `GEMINI_API_KEY` est absent.

### Comptes optionnels, résultats enregistrés & signalements
- `POST /v1/auth/register` / `POST /v1/auth/login`
- `GET /v1/me/profile` / `PATCH /v1/me/preferences`
- `GET /v1/me/saved-results` / `POST /v1/me/saved-results` / `DELETE /v1/me/saved-results/{saved_id}`
- `GET /v1/me/export` / `DELETE /v1/me/account`
- `POST /v1/abuse-reports`

### Administration & Évaluation (protégé par jeton Bearer administrateur)
- `GET /admin/v1/auth/status` / `POST /admin/v1/auth/bootstrap` / `POST /admin/v1/auth/login`
- `GET /admin/v1/overview`
- `GET /admin/v1/sources` / `POST /admin/v1/sources`
- `POST /admin/v1/ingestion-jobs` / `GET /admin/v1/ingestion-jobs/{job_id}`
- `POST /admin/v1/index-rebuilds`
- `POST /admin/v1/evaluation/run`
- `GET /admin/v1/abuse-reports` / `PATCH /admin/v1/abuse-reports/{report_id}`

## 2. Distinction honnête des capacités
- **Implémenté et exécuté en direct** : Interface fidèle à la maquette, indexation lexicale française BM25 (normalisation des accents NFD, élisions, racinisation, recherche d'expressions exactes, pondération du titre), filtres domaine/date, pagination par curseur, ingestion HTML/Markdown/Texte/PDF, collecteur borné avec protection SSRF & `robots.txt`, comptes `scrypt`, enregistrement, évaluation MRR@5 / Rappel@5, tests Vitest.
- **Intégré avec adaptateur externe conditionnel** : Mode `Web externe` (`EXTERNAL_WEB_SEARCH_URL` + `EXTERNAL_WEB_SEARCH_API_KEY`), Assistant IA (`GEMINI_API_KEY`), adaptateur `OpenSearch` (`OPENSEARCH_URL`). En l'absence d'identifiants, Éclair signale l'indisponibilité sans fabriquer de résultats.
- **Livré pour déploiement infrastructure** : Schéma PostgreSQL (`backend/migrations/001_init.sql`), service Python FastAPI (`backend/app/main.py`) et pile `docker-compose.yml`.
