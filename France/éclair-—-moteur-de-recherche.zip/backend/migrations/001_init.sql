-- Éclair — Schéma PostgreSQL initial (architecture de déploiement Docker / FastAPI)

CREATE TABLE IF NOT EXISTS approved_sources (
    source_id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    base_url TEXT NOT NULL,
    domain TEXT NOT NULL UNIQUE,
    allowed_paths JSONB NOT NULL DEFAULT '["/"]'::jsonb,
    vertical TEXT NOT NULL DEFAULT 'web',
    rights_default TEXT NOT NULL,
    crawl_delay_ms INTEGER NOT NULL DEFAULT 1000,
    max_depth INTEGER NOT NULL DEFAULT 1,
    enabled BOOLEAN NOT NULL DEFAULT TRUE,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS documents (
    document_id TEXT PRIMARY KEY,
    source_url TEXT NOT NULL,
    canonical_url TEXT NOT NULL UNIQUE,
    title TEXT NOT NULL,
    language TEXT NOT NULL DEFAULT 'fr',
    body_text TEXT NOT NULL,
    content_type TEXT NOT NULL,
    published_at DATE,
    modified_at DATE,
    fetched_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    content_hash TEXT NOT NULL UNIQUE,
    source_name TEXT NOT NULL,
    rights_metadata TEXT NOT NULL,
    index_status TEXT NOT NULL DEFAULT 'indexed',
    vertical TEXT NOT NULL DEFAULT 'web',
    raw_object_key TEXT
);

CREATE INDEX IF NOT EXISTS idx_documents_vertical ON documents (vertical, published_at DESC);
CREATE INDEX IF NOT EXISTS idx_documents_status ON documents (index_status);

CREATE TABLE IF NOT EXISTS ingestion_jobs (
    job_id TEXT PRIMARY KEY,
    kind TEXT NOT NULL,
    target_url TEXT,
    source_name TEXT NOT NULL,
    status TEXT NOT NULL,
    document_id TEXT REFERENCES documents(document_id) ON DELETE SET NULL,
    error_message TEXT,
    provenance JSONB,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    finished_at TIMESTAMPTZ
);

CREATE TABLE IF NOT EXISTS users (
    user_id TEXT PRIMARY KEY,
    email TEXT NOT NULL UNIQUE,
    display_name TEXT NOT NULL,
    password_hash TEXT NOT NULL,
    save_search_history BOOLEAN NOT NULL DEFAULT FALSE,
    default_mode TEXT NOT NULL DEFAULT 'local',
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS saved_results (
    saved_id TEXT PRIMARY KEY,
    user_id TEXT NOT NULL REFERENCES users(user_id) ON DELETE CASCADE,
    document_id TEXT NOT NULL,
    title TEXT NOT NULL,
    source_url TEXT NOT NULL,
    domain TEXT NOT NULL,
    snippet TEXT NOT NULL,
    collection TEXT NOT NULL DEFAULT 'Lectures enregistrées',
    saved_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS abuse_reports (
    report_id TEXT PRIMARY KEY,
    document_id TEXT,
    source_url TEXT NOT NULL,
    reason TEXT NOT NULL,
    details TEXT,
    status TEXT NOT NULL DEFAULT 'open',
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
