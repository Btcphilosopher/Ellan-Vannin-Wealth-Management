"""
Éclair — Backend FastAPI de référence (PostgreSQL + OpenSearch).
Note : dans l'aperçu AI Studio, le serveur Node/Express (src/server.ts) exécute directement
l'ensemble des endpoints /v1/* et /admin/v1/* sur le port 3000. Ce module FastAPI fournit
l'implémentation Python équivalente pour le déploiement Docker Compose (PostgreSQL + OpenSearch).
"""

from __future__ import annotations

import ipaddress
import os
import unicodedata
from typing import Any, Literal, Optional
from urllib.parse import urlparse

from fastapi import FastAPI, HTTPException, Query
from pydantic import BaseModel

app = FastAPI(title="Éclair — Moteur de recherche API", version="1.0.0")


def normalize_french(text: str) -> str:
    nfd = unicodedata.normalize("NFD", text.lower())
    stripped = "".join(ch for ch in nfd if unicodedata.category(ch) != "Mn")
    return " ".join(stripped.replace("’", "'").split())


def is_safe_public_url(raw_url: str, allowed_domains: set[str]) -> bool:
    parsed = urlparse(raw_url)
    if parsed.scheme not in {"http", "https"} or not parsed.hostname:
        return False
    host = parsed.hostname.lower()
    if host in {"localhost"} or host.endswith((".local", ".internal")):
        return False
    try:
        ip = ipaddress.ip_address(host)
        if ip.is_private or ip.is_loopback or ip.is_link_local or ip.is_reserved:
            return False
    except ValueError:
        pass
    return host in allowed_domains


class AssistantQuery(BaseModel):
    query: str


@app.get("/health")
def health() -> dict[str, Any]:
    return {
        "status": "ok",
        "opensearch_configured": bool(os.getenv("OPENSEARCH_URL")),
        "postgres_configured": bool(os.getenv("DATABASE_URL")),
    }


@app.get("/v1/search")
def search(
    q: str = Query(default="", max_length=240),
    vertical: Literal["web", "images", "actualites", "savoirs", "cartes"] = "web",
    mode: Literal["local", "external"] = "local",
) -> dict[str, Any]:
    if mode == "external" and not os.getenv("EXTERNAL_WEB_SEARCH_URL"):
        return {
            "query": q,
            "normalized_query": normalize_french(q),
            "vertical": vertical,
            "mode": "external",
            "provider_status": {
                "mode": "external",
                "available": False,
                "error_code": "MISSING_CREDENTIALS",
                "honest_notice": "Aucun fournisseur Web externe configuré.",
            },
            "results": [],
        }
    return {
        "query": q,
        "normalized_query": normalize_french(q),
        "vertical": vertical,
        "mode": mode,
        "opensearch_url": os.getenv("OPENSEARCH_URL", "unconfigured"),
        "results": [],
    }


@app.post("/v1/assistant/answers")
def assistant_answers(payload: AssistantQuery) -> dict[str, Any]:
    if not payload.query.strip():
        raise HTTPException(status_code=400, detail="Requête requise.")
    return {
        "query": payload.query,
        "status": "provider_unavailable",
        "summary": None,
        "uncertainty_note": "Adaptateur IA Python en attente de configuration OpenSearch.",
        "quotations": [],
        "citations": [],
    }
