# Renault Concept — Plateforme Automobile Française (Démonstration)

Projet de démonstration indépendant réalisé avec **Next.js 15 (App Router, TypeScript)**, **Tailwind CSS v4**, **Zod**, **Firebase Auth & Firestore** (en environnement hébergé), accompagné d'une configuration **Docker Compose** et d'un schéma **PostgreSQL / Prisma** de référence pour le développement local.

> **Avertissement** : Ce site est un concept indépendant sans affiliation ni connexion aux systèmes officiels Renault. Toutes les données véhicules, autonomies WLTP, stocks, tarifs et concessions sont fictifs et clairement identifiés comme données de démonstration.

## Fonctionnalités livrées
1. **Accueil fidèle à la maquette** (`/`) : en-tête 3 zones, bannière *« L’audace, électrique. »*, barre d'actions 4 entrées, présentation *« À chacun son élan. »* (Renault 5, Scénic, Rafale) et bandeau signature sombre.
2. **Catalogue & Fiches modèles** (`/vehicules`, `/vehicules/[slug]`) : séparation stricte Modèle / Année-modèle / Motorisation / Finition / Batterie / Couleur / Jantes / Sellerie / Packs / Stock, avec provenance, date d'effet et mention explicite `Non communiqué` pour les données non publiées.
3. **Configurateur 8 étapes** (`/configurateur`) : validation serveur (`POST /api/configure/validate`), gestion des dépendances, exclusivités et équipements inclus avec explication claire sans modification silencieuse des choix, calcul en centimes entiers, tarifs versionnés (`TARIF-FR-2026-Q4` / `Q2`), sauvegarde, reprise (`?configId=...`), partage, export `.txt` et impression.
4. **Comparateur & Stock** (`/comparer`, `/stock`) : comparaison jusqu'à 3 véhicules ou configurations sauvegardées, filtres multi-critères par distance/prix/modèle, revérification serveur de disponibilité (`POST /api/stock/verify`).
5. **Concessionnaires & Essais** (`/concessionnaires`, `/essais`) : annuaire de 6 concessions fictives, recherche par ville/code postal, géolocalisation facultative, carte vectorielle de France, réservation atomique de créneau sans double réservation, distinction `Demande reçue` vs `Rendez-vous confirmé`.
6. **Espace client & Administration** (`/compte`, `/admin`) : favoris, configurations sauvegardées, historique, préférences de communication, confirmation/refus des essais, gestion des stocks, publication de tarifs versionnés, activation de règles, journal d'audit et validation de sauvegarde JSON (`POST /api/backup`).

## Variables d'environnement
Consultez `.env.example` :
- `GEMINI_API_KEY`
- `APP_URL`
- Variables locales optionnelles Docker Compose : `POSTGRES_USER`, `POSTGRES_PASSWORD`, `POSTGRES_DB`, `MINIO_ROOT_USER`, `MINIO_ROOT_PASSWORD`.

## Installation locale
```bash
npm install
npm run dev
```

Pour lancer PostgreSQL et MinIO en local :
```bash
docker compose up -d
```

## Vérifications
```bash
npm run lint
npm run build
npx tsx scripts/run-tests.ts
```
