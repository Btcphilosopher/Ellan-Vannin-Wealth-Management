import { CompareClient } from "@/components/compare/CompareClient";

export default function ComparerPage() {
  return <CompareClient />;
}
