import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { INITIAL_STOCK_VEHICLES } from "@/lib/catalog/data";
import { checkRateLimit, getClientKey } from "@/lib/security/rateLimit";

const VerifySchema = z.object({
  vehicleId: z.string().min(1).max(128).regex(/^[a-zA-Z0-9_-]+$/),
  observedStatus: z.enum(["available", "reserved", "sold"]).optional(),
});

export async function POST(req: NextRequest) {
  const rate = checkRateLimit(`stock:${getClientKey(req.headers)}`, 60, 60_000);
  if (!rate.allowed) {
    return NextResponse.json(
      { error: "Limite de requêtes atteinte. Patientez un instant." },
      { status: 429 }
    );
  }

  let body: unknown;
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: "Corps JSON invalide." }, { status: 400 });
  }

  const parsed = VerifySchema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json(
      { error: "Identifiant véhicule invalide." },
      { status: 400 }
    );
  }

  const vehicle = INITIAL_STOCK_VEHICLES.find(
    (v) => v.id === parsed.data.vehicleId
  );
  if (!vehicle) {
    return NextResponse.json(
      {
        verified: false,
        status: "unknown",
        checkedAt: new Date().toISOString(),
        message:
          "Véhicule de stock personnalisé ou introuvable dans le référentiel initial.",
      },
      { status: 200, headers: { "Cache-Control": "no-store" } }
    );
  }

  const effectiveStatus = parsed.data.observedStatus ?? vehicle.status;
  return NextResponse.json(
    {
      verified: effectiveStatus === "available",
      vehicleId: vehicle.id,
      status: effectiveStatus,
      priceCents: vehicle.priceCents,
      checkedAt: new Date().toISOString(),
      message:
        effectiveStatus === "available"
          ? "Disponibilité confirmée pour demande de réservation en concession."
          : "Ce véhicule n'est plus disponible à la réservation.",
    },
    { status: 200, headers: { "Cache-Control": "no-store" } }
  );
}
