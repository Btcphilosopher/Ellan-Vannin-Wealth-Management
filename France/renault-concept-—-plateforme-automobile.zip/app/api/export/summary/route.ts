import { NextRequest, NextResponse } from "next/server";
import { ConfigSelectionSchema } from "@/lib/configurator/rules";
import { validateAndPriceConfiguration } from "@/lib/configurator/engine";
import { formatCentsEUR } from "@/lib/pricing/tariffs";
import { checkRateLimit, getClientKey } from "@/lib/security/rateLimit";

export async function POST(req: NextRequest) {
  const rate = checkRateLimit(`export:${getClientKey(req.headers)}`, 40, 60_000);
  if (!rate.allowed) {
    return NextResponse.json(
      { error: "Trop d'exports demandés. Patientez une minute." },
      { status: 429 }
    );
  }

  let body: unknown;
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: "Corps JSON invalide." }, { status: 400 });
  }

  const parsed = ConfigSelectionSchema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json(
      { error: "Configuration invalide pour l'export." },
      { status: 400 }
    );
  }

  let result;
  try {
    result = validateAndPriceConfiguration(parsed.data);
  } catch (error) {
    return NextResponse.json(
      {
        error:
          error instanceof Error
            ? error.message
            : "Erreur de validation de la configuration.",
      },
      { status: 400 }
    );
  }
  const { resolvedLabels, pricing, valid, issues } = result;

  const lines = [
    "================================================================",
    "RENAULT CONCEPT (PROJET INDÉPENDANT DE DÉMONSTRATION)",
    "RÉCAPITULATIF DE CONFIGURATION VÉHICULE",
    "================================================================",
    `Date d'édition : ${new Date().toLocaleString("fr-FR")}`,
    `Tarif versionné : ${pricing.tariffVersion} (effet ${pricing.tariffEffectiveDate}, marché ${pricing.market})`,
    `Statut de compatibilité : ${valid ? "Configuration valide" : "Incompatibilité(s) à résoudre"}`,
    "",
    `Modèle : ${resolvedLabels.modelName} (${resolvedLabels.modelYear})`,
    `Motorisation : ${resolvedLabels.motorisationName}`,
    `Batterie : ${resolvedLabels.batteryName}`,
    `Finition : ${resolvedLabels.trimName}`,
    `Couleur : ${resolvedLabels.colorName}`,
    `Jantes : ${resolvedLabels.wheelName}`,
    `Intérieur : ${resolvedLabels.interiorName}`,
    `Options : ${resolvedLabels.optionNames.length > 0 ? resolvedLabels.optionNames.join(", ") : "Aucune option sélectionnée"}`,
    "",
    "DÉTAIL TARIFAIRE ESTIMATIF (CENTIMES ENTIERS)",
    ` - Prix de base modèle : ${formatCentsEUR(pricing.baseVehicleCents, true)}`,
    ` - Motorisation : ${formatCentsEUR(pricing.motorisationDeltaCents, true)}`,
    ` - Finition : ${formatCentsEUR(pricing.trimDeltaCents, true)}`,
    ` - Peinture : ${formatCentsEUR(pricing.colorDeltaCents, true)}`,
    ` - Jantes : ${formatCentsEUR(pricing.wheelDeltaCents, true)}`,
    ` - Sellerie : ${formatCentsEUR(pricing.interiorDeltaCents, true)}`,
    ` - Options & packs : ${formatCentsEUR(pricing.optionsTotalCents, true)}`,
    ` - Frais obligatoires indicatifs : ${formatCentsEUR(pricing.mandatoryFeesCents, true)}`,
    ` - Livraison & mise à la route : ${formatCentsEUR(pricing.deliveryFeeCents, true)}`,
    ` - Remise commerciale démo : -${formatCentsEUR(pricing.discountDemoCents, true)}`,
    ` - Aides publiques appliquées : ${formatCentsEUR(pricing.publicAidCents, true)} (${pricing.publicAidNotice})`,
    ` - Dont TVA 20 % incluse : ${formatCentsEUR(pricing.vatIncludedCents, true)}`,
    `TOTAL CONNU ESTIMATIF : ${formatCentsEUR(pricing.totalKnownCents, true)}`,
    "",
    ...(issues.length > 0
      ? [
          "ALERTES DE COMPATIBILITÉ :",
          ...issues.map((i) => ` - [${i.ruleCode}] ${i.title} : ${i.explanation}`),
          "",
        ]
      : []),
    pricing.legalDisclaimer,
  ];

  return NextResponse.json(
    {
      text: lines.join("\n"),
      filename: `renault-concept-${parsed.data.modelSlug}-${pricing.tariffVersion}.txt`,
      result,
    },
    { status: 200, headers: { "Cache-Control": "no-store" } }
  );
}
