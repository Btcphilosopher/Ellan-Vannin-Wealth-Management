import { NextRequest, NextResponse } from "next/server";
import { ConfigSelectionSchema } from "@/lib/configurator/rules";
import { validateAndPriceConfiguration } from "@/lib/configurator/engine";
import { checkRateLimit, getClientKey } from "@/lib/security/rateLimit";

export async function POST(req: NextRequest) {
  const clientKey = `configure:${getClientKey(req.headers)}`;
  const rate = checkRateLimit(clientKey, 120, 60_000);
  if (!rate.allowed) {
    return NextResponse.json(
      { error: "Trop de requêtes de configuration. Réessayez dans une minute." },
      { status: 429 }
    );
  }

  let body: unknown;
  try {
    body = await req.json();
  } catch {
    return NextResponse.json(
      { error: "Corps JSON invalide." },
      { status: 400 }
    );
  }

  const parsed = ConfigSelectionSchema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json(
      {
        error: "Paramètres de configuration invalides.",
        details: parsed.error.flatten(),
      },
      { status: 400 }
    );
  }

  try {
    const result = validateAndPriceConfiguration(parsed.data);
    return NextResponse.json(result, {
      status: 200,
      headers: { "Cache-Control": "no-store" },
    });
  } catch (error) {
    return NextResponse.json(
      {
        error:
          error instanceof Error
            ? error.message
            : "Erreur de validation serveur.",
      },
      { status: 400 }
    );
  }
}
