import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import {
  isVerifiedAdminToken,
  verifyBearerToken,
} from "@/lib/firebase/admin";
import {
  checkRateLimit,
  getClientKey,
  redactEmail,
} from "@/lib/security/rateLimit";

const BackupValidateSchema = z.object({
  mode: z.enum(["validate_snapshot"]),
  snapshot: z.object({
    schemaVersion: z.string().min(1).max(32),
    exportedAt: z.string().min(10).max(64),
    collections: z.record(z.string(), z.array(z.record(z.string(), z.unknown()))),
  }),
});

export async function POST(req: NextRequest) {
  const rate = checkRateLimit(`backup:${getClientKey(req.headers)}`, 20, 60_000);
  if (!rate.allowed) {
    return NextResponse.json(
      { error: "Limite de requêtes atteinte." },
      { status: 429 }
    );
  }

  const decoded = await verifyBearerToken(req);
  if (!isVerifiedAdminToken(decoded)) {
    return NextResponse.json(
      { error: "Accès refusé : jeton administrateur vérifié requis." },
      { status: 403 }
    );
  }

  let body: unknown;
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: "Corps JSON invalide." }, { status: 400 });
  }

  const parsed = BackupValidateSchema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json(
      {
        error: "Structure de sauvegarde invalide.",
        details: parsed.error.flatten(),
      },
      { status: 400 }
    );
  }

  const counts = Object.fromEntries(
    Object.entries(parsed.data.snapshot.collections).map(([k, arr]) => [
      k,
      arr.length,
    ])
  );

  console.info(
    `[BackupValidate] actor=${redactEmail(decoded?.email || "admin")} collections=${JSON.stringify(counts)}`
  );

  return NextResponse.json(
    {
      valid: true,
      schemaVersion: parsed.data.snapshot.schemaVersion,
      counts,
      verifiedBy: redactEmail(decoded?.email || "admin"),
      checkedAt: new Date().toISOString(),
    },
    { status: 200, headers: { "Cache-Control": "no-store" } }
  );
}
