import { NextResponse } from "next/server";
import { getTariffByVersion } from "@/lib/pricing/tariffs";

export async function GET() {
  const tariff = getTariffByVersion();
  return NextResponse.json(
    {
      status: "ok",
      mode: "demonstration-concept",
      tariffVersion: tariff.version,
      timestamp: new Date().toISOString(),
    },
    { status: 200, headers: { "Cache-Control": "no-store" } }
  );
}
