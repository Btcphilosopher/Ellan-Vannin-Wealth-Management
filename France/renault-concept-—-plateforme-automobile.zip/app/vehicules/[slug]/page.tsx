import { notFound } from "next/navigation";
import { getModelBySlug, getModelResources, VEHICLE_MODELS } from "@/lib/catalog/data";
import { ModelDetailClient } from "@/components/catalog/ModelDetailClient";

export function generateStaticParams() {
  return VEHICLE_MODELS.map((m) => ({ slug: m.slug }));
}

export default async function ModelDetailPage({
  params,
}: {
  params: Promise<{ slug: string }>;
}) {
  const { slug } = await params;
  const model = getModelBySlug(slug);
  if (!model) {
    notFound();
  }

  const resources = getModelResources(model.slug);

  return (
    <ModelDetailClient
      model={resources.model}
      motorisations={resources.motorisations}
      batteries={resources.batteries}
      trims={resources.trims}
      colors={resources.colors}
      stock={resources.stock}
    />
  );
}
