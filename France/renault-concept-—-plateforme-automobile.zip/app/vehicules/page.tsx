import { CatalogExplorer } from "@/components/catalog/CatalogExplorer";

export default async function VehiculesPage({
  searchParams,
}: {
  searchParams: Promise<{ energie?: string }>;
}) {
  const params = await searchParams;
  const initialEnergy =
    params.energie === "electrique" || params.energie === "hybride"
      ? params.energie
      : "all";

  return <CatalogExplorer initialEnergy={initialEnergy} />;
}
