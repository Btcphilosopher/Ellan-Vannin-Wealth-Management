import Link from "next/link";
import { ArrowRight, Building2, Zap } from "lucide-react";
import { VEHICLE_MODELS } from "@/lib/catalog/data";
import { formatCentsEUR } from "@/lib/pricing/tariffs";

export default function ProfessionnelsPage() {
  return (
    <div className="max-w-[1440px] mx-auto px-4 sm:px-8 py-12 space-y-10">
      <div className="border-b border-[#E2E2DE] pb-8 max-w-3xl space-y-3">
        <p className="text-xs font-bold tracking-[0.14em] text-[#595959]">
          MOBILITÉ ENTREPRISES · DÉMONSTRATION
        </p>
        <h1 className="font-display text-4xl sm:text-5xl font-extrabold tracking-tight text-[#0D0D0D]">
          Solutions flotte &amp; professionnels
        </h1>
        <p className="text-base text-[#595959]">
          Découvrez les modèles éligibles aux flottes d&apos;entreprises et
          centres Pro+ de démonstration, sans aucune donnée fiscale ou aide
          publique pré-appliquée sans vérification.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {VEHICLE_MODELS.map((m) => (
          <article
            key={m.slug}
            className="bg-white border border-[#E2E2DE] p-6 flex flex-col justify-between space-y-6"
          >
            <div className="space-y-2">
              <div className="flex items-center justify-between text-xs text-[#595959]">
                <span>{m.segment}</span>
                <Building2 className="w-4 h-4" aria-hidden="true" />
              </div>
              <h2 className="font-display text-2xl font-bold">{m.name}</h2>
              <p className="text-sm text-[#595959]">{m.description}</p>
              <p className="font-mono-tabular text-base font-bold pt-2">
                À partir de {formatCentsEUR(m.basePriceCents)} (démo TTC)
              </p>
            </div>
            <div className="flex flex-wrap gap-2 pt-4 border-t border-[#E2E2DE]">
              <Link
                href={`/configurateur?modele=${m.slug}`}
                className="inline-flex items-center gap-1.5 bg-[#0D0D0D] text-white text-xs font-semibold px-4 py-2.5"
              >
                <span>Configurer</span>
                <ArrowRight className="w-3.5 h-3.5" aria-hidden="true" />
              </Link>
              <Link
                href="/concessionnaires"
                className="inline-flex items-center gap-1.5 border border-[#0D0D0D] text-xs font-semibold px-4 py-2.5"
              >
                <span>Centres Pro+</span>
              </Link>
            </div>
          </article>
        ))}
      </div>

      <div className="bg-white border border-[#E2E2DE] p-6 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="flex items-start gap-3">
          <Zap className="w-5 h-5 mt-0.5 shrink-0" aria-hidden="true" />
          <div>
            <p className="font-display text-lg font-bold">
              Besoin d&apos;un essai multi-conducteurs en concession ?
            </p>
            <p className="text-sm text-[#595959]">
              Réservez un créneau dédié dans l&apos;un de nos centres de
              démonstration en France.
            </p>
          </div>
        </div>
        <Link
          href="/essais"
          className="bg-[#0D0D0D] text-white text-xs font-semibold px-5 py-3 whitespace-nowrap shrink-0"
        >
          Planifier un essai
        </Link>
      </div>
    </div>
  );
}
