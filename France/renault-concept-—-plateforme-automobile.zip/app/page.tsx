import Link from "next/link";
import {
  ArrowRight,
  CircleDot,
  MapPin,
  SlidersHorizontal,
  Zap,
} from "lucide-react";
import { VEHICLE_MODELS } from "@/lib/catalog/data";
import { VehicleImage } from "@/components/common/VehicleImage";

const ACTION_BAR_ITEMS = [
  {
    href: "/configurateur",
    label: "Configurer",
    icon: SlidersHorizontal,
  },
  {
    href: "/essais",
    label: "Réserver un essai",
    icon: CircleDot,
  },
  {
    href: "/stock",
    label: "Trouver un véhicule",
    icon: MapPin,
  },
  {
    href: "/vehicules?energie=electrique",
    label: "Découvrir l’électrique",
    icon: Zap,
  },
];

export default function HomePage() {
  return (
    <div className="bg-[#FAF9F6]">
      {/* Bannière principale fidèle à la maquette */}
      <section className="relative overflow-hidden border-b border-[#E2E2DE] bg-[#EAEAE6]">
        <div className="relative max-w-[1440px] mx-auto min-h-[520px] lg:min-h-[600px] flex items-center">
          {/* Image de fond architecturale avec voiture jaune */}
          <div className="absolute inset-0">
            <VehicleImage
              src="/images/hero_renault5_jaune_1795864183947.jpg"
              alt="Citadine électrique jaune devant une architecture contemporaine de béton clair et de verre"
              fill
              priority
              sizes="100vw"
              className="object-cover object-center lg:object-[72%_center]"
            />
            <div
              className="absolute inset-0 bg-gradient-to-r from-[#FAF9F6]/95 via-[#FAF9F6]/75 to-transparent lg:via-[#FAF9F6]/55"
              aria-hidden="true"
            />
          </div>

          {/* Halo géométrique jaune électrique discret (fidèle au coin supérieur gauche de la maquette) */}
          <div
            className="pointer-events-none absolute -top-10 -left-10 w-44 h-44 rounded-full border border-[#F7E300]/90"
            aria-hidden="true"
          />

          {/* Bloc typographique principal */}
          <div className="relative z-10 px-4 sm:px-8 lg:px-14 py-16 max-w-2xl space-y-5">
            <p className="text-xs sm:text-sm font-bold tracking-[0.14em] text-[#0D0D0D]">
              RENAULT 5 E-TECH ÉLECTRIQUE
            </p>
            <h1 className="font-display text-5xl sm:text-6xl lg:text-[68px] font-extrabold leading-[0.98] tracking-[-0.03em] text-[#0D0D0D] text-balance">
              L’audace,
              <br />
              électrique.
            </h1>
            <p className="text-base sm:text-lg text-[#1A1A1A] font-medium max-w-md leading-relaxed">
              Une nouvelle énergie. Un esprit résolument français.
            </p>

            <div className="pt-2 flex flex-wrap items-center gap-3">
              <Link
                href="/vehicules/renault-5-e-tech"
                className="inline-flex items-center justify-center bg-[#0D0D0D] text-white text-sm font-semibold px-7 py-3.5 hover:bg-[#262626] transition-colors whitespace-nowrap shrink-0"
              >
                Découvrir Renault 5
              </Link>
              <Link
                href="/configurateur?modele=renault-5-e-tech"
                className="inline-flex items-center justify-center bg-white/95 text-[#0D0D0D] border border-[#0D0D0D] text-sm font-semibold px-7 py-3.5 hover:bg-[#0D0D0D] hover:text-white transition-colors whitespace-nowrap shrink-0"
              >
                Configurer la mienne
              </Link>
            </div>

            <p className="pt-2 text-[11px] text-[#595959]">
              Visuel et données de démonstration · Concept indépendant sans affiliation Renault
            </p>
          </div>
        </div>
      </section>

      {/* Barre d'actions horizontale à filets fins */}
      <section
        aria-label="Accès rapides"
        className="bg-white border-b border-[#E2E2DE]"
      >
        <div className="max-w-[1440px] mx-auto px-4 sm:px-8">
          <div className="grid grid-cols-2 lg:grid-cols-4 divide-y sm:divide-y-0 sm:divide-x divide-[#E2E2DE]">
            {ACTION_BAR_ITEMS.map((item) => {
              const Icon = item.icon;
              return (
                <Link
                  key={item.href}
                  href={item.href}
                  className="group flex items-center justify-center gap-3 py-5 px-4 text-sm font-semibold text-[#0D0D0D] hover:bg-[#FAF9F6] transition-colors whitespace-nowrap"
                >
                  <Icon
                    className="w-5 h-5 stroke-[1.6] text-[#0D0D0D] group-hover:translate-x-0.5 transition-transform shrink-0"
                    aria-hidden="true"
                  />
                  <span>{item.label}</span>
                </Link>
              );
            })}
          </div>
        </div>
      </section>

      {/* Présentation de gamme : À chacun son élan. */}
      <section className="max-w-[1440px] mx-auto px-4 sm:px-8 py-12 sm:py-16">
        <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 mb-8">
          <h2 className="font-display text-3xl sm:text-4xl font-extrabold tracking-tight text-[#0D0D0D] text-balance">
            À chacun son élan.
          </h2>
          <Link
            href="/vehicules"
            className="inline-flex items-center gap-2 text-sm font-semibold text-[#0D0D0D] hover:opacity-70 transition-opacity whitespace-nowrap shrink-0"
          >
            <span>Explorer la gamme</span>
            <ArrowRight className="w-4 h-4" aria-hidden="true" />
          </Link>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {VEHICLE_MODELS.map((model) => (
            <article
              key={model.slug}
              className="group bg-white border border-[#E2E2DE] flex flex-col transition-transform duration-200 hover:-translate-y-0.5"
            >
              <Link
                href={`/vehicules/${model.slug}`}
                className="relative aspect-[4/3] w-full overflow-hidden bg-[#ECECE9]"
              >
                <VehicleImage
                  src={model.cardImage}
                  alt={`${model.name} devant une architecture contemporaine`}
                  fill
                  sizes="(max-width: 768px) 100vw, 33vw"
                  className="object-cover transition-transform duration-500 group-hover:scale-[1.02]"
                />
              </Link>

              <div className="p-5 flex items-center justify-between gap-4 bg-white border-t border-[#E2E2DE]">
                <div className="min-w-0">
                  <h3 className="font-display text-xl font-bold text-[#0D0D0D] truncate">
                    {model.shortName}
                  </h3>
                  <p className="text-sm text-[#595959] truncate">
                    {model.tagline}
                  </p>
                </div>

                <Link
                  href={`/vehicules/${model.slug}`}
                  className="inline-flex items-center gap-1.5 pl-4 border-l border-[#E2E2DE] text-sm font-semibold text-[#0D0D0D] hover:opacity-70 transition-opacity whitespace-nowrap shrink-0 py-1"
                  aria-label={`Découvrir ${model.shortName}`}
                >
                  <span>Découvrir</span>
                  <ArrowRight className="w-4 h-4" aria-hidden="true" />
                </Link>
              </div>
            </article>
          ))}
        </div>
      </section>
    </div>
  );
}
