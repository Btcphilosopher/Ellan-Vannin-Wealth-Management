import { DealersClient } from "@/components/dealers/DealersClient";

export default function ConcessionnairesPage() {
  return <DealersClient />;
}
