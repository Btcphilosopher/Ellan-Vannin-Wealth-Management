import { ConfiguratorWorkbench } from "@/components/configurator/ConfiguratorWorkbench";
import { ConfigSelectionInput } from "@/lib/configurator/rules";

export default async function ConfigurateurPage({
  searchParams,
}: {
  searchParams: Promise<{
    modele?: string;
    finition?: string;
    configId?: string;
  }>;
}) {
  const params = await searchParams;
  const validSlugs: ConfigSelectionInput["modelSlug"][] = [
    "renault-5-e-tech",
    "scenic-e-tech",
    "rafale-e-tech",
  ];
  const initialModelSlug = validSlugs.includes(
    params.modele as ConfigSelectionInput["modelSlug"]
  )
    ? (params.modele as ConfigSelectionInput["modelSlug"])
    : "renault-5-e-tech";

  return (
    <ConfiguratorWorkbench
      initialModelSlug={initialModelSlug}
      initialTrimId={params.finition}
      initialConfigId={params.configId}
    />
  );
}
