import type { Metadata } from "next";
import { Outfit, Plus_Jakarta_Sans, JetBrains_Mono } from "next/font/google";
import "./globals.css";
import { AuthProvider } from "@/components/providers/AuthProvider";
import { CompareProvider } from "@/components/providers/CompareProvider";
import { SiteHeader } from "@/components/layout/SiteHeader";
import { SiteFooter } from "@/components/layout/SiteFooter";

const outfit = Outfit({
  subsets: ["latin"],
  weight: ["500", "600", "700", "800"],
  variable: "--font-display",
  display: "swap",
});

const plusJakarta = Plus_Jakarta_Sans({
  subsets: ["latin"],
  weight: ["400", "500", "600", "700"],
  variable: "--font-sans",
  display: "swap",
});

const jetbrainsMono = JetBrains_Mono({
  subsets: ["latin"],
  weight: ["400", "500", "600"],
  variable: "--font-mono",
  display: "swap",
});

export const metadata: Metadata = {
  title: "Renault Concept — Plateforme Automobile Française",
  description:
    "Concept indépendant de site automobile Renault en français : catalogue E-Tech, configurateur avec validation serveur, comparateur, recherche de concessionnaires, réservation d'essais et administration.",
  openGraph: {
    title: "Renault Concept — Plateforme Automobile Française",
    description:
      "Découvrez Renault 5 E-Tech électrique, Scénic E-Tech électrique et Rafale. Données de démonstration, configurateur interactif et prise de rendez-vous.",
    type: "website",
    locale: "fr_FR",
  },
  twitter: {
    card: "summary_large_image",
    title: "Renault Concept — Plateforme Automobile Française",
    description:
      "Concept indépendant : catalogue E-Tech, configurateur, comparateur et réservation d'essais.",
  },
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html
      lang="fr"
      className={`${outfit.variable} ${plusJakarta.variable} ${jetbrainsMono.variable}`}
    >
      <body
        suppressHydrationWarning
        className="min-h-screen flex flex-col bg-[#FAF9F6] text-[#0D0D0D] selection:bg-[#F7E300] selection:text-[#0D0D0D]"
      >
        <AuthProvider>
          <CompareProvider>
            <SiteHeader />
            <main className="flex-1">{children}</main>
            <SiteFooter />
          </CompareProvider>
        </AuthProvider>
      </body>
    </html>
  );
}
