import { StockClient } from "@/components/stock/StockClient";

export default async function StockPage({
  searchParams,
}: {
  searchParams: Promise<{ modele?: string }>;
}) {
  const params = await searchParams;
  return <StockClient initialModel={params.modele || "all"} />;
}
