import Link from "next/link";
import { ArrowRight, BatteryCharging, CalendarCheck, Shield, Wrench } from "lucide-react";

const SERVICES = [
  {
    icon: BatteryCharging,
    title: "Recharge & planification de trajets",
    summary:
      "Comparaison des puissances AC/DC par batterie et repérage des bornes rapides 150 kW disponibles en concession de démonstration.",
    href: "/concessionnaires",
    cta: "Localiser une borne",
  },
  {
    icon: CalendarCheck,
    title: "Essais accompagnés en concession",
    summary:
      "Prise de rendez-vous horodatée avec verrouillage de créneau en temps réel et confirmation par un conseiller.",
    href: "/essais",
    cta: "Réserver un essai",
  },
  {
    icon: Wrench,
    title: "Ateliers certifiés E-Tech",
    summary:
      "Entretien des chaînes de traction électriques et hybrides dans les ateliers habilités du réseau de démonstration.",
    href: "/concessionnaires",
    cta: "Trouver un atelier",
  },
  {
    icon: Shield,
    title: "Devis versionnés & suivi client",
    summary:
      "Chaque configuration sauvegardée conserve la version tarifaire et la date d'effet exacte de votre simulation.",
    href: "/compte",
    cta: "Accéder à Mon compte",
  },
];

export default function ServicesPage() {
  return (
    <div className="max-w-[1440px] mx-auto px-4 sm:px-8 py-12 space-y-10">
      <div className="border-b border-[#E2E2DE] pb-8 max-w-3xl space-y-3">
        <p className="text-xs font-bold tracking-[0.14em] text-[#595959]">
          SERVICES CONNECTÉS &amp; RÉSEAU · DÉMONSTRATION
        </p>
        <h1 className="font-display text-4xl sm:text-5xl font-extrabold tracking-tight text-[#0D0D0D]">
          Accompagnement électrique &amp; après-vente
        </h1>
        <p className="text-base text-[#595959]">
          Présentation conceptuelle des services associés à la gamme E-Tech.
          Aucune garantie commerciale officielle n&apos;est avancée sans document
          contractuel.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {SERVICES.map((srv) => {
          const Icon = srv.icon;
          return (
            <article
              key={srv.title}
              className="bg-white border border-[#E2E2DE] p-6 flex flex-col justify-between space-y-5"
            >
              <div className="space-y-3">
                <Icon className="w-6 h-6 stroke-[1.6]" aria-hidden="true" />
                <h2 className="font-display text-2xl font-bold">{srv.title}</h2>
                <p className="text-sm text-[#595959] leading-relaxed">
                  {srv.summary}
                </p>
              </div>
              <Link
                href={srv.href}
                className="inline-flex items-center gap-2 text-xs font-semibold text-[#0D0D0D] hover:opacity-75"
              >
                <span>{srv.cta}</span>
                <ArrowRight className="w-3.5 h-3.5" aria-hidden="true" />
              </Link>
            </article>
          );
        })}
      </div>
    </div>
  );
}
