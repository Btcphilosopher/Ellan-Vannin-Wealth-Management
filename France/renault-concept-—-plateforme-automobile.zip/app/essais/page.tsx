import { TestDriveBookingClient } from "@/components/dealers/TestDriveBookingClient";
import { DEMO_DEALERS } from "@/lib/dealers/data";

export default async function EssaisPage({
  searchParams,
}: {
  searchParams: Promise<{
    modele?: string;
    concessionnaire?: string;
    creneau?: string;
  }>;
}) {
  const params = await searchParams;
  return (
    <TestDriveBookingClient
      initialModelSlug={params.modele || "renault-5-e-tech"}
      initialDealerId={params.concessionnaire || DEMO_DEALERS[0].id}
      initialSlotId={params.creneau}
    />
  );
}
