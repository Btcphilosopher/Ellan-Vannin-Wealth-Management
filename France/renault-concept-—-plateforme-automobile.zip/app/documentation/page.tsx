import Link from "next/link";

const API_ENDPOINTS = [
  {
    method: "POST",
    path: "/api/configure/validate",
    auth: "Public (limité en débit)",
    description:
      "Valide la configuration via Zod, vérifie les règles de compatibilité sans modification silencieuse et calcule le prix exact en centimes entiers selon le tarif versionné.",
  },
  {
    method: "POST",
    path: "/api/stock/verify",
    auth: "Public (limité en débit)",
    description:
      "Revérifie la disponibilité d'un véhicule physique avant l'ouverture d'une demande commerciale de réservation.",
  },
  {
    method: "POST",
    path: "/api/export/summary",
    auth: "Public (limité en débit)",
    description:
      "Génère un récapitulatif textuel horodaté avec ventilation tarifaire et mentions légales de démonstration.",
  },
  {
    method: "POST",
    path: "/api/backup",
    auth: "Administrateur (Bearer Firebase ID Token vérifié)",
    description:
      "Valide la structure d'une sauvegarde JSON expurgée avant restauration et journalise l'opération sans exposer de PII.",
  },
  {
    method: "GET",
    path: "/api/health",
    auth: "Public",
    description:
      "Retourne l'état de l'application de démonstration et la version tarifaire active.",
  },
];

const FEATURE_MATRIX = [
  {
    feature: "Accueil fidèle à la maquette & navigation responsive",
    status: "Opérationnel",
  },
  {
    feature: "Catalogue séparé (modèles, motorisations, batteries, finitions, couleurs, jantes, sellerie, packs, stock)",
    status: "Opérationnel (données de démonstration)",
  },
  {
    feature: "Configurateur 8 étapes + validation serveur + rejet expliqué des incompatibilités",
    status: "Opérationnel",
  },
  {
    feature: "Calcul tarifaire en centimes entiers + tarifs versionnés",
    status: "Opérationnel",
  },
  {
    feature: "Sauvegarde, reprise, partage et export de configuration",
    status: "Opérationnel (Firestore + Export .txt/Print)",
  },
  {
    feature: "Comparateur (jusqu'à 3 véhicules ou configurations) avec normes & « Non communiqué »",
    status: "Opérationnel",
  },
  {
    feature: "Concessionnaires (carte SVG, recherche CP/ville, géolocalisation) & réservation atomique d'essai",
    status: "Opérationnel (transactions Firestore)",
  },
  {
    feature: "Espace client & Back-office Administration (confirmation essais, stocks, tarifs, règles, audit, sauvegarde)",
    status: "Opérationnel (RBAC Firebase + Rules)",
  },
  {
    feature: "Docker Compose + schéma PostgreSQL/Prisma pour développement local",
    status: "Livré en référence locale (environnement hébergé sur Firestore & Firebase Auth)",
  },
  {
    feature: "Moteur 3D WebGL temps réel & connexion directe aux SI officiels Renault",
    status: "Non inclus volontairement (visuels pré-rendus par calques & concept indépendant)",
  },
];

export default function DocumentationPage() {
  return (
    <div className="max-w-[1160px] mx-auto px-4 sm:px-8 py-12 space-y-10">
      <div className="border-b border-[#E2E2DE] pb-6 space-y-2">
        <p className="text-xs font-bold tracking-[0.14em] text-[#595959]">
          DOCUMENTATION TECHNIQUE, API &amp; TRANSPARENCE
        </p>
        <h1 className="font-display text-3xl sm:text-4xl font-extrabold">
          Architecture, API &amp; état de vérification
        </h1>
        <p className="text-sm text-[#595959]">
          Projet concept indépendant. Ce document récapitule les routes API, le
          modèle de sécurité et la distinction entre fonctionnalités
          opérationnelles, simulées et de référence locale.
        </p>
      </div>

      <section className="bg-white border border-[#E2E2DE] p-6 space-y-4">
        <h2 className="font-display text-2xl font-bold">Endpoints API Next.js</h2>
        <div className="divide-y divide-[#E2E2DE] text-sm">
          {API_ENDPOINTS.map((ep) => (
            <div key={ep.path} className="py-4 space-y-1">
              <p className="font-mono-tabular font-bold">
                {ep.method} {ep.path}{" "}
                <span className="font-sans text-xs font-normal text-[#595959]">
                  — {ep.auth}
                </span>
              </p>
              <p className="text-xs text-[#262626]">{ep.description}</p>
            </div>
          ))}
        </div>
      </section>

      <section className="bg-white border border-[#E2E2DE] p-6 space-y-4">
        <h2 className="font-display text-2xl font-bold">
          Statut des fonctionnalités livrées
        </h2>
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse text-sm">
            <thead>
              <tr className="border-b border-[#E2E2DE] text-xs text-[#595959]">
                <th className="py-2 pr-4">Capacité</th>
                <th className="py-2">Statut réel</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#E2E2DE]">
              {FEATURE_MATRIX.map((row) => (
                <tr key={row.feature}>
                  <td className="py-3 pr-4 font-medium">{row.feature}</td>
                  <td className="py-3 text-xs text-[#595959]">{row.status}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>

      <div className="flex flex-wrap gap-3">
        <Link
          href="/configurateur"
          className="bg-[#0D0D0D] text-white text-xs font-semibold px-5 py-3"
        >
          Tester le configurateur
        </Link>
        <Link
          href="/essais"
          className="border border-[#0D0D0D] bg-white text-xs font-semibold px-5 py-3"
        >
          Tester la réservation d&apos;essai
        </Link>
      </div>
    </div>
  );
}
