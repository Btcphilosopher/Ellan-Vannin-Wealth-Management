import { AccountClient } from "@/components/account/AccountClient";

export default function ComptePage() {
  return <AccountClient />;
}
