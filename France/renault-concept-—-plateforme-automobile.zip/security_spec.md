# Spécification de Sécurité Firestore (Phase 0 — Payload-First TDD)

## 1. Invariants de Données
1. **Isolation PII (`users`)** : Un utilisateur authentifié et vérifié ne peut lire et modifier que son propre document `/users/{userId}` (`request.auth.uid == userId`), sauf l'administrateur (`isAdmin()`). Aucun listing global de `/users` n'est autorisé aux clients.
2. **Intégrité des Configurations (`savedConfigurations`)** : Le champ `ownerUid` doit strictement égaler `request.auth.uid` à la création et reste immuable. Les mises à jour client ne peuvent ni changer `ownerUid`, ni `createdAt`, ni falsifier le `tariffVersion`. Seules les configurations marquées `isPublicShare == true` sont lisibles par un tiers via leur identifiant exact (`get`).
3. **Prévention des Doubles Réservations (`dealerSlots` + `testDriveRequests`)** : Un créneau `/dealerSlots/{slotId}` ne peut passer de `status == 'available'` à `status == 'booked'` par un client que si `bookedByUid == request.auth.uid`, et uniquement s'il n'est pas déjà `booked` ou `closed`. Une fois `confirmed` ou `declined` par l'administration, une demande d'essai ne peut plus être modifiée par le client (seule l'annulation depuis `received` vers `cancelled` est autorisée au propriétaire).
4. **Contrôle d'Accès Administrateur (`isAdmin()`)** : L'email vérifié `tom@ahyx.org` (`request.auth.token.email_verified == true && request.auth.token.email == 'tom@ahyx.org'`) ou la présence dans `/admins/{request.auth.uid}` confère le rôle administrateur. Aucun utilisateur ne peut s'auto-promouvoir dans `/admins`.
5. **Journal d'Audit Immuable (`auditLogs`)** : Seul l'administrateur peut lire et créer des entrées dans `/auditLogs` ; toute modification ou suppression est strictement interdite.

## 2. Les "Dirty Dozen" Payloads (12 vecteurs d'attaque bloqués)
1. **ID Poisoning** : Création sur `/savedConfigurations/${'a'.repeat(500)}` ou avec caractères spéciaux `../admin` → Rejeté par `isValidId()`.
2. **Identity Spoofing (Configuration)** : Création dans `/savedConfigurations` avec `ownerUid: "autre-uid"` → Rejeté par `incoming().ownerUid == request.auth.uid`.
3. **Ghost / Shadow Field** : Création dans `/users/{uid}` avec `{ ..., role: "admin", isAdmin: true }` → Rejeté par `keys().hasOnly(...)`.
4. **Email Spoofing** : Requête avec `email: "tom@ahyx.org"` mais `email_verified: false` → Rejeté par `request.auth.token.email_verified == true`.
5. **PII Blanket List** : `list` sur `/users` ou `/testDriveRequests` sans filtre `ownerUid == request.auth.uid` → Rejeté par `allow list`.
6. **Timestamp Forgery** : Création d'une configuration avec `createdAt` antidaté au lieu de `request.time` → Rejeté par `incoming().createdAt == request.time`.
7. **Terminal State Bypass** : Client tentant de passer son propre `/testDriveRequests/{id}` de `received` à `confirmed` → Rejeté (seul `isAdmin()` peut passer à `confirmed` ou `declined`).
8. **Double Booking Race** : Client tentant de réserver `/dealerSlots/{slotId}` alors que `existing().status == 'booked'` → Rejeté par la transition `existing().status == 'available' && incoming().status == 'booked'`.
9. **Slot Hijack** : Client tentant de modifier un `/dealerSlots/{slotId}` vers `status: 'closed'` → Rejeté par `affectedKeys().hasOnly(['status', 'bookedByUid', 'updatedAt'])` + état cible autorisé `booked` uniquement.
10. **Audit Log Tampering** : Utilisateur non-admin écrivant dans `/auditLogs`, ou admin tentant de supprimer/modifier un log → Rejeté (`allow update, delete: if false`).
11. **Denial-of-Wallet Oversized Array** : Ajout de 100 éléments dans `favoriteModelSlugs` → Rejeté par `.size() <= 12`.
12. **Catalog / Stock Manipulation** : Client non-admin modifiant `/stockVehicles/{id}` ou `/tariffVersions/{id}` → Rejeté par `isAdmin()`.
