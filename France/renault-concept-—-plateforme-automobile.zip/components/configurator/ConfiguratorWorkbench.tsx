"use client";

import { useCallback, useEffect, useMemo, useState } from "react";
import Link from "next/link";
import {
  AlertTriangle,
  ArrowRight,
  BookmarkCheck,
  Check,
  Download,
  Info,
  Printer,
  RotateCcw,
  Scale,
  Share2,
} from "lucide-react";
import {
  BATTERIES,
  COLORS,
  INTERIORS,
  MOTORISATIONS,
  PACK_OPTIONS,
  TRIMS,
  VEHICLE_MODELS,
  WHEELS,
} from "@/lib/catalog/data";
import {
  ConfigurationValidationResult,
  getDefaultSelectionForModel,
  validateAndPriceConfiguration,
} from "@/lib/configurator/engine";
import { ConfigSelectionInput } from "@/lib/configurator/rules";
import { DEMO_DEALERS } from "@/lib/dealers/data";
import { formatCentsEUR } from "@/lib/pricing/tariffs";
import { VehicleImage } from "@/components/common/VehicleImage";
import { useAuth } from "@/components/providers/AuthProvider";
import { useCompare } from "@/components/providers/CompareProvider";
import {
  createCommercialRequest,
  fetchSavedConfigurationById,
  saveConfigurationToFirestore,
} from "@/lib/firebase/services";

type ConfigStep =
  | "modele"
  | "motorisation"
  | "finition"
  | "couleur"
  | "jantes"
  | "interieur"
  | "options"
  | "recapitulatif";

const STEPS: { id: ConfigStep; label: string; index: string }[] = [
  { id: "modele", label: "Modèle", index: "01" },
  { id: "motorisation", label: "Motorisation", index: "02" },
  { id: "finition", label: "Finition", index: "03" },
  { id: "couleur", label: "Couleur", index: "04" },
  { id: "jantes", label: "Jantes", index: "05" },
  { id: "interieur", label: "Intérieur", index: "06" },
  { id: "options", label: "Options", index: "07" },
  { id: "recapitulatif", label: "Récapitulatif", index: "08" },
];

interface ConfiguratorWorkbenchProps {
  initialModelSlug?: ConfigSelectionInput["modelSlug"];
  initialTrimId?: string;
  initialConfigId?: string;
}

export function ConfiguratorWorkbench({
  initialModelSlug = "renault-5-e-tech",
  initialTrimId,
  initialConfigId,
}: ConfiguratorWorkbenchProps) {
  const { user, signInWithGoogle } = useAuth();
  const { addItem } = useCompare();

  const [step, setStep] = useState<ConfigStep>("modele");
  const [selection, setSelection] = useState<ConfigSelectionInput>(() => {
    const base = getDefaultSelectionForModel(initialModelSlug);
    if (initialTrimId && TRIMS.some((t) => t.id === initialTrimId && t.modelSlug === initialModelSlug)) {
      base.trimId = initialTrimId;
    }
    return base;
  });

  const [validation, setValidation] = useState<ConfigurationValidationResult>(() =>
    validateAndPriceConfiguration(selection)
  );
  const [validating, setValidating] = useState(false);
  const [serverError, setServerError] = useState<string | null>(null);

  const [visualMode, setVisualMode] = useState<"exterior" | "interior">("exterior");
  const [configTitle, setConfigTitle] = useState("Ma configuration personnalisée");
  const [isPublicShare, setIsPublicShare] = useState(true);
  const [saving, setSaving] = useState(false);
  const [savedId, setSavedId] = useState<string | null>(null);
  const [actionFeedback, setActionFeedback] = useState<string | null>(null);
  const [resumedBanner, setResumedBanner] = useState<string | null>(null);

  // Demande commerciale rapide depuis le récapitulatif
  const [quoteDealerId, setQuoteDealerId] = useState(DEMO_DEALERS[0].id);
  const [quoteNameInput, setQuoteNameInput] = useState<string | null>(null);
  const [quoteEmailInput, setQuoteEmailInput] = useState<string | null>(null);
  const quoteName = quoteNameInput ?? user?.displayName ?? "";
  const quoteEmail = quoteEmailInput ?? user?.email ?? "";
  const [quotePhone, setQuotePhone] = useState("");
  const [quoteMessage, setQuoteMessage] = useState("");
  const [sendingQuote, setSendingQuote] = useState(false);
  const [quoteSentId, setQuoteSentId] = useState<string | null>(null);

  // Reprise d'une configuration sauvegardée ou partagée (?configId=...)
  useEffect(() => {
    if (!initialConfigId) return;
    let active = true;
    (async () => {
      try {
        const docData = await fetchSavedConfigurationById(initialConfigId);
        if (!active || !docData) return;
        const loadedSelection: ConfigSelectionInput = {
          modelSlug: docData.modelSlug,
          motorisationId: docData.motorisationId,
          trimId: docData.trimId,
          colorId: docData.colorId,
          wheelId: docData.wheelId,
          interiorId: docData.interiorId,
          optionIds: docData.optionIds || [],
          tariffVersion: docData.tariffVersion,
        };
        setSelection(loadedSelection);
        setConfigTitle(docData.title);
        setSavedId(docData.id);
        setStep("recapitulatif");
        setResumedBanner(
          `Configuration reprise : "${docData.title}" (tarif figé ${docData.tariffVersion} · total enregistré ${formatCentsEUR(
            docData.totalKnownCents,
            true
          )}).`
        );
      } catch {
        setServerError(
          "Impossible de charger cette configuration (privée ou introuvable)."
        );
      }
    })();
    return () => {
      active = false;
    };
  }, [initialConfigId]);

  const validateOnServer = useCallback(async (nextSelection: ConfigSelectionInput) => {
    setValidating(true);
    setServerError(null);
    try {
      const res = await fetch("/api/configure/validate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(nextSelection),
      });
      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || "Erreur de validation serveur.");
      }
      setValidation(data as ConfigurationValidationResult);
    } catch (err) {
      setServerError(
        err instanceof Error ? err.message : "Erreur de communication serveur."
      );
      // Repli déterministe si hors ligne transitoire
      setValidation(validateAndPriceConfiguration(nextSelection));
    } finally {
      setValidating(false);
    }
  }, []);

  const updateSelection = useCallback(
    (patch: Partial<ConfigSelectionInput>) => {
      const next: ConfigSelectionInput = { ...selection, ...patch };
      setSelection(next);
      setSavedId(null);
      void validateOnServer(next);
    },
    [selection, validateOnServer]
  );

  const handleModelChange = (slug: ConfigSelectionInput["modelSlug"]) => {
    const fresh = getDefaultSelectionForModel(slug);
    setSelection(fresh);
    setSavedId(null);
    void validateOnServer(fresh);
  };

  const toggleOption = (optId: string) => {
    const exists = selection.optionIds.includes(optId);
    const nextOptionIds = exists
      ? selection.optionIds.filter((id) => id !== optId)
      : [...selection.optionIds, optId];
    updateSelection({ optionIds: nextOptionIds });
  };

  const model = useMemo(
    () => VEHICLE_MODELS.find((m) => m.slug === selection.modelSlug)!,
    [selection.modelSlug]
  );
  const modelMotos = useMemo(
    () => MOTORISATIONS.filter((m) => m.modelSlug === selection.modelSlug),
    [selection.modelSlug]
  );
  const modelTrims = useMemo(
    () => TRIMS.filter((t) => t.modelSlug === selection.modelSlug),
    [selection.modelSlug]
  );
  const modelColors = useMemo(
    () => COLORS.filter((c) => c.modelSlug === selection.modelSlug),
    [selection.modelSlug]
  );
  const modelWheels = useMemo(
    () => WHEELS.filter((w) => w.modelSlug === selection.modelSlug),
    [selection.modelSlug]
  );
  const modelInteriors = useMemo(
    () => INTERIORS.filter((i) => i.modelSlug === selection.modelSlug),
    [selection.modelSlug]
  );
  const modelOptions = useMemo(
    () => PACK_OPTIONS.filter((o) => o.modelSlug === selection.modelSlug),
    [selection.modelSlug]
  );

  const selectedMoto = modelMotos.find((m) => m.id === selection.motorisationId)!;
  const selectedBattery = BATTERIES.find((b) => b.id === selectedMoto.batteryId)!;
  const selectedColor = modelColors.find((c) => c.id === selection.colorId)!;
  const selectedInterior = modelInteriors.find((i) => i.id === selection.interiorId)!;

  const handleSave = async () => {
    if (!validation.valid) {
      setActionFeedback(
        "Résolvez les incompatibilités avant de sauvegarder votre configuration."
      );
      return;
    }
    const activeUser = user || (await signInWithGoogle());
    if (!activeUser) return;

    setSaving(true);
    setActionFeedback(null);
    try {
      const saved = await saveConfigurationToFirestore({
        ownerUid: activeUser.uid,
        title: configTitle.trim() || `${model.shortName} sur mesure`,
        isPublicShare,
        validation,
        batteryId: selectedBattery.id,
      });
      setSavedId(saved.id);
      setActionFeedback(
        `Configuration sauvegardée dans votre espace client (ID ${saved.id}).`
      );
    } catch (err) {
      setActionFeedback(
        err instanceof Error ? err.message : "Erreur lors de la sauvegarde."
      );
    } finally {
      setSaving(false);
    }
  };

  const handleShare = async () => {
    if (!savedId) {
      setActionFeedback(
        "Sauvegardez d'abord votre configuration avec le partage activé pour obtenir un lien partageable."
      );
      return;
    }
    const url = `${window.location.origin}/configurateur?configId=${savedId}`;
    try {
      await navigator.clipboard.writeText(url);
      setActionFeedback("Lien de partage copié dans le presse-papiers.");
    } catch {
      setActionFeedback(`Lien prêt à copier : ${url}`);
    }
  };

  const handleExportTxt = async () => {
    try {
      const res = await fetch("/api/export/summary", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(selection),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Erreur d'export");
      const blob = new Blob([data.text], { type: "text/plain;charset=utf-8" });
      const blobUrl = URL.createObjectURL(blob);
      const link = document.createElement("a");
      link.href = blobUrl;
      link.download = data.filename || "configuration-renault-concept.txt";
      link.click();
      URL.revokeObjectURL(blobUrl);
      setActionFeedback("Récapitulatif téléchargé au format texte.");
    } catch (err) {
      setActionFeedback(
        err instanceof Error ? err.message : "Impossible d'exporter le récapitulatif."
      );
    }
  };

  const handleSendQuoteRequest = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!validation.valid) return;
    const activeUser = user || (await signInWithGoogle());
    if (!activeUser) return;

    setSendingQuote(true);
    setActionFeedback(null);
    try {
      const created = await createCommercialRequest({
        ownerUid: activeUser.uid,
        requestType: "quote",
        modelSlug: selection.modelSlug,
        dealerId: quoteDealerId,
        configId: savedId || undefined,
        estimatedTotalCents: validation.pricing.totalKnownCents,
        tariffVersion: validation.pricing.tariffVersion,
        customerName: quoteName,
        customerEmail: quoteEmail,
        customerPhone: quotePhone,
        message:
          quoteMessage ||
          `Demande de devis indicatif pour ${validation.resolvedLabels.modelName} (${validation.resolvedLabels.trimName}).`,
      });
      setQuoteSentId(created.id);
      setActionFeedback(
        `Demande commerciale reçue (${created.id}) et transmise au concessionnaire sélectionné (statut : Demande reçue).`
      );
    } catch (err) {
      setActionFeedback(
        err instanceof Error
          ? err.message
          : "Impossible d'enregistrer la demande commerciale."
      );
    } finally {
      setSendingQuote(false);
    }
  };

  const stepIdx = STEPS.findIndex((s) => s.id === step);

  return (
    <div className="max-w-[1440px] mx-auto px-4 sm:px-8 py-8 sm:py-10 space-y-8">
      {/* En-tête et stepper */}
      <div className="border-b border-[#E2E2DE] pb-6 space-y-5">
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
          <div>
            <p className="text-xs font-bold tracking-[0.14em] text-[#595959]">
              CONFIGURATEUR VALIDÉ PAR SERVEUR · {validation.pricing.tariffVersion}
            </p>
            <h1 className="font-display text-3xl sm:text-4xl font-extrabold tracking-tight text-[#0D0D0D]">
              Configurer {model.shortName}
            </h1>
          </div>
          <div className="flex items-center gap-3">
            <button
              type="button"
              onClick={() => handleModelChange(selection.modelSlug)}
              className="inline-flex items-center gap-1.5 border border-[#E2E2DE] bg-white px-3.5 py-2 text-xs font-semibold hover:border-[#0D0D0D] transition-colors"
            >
              <RotateCcw className="w-3.5 h-3.5" aria-hidden="true" />
              <span>Réinitialiser</span>
            </button>
            <button
              type="button"
              onClick={() => {
                const res = addItem({
                  id: `cfg-${selection.modelSlug}-${selection.motorisationId}-${selection.trimId}`,
                  source: "saved",
                  label: `${model.shortName} · ${validation.resolvedLabels.trimName}`,
                  modelSlug: selection.modelSlug,
                  motorisationId: selection.motorisationId,
                  trimId: selection.trimId,
                  colorId: selection.colorId,
                  wheelId: selection.wheelId,
                  interiorId: selection.interiorId,
                  optionIds: selection.optionIds,
                  totalKnownCents: validation.pricing.totalKnownCents,
                  tariffVersion: validation.pricing.tariffVersion,
                });
                setActionFeedback(
                  res.ok
                    ? "Configuration ajoutée au comparateur."
                    : res.message || "Comparateur plein."
                );
              }}
              className="inline-flex items-center gap-1.5 border border-[#0D0D0D] bg-white px-3.5 py-2 text-xs font-semibold hover:bg-[#0D0D0D] hover:text-white transition-colors"
            >
              <Scale className="w-3.5 h-3.5" aria-hidden="true" />
              <span>Comparer</span>
            </button>
          </div>
        </div>

        <nav
          aria-label="Étapes du configurateur"
          className="grid grid-cols-4 lg:grid-cols-8 gap-1.5"
        >
          {STEPS.map((s) => {
            const active = s.id === step;
            return (
              <button
                key={s.id}
                type="button"
                onClick={() => setStep(s.id)}
                className={`text-left px-3 py-2.5 border transition-colors ${
                  active
                    ? "bg-[#0D0D0D] text-white border-[#0D0D0D]"
                    : "bg-white text-[#0D0D0D] border-[#E2E2DE] hover:border-[#0D0D0D]"
                }`}
              >
                <span
                  className={`block font-mono-tabular text-[11px] ${
                    active ? "text-[#F7E300]" : "text-[#595959]"
                  }`}
                >
                  {s.index}
                </span>
                <span className="block text-xs font-semibold truncate">
                  {s.label}
                </span>
              </button>
            );
          })}
        </nav>
      </div>

      {resumedBanner && (
        <div
          role="status"
          className="border border-[#0D0D0D] bg-[#F7E300]/25 px-4 py-3 text-sm font-medium flex items-center justify-between gap-4"
        >
          <span>{resumedBanner}</span>
          <span className="text-xs font-mono-tabular">Snapshot conservé</span>
        </div>
      )}

      {serverError && (
        <div
          role="alert"
          className="border border-[#B91C1C] bg-[#FEF2F2] text-[#991B1B] px-4 py-3 text-sm"
        >
          {serverError}
        </div>
      )}

      {/* Alertes d'incompatibilité expliquées sans modification silencieuse */}
      {validation.issues.length > 0 && (
        <div
          role="alert"
          aria-live="polite"
          className="space-y-3"
        >
          {validation.issues.map((issue) => (
            <div
              key={issue.ruleCode}
              className={`border p-4 space-y-3 ${
                issue.severity === "conflict"
                  ? "border-[#B91C1C] bg-[#FEF2F2]"
                  : "border-[#0D0D0D] bg-[#F7E300]/20"
              }`}
            >
              <div className="flex items-start gap-3">
                {issue.severity === "conflict" ? (
                  <AlertTriangle
                    className="w-5 h-5 text-[#B91C1C] shrink-0 mt-0.5"
                    aria-hidden="true"
                  />
                ) : (
                  <Info
                    className="w-5 h-5 text-[#0D0D0D] shrink-0 mt-0.5"
                    aria-hidden="true"
                  />
                )}
                <div className="space-y-1">
                  <p className="font-display text-base font-bold text-[#0D0D0D]">
                    {issue.title}{" "}
                    <span className="font-mono-tabular text-xs font-normal text-[#595959]">
                      ({issue.ruleCode})
                    </span>
                  </p>
                  <p className="text-sm text-[#262626]">{issue.explanation}</p>
                </div>
              </div>
              <div className="flex flex-wrap gap-2 pl-8">
                {issue.resolutionActions.map((act) => (
                  <button
                    key={act.label}
                    type="button"
                    onClick={() => updateSelection(act.patch)}
                    className="bg-[#0D0D0D] text-white text-xs font-semibold px-4 py-2 hover:bg-[#262626] transition-colors"
                  >
                    {act.label}
                  </button>
                ))}
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Corps principal : Visuel pré-rendu + Panneau d'étape */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        {/* Colonne gauche : Visuel pré-rendu par calques & synthèse prix */}
        <div className="lg:col-span-5 lg:sticky lg:top-24 space-y-4">
          <div className="bg-white border border-[#E2E2DE]">
            <div className="relative aspect-[16/10] w-full overflow-hidden bg-[#ECECE9]">
              <VehicleImage
                src={
                  visualMode === "exterior"
                    ? model.heroImage
                    : model.interiorImage
                }
                alt={`${model.name} — ${selectedColor.name}`}
                fill
                sizes="(max-width: 1024px) 100vw, 42vw"
                className="object-cover transition-all duration-300"
                style={
                  visualMode === "exterior"
                    ? { filter: selectedColor.previewTintCss }
                    : undefined
                }
              />
              {/* Calque d'aperçu teinte & finition */}
              <div className="absolute bottom-3 left-3 bg-white/95 border border-[#E2E2DE] px-3 py-2 flex items-center gap-2.5 text-xs">
                <span
                  className="w-4 h-4 border border-[#0D0D0D]/40 shrink-0"
                  style={{ backgroundColor: selectedColor.hex }}
                  aria-hidden="true"
                />
                <span className="font-semibold text-[#0D0D0D]">
                  {selectedColor.name}
                </span>
                <span className="text-[#595959]">·</span>
                <span className="text-[#595959]">{validation.resolvedLabels.trimName}</span>
              </div>
            </div>

            <div className="p-4 border-t border-[#E2E2DE] flex items-center justify-between gap-3">
              <div className="flex gap-1.5">
                <button
                  type="button"
                  onClick={() => setVisualMode("exterior")}
                  className={`px-3 py-1.5 text-xs font-semibold border ${
                    visualMode === "exterior"
                      ? "bg-[#0D0D0D] text-white border-[#0D0D0D]"
                      : "bg-white text-[#0D0D0D] border-[#E2E2DE]"
                  }`}
                >
                  Extérieur
                </button>
                <button
                  type="button"
                  onClick={() => setVisualMode("interior")}
                  className={`px-3 py-1.5 text-xs font-semibold border ${
                    visualMode === "interior"
                      ? "bg-[#0D0D0D] text-white border-[#0D0D0D]"
                      : "bg-white text-[#0D0D0D] border-[#E2E2DE]"
                  }`}
                >
                  Habitacle
                </button>
              </div>
              <p className="text-[11px] text-[#595959] text-right">
                Visuel pré-rendu par calques (non 3D)
              </p>
            </div>
          </div>

          {/* Synthèse tarifaire permanente */}
          <div className="bg-white border border-[#E2E2DE] p-5 space-y-3">
            <div className="flex items-baseline justify-between gap-4 border-b border-[#E2E2DE] pb-3">
              <div>
                <p className="text-xs font-semibold text-[#595959]">
                  Total estimatif connu ({validation.pricing.tariffVersion})
                </p>
                <p className="font-mono-tabular text-2xl font-extrabold text-[#0D0D0D]">
                  {validating
                    ? "Calcul serveur…"
                    : formatCentsEUR(validation.pricing.totalKnownCents, true)}
                </p>
              </div>
              <span
                className={`text-xs font-semibold px-2.5 py-1 border ${
                  validation.valid
                    ? "border-[#0D0D0D] bg-[#F7E300]/30 text-[#0D0D0D]"
                    : "border-[#B91C1C] bg-[#FEF2F2] text-[#991B1B]"
                }`}
              >
                {validation.valid ? "Valide" : "Conflit à résoudre"}
              </span>
            </div>

            <dl className="text-xs space-y-1.5 text-[#262626]">
              <div className="flex justify-between">
                <dt>Base + motorisation + finition</dt>
                <dd className="font-mono-tabular font-semibold">
                  {formatCentsEUR(
                    validation.pricing.baseVehicleCents +
                      validation.pricing.motorisationDeltaCents +
                      validation.pricing.trimDeltaCents,
                    true
                  )}
                </dd>
              </div>
              <div className="flex justify-between">
                <dt>Couleur, jantes, sellerie &amp; options</dt>
                <dd className="font-mono-tabular font-semibold">
                  {formatCentsEUR(
                    validation.pricing.colorDeltaCents +
                      validation.pricing.wheelDeltaCents +
                      validation.pricing.interiorDeltaCents +
                      validation.pricing.optionsTotalCents,
                    true
                  )}
                </dd>
              </div>
              <div className="flex justify-between">
                <dt>Frais obligatoires + livraison</dt>
                <dd className="font-mono-tabular font-semibold">
                  {formatCentsEUR(
                    validation.pricing.mandatoryFeesCents +
                      validation.pricing.deliveryFeeCents,
                    true
                  )}
                </dd>
              </div>
              {validation.pricing.discountDemoCents > 0 && (
                <div className="flex justify-between text-[#0D0D0D]">
                  <dt>Remise commerciale démo</dt>
                  <dd className="font-mono-tabular font-semibold">
                    −{formatCentsEUR(validation.pricing.discountDemoCents, true)}
                  </dd>
                </div>
              )}
            </dl>
            <p className="text-[11px] text-[#595959] pt-2 border-t border-[#E2E2DE]">
              {validation.pricing.legalDisclaimer}
            </p>
          </div>
        </div>

        {/* Colonne droite : Contrôles par étape */}
        <div className="lg:col-span-7 bg-white border border-[#E2E2DE] p-6 sm:p-8 space-y-6">
          {step === "modele" && (
            <div className="space-y-4">
              <h2 className="font-display text-2xl font-extrabold">
                01. Choisissez votre modèle
              </h2>
              <div className="grid grid-cols-1 gap-4">
                {VEHICLE_MODELS.map((m) => {
                  const selected = m.slug === selection.modelSlug;
                  return (
                    <button
                      key={m.slug}
                      type="button"
                      onClick={() => handleModelChange(m.slug)}
                      className={`text-left border p-4 flex items-center justify-between gap-4 transition-colors ${
                        selected
                          ? "border-[#0D0D0D] bg-[#FAF9F6]"
                          : "border-[#E2E2DE] hover:border-[#0D0D0D]"
                      }`}
                    >
                      <div>
                        <p className="text-xs text-[#595959]">
                          {m.segment} · Millésime {m.modelYear}
                        </p>
                        <p className="font-display text-lg font-bold text-[#0D0D0D]">
                          {m.name}
                        </p>
                        <p className="text-xs text-[#595959]">{m.tagline}</p>
                      </div>
                      <div className="text-right shrink-0">
                        <p className="font-mono-tabular font-bold text-sm">
                          {formatCentsEUR(m.basePriceCents)}
                        </p>
                        {selected && (
                          <span className="text-[11px] font-semibold text-[#0D0D0D]">
                            Sélectionné
                          </span>
                        )}
                      </div>
                    </button>
                  );
                })}
              </div>
            </div>
          )}

          {step === "motorisation" && (
            <div className="space-y-4">
              <h2 className="font-display text-2xl font-extrabold">
                02. Motorisation &amp; batterie
              </h2>
              <div className="space-y-3">
                {modelMotos.map((moto) => {
                  const bat = BATTERIES.find((b) => b.id === moto.batteryId)!;
                  const selected = moto.id === selection.motorisationId;
                  return (
                    <button
                      key={moto.id}
                      type="button"
                      onClick={() => updateSelection({ motorisationId: moto.id })}
                      className={`w-full text-left border p-5 space-y-2 transition-colors ${
                        selected
                          ? "border-[#0D0D0D] bg-[#FAF9F6]"
                          : "border-[#E2E2DE] hover:border-[#0D0D0D]"
                      }`}
                    >
                      <div className="flex items-start justify-between gap-4">
                        <div>
                          <p className="text-xs text-[#595959]">
                            {moto.energy} · {bat.name} ({bat.usableKwh} kWh)
                          </p>
                          <p className="font-display text-lg font-bold">
                            {moto.name}
                          </p>
                        </div>
                        <span className="font-mono-tabular text-sm font-bold shrink-0">
                          {moto.priceDeltaCents === 0
                            ? "Inclus"
                            : `+ ${formatCentsEUR(moto.priceDeltaCents)}`}
                        </span>
                      </div>
                      <p className="text-xs text-[#595959]">
                        {moto.powerCh} ch ({moto.powerKw} kW) · Autonomie{" "}
                        {moto.wltpRangeKm ? `${moto.wltpRangeKm} km` : "Non communiqué"}{" "}
                        ({moto.measurementStandard})
                      </p>
                    </button>
                  );
                })}
              </div>
            </div>
          )}

          {step === "finition" && (
            <div className="space-y-4">
              <h2 className="font-display text-2xl font-extrabold">
                03. Finition &amp; équipements inclus
              </h2>
              <div className="space-y-4">
                {modelTrims.map((trim) => {
                  const selected = trim.id === selection.trimId;
                  return (
                    <button
                      key={trim.id}
                      type="button"
                      onClick={() => updateSelection({ trimId: trim.id })}
                      className={`w-full text-left border p-5 space-y-3 transition-colors ${
                        selected
                          ? "border-[#0D0D0D] bg-[#FAF9F6]"
                          : "border-[#E2E2DE] hover:border-[#0D0D0D]"
                      }`}
                    >
                      <div className="flex items-start justify-between gap-4">
                        <div>
                          <p className="font-display text-lg font-bold">
                            {trim.name}
                          </p>
                          <p className="text-xs text-[#595959]">{trim.subtitle}</p>
                        </div>
                        <span className="font-mono-tabular text-sm font-bold shrink-0">
                          {trim.priceDeltaCents === 0
                            ? "Inclus"
                            : `+ ${formatCentsEUR(trim.priceDeltaCents)}`}
                        </span>
                      </div>
                      <ul className="grid grid-cols-1 sm:grid-cols-2 gap-1.5 text-xs text-[#262626] pt-2 border-t border-[#E2E2DE]">
                        {trim.includedEquipment.map((eq) => (
                          <li key={eq} className="flex items-start gap-1.5">
                            <Check className="w-3.5 h-3.5 mt-0.5 shrink-0" aria-hidden="true" />
                            <span>{eq}</span>
                          </li>
                        ))}
                      </ul>
                    </button>
                  );
                })}
              </div>
            </div>
          )}

          {step === "couleur" && (
            <div className="space-y-4">
              <h2 className="font-display text-2xl font-extrabold">
                04. Teinte extérieure
              </h2>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {modelColors.map((color) => {
                  const selected = color.id === selection.colorId;
                  return (
                    <button
                      key={color.id}
                      type="button"
                      onClick={() => updateSelection({ colorId: color.id })}
                      className={`text-left border p-4 flex items-center justify-between gap-3 transition-colors ${
                        selected
                          ? "border-[#0D0D0D] bg-[#FAF9F6]"
                          : "border-[#E2E2DE] hover:border-[#0D0D0D]"
                      }`}
                    >
                      <div className="flex items-center gap-3">
                        <span
                          className="w-9 h-9 border border-[#0D0D0D]/30 shrink-0"
                          style={{ backgroundColor: color.hex }}
                          aria-hidden="true"
                        />
                        <div>
                          <p className="font-semibold text-sm text-[#0D0D0D]">
                            {color.name}
                          </p>
                          <p className="text-xs text-[#595959]">
                            {color.finishType}
                          </p>
                        </div>
                      </div>
                      <span className="font-mono-tabular text-xs font-bold">
                        {color.priceDeltaCents === 0
                          ? "Inclus"
                          : `+ ${formatCentsEUR(color.priceDeltaCents)}`}
                      </span>
                    </button>
                  );
                })}
              </div>
            </div>
          )}

          {step === "jantes" && (
            <div className="space-y-4">
              <h2 className="font-display text-2xl font-extrabold">
                05. Jantes
              </h2>
              <div className="space-y-3">
                {modelWheels.map((wheel) => {
                  const selected = wheel.id === selection.wheelId;
                  return (
                    <button
                      key={wheel.id}
                      type="button"
                      onClick={() => updateSelection({ wheelId: wheel.id })}
                      className={`w-full text-left border p-4 flex items-center justify-between gap-4 transition-colors ${
                        selected
                          ? "border-[#0D0D0D] bg-[#FAF9F6]"
                          : "border-[#E2E2DE] hover:border-[#0D0D0D]"
                      }`}
                    >
                      <div>
                        <p className="font-semibold text-sm text-[#0D0D0D]">
                          {wheel.name}
                        </p>
                        <p className="text-xs text-[#595959]">
                          {wheel.sizeInches}&quot; · {wheel.finish}
                        </p>
                      </div>
                      <span className="font-mono-tabular text-xs font-bold shrink-0">
                        {wheel.priceDeltaCents === 0
                          ? "Inclus"
                          : `+ ${formatCentsEUR(wheel.priceDeltaCents)}`}
                      </span>
                    </button>
                  );
                })}
              </div>
            </div>
          )}

          {step === "interieur" && (
            <div className="space-y-4">
              <h2 className="font-display text-2xl font-extrabold">
                06. Sellerie &amp; ambiance intérieure
              </h2>
              <div className="space-y-3">
                {modelInteriors.map((interior) => {
                  const selected = interior.id === selection.interiorId;
                  return (
                    <button
                      key={interior.id}
                      type="button"
                      onClick={() => updateSelection({ interiorId: interior.id })}
                      className={`w-full text-left border p-4 flex items-center justify-between gap-4 transition-colors ${
                        selected
                          ? "border-[#0D0D0D] bg-[#FAF9F6]"
                          : "border-[#E2E2DE] hover:border-[#0D0D0D]"
                      }`}
                    >
                      <div className="flex items-center gap-3">
                        <span
                          className="w-8 h-8 border border-[#0D0D0D]/30 shrink-0"
                          style={{ backgroundColor: interior.swatchHex }}
                          aria-hidden="true"
                        />
                        <div>
                          <p className="font-semibold text-sm text-[#0D0D0D]">
                            {interior.name}
                          </p>
                          <p className="text-xs text-[#595959]">
                            {interior.material} · {interior.colorTheme}
                          </p>
                        </div>
                      </div>
                      <span className="font-mono-tabular text-xs font-bold shrink-0">
                        {interior.priceDeltaCents === 0
                          ? "Inclus"
                          : `+ ${formatCentsEUR(interior.priceDeltaCents)}`}
                      </span>
                    </button>
                  );
                })}
              </div>
              <p className="text-xs text-[#595959]">
                Sellerie active : {selectedInterior.name} ({selectedInterior.material})
              </p>
            </div>
          )}

          {step === "options" && (
            <div className="space-y-4">
              <h2 className="font-display text-2xl font-extrabold">
                07. Options &amp; packs
              </h2>
              <p className="text-xs text-[#595959]">
                Certaines options dépendent de la finition ou sont exclusives entre
                elles. Toute incompatibilité est expliquée sans altérer vos choix.
              </p>
              <div className="space-y-3">
                {modelOptions.map((opt) => {
                  const checked = selection.optionIds.includes(opt.id);
                  return (
                    <label
                      key={opt.id}
                      className={`block border p-4 cursor-pointer transition-colors ${
                        checked
                          ? "border-[#0D0D0D] bg-[#FAF9F6]"
                          : "border-[#E2E2DE] hover:border-[#0D0D0D]"
                      }`}
                    >
                      <div className="flex items-start justify-between gap-4">
                        <div className="flex items-start gap-3">
                          <input
                            type="checkbox"
                            checked={checked}
                            onChange={() => toggleOption(opt.id)}
                            className="mt-1 w-4 h-4 accent-[#0D0D0D]"
                          />
                          <div className="space-y-1">
                            <p className="text-xs text-[#595959]">
                              {opt.category}
                            </p>
                            <p className="font-semibold text-sm text-[#0D0D0D]">
                              {opt.name}
                            </p>
                            <p className="text-xs text-[#595959]">
                              {opt.description}
                            </p>
                          </div>
                        </div>
                        <span className="font-mono-tabular text-xs font-bold shrink-0">
                          + {formatCentsEUR(opt.priceDeltaCents)}
                        </span>
                      </div>
                    </label>
                  );
                })}
              </div>

              <div className="pt-3 border-t border-[#E2E2DE]">
                <label className="inline-flex items-center gap-2.5 text-xs font-medium cursor-pointer">
                  <input
                    type="checkbox"
                    checked={Boolean(selection.applyDemoDiscount)}
                    onChange={(e) =>
                      updateSelection({ applyDemoDiscount: e.target.checked })
                    }
                    className="w-4 h-4 accent-[#0D0D0D]"
                  />
                  <span>
                    Simuler l&apos;avantage client démonstration (−1 000,00 €)
                  </span>
                </label>
              </div>
            </div>
          )}

          {step === "recapitulatif" && (
            <div className="space-y-6">
              <div>
                <h2 className="font-display text-2xl font-extrabold">
                  08. Récapitulatif détaillé &amp; actions
                </h2>
                <p className="text-xs text-[#595959] mt-1">
                  Tarif appliqué : {validation.pricing.tariffVersion} (date
                  d&apos;effet {validation.pricing.tariffEffectiveDate})
                </p>
              </div>

              {/* Détail configuration */}
              <div className="border border-[#E2E2DE] divide-y divide-[#E2E2DE] text-sm">
                <div className="p-3.5 flex justify-between gap-4">
                  <span className="text-[#595959]">Modèle</span>
                  <span className="font-semibold text-right">
                    {validation.resolvedLabels.modelName} (
                    {validation.resolvedLabels.modelYear})
                  </span>
                </div>
                <div className="p-3.5 flex justify-between gap-4">
                  <span className="text-[#595959]">Motorisation &amp; batterie</span>
                  <span className="font-semibold text-right">
                    {validation.resolvedLabels.motorisationName} ·{" "}
                    {validation.resolvedLabels.batteryName}
                  </span>
                </div>
                <div className="p-3.5 flex justify-between gap-4">
                  <span className="text-[#595959]">Finition</span>
                  <span className="font-semibold text-right">
                    {validation.resolvedLabels.trimName}
                  </span>
                </div>
                <div className="p-3.5 flex justify-between gap-4">
                  <span className="text-[#595959]">Couleur</span>
                  <span className="font-semibold text-right">
                    {validation.resolvedLabels.colorName}
                  </span>
                </div>
                <div className="p-3.5 flex justify-between gap-4">
                  <span className="text-[#595959]">Jantes</span>
                  <span className="font-semibold text-right">
                    {validation.resolvedLabels.wheelName}
                  </span>
                </div>
                <div className="p-3.5 flex justify-between gap-4">
                  <span className="text-[#595959]">Intérieur</span>
                  <span className="font-semibold text-right">
                    {validation.resolvedLabels.interiorName}
                  </span>
                </div>
                <div className="p-3.5 flex justify-between gap-4">
                  <span className="text-[#595959]">Options</span>
                  <span className="font-semibold text-right">
                    {validation.resolvedLabels.optionNames.length > 0
                      ? validation.resolvedLabels.optionNames.join(", ")
                      : "Aucune"}
                  </span>
                </div>
              </div>

              {/* Ventilation complète du prix en centimes entiers */}
              <div className="bg-[#FAF9F6] border border-[#E2E2DE] p-4 space-y-2 text-xs">
                <p className="font-bold text-sm text-[#0D0D0D]">
                  Ventilation tarifaire indicative
                </p>
                <div className="flex justify-between">
                  <span>Prix de base du véhicule</span>
                  <span className="font-mono-tabular">
                    {formatCentsEUR(validation.pricing.baseVehicleCents, true)}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span>Supplément motorisation &amp; finition</span>
                  <span className="font-mono-tabular">
                    {formatCentsEUR(
                      validation.pricing.motorisationDeltaCents +
                        validation.pricing.trimDeltaCents,
                      true
                    )}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span>Couleur, jantes, sellerie &amp; options</span>
                  <span className="font-mono-tabular">
                    {formatCentsEUR(
                      validation.pricing.colorDeltaCents +
                        validation.pricing.wheelDeltaCents +
                        validation.pricing.interiorDeltaCents +
                        validation.pricing.optionsTotalCents,
                      true
                    )}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span>Frais obligatoires indicatifs</span>
                  <span className="font-mono-tabular">
                    {formatCentsEUR(validation.pricing.mandatoryFeesCents, true)}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span>Livraison &amp; mise à la route</span>
                  <span className="font-mono-tabular">
                    {formatCentsEUR(validation.pricing.deliveryFeeCents, true)}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span>Remise commerciale démonstration</span>
                  <span className="font-mono-tabular">
                    −{formatCentsEUR(validation.pricing.discountDemoCents, true)}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span>Aides publiques</span>
                  <span className="font-mono-tabular">
                    {formatCentsEUR(validation.pricing.publicAidCents, true)}
                  </span>
                </div>
                <p className="text-[11px] text-[#595959]">
                  {validation.pricing.publicAidNotice}
                </p>
                <div className="flex justify-between pt-2 border-t border-[#E2E2DE] text-[#595959]">
                  <span>Dont TVA (20 %) incluse</span>
                  <span className="font-mono-tabular">
                    {formatCentsEUR(validation.pricing.vatIncludedCents, true)}
                  </span>
                </div>
                <div className="flex justify-between pt-2 border-t border-[#0D0D0D] text-base font-extrabold text-[#0D0D0D]">
                  <span>Total connu estimatif</span>
                  <span className="font-mono-tabular">
                    {formatCentsEUR(validation.pricing.totalKnownCents, true)}
                  </span>
                </div>
              </div>

              {/* Sauvegarde, Partage, Export */}
              <div className="border border-[#E2E2DE] p-4 space-y-4">
                <p className="font-semibold text-sm">
                  Sauvegarder, partager ou exporter
                </p>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label
                      htmlFor="config-title"
                      className="block text-xs text-[#595959] mb-1"
                    >
                      Nom de votre configuration
                    </label>
                    <input
                      id="config-title"
                      type="text"
                      value={configTitle}
                      onChange={(e) => setConfigTitle(e.target.value)}
                      maxLength={120}
                      className="w-full border border-[#E2E2DE] px-3 py-2 text-sm focus:border-[#0D0D0D] focus:outline-none"
                    />
                  </div>
                  <div className="flex items-end pb-2">
                    <label className="inline-flex items-center gap-2 text-xs cursor-pointer">
                      <input
                        type="checkbox"
                        checked={isPublicShare}
                        onChange={(e) => setIsPublicShare(e.target.checked)}
                        className="w-4 h-4 accent-[#0D0D0D]"
                      />
                      <span>Autoriser le lien de partage</span>
                    </label>
                  </div>
                </div>

                <div className="flex flex-wrap gap-2">
                  <button
                    type="button"
                    onClick={handleSave}
                    disabled={saving || !validation.valid}
                    className="inline-flex items-center gap-2 bg-[#0D0D0D] text-white text-xs font-semibold px-4 py-2.5 hover:bg-[#262626] disabled:opacity-50"
                  >
                    <BookmarkCheck className="w-4 h-4" aria-hidden="true" />
                    <span>
                      {saving
                        ? "Sauvegarde…"
                        : savedId
                        ? "Sauvegardée"
                        : "Sauvegarder dans Mon compte"}
                    </span>
                  </button>
                  <button
                    type="button"
                    onClick={handleShare}
                    className="inline-flex items-center gap-2 border border-[#0D0D0D] bg-white text-xs font-semibold px-4 py-2.5 hover:bg-[#F3F3F1]"
                  >
                    <Share2 className="w-4 h-4" aria-hidden="true" />
                    <span>Partager le lien</span>
                  </button>
                  <button
                    type="button"
                    onClick={handleExportTxt}
                    className="inline-flex items-center gap-2 border border-[#E2E2DE] bg-white text-xs font-semibold px-4 py-2.5 hover:border-[#0D0D0D]"
                  >
                    <Download className="w-4 h-4" aria-hidden="true" />
                    <span>Exporter (.txt)</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => window.print()}
                    className="inline-flex items-center gap-2 border border-[#E2E2DE] bg-white text-xs font-semibold px-4 py-2.5 hover:border-[#0D0D0D]"
                  >
                    <Printer className="w-4 h-4" aria-hidden="true" />
                    <span>Imprimer / PDF</span>
                  </button>
                </div>

                {actionFeedback && (
                  <p
                    role="status"
                    className="text-xs font-medium bg-[#F7E300]/25 border border-[#0D0D0D] px-3 py-2"
                  >
                    {actionFeedback}
                  </p>
                )}
              </div>

              {/* Demande concessionnaire / devis indicatif */}
              <form
                onSubmit={handleSendQuoteRequest}
                className="border border-[#E2E2DE] p-4 space-y-4"
              >
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <p className="font-semibold text-sm">
                    Transmettre cette configuration à un concessionnaire
                  </p>
                  <Link
                    href={`/essais?modele=${selection.modelSlug}`}
                    className="text-xs font-semibold underline"
                  >
                    Ou réserver un essai routier
                  </Link>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-sm">
                  <div className="sm:col-span-2">
                    <label
                      htmlFor="quote-dealer"
                      className="block text-xs text-[#595959] mb-1"
                    >
                      Concessionnaire de démonstration
                    </label>
                    <select
                      id="quote-dealer"
                      value={quoteDealerId}
                      onChange={(e) => setQuoteDealerId(e.target.value)}
                      className="w-full border border-[#E2E2DE] bg-white px-3 py-2 text-sm focus:border-[#0D0D0D] focus:outline-none"
                    >
                      {DEMO_DEALERS.map((d) => (
                        <option key={d.id} value={d.id}>
                          {d.name} ({d.postalCode} {d.city})
                        </option>
                      ))}
                    </select>
                  </div>
                  <div>
                    <label
                      htmlFor="quote-name"
                      className="block text-xs text-[#595959] mb-1"
                    >
                      Nom complet
                    </label>
                    <input
                      id="quote-name"
                      type="text"
                      required
                      value={quoteName}
                      onChange={(e) => setQuoteNameInput(e.target.value)}
                      className="w-full border border-[#E2E2DE] px-3 py-2 text-sm"
                    />
                  </div>
                  <div>
                    <label
                      htmlFor="quote-email"
                      className="block text-xs text-[#595959] mb-1"
                    >
                      Adresse e-mail
                    </label>
                    <input
                      id="quote-email"
                      type="email"
                      required
                      value={quoteEmail}
                      onChange={(e) => setQuoteEmailInput(e.target.value)}
                      className="w-full border border-[#E2E2DE] px-3 py-2 text-sm"
                    />
                  </div>
                  <div>
                    <label
                      htmlFor="quote-phone"
                      className="block text-xs text-[#595959] mb-1"
                    >
                      Téléphone (facultatif)
                    </label>
                    <input
                      id="quote-phone"
                      type="tel"
                      value={quotePhone}
                      onChange={(e) => setQuotePhone(e.target.value)}
                      className="w-full border border-[#E2E2DE] px-3 py-2 text-sm"
                    />
                  </div>
                  <div>
                    <label
                      htmlFor="quote-msg"
                      className="block text-xs text-[#595959] mb-1"
                    >
                      Précision (facultatif)
                    </label>
                    <input
                      id="quote-msg"
                      type="text"
                      value={quoteMessage}
                      onChange={(e) => setQuoteMessage(e.target.value)}
                      className="w-full border border-[#E2E2DE] px-3 py-2 text-sm"
                    />
                  </div>
                </div>

                <button
                  type="submit"
                  disabled={sendingQuote || !validation.valid}
                  className="inline-flex items-center gap-2 bg-[#0D0D0D] text-white text-xs font-semibold px-5 py-3 hover:bg-[#262626] disabled:opacity-50"
                >
                  <span>
                    {sendingQuote
                      ? "Envoi en cours…"
                      : "Envoyer ma demande commerciale"}
                  </span>
                  <ArrowRight className="w-4 h-4" aria-hidden="true" />
                </button>

                {quoteSentId && (
                  <p className="text-xs text-[#0D0D0D] font-medium">
                    Référence enregistrée : {quoteSentId} · Retrouvez le suivi
                    dans <Link href="/compte" className="underline">Mon compte</Link>.
                  </p>
                )}
              </form>
            </div>
          )}

          {/* Navigation Suivant / Précédent entre étapes */}
          <div className="pt-6 border-t border-[#E2E2DE] flex items-center justify-between gap-4">
            <button
              type="button"
              disabled={stepIdx === 0}
              onClick={() => setStep(STEPS[Math.max(0, stepIdx - 1)].id)}
              className="border border-[#E2E2DE] px-5 py-2.5 text-xs font-semibold text-[#0D0D0D] hover:border-[#0D0D0D] disabled:opacity-40"
            >
              Étape précédente
            </button>
            {stepIdx < STEPS.length - 1 ? (
              <button
                type="button"
                onClick={() => setStep(STEPS[stepIdx + 1].id)}
                className="inline-flex items-center gap-2 bg-[#0D0D0D] text-white px-6 py-2.5 text-xs font-semibold hover:bg-[#262626]"
              >
                <span>Étape suivante : {STEPS[stepIdx + 1].label}</span>
                <ArrowRight className="w-4 h-4" aria-hidden="true" />
              </button>
            ) : (
              <Link
                href="/essais"
                className="inline-flex items-center gap-2 border border-[#0D0D0D] px-5 py-2.5 text-xs font-semibold hover:bg-[#0D0D0D] hover:text-white transition-colors"
              >
                <span>Réserver un essai</span>
                <ArrowRight className="w-4 h-4" aria-hidden="true" />
              </Link>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
