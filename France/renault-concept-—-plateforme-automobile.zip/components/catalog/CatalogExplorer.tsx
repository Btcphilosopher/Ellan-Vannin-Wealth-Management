"use client";

import { useMemo, useState } from "react";
import Link from "next/link";
import { ArrowRight, Check, Scale, SlidersHorizontal } from "lucide-react";
import {
  INITIAL_STOCK_VEHICLES,
  MOTORISATIONS,
  VEHICLE_MODELS,
} from "@/lib/catalog/data";
import { VehicleModel } from "@/lib/catalog/types";
import { formatCentsEUR } from "@/lib/pricing/tariffs";
import { VehicleImage } from "@/components/common/VehicleImage";
import { useCompare } from "@/components/providers/CompareProvider";

interface CatalogExplorerProps {
  initialEnergy?: string;
}

export function CatalogExplorer({ initialEnergy = "all" }: CatalogExplorerProps) {
  const [energyFilter, setEnergyFilter] = useState<string>(initialEnergy);
  const [onlyStock, setOnlyStock] = useState(false);
  const [feedback, setFeedback] = useState<string | null>(null);
  const { addItem, hasItem } = useCompare();

  const filteredModels = useMemo(() => {
    return VEHICLE_MODELS.filter((model) => {
      if (energyFilter === "electrique" && model.energyCategory !== "electrique") {
        return false;
      }
      if (energyFilter === "hybride" && model.energyCategory !== "hybride") {
        return false;
      }
      if (onlyStock) {
        const hasStock = INITIAL_STOCK_VEHICLES.some(
          (s) => s.modelSlug === model.slug && s.status === "available"
        );
        if (!hasStock) return false;
      }
      return true;
    });
  }, [energyFilter, onlyStock]);

  const handleAddCompare = (model: VehicleModel) => {
    const moto = MOTORISATIONS.find((m) => m.modelSlug === model.slug)!;
    const itemId = `catalog-${model.slug}-${moto.id}`;
    const res = addItem({
      id: itemId,
      source: "catalog",
      label: `${model.shortName} · ${moto.powerCh} ch`,
      modelSlug: model.slug,
      motorisationId: moto.id,
      trimId:
        model.slug === "rafale-e-tech"
          ? "trim-rafale-techno"
          : `trim-${model.slug === "renault-5-e-tech" ? "r5" : "scenic"}-evolution`,
    });
    setFeedback(
      res.ok
        ? `${model.shortName} ajouté au comparateur.`
        : res.message || "Comparateur plein."
    );
  };

  return (
    <div className="max-w-[1440px] mx-auto px-4 sm:px-8 py-10 sm:py-14 space-y-10">
      <div className="flex flex-col lg:flex-row lg:items-end justify-between gap-6 border-b border-[#E2E2DE] pb-8">
        <div className="space-y-2 max-w-2xl">
          <p className="text-xs font-bold tracking-[0.14em] text-[#595959]">
            CATALOGUE DE DÉMONSTRATION · MARCHÉ FRANCE
          </p>
          <h1 className="font-display text-4xl sm:text-5xl font-extrabold tracking-tight text-[#0D0D0D] text-balance">
            Gamme E-Tech &amp; hybride
          </h1>
          <p className="text-sm sm:text-base text-[#595959]">
            Chaque modèle sépare rigoureusement motorisation, batterie, finition,
            couleurs, jantes, sellerie et stock physique. Toutes les données
            affichées sont des valeurs de démonstration datées.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-3">
          <Link
            href="/comparer"
            className="inline-flex items-center gap-2 border border-[#0D0D0D] bg-white px-4 py-2.5 text-sm font-semibold text-[#0D0D0D] hover:bg-[#0D0D0D] hover:text-white transition-colors whitespace-nowrap"
          >
            <Scale className="w-4 h-4" aria-hidden="true" />
            <span>Ouvrir le comparateur</span>
          </Link>
          <Link
            href="/stock"
            className="inline-flex items-center gap-2 bg-[#0D0D0D] text-white px-5 py-2.5 text-sm font-semibold hover:bg-[#262626] transition-colors whitespace-nowrap"
          >
            <span>Voir le stock disponible</span>
            <ArrowRight className="w-4 h-4" aria-hidden="true" />
          </Link>
        </div>
      </div>

      {/* Barre de filtres */}
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div
          role="group"
          aria-label="Filtrer par motorisation"
          className="flex flex-wrap items-center gap-2"
        >
          {[
            { id: "all", label: "Tous les modèles" },
            { id: "electrique", label: "100 % Électrique" },
            { id: "hybride", label: "Hybride & 4x4" },
          ].map((tab) => (
            <button
              key={tab.id}
              type="button"
              onClick={() => setEnergyFilter(tab.id)}
              className={`px-4 py-2 text-sm font-semibold border transition-colors whitespace-nowrap ${
                energyFilter === tab.id
                  ? "bg-[#0D0D0D] text-white border-[#0D0D0D]"
                  : "bg-white text-[#0D0D0D] border-[#E2E2DE] hover:border-[#0D0D0D]"
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>

        <label className="inline-flex items-center gap-2.5 text-sm font-medium text-[#0D0D0D] cursor-pointer select-none">
          <input
            type="checkbox"
            checked={onlyStock}
            onChange={(e) => setOnlyStock(e.target.checked)}
            className="w-4 h-4 accent-[#0D0D0D]"
          />
          <span>Uniquement avec stock disponible</span>
        </label>
      </div>

      {feedback && (
        <div
          role="status"
          className="border border-[#0D0D0D] bg-[#F7E300]/25 px-4 py-3 text-sm font-medium flex items-center justify-between gap-4"
        >
          <span>{feedback}</span>
          <Link
            href="/comparer"
            className="font-semibold underline whitespace-nowrap"
          >
            Voir la comparaison
          </Link>
        </div>
      )}

      {/* Grille des modèles */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {filteredModels.map((model) => {
          const motos = MOTORISATIONS.filter((m) => m.modelSlug === model.slug);
          const maxWltp = Math.max(...motos.map((m) => m.wltpRangeKm ?? 0));
          const stockCount = INITIAL_STOCK_VEHICLES.filter(
            (s) => s.modelSlug === model.slug && s.status === "available"
          ).length;
          const compareKey = `catalog-${model.slug}-${motos[0].id}`;
          const inCompare = hasItem(compareKey);

          return (
            <article
              key={model.slug}
              className="bg-white border border-[#E2E2DE] flex flex-col"
            >
              <Link
                href={`/vehicules/${model.slug}`}
                className="relative aspect-[4/3] w-full overflow-hidden bg-[#ECECE9]"
              >
                <VehicleImage
                  src={model.cardImage}
                  alt={model.name}
                  fill
                  sizes="(max-width: 1024px) 100vw, 33vw"
                  className="object-cover hover:scale-[1.02] transition-transform duration-500"
                />
              </Link>

              <div className="p-6 flex-1 flex flex-col justify-between space-y-6">
                <div className="space-y-3">
                  <div className="flex items-center justify-between text-xs text-[#595959]">
                    <span>
                      {model.segment} · Millésime {model.modelYear}
                    </span>
                    <span className="font-mono-tabular">
                      {stockCount} en stock
                    </span>
                  </div>
                  <h2 className="font-display text-2xl font-extrabold text-[#0D0D0D]">
                    {model.name}
                  </h2>
                  <p className="text-sm text-[#595959] leading-relaxed">
                    {model.description}
                  </p>

                  <dl className="pt-3 border-t border-[#E2E2DE] grid grid-cols-2 gap-3 text-xs">
                    <div>
                      <dt className="text-[#595959]">À partir de (démo)</dt>
                      <dd className="font-mono-tabular text-base font-bold text-[#0D0D0D]">
                        {formatCentsEUR(model.basePriceCents)}
                      </dd>
                    </div>
                    <div>
                      <dt className="text-[#595959]">Autonomie max (WLTP démo)</dt>
                      <dd className="font-mono-tabular text-base font-bold text-[#0D0D0D]">
                        {maxWltp > 0 ? `${maxWltp} km` : "Non communiqué"}
                      </dd>
                    </div>
                  </dl>

                  <p className="text-[11px] text-[#595959]">
                    Statut : {model.provenance.verificationStatus} · Effet{" "}
                    {model.provenance.effectiveDate}
                  </p>
                </div>

                <div className="pt-4 border-t border-[#E2E2DE] space-y-2">
                  <div className="grid grid-cols-2 gap-2">
                    <Link
                      href={`/vehicules/${model.slug}`}
                      className="inline-flex items-center justify-center border border-[#0D0D0D] bg-white text-[#0D0D0D] text-xs font-semibold py-2.5 px-3 hover:bg-[#F3F3F1] transition-colors whitespace-nowrap"
                    >
                      Fiche modèle
                    </Link>
                    <Link
                      href={`/configurateur?modele=${model.slug}`}
                      className="inline-flex items-center justify-center gap-1.5 bg-[#0D0D0D] text-white text-xs font-semibold py-2.5 px-3 hover:bg-[#262626] transition-colors whitespace-nowrap"
                    >
                      <SlidersHorizontal className="w-3.5 h-3.5" aria-hidden="true" />
                      <span>Configurer</span>
                    </Link>
                  </div>
                  <button
                    type="button"
                    onClick={() => handleAddCompare(model)}
                    className="w-full inline-flex items-center justify-center gap-1.5 text-xs font-semibold text-[#595959] hover:text-[#0D0D0D] py-2 border border-[#E2E2DE] transition-colors"
                  >
                    {inCompare ? (
                      <>
                        <Check className="w-3.5 h-3.5" aria-hidden="true" />
                        <span>Dans le comparateur</span>
                      </>
                    ) : (
                      <>
                        <Scale className="w-3.5 h-3.5" aria-hidden="true" />
                        <span>Ajouter au comparateur</span>
                      </>
                    )}
                  </button>
                </div>
              </div>
            </article>
          );
        })}
      </div>
    </div>
  );
}
