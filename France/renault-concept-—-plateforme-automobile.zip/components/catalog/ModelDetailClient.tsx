"use client";

import { useState } from "react";
import Link from "next/link";
import {
  ArrowRight,
  CalendarClock,
  Check,
  Heart,
  MapPin,
  Scale,
  SlidersHorizontal,
} from "lucide-react";
import {
  BatterySpec,
  ExteriorColor,
  Motorisation,
  StockVehicle,
  TrimLevel,
  VehicleModel,
} from "@/lib/catalog/types";
import { DEMO_DEALERS } from "@/lib/dealers/data";
import { formatCentsEUR } from "@/lib/pricing/tariffs";
import { VehicleImage } from "@/components/common/VehicleImage";
import { useAuth } from "@/components/providers/AuthProvider";
import { useCompare } from "@/components/providers/CompareProvider";
import { toggleFavoriteModel } from "@/lib/firebase/services";

interface ModelDetailClientProps {
  model: VehicleModel;
  motorisations: Motorisation[];
  batteries: BatterySpec[];
  trims: TrimLevel[];
  colors: ExteriorColor[];
  stock: StockVehicle[];
}

export function ModelDetailClient({
  model,
  motorisations,
  batteries,
  trims,
  colors,
  stock,
}: ModelDetailClientProps) {
  const { user, profile, signInWithGoogle, refreshProfile } = useAuth();
  const { addItem } = useCompare();

  const gallery = [
    {
      id: "hero",
      label: "Vue architecturale",
      src: model.heroImage,
      caption: `${model.name} — Vue principale de démonstration`,
    },
    {
      id: "card",
      label: "Profil extérieur",
      src: model.cardImage,
      caption: `${model.name} — Design extérieur`,
    },
    {
      id: "interior",
      label: "Habitacle OpenR",
      src: model.interiorImage,
      caption: "Poste de conduite numérique et matériaux recyclés (démonstration)",
    },
    {
      id: "detail",
      label: "Détail technique",
      src: model.detailImage,
      caption: "Signature lumineuse et jante diamantée (démonstration)",
    },
  ];

  const [activeSlide, setActiveSlide] = useState(gallery[0]);
  const [notice, setNotice] = useState<string | null>(null);
  const [favPending, setFavPending] = useState(false);

  const isFavorite = Boolean(profile?.favoriteModelSlugs?.includes(model.slug));

  const handleToggleFavorite = async () => {
    if (!user) {
      await signInWithGoogle();
      return;
    }
    setFavPending(true);
    try {
      await toggleFavoriteModel(
        user.uid,
        model.slug,
        profile?.favoriteModelSlugs || []
      );
      await refreshProfile();
      setNotice(
        isFavorite
          ? `${model.shortName} retiré de vos favoris.`
          : `${model.shortName} enregistré dans vos favoris.`
      );
    } finally {
      setFavPending(false);
    }
  };

  const handleAddCompare = () => {
    const baseMoto = motorisations[0];
    const baseTrim = trims[0];
    const res = addItem({
      id: `catalog-${model.slug}-${baseMoto.id}`,
      source: "catalog",
      label: `${model.shortName} · ${baseMoto.powerCh} ch ${baseTrim.name}`,
      modelSlug: model.slug,
      motorisationId: baseMoto.id,
      trimId: baseTrim.id,
    });
    setNotice(
      res.ok
        ? `${model.shortName} ajouté au comparateur.`
        : res.message || "Limite atteinte."
    );
  };

  return (
    <div className="bg-[#FAF9F6]">
      {/* Présentation visuelle principale */}
      <section className="bg-white border-b border-[#E2E2DE]">
        <div className="max-w-[1440px] mx-auto px-4 sm:px-8 py-10 lg:py-14 grid grid-cols-1 lg:grid-cols-12 gap-8 items-stretch">
          <div className="lg:col-span-5 flex flex-col justify-between space-y-6">
            <div className="space-y-4">
              <div className="text-xs font-bold tracking-[0.14em] text-[#595959]">
                {model.kicker} · MILLÉSIME {model.modelYear}
              </div>
              <h1 className="font-display text-4xl sm:text-5xl font-extrabold tracking-tight text-[#0D0D0D] text-balance">
                {model.name}
              </h1>
              <p className="text-base text-[#262626] leading-relaxed">
                {model.description}
              </p>

              <div className="pt-2 border-t border-[#E2E2DE] grid grid-cols-2 gap-4 text-sm">
                <div>
                  <span className="text-xs text-[#595959] block">
                    À partir de (tarif indicatif démo)
                  </span>
                  <span className="font-mono-tabular text-2xl font-bold text-[#0D0D0D]">
                    {formatCentsEUR(model.basePriceCents)}
                  </span>
                </div>
                <div>
                  <span className="text-xs text-[#595959] block">
                    Statut des données
                  </span>
                  <span className="text-xs font-semibold text-[#0D0D0D]">
                    {model.provenance.verificationStatus}
                  </span>
                  <span className="text-[11px] text-[#595959] block">
                    Marché {model.provenance.market} · Effet{" "}
                    {model.provenance.effectiveDate}
                  </span>
                </div>
              </div>
            </div>

            <div className="space-y-3 pt-4">
              <div className="flex flex-wrap gap-3">
                <Link
                  href={`/configurateur?modele=${model.slug}`}
                  className="inline-flex items-center justify-center gap-2 bg-[#0D0D0D] text-white px-6 py-3.5 text-sm font-semibold hover:bg-[#262626] transition-colors whitespace-nowrap"
                >
                  <SlidersHorizontal className="w-4 h-4" aria-hidden="true" />
                  <span>Configurer ce modèle</span>
                </Link>
                <Link
                  href={`/essais?modele=${model.slug}`}
                  className="inline-flex items-center justify-center gap-2 border border-[#0D0D0D] bg-white text-[#0D0D0D] px-6 py-3.5 text-sm font-semibold hover:bg-[#0D0D0D] hover:text-white transition-colors whitespace-nowrap"
                >
                  <CalendarClock className="w-4 h-4" aria-hidden="true" />
                  <span>Réserver un essai</span>
                </Link>
              </div>

              <div className="flex flex-wrap items-center gap-4 pt-1">
                <button
                  type="button"
                  onClick={handleToggleFavorite}
                  disabled={favPending}
                  className="inline-flex items-center gap-1.5 text-xs font-semibold text-[#0D0D0D] hover:opacity-75 py-1.5"
                >
                  <Heart
                    className={`w-4 h-4 ${isFavorite ? "fill-[#0D0D0D]" : ""}`}
                    aria-hidden="true"
                  />
                  <span>
                    {isFavorite ? "Enregistré en favori" : "Ajouter aux favoris"}
                  </span>
                </button>
                <button
                  type="button"
                  onClick={handleAddCompare}
                  className="inline-flex items-center gap-1.5 text-xs font-semibold text-[#0D0D0D] hover:opacity-75 py-1.5"
                >
                  <Scale className="w-4 h-4" aria-hidden="true" />
                  <span>Comparer</span>
                </button>
              </div>

              {notice && (
                <p
                  role="status"
                  className="text-xs font-medium bg-[#F7E300]/30 border border-[#0D0D0D] px-3 py-2"
                >
                  {notice}
                </p>
              )}
            </div>
          </div>

          {/* Galerie interactive */}
          <div className="lg:col-span-7 flex flex-col gap-3">
            <div className="relative aspect-[16/10] w-full bg-[#ECECE9] border border-[#E2E2DE] overflow-hidden">
              <VehicleImage
                src={activeSlide.src}
                alt={activeSlide.caption}
                fill
                priority
                sizes="(max-width: 1024px) 100vw, 60vw"
                className="object-cover"
              />
            </div>
            <div className="flex flex-wrap items-center justify-between gap-3">
              <p className="text-xs text-[#595959]">{activeSlide.caption}</p>
              <div className="flex flex-wrap gap-2">
                {gallery.map((slide) => (
                  <button
                    key={slide.id}
                    type="button"
                    onClick={() => setActiveSlide(slide)}
                    className={`px-3 py-1.5 text-xs font-semibold border transition-colors ${
                      activeSlide.id === slide.id
                        ? "bg-[#0D0D0D] text-white border-[#0D0D0D]"
                        : "bg-white text-[#0D0D0D] border-[#E2E2DE] hover:border-[#0D0D0D]"
                    }`}
                  >
                    {slide.label}
                  </button>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Design extérieur & Habitacle (informations textuelles accessibles) */}
      <section className="max-w-[1440px] mx-auto px-4 sm:px-8 py-12 grid grid-cols-1 lg:grid-cols-2 gap-8">
        <article className="bg-white border border-[#E2E2DE] flex flex-col">
          <div className="relative aspect-[16/10] w-full bg-[#ECECE9] overflow-hidden">
            <VehicleImage
              src={model.detailImage}
              alt={`Détail du design extérieur ${model.shortName}`}
              fill
              sizes="(max-width: 1024px) 100vw, 50vw"
              className="object-cover"
            />
          </div>
          <div className="p-6 space-y-4">
            <h2 className="font-display text-2xl font-extrabold text-[#0D0D0D]">
              Design extérieur &amp; teintes
            </h2>
            <ul className="space-y-2 text-sm text-[#262626]">
              {model.exteriorHighlights.map((item) => (
                <li key={item} className="flex items-start gap-2.5">
                  <Check className="w-4 h-4 mt-0.5 shrink-0" aria-hidden="true" />
                  <span>{item}</span>
                </li>
              ))}
            </ul>
            <div className="pt-3 border-t border-[#E2E2DE]">
              <p className="text-xs font-semibold text-[#595959] mb-2">
                Teintes disponibles au catalogue :
              </p>
              <div className="flex flex-wrap gap-3">
                {colors.map((c) => (
                  <div
                    key={c.id}
                    className="inline-flex items-center gap-2 text-xs text-[#0D0D0D]"
                  >
                    <span
                      className="w-4 h-4 border border-[#0D0D0D]/30 shrink-0"
                      style={{ backgroundColor: c.hex }}
                      aria-hidden="true"
                    />
                    <span>{c.name}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </article>

        <article className="bg-white border border-[#E2E2DE] flex flex-col">
          <div className="relative aspect-[16/10] w-full bg-[#ECECE9] overflow-hidden">
            <VehicleImage
              src={model.interiorImage}
              alt={`Habitacle et poste de conduite ${model.shortName}`}
              fill
              sizes="(max-width: 1024px) 100vw, 50vw"
              className="object-cover"
            />
          </div>
          <div className="p-6 space-y-4">
            <h2 className="font-display text-2xl font-extrabold text-[#0D0D0D]">
              Habitacle &amp; ergonomie
            </h2>
            <ul className="space-y-2 text-sm text-[#262626]">
              {model.interiorHighlights.map((item) => (
                <li key={item} className="flex items-start gap-2.5">
                  <Check className="w-4 h-4 mt-0.5 shrink-0" aria-hidden="true" />
                  <span>{item}</span>
                </li>
              ))}
            </ul>
          </div>
        </article>
      </section>

      {/* Motorisations & Batteries */}
      <section className="max-w-[1440px] mx-auto px-4 sm:px-8 py-8 space-y-6">
        <div>
          <h2 className="font-display text-3xl font-extrabold text-[#0D0D0D]">
            Motorisations &amp; batteries
          </h2>
          <p className="text-sm text-[#595959] mt-1">
            Toutes les caractéristiques ci-dessous sont exprimées en texte
            accessible selon les normes indiquées (valeurs de démonstration).
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {motorisations.map((moto) => {
            const battery = batteries.find((b) => b.id === moto.batteryId);
            return (
              <div
                key={moto.id}
                className="bg-white border border-[#E2E2DE] p-6 space-y-4"
              >
                <div className="flex items-start justify-between gap-4 border-b border-[#E2E2DE] pb-4">
                  <div>
                    <p className="text-xs font-semibold text-[#595959]">
                      {moto.energy} · {moto.drivetrain}
                    </p>
                    <h3 className="font-display text-xl font-bold text-[#0D0D0D]">
                      {moto.name}
                    </h3>
                  </div>
                  <span className="font-mono-tabular text-sm font-bold text-[#0D0D0D] whitespace-nowrap">
                    {moto.priceDeltaCents === 0
                      ? "Inclus base"
                      : `+ ${formatCentsEUR(moto.priceDeltaCents)}`}
                  </span>
                </div>

                <dl className="grid grid-cols-2 gap-y-3 gap-x-4 text-sm">
                  <div>
                    <dt className="text-xs text-[#595959]">Puissance</dt>
                    <dd className="font-mono-tabular font-semibold">
                      {moto.powerCh} ch ({moto.powerKw} kW)
                    </dd>
                  </div>
                  <div>
                    <dt className="text-xs text-[#595959]">Couple maximal</dt>
                    <dd className="font-mono-tabular font-semibold">
                      {moto.torqueNm !== null
                        ? `${moto.torqueNm} Nm`
                        : "Non communiqué"}
                    </dd>
                  </div>
                  <div>
                    <dt className="text-xs text-[#595959]">
                      Autonomie ({moto.measurementStandard})
                    </dt>
                    <dd className="font-mono-tabular font-semibold">
                      {moto.wltpRangeKm !== null
                        ? `${moto.wltpRangeKm} km`
                        : "Non communiqué"}
                    </dd>
                  </div>
                  <div>
                    <dt className="text-xs text-[#595959]">Batterie</dt>
                    <dd className="font-semibold">
                      {battery
                        ? `${battery.usableKwh} kWh (${battery.chemistry})`
                        : "Non communiqué"}
                    </dd>
                  </div>
                  <div>
                    <dt className="text-xs text-[#595959]">Recharge rapide DC</dt>
                    <dd className="font-mono-tabular font-semibold">
                      {battery?.dcMaxKw
                        ? `${battery.dcMaxKw} kW (15–80 % en ~${battery.charge15to80Min} min démo)`
                        : "Non applicable / Non communiqué"}
                    </dd>
                  </div>
                  <div>
                    <dt className="text-xs text-[#595959]">0 à 100 km/h</dt>
                    <dd className="font-mono-tabular font-semibold">
                      {moto.zeroToHundredSec !== null
                        ? `${moto.zeroToHundredSec} s`
                        : "Non communiqué"}
                    </dd>
                  </div>
                </dl>
              </div>
            );
          })}
        </div>
      </section>

      {/* Tableau technique accessible : Dimensions & Données */}
      <section className="max-w-[1440px] mx-auto px-4 sm:px-8 py-8">
        <div className="bg-white border border-[#E2E2DE] p-6 space-y-4">
          <h2 className="font-display text-2xl font-extrabold text-[#0D0D0D]">
            Dimensions &amp; caractéristiques techniques
          </h2>
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse text-sm">
              <thead>
                <tr className="border-b border-[#E2E2DE] text-xs text-[#595959]">
                  <th className="py-3 pr-4 font-semibold">Caractéristique</th>
                  <th className="py-3 pr-4 font-semibold">Valeur</th>
                  <th className="py-3 font-semibold">Norme / Statut</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#E2E2DE]">
                <tr>
                  <td className="py-3 pr-4 font-medium">Longueur × Largeur × Hauteur</td>
                  <td className="py-3 pr-4 font-mono-tabular">
                    {model.dimensions.lengthMm} × {model.dimensions.widthMm} ×{" "}
                    {model.dimensions.heightMm} mm
                  </td>
                  <td className="py-3 text-xs text-[#595959]">
                    Gabarit hors rétroviseurs (démonstration)
                  </td>
                </tr>
                <tr>
                  <td className="py-3 pr-4 font-medium">Volume de coffre</td>
                  <td className="py-3 pr-4 font-mono-tabular">
                    {model.dimensions.bootVolumeLiters !== null
                      ? `${model.dimensions.bootVolumeLiters} L`
                      : "Non communiqué"}
                  </td>
                  <td className="py-3 text-xs text-[#595959]">
                    {model.dimensions.bootStandard}
                  </td>
                </tr>
                <tr>
                  <td className="py-3 pr-4 font-medium">Masse à vide</td>
                  <td className="py-3 pr-4 font-mono-tabular">
                    {model.dimensions.curbWeightKg !== null
                      ? `${model.dimensions.curbWeightKg} kg`
                      : "Non communiqué"}
                  </td>
                  <td className="py-3 text-xs text-[#595959]">
                    Norme DIN indicative (démonstration)
                  </td>
                </tr>
                <tr>
                  <td className="py-3 pr-4 font-medium">Masse remorquable freinée</td>
                  <td className="py-3 pr-4 font-mono-tabular">
                    {model.dimensions.towingCapacityKg !== null
                      ? `${model.dimensions.towingCapacityKg} kg`
                      : "Non communiqué"}
                  </td>
                  <td className="py-3 text-xs text-[#595959]">
                    {model.dimensions.towingCapacityKg !== null
                      ? "Valeur indicative de démonstration"
                      : "Non homologué ou non communiqué"}
                  </td>
                </tr>
                <tr>
                  <td className="py-3 pr-4 font-medium">Garantie commerciale constructeur</td>
                  <td className="py-3 pr-4">
                    {model.warrantySummary ?? "Non communiqué"}
                  </td>
                  <td className="py-3 text-xs text-[#595959]">
                    Aucune garantie officielle inventée
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      </section>

      {/* Comparaison des finitions */}
      <section className="max-w-[1440px] mx-auto px-4 sm:px-8 py-8 space-y-6">
        <h2 className="font-display text-3xl font-extrabold text-[#0D0D0D]">
          Comparaison des finitions
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {trims.map((trim) => (
            <div
              key={trim.id}
              className="bg-white border border-[#E2E2DE] p-6 flex flex-col justify-between space-y-6"
            >
              <div className="space-y-3">
                <div className="flex items-baseline justify-between gap-2">
                  <h3 className="font-display text-2xl font-bold text-[#0D0D0D]">
                    {trim.name}
                  </h3>
                  <span className="font-mono-tabular text-sm font-bold text-[#0D0D0D]">
                    {trim.priceDeltaCents === 0
                      ? "Base"
                      : `+ ${formatCentsEUR(trim.priceDeltaCents)}`}
                  </span>
                </div>
                <p className="text-xs text-[#595959]">{trim.subtitle}</p>
                <ul className="pt-3 border-t border-[#E2E2DE] space-y-2 text-sm">
                  {trim.includedEquipment.map((eq) => (
                    <li key={eq} className="flex items-start gap-2">
                      <Check
                        className="w-4 h-4 mt-0.5 shrink-0 text-[#0D0D0D]"
                        aria-hidden="true"
                      />
                      <span>{eq}</span>
                    </li>
                  ))}
                </ul>
              </div>
              <Link
                href={`/configurateur?modele=${model.slug}&finition=${trim.id}`}
                className="inline-flex items-center justify-center gap-2 bg-[#0D0D0D] text-white text-xs font-semibold py-3 px-4 hover:bg-[#262626] transition-colors"
              >
                <span>Configurer en {trim.name}</span>
                <ArrowRight className="w-3.5 h-3.5" aria-hidden="true" />
              </Link>
            </div>
          ))}
        </div>
      </section>

      {/* Véhicules physiques disponibles en stock */}
      <section className="max-w-[1440px] mx-auto px-4 sm:px-8 py-10 space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4">
          <div>
            <h2 className="font-display text-2xl sm:text-3xl font-extrabold text-[#0D0D0D]">
              Véhicules disponibles en stock ({stock.length})
            </h2>
            <p className="text-sm text-[#595959]">
              Exemplaires physiques de démonstration disponibles dans le réseau.
            </p>
          </div>
          <Link
            href={`/stock?modele=${model.slug}`}
            className="inline-flex items-center gap-2 text-sm font-semibold text-[#0D0D0D] hover:opacity-75"
          >
            <span>Filtrer tout le stock</span>
            <ArrowRight className="w-4 h-4" aria-hidden="true" />
          </Link>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {stock.map((v) => {
            const dealer = DEMO_DEALERS.find((d) => d.id === v.dealerId);
            return (
              <div
                key={v.id}
                className="bg-white border border-[#E2E2DE] p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-4"
              >
                <div className="space-y-1">
                  <div className="flex items-center gap-2 text-xs text-[#595959]">
                    <span>{v.vinDemo}</span>
                    <span aria-hidden="true">·</span>
                    <span>
                      {v.status === "available" ? "Disponible" : "Réservé"}
                    </span>
                  </div>
                  <p className="font-display text-lg font-bold text-[#0D0D0D]">
                    {v.trimName} · {v.motorisationName}
                  </p>
                  <p className="text-xs text-[#595959] flex items-center gap-1.5">
                    <MapPin className="w-3.5 h-3.5" aria-hidden="true" />
                    <span>
                      {dealer ? `${dealer.name} (${dealer.city})` : v.dealerId}
                    </span>
                  </p>
                </div>
                <div className="text-left sm:text-right space-y-2 shrink-0">
                  <p className="font-mono-tabular text-lg font-bold text-[#0D0D0D]">
                    {formatCentsEUR(v.priceCents)}
                  </p>
                  <Link
                    href={`/stock?modele=${model.slug}`}
                    className="inline-block border border-[#0D0D0D] px-4 py-2 text-xs font-semibold hover:bg-[#0D0D0D] hover:text-white transition-colors"
                  >
                    Vérifier &amp; réserver
                  </Link>
                </div>
              </div>
            );
          })}
        </div>
      </section>
    </div>
  );
}
