"use client";

import { useEffect, useMemo, useState } from "react";
import Link from "next/link";
import { CheckCircle2, LocateFixed, MapPin, RefreshCw } from "lucide-react";
import { INITIAL_STOCK_VEHICLES, VEHICLE_MODELS } from "@/lib/catalog/data";
import { StockVehicle } from "@/lib/catalog/types";
import {
  DEMO_DEALERS,
  POSTAL_PREFIX_COORDS,
  calculateDistanceKm,
} from "@/lib/dealers/data";
import { formatCentsEUR } from "@/lib/pricing/tariffs";
import { useAuth } from "@/components/providers/AuthProvider";
import {
  createCommercialRequest,
  fetchStockVehicles,
} from "@/lib/firebase/services";

export function StockClient({ initialModel = "all" }: { initialModel?: string }) {
  const { user, signInWithGoogle } = useAuth();
  const [stocks, setStocks] = useState<StockVehicle[]>(INITIAL_STOCK_VEHICLES);
  const [modelFilter, setModelFilter] = useState(initialModel);
  const [trimFilter, setTrimFilter] = useState("all");
  const [colorFilter, setColorFilter] = useState("all");
  const [maxPriceEuros, setMaxPriceEuros] = useState(70000);
  const [postalQuery, setPostalQuery] = useState("75008");
  const [maxDistanceKm, setMaxDistanceKm] = useState(1000);
  const [geoCoords, setGeoCoords] = useState<{ lat: number; lng: number } | null>(
    null
  );

  const [verifyingId, setVerifyingId] = useState<string | null>(null);
  const [verifiedMap, setVerifiedMap] = useState<
    Record<string, { verified: boolean; checkedAt: string; message: string }>
  >({});
  const [bookingStock, setBookingStock] = useState<StockVehicle | null>(null);
  const [custNameInput, setCustNameInput] = useState<string | null>(null);
  const [custEmailInput, setCustEmailInput] = useState<string | null>(null);
  const custName = custNameInput ?? user?.displayName ?? "";
  const custEmail = custEmailInput ?? user?.email ?? "";
  const [submitting, setSubmitting] = useState(false);
  const [feedback, setFeedback] = useState<string | null>(null);

  useEffect(() => {
    fetchStockVehicles().then(setStocks).catch(() => {});
  }, []);

  const userCoords = useMemo(() => {
    if (geoCoords) return geoCoords;
    const prefix = postalQuery.trim().slice(0, 2);
    return POSTAL_PREFIX_COORDS[prefix] ?? POSTAL_PREFIX_COORDS["75"];
  }, [geoCoords, postalQuery]);

  const handleGeolocate = () => {
    if (!navigator.geolocation) return;
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        setGeoCoords({
          lat: pos.coords.latitude,
          lng: pos.coords.longitude,
        });
      },
      () => {
        setFeedback("Géolocalisation refusée ou indisponible ; filtre par code postal maintenu.");
      }
    );
  };

  const enrichedStocks = useMemo(() => {
    return stocks
      .map((s) => {
        const dealer = DEMO_DEALERS.find((d) => d.id === s.dealerId);
        const distanceKm =
          dealer && userCoords
            ? calculateDistanceKm(
                userCoords.lat,
                userCoords.lng,
                dealer.lat,
                dealer.lng
              )
            : 0;
        return { stock: s, dealer, distanceKm };
      })
      .filter(({ stock, distanceKm }) => {
        if (modelFilter !== "all" && stock.modelSlug !== modelFilter) return false;
        if (trimFilter !== "all" && stock.trimName !== trimFilter) return false;
        if (colorFilter !== "all" && stock.colorName !== colorFilter) return false;
        if (stock.priceCents > maxPriceEuros * 100) return false;
        if (distanceKm > maxDistanceKm) return false;
        return true;
      })
      .sort((a, b) => a.distanceKm - b.distanceKm);
  }, [stocks, modelFilter, trimFilter, colorFilter, maxPriceEuros, maxDistanceKm, userCoords]);

  const trimOptions = useMemo(
    () => Array.from(new Set(stocks.map((s) => s.trimName))),
    [stocks]
  );
  const colorOptions = useMemo(
    () => Array.from(new Set(stocks.map((s) => s.colorName))),
    [stocks]
  );

  const handleVerifyAvailability = async (v: StockVehicle) => {
    setVerifyingId(v.id);
    setFeedback(null);
    try {
      const res = await fetch("/api/stock/verify", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ vehicleId: v.id, observedStatus: v.status }),
      });
      const data = await res.json();
      setVerifiedMap((prev) => ({
        ...prev,
        [v.id]: {
          verified: Boolean(data.verified),
          checkedAt: data.checkedAt,
          message: data.message,
        },
      }));
      if (data.verified) {
        setBookingStock(v);
      } else {
        setFeedback(data.message);
      }
    } finally {
      setVerifyingId(null);
    }
  };

  const handleConfirmStockReservation = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!bookingStock) return;
    const activeUser = user || (await signInWithGoogle());
    if (!activeUser) return;

    setSubmitting(true);
    try {
      const created = await createCommercialRequest({
        ownerUid: activeUser.uid,
        requestType: "stock_reservation",
        modelSlug: bookingStock.modelSlug,
        dealerId: bookingStock.dealerId,
        stockVehicleId: bookingStock.id,
        estimatedTotalCents: bookingStock.priceCents,
        customerName: custName,
        customerEmail: custEmail,
        message: `Demande de réservation véhicule en stock ${bookingStock.vinDemo}`,
      });
      setFeedback(
        `Demande de réservation reçue (${created.id}) pour le châssis ${bookingStock.vinDemo}.`
      );
      setBookingStock(null);
    } catch (err) {
      setFeedback(
        err instanceof Error ? err.message : "Erreur lors de l'envoi."
      );
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="max-w-[1440px] mx-auto px-4 sm:px-8 py-10 space-y-8">
      <div className="border-b border-[#E2E2DE] pb-6 flex flex-col lg:flex-row lg:items-end justify-between gap-4">
        <div>
          <p className="text-xs font-bold tracking-[0.14em] text-[#595959]">
            INVENTAIRE PHYSIQUE DE DÉMONSTRATION
          </p>
          <h1 className="font-display text-3xl sm:text-4xl font-extrabold text-[#0D0D0D]">
            Véhicules disponibles en stock
          </h1>
          <p className="text-sm text-[#595959] mt-1">
            Chaque demande de réservation déclenche une revérification serveur
            préalable de la disponibilité.
          </p>
        </div>
        <Link
          href="/configurateur"
          className="inline-flex items-center justify-center bg-[#0D0D0D] text-white text-xs font-semibold px-5 py-3"
        >
          Ou configurer un véhicule neuf
        </Link>
      </div>

      {/* Filtres */}
      <div className="bg-white border border-[#E2E2DE] p-5 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-6 gap-4 text-xs">
        <div>
          <label htmlFor="f-model" className="block font-semibold mb-1">
            Modèle
          </label>
          <select
            id="f-model"
            value={modelFilter}
            onChange={(e) => setModelFilter(e.target.value)}
            className="w-full border border-[#E2E2DE] bg-white px-2.5 py-2"
          >
            <option value="all">Tous</option>
            {VEHICLE_MODELS.map((m) => (
              <option key={m.slug} value={m.slug}>
                {m.shortName}
              </option>
            ))}
          </select>
        </div>
        <div>
          <label htmlFor="f-trim" className="block font-semibold mb-1">
            Finition
          </label>
          <select
            id="f-trim"
            value={trimFilter}
            onChange={(e) => setTrimFilter(e.target.value)}
            className="w-full border border-[#E2E2DE] bg-white px-2.5 py-2"
          >
            <option value="all">Toutes</option>
            {trimOptions.map((t) => (
              <option key={t} value={t}>
                {t}
              </option>
            ))}
          </select>
        </div>
        <div>
          <label htmlFor="f-color" className="block font-semibold mb-1">
            Couleur
          </label>
          <select
            id="f-color"
            value={colorFilter}
            onChange={(e) => setColorFilter(e.target.value)}
            className="w-full border border-[#E2E2DE] bg-white px-2.5 py-2"
          >
            <option value="all">Toutes</option>
            {colorOptions.map((c) => (
              <option key={c} value={c}>
                {c}
              </option>
            ))}
          </select>
        </div>
        <div>
          <label htmlFor="f-price" className="block font-semibold mb-1">
            Prix max ({maxPriceEuros.toLocaleString("fr-FR")} €)
          </label>
          <input
            id="f-price"
            type="range"
            min={28000}
            max={70000}
            step={1000}
            value={maxPriceEuros}
            onChange={(e) => setMaxPriceEuros(Number(e.target.value))}
            className="w-full accent-[#0D0D0D] mt-2"
          />
        </div>
        <div>
          <label htmlFor="f-cp" className="block font-semibold mb-1">
            Code postal (distance)
          </label>
          <div className="flex gap-1">
            <input
              id="f-cp"
              type="text"
              value={postalQuery}
              onChange={(e) => setPostalQuery(e.target.value)}
              maxLength={5}
              className="w-full border border-[#E2E2DE] px-2.5 py-2 font-mono-tabular"
            />
            <button
              type="button"
              onClick={handleGeolocate}
              title="Me géolocaliser"
              aria-label="Utiliser ma géolocalisation"
              className="border border-[#E2E2DE] px-2.5 hover:border-[#0D0D0D]"
            >
              <LocateFixed className="w-4 h-4" aria-hidden="true" />
            </button>
          </div>
        </div>
        <div>
          <label htmlFor="f-dist" className="block font-semibold mb-1">
            Rayon max ({maxDistanceKm} km)
          </label>
          <select
            id="f-dist"
            value={maxDistanceKm}
            onChange={(e) => setMaxDistanceKm(Number(e.target.value))}
            className="w-full border border-[#E2E2DE] bg-white px-2.5 py-2"
          >
            <option value={50}>50 km</option>
            <option value={250}>250 km</option>
            <option value={500}>500 km</option>
            <option value={1000}>Toute la France</option>
          </select>
        </div>
      </div>

      {feedback && (
        <div
          role="status"
          className="border border-[#0D0D0D] bg-[#F7E300]/25 px-4 py-3 text-sm font-medium"
        >
          {feedback}
        </div>
      )}

      {/* Liste stock */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {enrichedStocks.map(({ stock, dealer, distanceKm }) => {
          const model = VEHICLE_MODELS.find((m) => m.slug === stock.modelSlug);
          const verified = verifiedMap[stock.id];
          return (
            <article
              key={stock.id}
              className="bg-white border border-[#E2E2DE] p-6 space-y-4"
            >
              <div className="flex items-start justify-between gap-4 border-b border-[#E2E2DE] pb-4">
                <div className="space-y-1">
                  <p className="text-xs text-[#595959]">
                    {stock.vinDemo} · Millésime {stock.modelYear} ·{" "}
                    {stock.mileageKm} km
                  </p>
                  <h2 className="font-display text-xl font-bold text-[#0D0D0D]">
                    {model?.shortName} · {stock.trimName}
                  </h2>
                  <p className="text-xs text-[#595959]">
                    {stock.motorisationName}
                  </p>
                </div>
                <div className="text-right shrink-0">
                  <p className="font-mono-tabular text-xl font-extrabold text-[#0D0D0D]">
                    {formatCentsEUR(stock.priceCents)}
                  </p>
                  <p className="text-xs font-semibold text-[#0D0D0D]">
                    {stock.status === "available"
                      ? "Disponible"
                      : stock.status === "reserved"
                      ? "Réservé"
                      : "Vendu"}
                  </p>
                </div>
              </div>

              <div className="flex flex-wrap items-center justify-between gap-3 text-xs text-[#595959]">
                <span className="inline-flex items-center gap-2">
                  <span
                    className="w-3.5 h-3.5 border border-[#0D0D0D]/30"
                    style={{ backgroundColor: stock.colorHex }}
                    aria-hidden="true"
                  />
                  <span>{stock.colorName}</span>
                </span>
                <span className="inline-flex items-center gap-1">
                  <MapPin className="w-3.5 h-3.5" aria-hidden="true" />
                  <span>
                    {dealer?.city} ({distanceKm} km)
                  </span>
                </span>
              </div>

              <div className="pt-2 flex flex-wrap items-center justify-between gap-3 border-t border-[#E2E2DE]">
                <span className="text-[11px] text-[#595959]">
                  Stock mis à jour le{" "}
                  {new Date(stock.stockUpdatedAt).toLocaleString("fr-FR")}
                </span>
                <button
                  type="button"
                  onClick={() => handleVerifyAvailability(stock)}
                  disabled={verifyingId === stock.id}
                  className="inline-flex items-center gap-2 bg-[#0D0D0D] text-white text-xs font-semibold px-4 py-2.5 hover:bg-[#262626] disabled:opacity-50"
                >
                  <RefreshCw className="w-3.5 h-3.5" aria-hidden="true" />
                  <span>
                    {verifyingId === stock.id
                      ? "Vérification…"
                      : "Revérifier & réserver"}
                  </span>
                </button>
              </div>

              {verified && (
                <p className="text-xs flex items-center gap-1.5 text-[#0D0D0D]">
                  <CheckCircle2 className="w-4 h-4 shrink-0" aria-hidden="true" />
                  <span>
                    {verified.message} (vérifié à{" "}
                    {new Date(verified.checkedAt).toLocaleTimeString("fr-FR")})
                  </span>
                </p>
              )}
            </article>
          );
        })}
      </div>

      {/* Formulaire modal/inline de réservation de stock après revérification */}
      {bookingStock && (
        <div className="bg-white border-2 border-[#0D0D0D] p-6 space-y-4">
          <div className="flex items-center justify-between gap-4">
            <h2 className="font-display text-xl font-bold">
              Confirmer la demande de réservation — {bookingStock.vinDemo}
            </h2>
            <button
              type="button"
              onClick={() => setBookingStock(null)}
              className="text-xs underline"
            >
              Fermer
            </button>
          </div>
          <form
            onSubmit={handleConfirmStockReservation}
            className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-sm"
          >
            <input
              type="text"
              required
              placeholder="Nom complet"
              value={custName}
              onChange={(e) => setCustNameInput(e.target.value)}
              className="border border-[#E2E2DE] px-3 py-2"
            />
            <input
              type="email"
              required
              placeholder="Adresse e-mail"
              value={custEmail}
              onChange={(e) => setCustEmailInput(e.target.value)}
              className="border border-[#E2E2DE] px-3 py-2"
            />
            <button
              type="submit"
              disabled={submitting}
              className="bg-[#0D0D0D] text-white text-xs font-semibold px-4 py-2.5"
            >
              {submitting ? "Envoi…" : "Envoyer la demande"}
            </button>
          </form>
        </div>
      )}
    </div>
  );
}
