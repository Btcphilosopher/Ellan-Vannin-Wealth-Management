"use client";

import { useEffect, useMemo, useState } from "react";
import Link from "next/link";
import { Plus, Trash2 } from "lucide-react";
import {
  BATTERIES,
  MOTORISATIONS,
  TRIMS,
  VEHICLE_MODELS,
} from "@/lib/catalog/data";
import { formatCentsEUR } from "@/lib/pricing/tariffs";
import { useCompare } from "@/components/providers/CompareProvider";
import { useAuth } from "@/components/providers/AuthProvider";
import {
  SavedConfigurationDoc,
  fetchUserConfigurations,
} from "@/lib/firebase/services";
import { VehicleImage } from "@/components/common/VehicleImage";

export function CompareClient() {
  const { items, addItem, removeItem } = useCompare();
  const { user } = useAuth();
  const [savedConfigs, setSavedConfigs] = useState<SavedConfigurationDoc[]>([]);
  const [selectedModelSlug, setSelectedModelSlug] =
    useState<(typeof VEHICLE_MODELS)[number]["slug"]>("rafale-e-tech");
  const [selectedMotoId, setSelectedMotoId] = useState("moto-rafale-200");
  const [selectedTrimId, setSelectedTrimId] = useState("trim-rafale-esprit");
  const [onlyDifferences, setOnlyDifferences] = useState(false);
  const [notice, setNotice] = useState<string | null>(null);

  useEffect(() => {
    if (!user) return;
    let active = true;
    fetchUserConfigurations(user.uid)
      .then((list) => {
        if (active) setSavedConfigs(list);
      })
      .catch(() => {});
    return () => {
      active = false;
    };
  }, [user]);

  const modelMotos = useMemo(
    () => MOTORISATIONS.filter((m) => m.modelSlug === selectedModelSlug),
    [selectedModelSlug]
  );
  const modelTrims = useMemo(
    () => TRIMS.filter((t) => t.modelSlug === selectedModelSlug),
    [selectedModelSlug]
  );

  const handleModelSwitch = (slug: (typeof VEHICLE_MODELS)[number]["slug"]) => {
    setSelectedModelSlug(slug);
    const firstMoto = MOTORISATIONS.find((m) => m.modelSlug === slug)!;
    const firstTrim = TRIMS.find((t) => t.modelSlug === slug)!;
    setSelectedMotoId(firstMoto.id);
    setSelectedTrimId(firstTrim.id);
  };

  const handleAddPreset = () => {
    const model = VEHICLE_MODELS.find((m) => m.slug === selectedModelSlug)!;
    const moto = MOTORISATIONS.find((m) => m.id === selectedMotoId)!;
    const trim = TRIMS.find((t) => t.id === selectedTrimId)!;
    const res = addItem({
      id: `catalog-${model.slug}-${moto.id}-${trim.id}`,
      source: "catalog",
      label: `${model.shortName} · ${moto.powerCh} ch ${trim.name}`,
      modelSlug: model.slug,
      motorisationId: moto.id,
      trimId: trim.id,
    });
    setNotice(res.ok ? "Ajouté au comparateur." : res.message || "Limite atteinte.");
  };

  const handleAddSaved = (cfg: SavedConfigurationDoc) => {
    const res = addItem({
      id: `saved-${cfg.id}`,
      source: "saved",
      label: cfg.title,
      modelSlug: cfg.modelSlug,
      motorisationId: cfg.motorisationId,
      trimId: cfg.trimId,
      colorId: cfg.colorId,
      wheelId: cfg.wheelId,
      interiorId: cfg.interiorId,
      optionIds: cfg.optionIds,
      totalKnownCents: cfg.totalKnownCents,
      tariffVersion: cfg.tariffVersion,
    });
    setNotice(
      res.ok ? `"${cfg.title}" ajouté au comparateur.` : res.message || "Limite atteinte."
    );
  };

  const resolvedColumns = items.map((item) => {
    const model = VEHICLE_MODELS.find((m) => m.slug === item.modelSlug)!;
    const moto = MOTORISATIONS.find((m) => m.id === item.motorisationId)!;
    const trim = TRIMS.find((t) => t.id === item.trimId)!;
    const battery = BATTERIES.find((b) => b.id === moto.batteryId)!;
    const estimatedVehicleCents =
      item.totalKnownCents ??
      model.basePriceCents + moto.priceDeltaCents + trim.priceDeltaCents;

    return {
      item,
      model,
      moto,
      trim,
      battery,
      estimatedVehicleCents,
    };
  });

  const rows = [
    {
      label: "Source / Type",
      values: resolvedColumns.map((c) =>
        c.item.source === "saved"
          ? `Configuration sauvegardée (${c.item.tariffVersion || "démo"})`
          : "Catalogue démonstration"
      ),
    },
    {
      label: "Tarif indicatif (centimes)",
      values: resolvedColumns.map((c) =>
        formatCentsEUR(c.estimatedVehicleCents, true)
      ),
    },
    {
      label: "Énergie",
      values: resolvedColumns.map((c) => c.moto.energy),
    },
    {
      label: "Puissance maximale",
      values: resolvedColumns.map(
        (c) => `${c.moto.powerCh} ch (${c.moto.powerKw} kW)`
      ),
    },
    {
      label: "Couple maximal",
      values: resolvedColumns.map((c) =>
        c.moto.torqueNm !== null ? `${c.moto.torqueNm} Nm` : "Non communiqué"
      ),
    },
    {
      label: "Autonomie (WLTP cycle mixte démo)",
      values: resolvedColumns.map((c) =>
        c.moto.wltpRangeKm !== null ? `${c.moto.wltpRangeKm} km` : "Non communiqué"
      ),
    },
    {
      label: "Batterie & Recharge DC",
      values: resolvedColumns.map((c) =>
        c.battery.dcMaxKw !== null
          ? `${c.battery.usableKwh} kWh · ${c.battery.dcMaxKw} kW DC`
          : `${c.battery.usableKwh} kWh · Recharge DC non applicable`
      ),
    },
    {
      label: "Volume de coffre (VDA démo)",
      values: resolvedColumns.map((c) =>
        c.model.dimensions.bootVolumeLiters !== null
          ? `${c.model.dimensions.bootVolumeLiters} L`
          : "Non communiqué"
      ),
    },
    {
      label: "Masse remorquable freinée",
      values: resolvedColumns.map((c) =>
        c.model.dimensions.towingCapacityKg !== null
          ? `${c.model.dimensions.towingCapacityKg} kg`
          : "Non communiqué"
      ),
    },
    {
      label: "Garantie constructeur",
      values: resolvedColumns.map(
        (c) => c.model.warrantySummary ?? "Non communiqué"
      ),
    },
  ];

  const displayedRows = onlyDifferences
    ? rows.filter((r) => new Set(r.values).size > 1)
    : rows;

  return (
    <div className="max-w-[1440px] mx-auto px-4 sm:px-8 py-10 space-y-8">
      <div className="border-b border-[#E2E2DE] pb-6 flex flex-col lg:flex-row lg:items-end justify-between gap-4">
        <div>
          <p className="text-xs font-bold tracking-[0.14em] text-[#595959]">
            COMPARATEUR TECHNIQUE · JUSQU&apos;À 3 VÉHICULES OU CONFIGURATIONS
          </p>
          <h1 className="font-display text-3xl sm:text-4xl font-extrabold text-[#0D0D0D]">
            Comparer les véhicules
          </h1>
          <p className="text-sm text-[#595959] mt-1">
            Les normes de mesure sont explicitement identifiées. Toute donnée
            non publiée est affichée comme « Non communiqué ».
          </p>
        </div>
        <label className="inline-flex items-center gap-2 text-sm font-medium cursor-pointer">
          <input
            type="checkbox"
            checked={onlyDifferences}
            onChange={(e) => setOnlyDifferences(e.target.checked)}
            className="w-4 h-4 accent-[#0D0D0D]"
          />
          <span>Afficher uniquement les différences</span>
        </label>
      </div>

      {/* Ajout rapide catalogue + configurations sauvegardées */}
      <div className="bg-white border border-[#E2E2DE] p-5 space-y-4">
        <p className="font-display text-lg font-bold">
          Ajouter au comparateur ({items.length}/3)
        </p>
        <div className="grid grid-cols-1 md:grid-cols-4 gap-3 text-sm">
          <select
            aria-label="Modèle à ajouter"
            value={selectedModelSlug}
            onChange={(e) =>
              handleModelSwitch(
                e.target.value as (typeof VEHICLE_MODELS)[number]["slug"]
              )
            }
            className="border border-[#E2E2DE] bg-white px-3 py-2"
          >
            {VEHICLE_MODELS.map((m) => (
              <option key={m.slug} value={m.slug}>
                {m.shortName}
              </option>
            ))}
          </select>
          <select
            aria-label="Motorisation à ajouter"
            value={selectedMotoId}
            onChange={(e) => setSelectedMotoId(e.target.value)}
            className="border border-[#E2E2DE] bg-white px-3 py-2"
          >
            {modelMotos.map((m) => (
              <option key={m.id} value={m.id}>
                {m.name}
              </option>
            ))}
          </select>
          <select
            aria-label="Finition à ajouter"
            value={selectedTrimId}
            onChange={(e) => setSelectedTrimId(e.target.value)}
            className="border border-[#E2E2DE] bg-white px-3 py-2"
          >
            {modelTrims.map((t) => (
              <option key={t.id} value={t.id}>
                {t.name}
              </option>
            ))}
          </select>
          <button
            type="button"
            onClick={handleAddPreset}
            disabled={items.length >= 3}
            className="inline-flex items-center justify-center gap-2 bg-[#0D0D0D] text-white text-xs font-semibold px-4 py-2.5 hover:bg-[#262626] disabled:opacity-40"
          >
            <Plus className="w-4 h-4" aria-hidden="true" />
            <span>Ajouter ce modèle</span>
          </button>
        </div>

        {savedConfigs.length > 0 && (
          <div className="pt-3 border-t border-[#E2E2DE] flex flex-wrap items-center gap-2">
            <span className="text-xs font-semibold text-[#595959]">
              Vos configurations sauvegardées :
            </span>
            {savedConfigs.map((cfg) => (
              <button
                key={cfg.id}
                type="button"
                onClick={() => handleAddSaved(cfg)}
                disabled={items.length >= 3}
                className="text-xs border border-[#E2E2DE] px-3 py-1.5 hover:border-[#0D0D0D] disabled:opacity-40"
              >
                + {cfg.title}
              </button>
            ))}
          </div>
        )}

        {notice && (
          <p role="status" className="text-xs font-medium text-[#0D0D0D]">
            {notice}
          </p>
        )}
      </div>

      {/* Tableau comparatif */}
      {resolvedColumns.length === 0 ? (
        <div className="bg-white border border-[#E2E2DE] p-8 text-center space-y-3">
          <p className="text-sm text-[#595959]">
            Aucun véhicule sélectionné dans le comparateur.
          </p>
          <Link
            href="/vehicules"
            className="inline-block bg-[#0D0D0D] text-white text-xs font-semibold px-5 py-2.5"
          >
            Parcourir le catalogue
          </Link>
        </div>
      ) : (
        <div className="bg-white border border-[#E2E2DE] overflow-x-auto">
          <table className="w-full text-left border-collapse min-w-[680px]">
            <thead>
              <tr className="border-b border-[#E2E2DE] align-top">
                <th className="w-56 p-4 text-xs font-semibold text-[#595959]">
                  Critère comparé
                </th>
                {resolvedColumns.map((col) => (
                  <th key={col.item.id} className="p-4 border-l border-[#E2E2DE]">
                    <div className="space-y-3">
                      <div className="relative aspect-[16/10] w-full bg-[#ECECE9] overflow-hidden">
                        <VehicleImage
                          src={col.model.cardImage}
                          alt={col.model.name}
                          fill
                          sizes="300px"
                          className="object-cover"
                        />
                      </div>
                      <div className="flex items-start justify-between gap-2">
                        <div>
                          <p className="font-display text-base font-bold text-[#0D0D0D]">
                            {col.item.label}
                          </p>
                          <p className="text-xs text-[#595959] font-normal">
                            {col.trim.name}
                          </p>
                        </div>
                        <button
                          type="button"
                          onClick={() => removeItem(col.item.id)}
                          aria-label={`Retirer ${col.item.label}`}
                          className="p-1.5 text-[#595959] hover:text-[#B91C1C]"
                        >
                          <Trash2 className="w-4 h-4" aria-hidden="true" />
                        </button>
                      </div>
                    </div>
                  </th>
                ))}
              </tr>
            </thead>
            <tbody className="divide-y divide-[#E2E2DE] text-sm">
              {displayedRows.map((row) => (
                <tr key={row.label}>
                  <th
                    scope="row"
                    className="p-4 text-xs font-semibold text-[#595959] bg-[#FAF9F6]"
                  >
                    {row.label}
                  </th>
                  {row.values.map((val, idx) => (
                    <td
                      key={`${row.label}-${idx}`}
                      className="p-4 border-l border-[#E2E2DE] font-mono-tabular text-xs sm:text-sm"
                    >
                      {val}
                    </td>
                  ))}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
