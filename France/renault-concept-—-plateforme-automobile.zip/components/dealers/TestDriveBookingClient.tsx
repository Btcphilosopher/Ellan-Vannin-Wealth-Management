"use client";

import { useEffect, useMemo, useState } from "react";
import Link from "next/link";
import { CalendarClock, CheckCircle2 } from "lucide-react";
import { VEHICLE_MODELS } from "@/lib/catalog/data";
import {
  DEMO_DEALERS,
  INITIAL_DEALER_SLOTS,
} from "@/lib/dealers/data";
import { useAuth } from "@/components/providers/AuthProvider";
import {
  DealerSlotDoc,
  TestDriveRequestDoc,
  bookTestDriveAtomic,
  fetchDealerSlots,
} from "@/lib/firebase/services";

interface TestDriveBookingClientProps {
  initialModelSlug?: string;
  initialDealerId?: string;
  initialSlotId?: string;
}

export function TestDriveBookingClient({
  initialModelSlug = "renault-5-e-tech",
  initialDealerId = DEMO_DEALERS[0].id,
  initialSlotId,
}: TestDriveBookingClientProps) {
  const { user, signInWithGoogle } = useAuth();

  const [modelSlug, setModelSlug] = useState(initialModelSlug);
  const [dealerId, setDealerId] = useState(initialDealerId);
  const [liveSlots, setLiveSlots] = useState<DealerSlotDoc[]>([]);
  const [selectedSlotId, setSelectedSlotId] = useState<string>(
    initialSlotId || ""
  );
  const [customerNameInput, setCustomerNameInput] = useState<string | null>(null);
  const [customerEmailInput, setCustomerEmailInput] = useState<string | null>(null);
  const customerName = customerNameInput ?? user?.displayName ?? "";
  const customerEmail = customerEmailInput ?? user?.email ?? "";
  const [customerPhone, setCustomerPhone] = useState("");
  const [notes, setNotes] = useState("");
  const [idempotencyKey, setIdempotencyKey] = useState(() =>
    `req_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`
  );

  const [submitting, setSubmitting] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [confirmedResult, setConfirmedResult] =
    useState<TestDriveRequestDoc | null>(null);

  const reloadSlots = async (targetDealer: string) => {
    try {
      const list = await fetchDealerSlots(targetDealer);
      setLiveSlots(list);
    } catch {
      // Fallback seed
    }
  };

  useEffect(() => {
    let active = true;
    fetchDealerSlots(dealerId)
      .then((list) => {
        if (active) setLiveSlots(list);
      })
      .catch(() => {});
    return () => {
      active = false;
    };
  }, [dealerId]);

  const dealerSlots = useMemo(() => {
    const seeds = INITIAL_DEALER_SLOTS.filter((s) => s.dealerId === dealerId);
    return seeds.map((seed) => {
      const live = liveSlots.find((l) => l.id === seed.id);
      return live ? { ...seed, status: live.status } : seed;
    });
  }, [dealerId, liveSlots]);

  const selectedSlot = dealerSlots.find((s) => s.id === selectedSlotId);
  const selectedDealer = DEMO_DEALERS.find((d) => d.id === dealerId)!;
  const selectedModel = VEHICLE_MODELS.find((m) => m.slug === modelSlug)!;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);

    if (!selectedSlot || selectedSlot.status !== "available") {
      setErrorMsg("Veuillez sélectionner un créneau disponible.");
      return;
    }

    const activeUser = user || (await signInWithGoogle());
    if (!activeUser) return;

    setSubmitting(true);
    try {
      const created = await bookTestDriveAtomic({
        ownerUid: activeUser.uid,
        modelSlug,
        dealerId,
        slotId: selectedSlot.id,
        dateIso: selectedSlot.dateIso,
        timeSlot: selectedSlot.timeSlot,
        slotLabel: `${selectedSlot.dateIso} à ${selectedSlot.timeSlot}`,
        customerName,
        customerEmail,
        customerPhone,
        notes,
        idempotencyKey,
      });
      setConfirmedResult(created);
      await reloadSlots(dealerId);
      setIdempotencyKey(
        `req_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`
      );
    } catch (err) {
      setErrorMsg(
        err instanceof Error
          ? err.message
          : "Impossible d'enregistrer la demande d'essai."
      );
      await reloadSlots(dealerId);
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="max-w-[1160px] mx-auto px-4 sm:px-8 py-10 space-y-8">
      <div className="border-b border-[#E2E2DE] pb-6">
        <p className="text-xs font-bold tracking-[0.14em] text-[#595959]">
          PARCOURS DE RÉSERVATION D&apos;ESSAI
        </p>
        <h1 className="font-display text-3xl sm:text-4xl font-extrabold text-[#0D0D0D]">
          Réserver un essai en concession
        </h1>
        <p className="text-sm text-[#595959] mt-1">
          Une demande soumise est d&apos;abord enregistrée au statut « Demande
          reçue », puis passe à « Rendez-vous confirmé » après validation depuis
          l&apos;administration.
        </p>
      </div>

      {confirmedResult ? (
        <div className="bg-white border-2 border-[#0D0D0D] p-6 sm:p-8 space-y-4">
          <div className="flex items-start gap-3">
            <CheckCircle2 className="w-6 h-6 shrink-0 mt-0.5" aria-hidden="true" />
            <div className="space-y-1">
              <p className="text-xs font-bold tracking-wide text-[#595959]">
                STATUT ACTUEL : DEMANDE REÇUE (EN ATTENTE DE CONFIRMATION CONCESSIONNAIRE)
              </p>
              <h2 className="font-display text-2xl font-extrabold">
                Demande d&apos;essai enregistrée ({confirmedResult.id})
              </h2>
            </div>
          </div>

          <dl className="grid grid-cols-1 sm:grid-cols-3 gap-4 border-t border-b border-[#E2E2DE] py-4 text-sm">
            <div>
              <dt className="text-xs text-[#595959]">Modèle</dt>
              <dd className="font-semibold">{selectedModel.name}</dd>
            </div>
            <div>
              <dt className="text-xs text-[#595959]">Concessionnaire</dt>
              <dd className="font-semibold">{selectedDealer.name}</dd>
            </div>
            <div>
              <dt className="text-xs text-[#595959]">Créneau verrouillé</dt>
              <dd className="font-mono-tabular font-semibold">
                {confirmedResult.slotLabel}
              </dd>
            </div>
          </dl>

          <div className="flex flex-wrap gap-3">
            <Link
              href="/compte"
              className="bg-[#0D0D0D] text-white text-xs font-semibold px-5 py-3"
            >
              Suivre dans Mon compte
            </Link>
            <button
              type="button"
              onClick={() => setConfirmedResult(null)}
              className="border border-[#0D0D0D] bg-white text-xs font-semibold px-5 py-3"
            >
              Effectuer une autre demande
            </button>
          </div>
        </div>
      ) : (
        <form onSubmit={handleSubmit} className="space-y-8">
          {/* 1. Choisir un modèle */}
          <section className="bg-white border border-[#E2E2DE] p-6 space-y-4">
            <h2 className="font-display text-xl font-bold">
              01. Choisir un modèle
            </h2>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              {VEHICLE_MODELS.map((m) => (
                <button
                  key={m.slug}
                  type="button"
                  onClick={() => setModelSlug(m.slug)}
                  className={`text-left border p-4 transition-colors ${
                    modelSlug === m.slug
                      ? "border-[#0D0D0D] bg-[#FAF9F6]"
                      : "border-[#E2E2DE] hover:border-[#0D0D0D]"
                  }`}
                >
                  <p className="font-display font-bold text-base">
                    {m.shortName}
                  </p>
                  <p className="text-xs text-[#595959]">{m.tagline}</p>
                </button>
              ))}
            </div>
          </section>

          {/* 2. Sélectionner un concessionnaire */}
          <section className="bg-white border border-[#E2E2DE] p-6 space-y-4">
            <h2 className="font-display text-xl font-bold">
              02. Sélectionner un concessionnaire
            </h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              {DEMO_DEALERS.map((d) => (
                <button
                  key={d.id}
                  type="button"
                  onClick={() => {
                    setDealerId(d.id);
                    setSelectedSlotId("");
                  }}
                  className={`text-left border p-4 transition-colors ${
                    dealerId === d.id
                      ? "border-[#0D0D0D] bg-[#FAF9F6]"
                      : "border-[#E2E2DE] hover:border-[#0D0D0D]"
                  }`}
                >
                  <p className="text-xs text-[#595959]">
                    {d.postalCode} {d.city}
                  </p>
                  <p className="font-semibold text-sm text-[#0D0D0D]">
                    {d.name}
                  </p>
                  <p className="text-xs text-[#595959] mt-1">{d.hours}</p>
                </button>
              ))}
            </div>
          </section>

          {/* 3. Choisir un créneau */}
          <section className="bg-white border border-[#E2E2DE] p-6 space-y-4">
            <div className="flex items-center justify-between">
              <h2 className="font-display text-xl font-bold">
                03. Choisir un créneau horaire
              </h2>
              <span className="text-xs text-[#595959] inline-flex items-center gap-1.5">
                <CalendarClock className="w-4 h-4" aria-hidden="true" />
                <span>Verrouillage atomique anti-double réservation</span>
              </span>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-2.5">
              {dealerSlots.map((slot) => {
                const available = slot.status === "available";
                const active = selectedSlotId === slot.id;
                return (
                  <button
                    key={slot.id}
                    type="button"
                    disabled={!available}
                    onClick={() => setSelectedSlotId(slot.id)}
                    className={`border p-3 text-left transition-colors ${
                      !available
                        ? "border-[#E2E2DE] bg-[#F3F3F1] text-[#8A8A85] cursor-not-allowed"
                        : active
                        ? "border-[#0D0D0D] bg-[#0D0D0D] text-white"
                        : "border-[#E2E2DE] bg-white hover:border-[#0D0D0D]"
                    }`}
                  >
                    <span className="block font-mono-tabular text-xs font-semibold">
                      {slot.dateIso}
                    </span>
                    <span className="block font-mono-tabular text-sm font-bold">
                      {slot.timeSlot}
                    </span>
                    <span
                      className={`block text-[11px] mt-1 ${
                        active ? "text-[#F7E300]" : "text-[#595959]"
                      }`}
                    >
                      {slot.status === "available"
                        ? "Disponible"
                        : slot.status === "booked"
                        ? "Déjà réservé"
                        : "Fermé"}
                    </span>
                  </button>
                );
              })}
            </div>
          </section>

          {/* 4. Coordonnées & confirmation */}
          <section className="bg-white border border-[#E2E2DE] p-6 space-y-4">
            <h2 className="font-display text-xl font-bold">
              04. Vos coordonnées &amp; confirmation de la demande
            </h2>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-sm">
              <div>
                <label
                  htmlFor="td-name"
                  className="block text-xs text-[#595959] mb-1"
                >
                  Nom complet
                </label>
                <input
                  id="td-name"
                  type="text"
                  required
                  minLength={2}
                  value={customerName}
                  onChange={(e) => setCustomerNameInput(e.target.value)}
                  className="w-full border border-[#E2E2DE] px-3 py-2.5"
                />
              </div>
              <div>
                <label
                  htmlFor="td-email"
                  className="block text-xs text-[#595959] mb-1"
                >
                  Adresse e-mail
                </label>
                <input
                  id="td-email"
                  type="email"
                  required
                  value={customerEmail}
                  onChange={(e) => setCustomerEmailInput(e.target.value)}
                  className="w-full border border-[#E2E2DE] px-3 py-2.5"
                />
              </div>
              <div>
                <label
                  htmlFor="td-phone"
                  className="block text-xs text-[#595959] mb-1"
                >
                  Téléphone
                </label>
                <input
                  id="td-phone"
                  type="tel"
                  required
                  minLength={6}
                  placeholder="06 00 00 00 00"
                  value={customerPhone}
                  onChange={(e) => setCustomerPhone(e.target.value)}
                  className="w-full border border-[#E2E2DE] px-3 py-2.5"
                />
              </div>
              <div className="sm:col-span-3">
                <label
                  htmlFor="td-notes"
                  className="block text-xs text-[#595959] mb-1"
                >
                  Commentaire pour le conseiller (facultatif)
                </label>
                <input
                  id="td-notes"
                  type="text"
                  maxLength={500}
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  className="w-full border border-[#E2E2DE] px-3 py-2.5"
                />
              </div>
            </div>

            {errorMsg && (
              <p
                role="alert"
                className="text-sm text-[#991B1B] bg-[#FEF2F2] border border-[#B91C1C] px-4 py-3"
              >
                {errorMsg}
              </p>
            )}

            <div className="pt-2 flex flex-wrap items-center justify-between gap-4">
              <p className="text-xs text-[#595959]">
                {user
                  ? `Connecté en tant que ${user.email}`
                  : "Connexion Google requise au moment de l'envoi pour sécuriser votre réservation."}
              </p>
              <button
                type="submit"
                disabled={submitting}
                className="bg-[#0D0D0D] text-white text-sm font-semibold px-7 py-3.5 hover:bg-[#262626] disabled:opacity-50"
              >
                {submitting
                  ? "Enregistrement en cours…"
                  : "Confirmer la demande d'essai"}
              </button>
            </div>
          </section>
        </form>
      )}
    </div>
  );
}
