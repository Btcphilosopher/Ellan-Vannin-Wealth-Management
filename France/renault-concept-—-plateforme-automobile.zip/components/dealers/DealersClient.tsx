"use client";

import { useEffect, useMemo, useState } from "react";
import Link from "next/link";
import { Clock, LocateFixed, MapPin, Phone, Search } from "lucide-react";
import {
  DEMO_DEALERS,
  DealerInfo,
  INITIAL_DEALER_SLOTS,
  POSTAL_PREFIX_COORDS,
  calculateDistanceKm,
} from "@/lib/dealers/data";
import { DealerSlotDoc, fetchDealerSlots, fetchDealers } from "@/lib/firebase/services";

// Projection simple de la France métropolitaine pour carte SVG interactive sans dépendance externe
function projectFrance(lat: number, lng: number) {
  const minLng = -5.0;
  const maxLng = 8.5;
  const minLat = 42.2;
  const maxLat = 51.2;
  const x = ((lng - minLng) / (maxLng - minLng)) * 360 + 20;
  const y = ((maxLat - lat) / (maxLat - minLat)) * 320 + 20;
  return { x, y };
}

export function DealersClient() {
  const [dealers, setDealers] = useState<DealerInfo[]>(DEMO_DEALERS);
  const [slots, setSlots] = useState<DealerSlotDoc[]>([]);
  const [searchText, setSearchText] = useState("");
  const [userCoords, setUserCoords] = useState<{ lat: number; lng: number } | null>(
    null
  );
  const [selectedDealerId, setSelectedDealerId] = useState<string>(
    DEMO_DEALERS[0].id
  );
  const [geoNotice, setGeoNotice] = useState<string | null>(null);

  useEffect(() => {
    fetchDealers().then(setDealers).catch(() => {});
    fetchDealerSlots().then(setSlots).catch(() => {});
  }, []);

  const handleGeolocate = () => {
    if (!navigator.geolocation) {
      setGeoNotice("Géolocalisation non prise en charge par ce navigateur.");
      return;
    }
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        setUserCoords({
          lat: pos.coords.latitude,
          lng: pos.coords.longitude,
        });
        setGeoNotice("Position détectée : tri par proximité activé.");
      },
      () => {
        setGeoNotice("Accès à la position refusé.");
      }
    );
  };

  const filteredDealers = useMemo(() => {
    const q = searchText.trim().toLowerCase();
    const prefix = q.slice(0, 2);
    const refCoords =
      userCoords || (POSTAL_PREFIX_COORDS[prefix] ?? null);

    return dealers
      .filter((d) => d.active)
      .map((d) => ({
        dealer: d,
        distanceKm: refCoords
          ? calculateDistanceKm(refCoords.lat, refCoords.lng, d.lat, d.lng)
          : null,
      }))
      .filter(({ dealer }) => {
        if (!q) return true;
        return (
          dealer.city.toLowerCase().includes(q) ||
          dealer.postalCode.toLowerCase().includes(q) ||
          dealer.name.toLowerCase().includes(q)
        );
      })
      .sort((a, b) => {
        if (a.distanceKm !== null && b.distanceKm !== null) {
          return a.distanceKm - b.distanceKm;
        }
        return a.dealer.postalCode.localeCompare(b.dealer.postalCode);
      });
  }, [dealers, searchText, userCoords]);

  const activeDealer =
    dealers.find((d) => d.id === selectedDealerId) || filteredDealers[0]?.dealer;

  const activeDealerSlots = useMemo(() => {
    if (!activeDealer) return [];
    const base = INITIAL_DEALER_SLOTS.filter(
      (s) => s.dealerId === activeDealer.id
    );
    return base.map((seed) => {
      const live = slots.find((s) => s.id === seed.id);
      return live ? { ...seed, status: live.status } : seed;
    });
  }, [activeDealer, slots]);

  return (
    <div className="max-w-[1440px] mx-auto px-4 sm:px-8 py-10 space-y-8">
      <div className="border-b border-[#E2E2DE] pb-6 flex flex-col lg:flex-row lg:items-end justify-between gap-4">
        <div>
          <p className="text-xs font-bold tracking-[0.14em] text-[#595959]">
            RÉSEAU DE DÉMONSTRATION FRANCE
          </p>
          <h1 className="font-display text-3xl sm:text-4xl font-extrabold text-[#0D0D0D]">
            Trouver un concessionnaire
          </h1>
          <p className="text-sm text-[#595959] mt-1">
            Recherchez par ville ou code postal, activez la géolocalisation
            facultative et consultez les créneaux d&apos;essai disponibles.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <div className="relative">
            <Search
              className="w-4 h-4 text-[#595959] absolute left-3 top-1/2 -translate-y-1/2"
              aria-hidden="true"
            />
            <input
              type="search"
              aria-label="Rechercher par ville ou code postal"
              placeholder="Ville ou code postal (ex. 75, Lyon)"
              value={searchText}
              onChange={(e) => setSearchText(e.target.value)}
              className="border border-[#E2E2DE] bg-white pl-9 pr-3 py-2.5 text-sm w-64 focus:border-[#0D0D0D] focus:outline-none"
            />
          </div>
          <button
            type="button"
            onClick={handleGeolocate}
            className="inline-flex items-center gap-2 border border-[#0D0D0D] bg-white px-4 py-2.5 text-xs font-semibold hover:bg-[#0D0D0D] hover:text-white transition-colors"
          >
            <LocateFixed className="w-4 h-4" aria-hidden="true" />
            <span>Autour de moi</span>
          </button>
        </div>
      </div>

      {geoNotice && (
        <p role="status" className="text-xs font-medium text-[#595959]">
          {geoNotice}
        </p>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        {/* Liste des concessionnaires */}
        <div className="lg:col-span-6 space-y-4">
          {filteredDealers.length === 0 ? (
            <div className="bg-white border border-[#E2E2DE] p-6 text-sm text-[#595959]">
              Aucun concessionnaire de démonstration ne correspond à « {searchText} ».
            </div>
          ) : (
            filteredDealers.map(({ dealer, distanceKm }) => {
              const selected = activeDealer?.id === dealer.id;
              return (
                <article
                  key={dealer.id}
                  className={`bg-white border p-5 space-y-3 transition-colors ${
                    selected ? "border-[#0D0D0D]" : "border-[#E2E2DE]"
                  }`}
                >
                  <div className="flex items-start justify-between gap-4">
                    <div>
                      <p className="text-xs text-[#595959]">
                        {dealer.postalCode} {dealer.city}
                        {distanceKm !== null ? ` · à ${distanceKm} km` : ""}
                      </p>
                      <h2 className="font-display text-lg font-bold text-[#0D0D0D]">
                        {dealer.name}
                      </h2>
                    </div>
                    <button
                      type="button"
                      onClick={() => setSelectedDealerId(dealer.id)}
                      className={`text-xs font-semibold px-3 py-1.5 border shrink-0 ${
                        selected
                          ? "bg-[#0D0D0D] text-white border-[#0D0D0D]"
                          : "bg-white text-[#0D0D0D] border-[#E2E2DE] hover:border-[#0D0D0D]"
                      }`}
                    >
                      {selected ? "Sélectionné" : "Voir sur la carte"}
                    </button>
                  </div>

                  <p className="text-xs text-[#262626] flex items-center gap-2">
                    <MapPin className="w-3.5 h-3.5 shrink-0" aria-hidden="true" />
                    <span>{dealer.address}</span>
                  </p>
                  <div className="flex flex-wrap gap-4 text-xs text-[#595959]">
                    <span className="inline-flex items-center gap-1.5">
                      <Phone className="w-3.5 h-3.5" aria-hidden="true" />
                      <span>{dealer.phone}</span>
                    </span>
                    <span className="inline-flex items-center gap-1.5">
                      <Clock className="w-3.5 h-3.5" aria-hidden="true" />
                      <span>{dealer.hours}</span>
                    </span>
                  </div>
                  <p className="text-xs text-[#595959]">
                    Services : {dealer.services.join(" · ")}
                  </p>

                  <div className="pt-2 border-t border-[#E2E2DE] flex flex-wrap items-center justify-between gap-3">
                    <Link
                      href={`/essais?concessionnaire=${dealer.id}`}
                      className="inline-flex items-center justify-center bg-[#0D0D0D] text-white text-xs font-semibold px-4 py-2 hover:bg-[#262626]"
                    >
                      Réserver un essai dans ce site
                    </Link>
                    <Link
                      href={`/stock`}
                      className="text-xs font-semibold underline"
                    >
                      Voir le stock
                    </Link>
                  </div>
                </article>
              );
            })
          )}
        </div>

        {/* Carte vectorielle de France + créneaux du site sélectionné */}
        <div className="lg:col-span-6 lg:sticky lg:top-24 space-y-6">
          <div className="bg-white border border-[#E2E2DE] p-5 space-y-3">
            <div className="flex items-center justify-between">
              <h2 className="font-display text-lg font-bold">
                Carte du réseau (démonstration)
              </h2>
              <span className="text-xs text-[#595959]">
                {filteredDealers.length} implantations
              </span>
            </div>

            <div className="bg-[#FAF9F6] border border-[#E2E2DE] p-4">
              <svg
                viewBox="0 0 400 360"
                className="w-full h-auto max-h-[320px]"
                role="img"
                aria-label="Carte schématique de France des concessionnaires de démonstration"
              >
                {/* Silhouette géométrique simplifiée de la France */}
                <polygon
                  points="185,35 280,65 340,125 320,210 345,270 285,315 200,320 135,305 100,255 110,175 55,140 85,90 140,70"
                  fill="#ECECE9"
                  stroke="#D0D0CA"
                  strokeWidth="1.5"
                />
                {dealers.map((d) => {
                  const { x, y } = projectFrance(d.lat, d.lng);
                  const isSel = activeDealer?.id === d.id;
                  return (
                    <g
                      key={d.id}
                      className="cursor-pointer"
                      onClick={() => setSelectedDealerId(d.id)}
                    >
                      <circle
                        cx={x}
                        cy={y}
                        r={isSel ? 9 : 6}
                        fill={isSel ? "#F7E300" : "#0D0D0D"}
                        stroke="#0D0D0D"
                        strokeWidth={isSel ? 2 : 1}
                      />
                      <text
                        x={x + 11}
                        y={y + 4}
                        fontSize="10"
                        fontWeight={isSel ? "700" : "500"}
                        fill="#0D0D0D"
                      >
                        {d.city}
                      </text>
                    </g>
                  );
                })}
              </svg>
            </div>
          </div>

          {activeDealer && (
            <div className="bg-white border border-[#E2E2DE] p-5 space-y-4">
              <div className="flex items-center justify-between gap-3">
                <div>
                  <p className="text-xs text-[#595959]">Prochains créneaux</p>
                  <h3 className="font-display text-lg font-bold">
                    {activeDealer.name}
                  </h3>
                </div>
                <Link
                  href={`/essais?concessionnaire=${activeDealer.id}`}
                  className="bg-[#0D0D0D] text-white text-xs font-semibold px-4 py-2"
                >
                  Réserver
                </Link>
              </div>

              <div className="grid grid-cols-3 gap-2 text-xs">
                {activeDealerSlots.map((slot) => (
                  <Link
                    key={slot.id}
                    href={
                      slot.status === "available"
                        ? `/essais?concessionnaire=${activeDealer.id}&creneau=${slot.id}`
                        : "#"
                    }
                    aria-disabled={slot.status !== "available"}
                    className={`border p-2.5 text-center transition-colors ${
                      slot.status === "available"
                        ? "border-[#E2E2DE] hover:border-[#0D0D0D] bg-white"
                        : "border-[#E2E2DE] bg-[#F3F3F1] text-[#8A8A85] pointer-events-none"
                    }`}
                  >
                    <span className="block font-mono-tabular font-semibold">
                      {slot.dateIso.slice(5)}
                    </span>
                    <span className="block font-mono-tabular">{slot.timeSlot}</span>
                    <span className="block text-[10px] mt-0.5">
                      {slot.status === "available"
                        ? "Disponible"
                        : slot.status === "booked"
                        ? "Réservé"
                        : "Fermé"}
                    </span>
                  </Link>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
