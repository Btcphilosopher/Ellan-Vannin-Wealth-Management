"use client";

import React from "react";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { Menu, User, X } from "lucide-react";
import { useState } from "react";
import { useAuth } from "@/components/providers/AuthProvider";

function RenaultDiamondMark() {
  return (
    <svg
      width="24"
      height="28"
      viewBox="0 0 24 28"
      fill="none"
      aria-hidden="true"
      className="shrink-0"
    >
      <path
        d="M12 1.5L3 14L12 26.5L21 14L12 1.5Z"
        stroke="currentColor"
        strokeWidth="2"
      />
      <path
        d="M12 6.5L6.7 14L12 21.5L17.3 14L12 6.5Z"
        stroke="currentColor"
        strokeWidth="1.6"
      />
    </svg>
  );
}

const NAV_LINKS = [
  { href: "/vehicules", label: "Nos véhicules" },
  { href: "/vehicules?energie=electrique", label: "Électrique" },
  { href: "/professionnels", label: "Professionnels" },
  { href: "/services", label: "Services" },
];

export function SiteHeader() {
  const pathname = usePathname();
  const { user, isAdmin } = useAuth();
  const [mobileOpen, setMobileOpen] = useState(false);

  return (
    <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-sm border-b border-[#E2E2DE] no-print">
      <div className="max-w-[1440px] mx-auto px-4 sm:px-8 h-[68px] flex items-center justify-between gap-8">
        {/* Zone 1 : Marque + séparateur vertical fin */}
        <div className="flex items-center gap-6 shrink-0">
          <Link
            href="/"
            className="flex items-center gap-2.5 text-[#0D0D0D] whitespace-nowrap shrink-0 focus-visible:outline-2 focus-visible:outline-offset-4 focus-visible:outline-[#0D0D0D]"
            aria-label="Accueil Renault Concept"
          >
            <RenaultDiamondMark />
            <span className="font-display text-lg font-extrabold tracking-[0.06em]">
              RENAULT
            </span>
          </Link>
          <span
            className="hidden lg:block h-5 w-px bg-[#E2E2DE]"
            aria-hidden="true"
          />
        </div>

        {/* Zone 2 : Navigation principale (4 liens sur une ligne) */}
        <nav
          aria-label="Navigation principale"
          className="hidden md:flex items-center gap-7 text-[14px] font-semibold text-[#1A1A1A]"
        >
          {NAV_LINKS.map((item) => {
            const active =
              item.href === "/vehicules"
                ? pathname === "/vehicules"
                : pathname.startsWith(item.href.split("?")[0]) &&
                  item.href !== "/vehicules";
            return (
              <Link
                key={item.href}
                href={item.href}
                className={`whitespace-nowrap shrink-0 py-1 transition-colors border-b-2 ${
                  active
                    ? "border-[#0D0D0D] text-[#0D0D0D]"
                    : "border-transparent hover:border-[#0D0D0D]/50 text-[#262626] hover:text-[#0D0D0D]"
                }`}
              >
                {item.label}
              </Link>
            );
          })}
        </nav>

        {/* Zone 3 : Actions droite fidèles à la maquette */}
        <div className="flex items-center gap-4 shrink-0">
          <Link
            href="/concessionnaires"
            className="hidden xl:inline-flex items-center text-[13px] font-medium text-[#262626] hover:text-[#0D0D0D] whitespace-nowrap shrink-0 py-1 transition-colors"
          >
            Trouver un concessionnaire
          </Link>
          <span
            className="hidden xl:block h-5 w-px bg-[#E2E2DE]"
            aria-hidden="true"
          />
          <Link
            href="/compte"
            aria-label={
              user ? `Mon compte (${user.displayName || "connecté"})` : "Mon compte"
            }
            title={user ? "Mon compte" : "Se connecter / Mon compte"}
            className="inline-flex items-center justify-center w-10 h-10 text-[#0D0D0D] hover:bg-[#F3F3F1] transition-colors shrink-0 relative"
          >
            <User className="w-5 h-5 stroke-[1.75]" aria-hidden="true" />
            {isAdmin && (
              <span className="sr-only">Administrateur connecté</span>
            )}
          </Link>
          <Link
            href="/configurateur"
            className="hidden sm:inline-flex items-center justify-center bg-[#0D0D0D] text-white text-[13px] font-semibold px-5 py-2.5 hover:bg-[#262626] transition-colors whitespace-nowrap shrink-0"
          >
            Configurer
          </Link>

          <button
            type="button"
            onClick={() => setMobileOpen((v) => !v)}
            className="md:hidden inline-flex items-center justify-center w-11 h-11 text-[#0D0D0D] hover:bg-[#F3F3F1]"
            aria-label={mobileOpen ? "Fermer le menu" : "Ouvrir le menu"}
            aria-expanded={mobileOpen}
          >
            {mobileOpen ? (
              <X className="w-5 h-5" aria-hidden="true" />
            ) : (
              <Menu className="w-5 h-5" aria-hidden="true" />
            )}
          </button>
        </div>
      </div>

      {/* Menu mobile accessible */}
      {mobileOpen && (
        <div className="md:hidden border-t border-[#E2E2DE] bg-white px-4 py-4 space-y-2">
          {NAV_LINKS.map((item) => (
            <Link
              key={item.href}
              href={item.href}
              onClick={() => setMobileOpen(false)}
              className="block py-2.5 text-sm font-semibold text-[#0D0D0D] border-b border-[#F3F3F1]"
            >
              {item.label}
            </Link>
          ))}
          <Link
            href="/concessionnaires"
            onClick={() => setMobileOpen(false)}
            className="block py-2.5 text-sm font-medium text-[#262626] border-b border-[#F3F3F1]"
          >
            Trouver un concessionnaire
          </Link>
          <Link
            href="/comparer"
            onClick={() => setMobileOpen(false)}
            className="block py-2.5 text-sm font-medium text-[#262626] border-b border-[#F3F3F1]"
          >
            Comparer des véhicules
          </Link>
          <Link
            href="/stock"
            onClick={() => setMobileOpen(false)}
            className="block py-2.5 text-sm font-medium text-[#262626] border-b border-[#F3F3F1]"
          >
            Véhicules disponibles
          </Link>
          <div className="pt-2">
            <Link
              href="/configurateur"
              onClick={() => setMobileOpen(false)}
              className="block w-full text-center bg-[#0D0D0D] text-white text-sm font-semibold py-3"
            >
              Configurer un véhicule
            </Link>
          </div>
        </div>
      )}
    </header>
  );
}
