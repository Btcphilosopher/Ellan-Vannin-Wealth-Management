import Link from "next/link";

function KineticSlashMark() {
  return (
    <svg
      width="24"
      height="20"
      viewBox="0 0 24 20"
      fill="none"
      aria-hidden="true"
      className="shrink-0"
    >
      <path d="M5 19L11 1H14.5L8.5 19H5Z" fill="#F7E300" />
      <path d="M12.5 19L18.5 1H22L16 19H12.5Z" fill="#F7E300" />
    </svg>
  );
}

export function SiteFooter() {
  return (
    <footer className="bg-[#0D0D0D] text-white no-print mt-auto">
      {/* Bandeau signature fidèle à la maquette */}
      <div className="max-w-[1440px] mx-auto px-4 sm:px-8 py-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <KineticSlashMark />
          <p className="font-display text-base sm:text-lg font-bold tracking-tight">
            Le design français,{" "}
            <span className="text-[#F7E300]">tourné vers demain.</span>
          </p>
        </div>
        <div className="flex items-center gap-4 text-xs text-[#C7C7C2] sm:border-l sm:border-white/20 sm:pl-6">
          <span>Concept indépendant de site web</span>
        </div>
      </div>

      {/* Navigation complète et mentions de démonstration */}
      <div className="border-t border-white/10 bg-[#141414]">
        <div className="max-w-[1440px] mx-auto px-4 sm:px-8 py-8 grid grid-cols-1 md:grid-cols-4 gap-8 text-xs text-[#B3B3AE]">
          <div className="space-y-2 md:col-span-2">
            <p className="text-white font-semibold text-sm">
              Avertissement de démonstration
            </p>
            <p className="leading-relaxed max-w-xl">
              Plateforme automobile de démonstration présentée comme un concept
              indépendant. Les tarifs, autonomies WLTP, stocks, concessions et
              créneaux affichés sont des données fictives sans connexion aux
              systèmes d&apos;information Renault ni engagement contractuel.
            </p>
          </div>
          <div className="space-y-2">
            <p className="text-white font-semibold">Parcours véhicules</p>
            <ul className="space-y-1.5">
              <li>
                <Link href="/vehicules" className="hover:text-white transition-colors">
                  Toute la gamme
                </Link>
              </li>
              <li>
                <Link href="/configurateur" className="hover:text-white transition-colors">
                  Configurateur interactif
                </Link>
              </li>
              <li>
                <Link href="/comparer" className="hover:text-white transition-colors">
                  Comparateur (jusqu&apos;à 3 véhicules)
                </Link>
              </li>
              <li>
                <Link href="/stock" className="hover:text-white transition-colors">
                  Stock physique disponible
                </Link>
              </li>
            </ul>
          </div>
          <div className="space-y-2">
            <p className="text-white font-semibold">Réseau &amp; Gestion</p>
            <ul className="space-y-1.5">
              <li>
                <Link href="/concessionnaires" className="hover:text-white transition-colors">
                  Annuaire des concessionnaires
                </Link>
              </li>
              <li>
                <Link href="/essais" className="hover:text-white transition-colors">
                  Réserver un essai
                </Link>
              </li>
              <li>
                <Link href="/compte" className="hover:text-white transition-colors">
                  Espace client
                </Link>
              </li>
              <li>
                <Link href="/admin" className="hover:text-white transition-colors">
                  Administration
                </Link>
              </li>
              <li>
                <Link href="/documentation" className="hover:text-white transition-colors">
                  Documentation technique &amp; API
                </Link>
              </li>
            </ul>
          </div>
        </div>
      </div>
    </footer>
  );
}
