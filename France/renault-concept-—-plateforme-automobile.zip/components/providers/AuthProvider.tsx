"use client";

import React, {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useState,
} from "react";
import {
  User,
  onAuthStateChanged,
  signInWithPopup,
  signOut as firebaseSignOut,
} from "firebase/auth";
import {
  doc,
  getDoc,
  serverTimestamp,
  setDoc,
} from "firebase/firestore";
import {
  OperationType,
  auth,
  db,
  googleAuthProvider,
  handleFirestoreError,
  testFirestoreConnection,
} from "@/lib/firebase/client";

export interface UserProfileData {
  uid: string;
  email: string;
  displayName: string;
  phone?: string;
  postalCode?: string;
  favoriteModelSlugs: string[];
  emailOptIn: boolean;
  smsOptIn: boolean;
  preferredDealerId?: string;
}

interface AuthContextValue {
  user: User | null;
  profile: UserProfileData | null;
  loading: boolean;
  isAdmin: boolean;
  authError: string | null;
  signInWithGoogle: () => Promise<User | null>;
  signOut: () => Promise<void>;
  getIdToken: () => Promise<string | null>;
  refreshProfile: () => Promise<void>;
}

const AuthContext = createContext<AuthContextValue | null>(null);

const ADMIN_EMAIL = "tom@ahyx.org";

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [profile, setProfile] = useState<UserProfileData | null>(null);
  const [loading, setLoading] = useState(true);
  const [authError, setAuthError] = useState<string | null>(null);

  const syncUserProfile = useCallback(async (firebaseUser: User) => {
    const path = `users/${firebaseUser.uid}`;
    const ref = doc(db, "users", firebaseUser.uid);
    try {
      const snap = await getDoc(ref);
      if (snap.exists()) {
        const data = snap.data() as UserProfileData;
        setProfile(data);
      } else {
        const initialProfile: UserProfileData = {
          uid: firebaseUser.uid,
          email: firebaseUser.email || "client@exemple.fr",
          displayName: firebaseUser.displayName || "Client Concept",
          favoriteModelSlugs: [],
          emailOptIn: false,
          smsOptIn: false,
        };
        await setDoc(ref, {
          ...initialProfile,
          updatedAt: serverTimestamp(),
        });
        setProfile(initialProfile);
      }
    } catch (error) {
      // Ne pas faire planter l'UI si les règles rejettent temporairement avant vérification email
      if (error instanceof Error && error.message.includes("permissions")) {
        handleFirestoreError(error, OperationType.GET, path);
      }
    }
  }, []);

  useEffect(() => {
    void testFirestoreConnection();
    const unsub = onAuthStateChanged(auth, async (nextUser) => {
      setUser(nextUser);
      if (nextUser && nextUser.emailVerified) {
        try {
          await syncUserProfile(nextUser);
        } catch {
          // L'erreur structurée est déjà tracée
        }
      } else {
        setProfile(null);
      }
      setLoading(false);
    });
    return () => unsub();
  }, [syncUserProfile]);

  const signInWithGoogle = useCallback(async (): Promise<User | null> => {
    setAuthError(null);
    try {
      const cred = await signInWithPopup(auth, googleAuthProvider);
      return cred.user;
    } catch (error) {
      const message =
        error instanceof Error
          ? error.message
          : "Connexion interrompue ou bloquée par le navigateur.";
      setAuthError(message);
      return null;
    }
  }, []);

  const signOut = useCallback(async () => {
    setAuthError(null);
    await firebaseSignOut(auth);
    setProfile(null);
  }, []);

  const getIdToken = useCallback(async () => {
    if (!auth.currentUser) return null;
    return auth.currentUser.getIdToken();
  }, []);

  const refreshProfile = useCallback(async () => {
    if (!auth.currentUser) return;
    await syncUserProfile(auth.currentUser);
  }, [syncUserProfile]);

  const isAdmin = useMemo(() => {
    return Boolean(
      user?.emailVerified &&
        user?.email &&
        user.email.toLowerCase() === ADMIN_EMAIL
    );
  }, [user]);

  const value = useMemo<AuthContextValue>(
    () => ({
      user,
      profile,
      loading,
      isAdmin,
      authError,
      signInWithGoogle,
      signOut,
      getIdToken,
      refreshProfile,
    }),
    [
      user,
      profile,
      loading,
      isAdmin,
      authError,
      signInWithGoogle,
      signOut,
      getIdToken,
      refreshProfile,
    ]
  );

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) {
    throw new Error("useAuth doit être utilisé à l'intérieur de AuthProvider");
  }
  return ctx;
}
