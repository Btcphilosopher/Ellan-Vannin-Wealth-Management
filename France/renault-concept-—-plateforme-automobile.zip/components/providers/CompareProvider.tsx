"use client";

import React, { createContext, useCallback, useContext, useState } from "react";
import { VehicleModel } from "@/lib/catalog/types";

export interface CompareItem {
  id: string;
  source: "catalog" | "saved";
  label: string;
  modelSlug: VehicleModel["slug"];
  motorisationId: string;
  trimId: string;
  colorId?: string;
  wheelId?: string;
  interiorId?: string;
  optionIds?: string[];
  totalKnownCents?: number;
  tariffVersion?: string;
}

interface CompareContextValue {
  items: CompareItem[];
  addItem: (item: CompareItem) => { ok: boolean; message?: string };
  removeItem: (id: string) => void;
  clearItems: () => void;
  hasItem: (id: string) => boolean;
}

const DEFAULT_COMPARE_ITEMS: CompareItem[] = [
  {
    id: "catalog-r5-150-techno",
    source: "catalog",
    label: "Renault 5 E-Tech · 150 ch Techno",
    modelSlug: "renault-5-e-tech",
    motorisationId: "moto-r5-150",
    trimId: "trim-r5-techno",
  },
  {
    id: "catalog-scenic-220-techno",
    source: "catalog",
    label: "Scénic E-Tech · 220 ch Techno",
    modelSlug: "scenic-e-tech",
    motorisationId: "moto-scenic-220",
    trimId: "trim-scenic-techno",
  },
];

const CompareContext = createContext<CompareContextValue | null>(null);

export function CompareProvider({ children }: { children: React.ReactNode }) {
  const [items, setItems] = useState<CompareItem[]>(DEFAULT_COMPARE_ITEMS);

  const addItem = useCallback((item: CompareItem) => {
    let outcome: { ok: boolean; message?: string } = { ok: true };
    setItems((prev) => {
      if (prev.some((existing) => existing.id === item.id)) {
        outcome = { ok: true, message: "Déjà présent dans le comparateur." };
        return prev;
      }
      if (prev.length >= 3) {
        outcome = {
          ok: false,
          message:
            "Le comparateur accepte jusqu'à 3 véhicules ou configurations simultanément.",
        };
        return prev;
      }
      return [...prev, item];
    });
    return outcome;
  }, []);

  const removeItem = useCallback((id: string) => {
    setItems((prev) => prev.filter((item) => item.id !== id));
  }, []);

  const clearItems = useCallback(() => {
    setItems([]);
  }, []);

  const hasItem = useCallback(
    (id: string) => items.some((item) => item.id === id),
    [items]
  );

  return (
    <CompareContext.Provider
      value={{ items, addItem, removeItem, clearItems, hasItem }}
    >
      {children}
    </CompareContext.Provider>
  );
}

export function useCompare() {
  const ctx = useContext(CompareContext);
  if (!ctx) {
    throw new Error(
      "useCompare doit être utilisé à l'intérieur de CompareProvider"
    );
  }
  return ctx;
}
