"use client";

import { useCallback, useEffect, useState } from "react";
import Link from "next/link";
import {
  ArrowRight,
  LogOut,
  Scale,
  ShieldCheck,
  Trash2,
} from "lucide-react";
import { VEHICLE_MODELS } from "@/lib/catalog/data";
import { DEMO_DEALERS } from "@/lib/dealers/data";
import { formatCentsEUR } from "@/lib/pricing/tariffs";
import { useAuth } from "@/components/providers/AuthProvider";
import { useCompare } from "@/components/providers/CompareProvider";
import {
  CommercialRequestDoc,
  SavedConfigurationDoc,
  TestDriveRequestDoc,
  cancelUserTestDrive,
  deleteSavedConfiguration,
  fetchUserCommercialRequests,
  fetchUserConfigurations,
  fetchUserTestDrives,
  toggleFavoriteModel,
  updateUserPreferences,
} from "@/lib/firebase/services";

function statusLabel(status: string): string {
  switch (status) {
    case "received":
      return "Demande reçue (en attente)";
    case "confirmed":
      return "Rendez-vous confirmé";
    case "declined":
      return "Non retenue";
    case "cancelled":
      return "Annulée";
    default:
      return status;
  }
}

export function AccountClient() {
  const {
    user,
    profile,
    loading,
    isAdmin,
    authError,
    signInWithGoogle,
    signOut,
    refreshProfile,
  } = useAuth();
  const { addItem } = useCompare();

  const [configs, setConfigs] = useState<SavedConfigurationDoc[]>([]);
  const [testDrives, setTestDrives] = useState<TestDriveRequestDoc[]>([]);
  const [commercials, setCommercials] = useState<CommercialRequestDoc[]>([]);
  const [busy, setBusy] = useState(false);
  const [feedback, setFeedback] = useState<string | null>(null);

  const [phoneInput, setPhoneInput] = useState<string | null>(null);
  const [postalCodeInput, setPostalCodeInput] = useState<string | null>(null);
  const [emailOptInInput, setEmailOptInInput] = useState<boolean | null>(null);
  const [smsOptInInput, setSmsOptInInput] = useState<boolean | null>(null);
  const [preferredDealerInput, setPreferredDealerInput] = useState<string | null>(
    null
  );

  const phone = phoneInput ?? profile?.phone ?? "";
  const postalCode = postalCodeInput ?? profile?.postalCode ?? "";
  const emailOptIn = emailOptInInput ?? Boolean(profile?.emailOptIn);
  const smsOptIn = smsOptInInput ?? Boolean(profile?.smsOptIn);
  const preferredDealerId =
    preferredDealerInput ?? profile?.preferredDealerId ?? DEMO_DEALERS[0].id;

  const loadAccountData = useCallback(async (uid: string) => {
    setBusy(true);
    try {
      const [c, t, com] = await Promise.all([
        fetchUserConfigurations(uid),
        fetchUserTestDrives(uid),
        fetchUserCommercialRequests(uid),
      ]);
      setConfigs(c);
      setTestDrives(t);
      setCommercials(com);
    } finally {
      setBusy(false);
    }
  }, []);

  useEffect(() => {
    if (!user) return;
    let active = true;
    Promise.all([
      fetchUserConfigurations(user.uid),
      fetchUserTestDrives(user.uid),
      fetchUserCommercialRequests(user.uid),
    ])
      .then(([c, t, com]) => {
        if (!active) return;
        setConfigs(c);
        setTestDrives(t);
        setCommercials(com);
      })
      .catch(() => {});
    return () => {
      active = false;
    };
  }, [user]);

  const handleSavePrefs = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) return;
    await updateUserPreferences(user.uid, {
      phone,
      postalCode,
      emailOptIn,
      smsOptIn,
      preferredDealerId,
    });
    await refreshProfile();
    setFeedback("Préférences de communication enregistrées.");
  };

  if (loading) {
    return (
      <div className="max-w-[1160px] mx-auto px-4 sm:px-8 py-16 text-sm text-[#595959]">
        Chargement de votre espace client…
      </div>
    );
  }

  if (!user) {
    return (
      <div className="max-w-[760px] mx-auto px-4 sm:px-8 py-16">
        <div className="bg-white border border-[#E2E2DE] p-8 sm:p-10 space-y-5">
          <p className="text-xs font-bold tracking-[0.14em] text-[#595959]">
            ESPACE CLIENT SÉCURISÉ
          </p>
          <h1 className="font-display text-3xl sm:text-4xl font-extrabold text-[#0D0D0D]">
            Mon compte Renault Concept
          </h1>
          <p className="text-sm text-[#595959] leading-relaxed">
            Connectez-vous avec votre compte Google pour retrouver vos
            véhicules favoris, reprendre vos configurations sauvegardées, suivre
            vos demandes d&apos;essai et gérer vos préférences de communication.
          </p>
          {authError && (
            <p className="text-xs text-[#991B1B] bg-[#FEF2F2] border border-[#B91C1C] px-3 py-2">
              {authError}
            </p>
          )}
          <button
            type="button"
            onClick={() => void signInWithGoogle()}
            className="bg-[#0D0D0D] text-white text-sm font-semibold px-6 py-3.5 hover:bg-[#262626] transition-colors"
          >
            Se connecter avec Google
          </button>
        </div>
      </div>
    );
  }

  const favoriteModels = VEHICLE_MODELS.filter((m) =>
    profile?.favoriteModelSlugs?.includes(m.slug)
  );

  return (
    <div className="max-w-[1440px] mx-auto px-4 sm:px-8 py-10 space-y-10">
      <div className="border-b border-[#E2E2DE] pb-6 flex flex-col sm:flex-row sm:items-end justify-between gap-4">
        <div>
          <p className="text-xs font-bold tracking-[0.14em] text-[#595959]">
            ESPACE CLIENT · {user.email}
          </p>
          <h1 className="font-display text-3xl sm:text-4xl font-extrabold text-[#0D0D0D]">
            Bonjour, {profile?.displayName || user.displayName || "Client"}
          </h1>
        </div>
        <div className="flex flex-wrap items-center gap-3">
          {isAdmin && (
            <Link
              href="/admin"
              className="inline-flex items-center gap-2 bg-[#F7E300] text-[#0D0D0D] border border-[#0D0D0D] px-4 py-2.5 text-xs font-bold"
            >
              <ShieldCheck className="w-4 h-4" aria-hidden="true" />
              <span>Accéder à l&apos;administration</span>
            </Link>
          )}
          <button
            type="button"
            onClick={() => void signOut()}
            className="inline-flex items-center gap-2 border border-[#E2E2DE] bg-white px-4 py-2.5 text-xs font-semibold hover:border-[#0D0D0D]"
          >
            <LogOut className="w-4 h-4" aria-hidden="true" />
            <span>Déconnexion</span>
          </button>
        </div>
      </div>

      {feedback && (
        <div
          role="status"
          className="border border-[#0D0D0D] bg-[#F7E300]/25 px-4 py-3 text-sm font-medium"
        >
          {feedback}
        </div>
      )}

      {/* Véhicules favoris */}
      <section className="space-y-4">
        <h2 className="font-display text-2xl font-extrabold">
          Véhicules favoris ({favoriteModels.length})
        </h2>
        {favoriteModels.length === 0 ? (
          <div className="bg-white border border-[#E2E2DE] p-5 text-sm text-[#595959]">
            Aucun véhicule favori enregistré.{" "}
            <Link href="/vehicules" className="underline text-[#0D0D0D]">
              Explorer la gamme
            </Link>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {favoriteModels.map((m) => (
              <div
                key={m.slug}
                className="bg-white border border-[#E2E2DE] p-5 flex items-center justify-between gap-4"
              >
                <div>
                  <p className="font-display font-bold text-lg">{m.shortName}</p>
                  <p className="text-xs text-[#595959]">{m.tagline}</p>
                  <Link
                    href={`/configurateur?modele=${m.slug}`}
                    className="inline-flex items-center gap-1 text-xs font-semibold underline mt-2"
                  >
                    <span>Configurer</span>
                    <ArrowRight className="w-3 h-3" aria-hidden="true" />
                  </Link>
                </div>
                <button
                  type="button"
                  onClick={async () => {
                    await toggleFavoriteModel(
                      user.uid,
                      m.slug,
                      profile?.favoriteModelSlugs || []
                    );
                    await refreshProfile();
                  }}
                  aria-label={`Retirer ${m.shortName} des favoris`}
                  className="text-xs text-[#595959] hover:text-[#B91C1C]"
                >
                  Retirer
                </button>
              </div>
            ))}
          </div>
        )}
      </section>

      {/* Configurations sauvegardées */}
      <section className="space-y-4">
        <div className="flex items-center justify-between">
          <h2 className="font-display text-2xl font-extrabold">
            Configurations sauvegardées ({configs.length})
          </h2>
          <Link
            href="/configurateur"
            className="text-xs font-semibold underline"
          >
            + Nouvelle configuration
          </Link>
        </div>

        {busy ? (
          <p className="text-sm text-[#595959]">Actualisation…</p>
        ) : configs.length === 0 ? (
          <div className="bg-white border border-[#E2E2DE] p-5 text-sm text-[#595959]">
            Aucune configuration sauvegardée pour le moment.
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {configs.map((cfg) => (
              <article
                key={cfg.id}
                className="bg-white border border-[#E2E2DE] p-5 space-y-3"
              >
                <div className="flex items-start justify-between gap-4">
                  <div>
                    <p className="text-xs text-[#595959]">
                      Tarif conservé : {cfg.tariffVersion}
                    </p>
                    <h3 className="font-display text-lg font-bold">
                      {cfg.title}
                    </h3>
                  </div>
                  <span className="font-mono-tabular text-base font-extrabold">
                    {formatCentsEUR(cfg.totalKnownCents, true)}
                  </span>
                </div>

                <div className="flex flex-wrap gap-2 pt-2 border-t border-[#E2E2DE]">
                  <Link
                    href={`/configurateur?configId=${cfg.id}`}
                    className="bg-[#0D0D0D] text-white text-xs font-semibold px-4 py-2"
                  >
                    Reprendre
                  </Link>
                  <button
                    type="button"
                    onClick={() => {
                      const res = addItem({
                        id: `saved-${cfg.id}`,
                        source: "saved",
                        label: cfg.title,
                        modelSlug: cfg.modelSlug,
                        motorisationId: cfg.motorisationId,
                        trimId: cfg.trimId,
                        totalKnownCents: cfg.totalKnownCents,
                        tariffVersion: cfg.tariffVersion,
                      });
                      setFeedback(
                        res.ok
                          ? `"${cfg.title}" ajouté au comparateur.`
                          : res.message || "Comparateur plein."
                      );
                    }}
                    className="inline-flex items-center gap-1.5 border border-[#0D0D0D] bg-white text-xs font-semibold px-3 py-2"
                  >
                    <Scale className="w-3.5 h-3.5" aria-hidden="true" />
                    <span>Comparer</span>
                  </button>
                  <button
                    type="button"
                    onClick={async () => {
                      await deleteSavedConfiguration(cfg.id);
                      await loadAccountData(user.uid);
                      setFeedback("Configuration supprimée.");
                    }}
                    className="inline-flex items-center gap-1 border border-[#E2E2DE] text-xs px-3 py-2 text-[#595959] hover:text-[#B91C1C]"
                  >
                    <Trash2 className="w-3.5 h-3.5" aria-hidden="true" />
                    <span>Supprimer</span>
                  </button>
                </div>
              </article>
            ))}
          </div>
        )}
      </section>

      {/* Essais & Demandes commerciales */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <section className="space-y-4">
          <h2 className="font-display text-2xl font-extrabold">
            Mes demandes d&apos;essai ({testDrives.length})
          </h2>
          {testDrives.length === 0 ? (
            <div className="bg-white border border-[#E2E2DE] p-5 text-sm text-[#595959]">
              Aucun essai planifié.{" "}
              <Link href="/essais" className="underline text-[#0D0D0D]">
                Réserver un essai
              </Link>
            </div>
          ) : (
            <div className="space-y-3">
              {testDrives.map((td) => {
                const dealer = DEMO_DEALERS.find((d) => d.id === td.dealerId);
                return (
                  <div
                    key={td.id}
                    className="bg-white border border-[#E2E2DE] p-4 space-y-2 text-sm"
                  >
                    <div className="flex items-start justify-between gap-3">
                      <div>
                        <p className="font-semibold text-[#0D0D0D]">
                          {td.modelSlug} · {td.slotLabel}
                        </p>
                        <p className="text-xs text-[#595959]">
                          {dealer?.name || td.dealerId}
                        </p>
                      </div>
                      <span
                        className={`text-xs font-semibold px-2.5 py-1 border ${
                          td.status === "confirmed"
                            ? "border-[#0D0D0D] bg-[#F7E300] text-[#0D0D0D]"
                            : "border-[#E2E2DE] bg-[#FAF9F6] text-[#0D0D0D]"
                        }`}
                      >
                        {statusLabel(td.status)}
                      </span>
                    </div>
                    {td.adminNote && (
                      <p className="text-xs text-[#262626] bg-[#FAF9F6] p-2 border border-[#E2E2DE]">
                        Note concessionnaire : {td.adminNote}
                      </p>
                    )}
                    {td.status === "received" && (
                      <button
                        type="button"
                        onClick={async () => {
                          await cancelUserTestDrive(td.id);
                          await loadAccountData(user.uid);
                          setFeedback("Demande d'essai annulée.");
                        }}
                        className="text-xs underline text-[#595959] hover:text-[#B91C1C]"
                      >
                        Annuler ma demande
                      </button>
                    )}
                  </div>
                );
              })}
            </div>
          )}
        </section>

        <section className="space-y-4">
          <h2 className="font-display text-2xl font-extrabold">
            Demandes commerciales &amp; historique ({commercials.length})
          </h2>
          {commercials.length === 0 ? (
            <div className="bg-white border border-[#E2E2DE] p-5 text-sm text-[#595959]">
              Aucune demande commerciale enregistrée.
            </div>
          ) : (
            <div className="space-y-3">
              {commercials.map((c) => (
                <div
                  key={c.id}
                  className="bg-white border border-[#E2E2DE] p-4 space-y-1 text-sm"
                >
                  <div className="flex items-start justify-between gap-3">
                    <p className="font-semibold">
                      {c.requestType === "stock_reservation"
                        ? "Réservation stock"
                        : "Demande de devis"}{" "}
                      · {c.modelSlug}
                    </p>
                    <span className="text-xs font-semibold px-2 py-0.5 border border-[#E2E2DE]">
                      {statusLabel(c.status)}
                    </span>
                  </div>
                  {typeof c.estimatedTotalCents === "number" && (
                    <p className="font-mono-tabular text-xs text-[#595959]">
                      Montant indicatif :{" "}
                      {formatCentsEUR(c.estimatedTotalCents, true)} (
                      {c.tariffVersion || "stock"})
                    </p>
                  )}
                </div>
              ))}
            </div>
          )}
        </section>
      </div>

      {/* Préférences de communication */}
      <section className="bg-white border border-[#E2E2DE] p-6 space-y-4">
        <h2 className="font-display text-2xl font-extrabold">
          Préférences de communication
        </h2>
        <form
          onSubmit={handleSavePrefs}
          className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-sm"
        >
          <div>
            <label htmlFor="pref-phone" className="block text-xs text-[#595959] mb-1">
              Téléphone
            </label>
            <input
              id="pref-phone"
              type="tel"
              value={phone}
              onChange={(e) => setPhoneInput(e.target.value)}
              className="w-full border border-[#E2E2DE] px-3 py-2"
            />
          </div>
          <div>
            <label htmlFor="pref-cp" className="block text-xs text-[#595959] mb-1">
              Code postal
            </label>
            <input
              id="pref-cp"
              type="text"
              value={postalCode}
              onChange={(e) => setPostalCodeInput(e.target.value)}
              className="w-full border border-[#E2E2DE] px-3 py-2"
            />
          </div>
          <div>
            <label htmlFor="pref-dealer" className="block text-xs text-[#595959] mb-1">
              Concessionnaire favori
            </label>
            <select
              id="pref-dealer"
              value={preferredDealerId}
              onChange={(e) => setPreferredDealerInput(e.target.value)}
              className="w-full border border-[#E2E2DE] bg-white px-3 py-2"
            >
              {DEMO_DEALERS.map((d) => (
                <option key={d.id} value={d.id}>
                  {d.name}
                </option>
              ))}
            </select>
          </div>
          <div className="sm:col-span-3 flex flex-wrap gap-6 pt-2">
            <label className="inline-flex items-center gap-2 text-xs cursor-pointer">
              <input
                type="checkbox"
                checked={emailOptIn}
                onChange={(e) => setEmailOptInInput(e.target.checked)}
                className="w-4 h-4 accent-[#0D0D0D]"
              />
              <span>Recevoir le suivi de mes dossiers par e-mail (démo)</span>
            </label>
            <label className="inline-flex items-center gap-2 text-xs cursor-pointer">
              <input
                type="checkbox"
                checked={smsOptIn}
                onChange={(e) => setSmsOptInInput(e.target.checked)}
                className="w-4 h-4 accent-[#0D0D0D]"
              />
              <span>Recevoir les confirmations de créneau par SMS (démo)</span>
            </label>
          </div>
          <div className="sm:col-span-3">
            <button
              type="submit"
              className="bg-[#0D0D0D] text-white text-xs font-semibold px-5 py-2.5"
            >
              Enregistrer mes préférences
            </button>
          </div>
        </form>
      </section>
    </div>
  );
}
