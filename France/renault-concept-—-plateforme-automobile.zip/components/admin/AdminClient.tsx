"use client";

import { useCallback, useEffect, useState } from "react";
import {
  CheckCircle2,
  Database,
  Download,
  Lock,
  ShieldCheck,
  Upload,
} from "lucide-react";
import { INITIAL_STOCK_VEHICLES, VEHICLE_MODELS } from "@/lib/catalog/data";
import { StockVehicle } from "@/lib/catalog/types";
import { CONFIGURATOR_RULES } from "@/lib/configurator/rules";
import {
  DEMO_DEALERS,
  INITIAL_DEALER_SLOTS,
} from "@/lib/dealers/data";
import {
  TARIFF_VERSIONS,
  TariffVersionRecord,
  formatCentsEUR,
} from "@/lib/pricing/tariffs";
import { useAuth } from "@/components/providers/AuthProvider";
import {
  AuditLogDoc,
  CommercialRequestDoc,
  DealerSlotDoc,
  TestDriveRequestDoc,
  adminFetchAllCommercialRequests,
  adminFetchAllTestDrives,
  adminFetchAuditLogs,
  adminFetchTariffs,
  adminPublishTariff,
  adminSeedDemoCollections,
  adminToggleRule,
  adminUpdateCommercialStatus,
  adminUpdateSlotStatus,
  adminUpdateStockStatus,
  adminUpdateTestDriveStatus,
  fetchDealerSlots,
  fetchStockVehicles,
} from "@/lib/firebase/services";

type AdminTab =
  | "requests"
  | "stock"
  | "tariffs"
  | "dealers"
  | "catalog"
  | "audit";

export function AdminClient() {
  const { user, loading, isAdmin, signInWithGoogle, getIdToken } = useAuth();
  const [tab, setTab] = useState<AdminTab>("requests");

  const [testDrives, setTestDrives] = useState<TestDriveRequestDoc[]>([]);
  const [commercials, setCommercials] = useState<CommercialRequestDoc[]>([]);
  const [stocks, setStocks] = useState<StockVehicle[]>(INITIAL_STOCK_VEHICLES);
  const [tariffs, setTariffs] = useState<TariffVersionRecord[]>(TARIFF_VERSIONS);
  const [slots, setSlots] = useState<DealerSlotDoc[]>([]);
  const [auditLogs, setAuditLogs] = useState<AuditLogDoc[]>([]);
  const [ruleStates, setRuleStates] = useState<Record<string, boolean>>(() =>
    Object.fromEntries(CONFIGURATOR_RULES.map((r) => [r.code, true]))
  );

  const [adminNoteMap, setAdminNoteMap] = useState<Record<string, string>>({});
  const [newTariffVersion, setNewTariffVersion] = useState("TARIF-FR-2026-Q4B");
  const [newTariffDate, setNewTariffDate] = useState("2026-12-01");
  const [newDeliveryEuros, setNewDeliveryEuros] = useState(690);
  const [newDiscountEuros, setNewDiscountEuros] = useState(0);

  const [busy, setBusy] = useState(false);
  const [feedback, setFeedback] = useState<string | null>(null);
  const [restoreJson, setRestoreJson] = useState("");

  const loadAllAdmin = useCallback(async () => {
    setBusy(true);
    try {
      const [td, com, st, tf, sl, al] = await Promise.all([
        adminFetchAllTestDrives(),
        adminFetchAllCommercialRequests(),
        fetchStockVehicles(),
        adminFetchTariffs(),
        fetchDealerSlots(),
        adminFetchAuditLogs(),
      ]);
      setTestDrives(td);
      setCommercials(com);
      setStocks(st);
      setTariffs(tf);
      setSlots(sl);
      setAuditLogs(al);
    } catch (err) {
      setFeedback(
        err instanceof Error ? err.message : "Erreur de chargement admin."
      );
    } finally {
      setBusy(false);
    }
  }, []);

  useEffect(() => {
    if (!isAdmin) return;
    let active = true;
    Promise.all([
      adminFetchAllTestDrives(),
      adminFetchAllCommercialRequests(),
      fetchStockVehicles(),
      adminFetchTariffs(),
      fetchDealerSlots(),
      adminFetchAuditLogs(),
    ])
      .then(([td, com, st, tf, sl, al]) => {
        if (!active) return;
        setTestDrives(td);
        setCommercials(com);
        setStocks(st);
        setTariffs(tf);
        setSlots(sl);
        setAuditLogs(al);
      })
      .catch((err) => {
        if (active) {
          setFeedback(
            err instanceof Error ? err.message : "Erreur de chargement admin."
          );
        }
      });
    return () => {
      active = false;
    };
  }, [isAdmin]);

  if (loading) {
    return (
      <div className="max-w-[1160px] mx-auto px-4 sm:px-8 py-16 text-sm text-[#595959]">
        Vérification des droits d&apos;administration…
      </div>
    );
  }

  if (!user || !isAdmin) {
    return (
      <div className="max-w-[760px] mx-auto px-4 sm:px-8 py-16">
        <div className="bg-white border border-[#E2E2DE] p-8 space-y-4">
          <div className="flex items-center gap-3">
            <Lock className="w-6 h-6" aria-hidden="true" />
            <h1 className="font-display text-2xl font-extrabold">
              Accès réservé à l&apos;administration
            </h1>
          </div>
          <p className="text-sm text-[#595959]">
            Les permissions sont vérifiées côté serveur et par les règles de
            sécurité Firestore. Connectez-vous avec le compte administrateur
            autorisé pour accéder au back-office.
          </p>
          {!user ? (
            <button
              type="button"
              onClick={() => void signInWithGoogle()}
              className="bg-[#0D0D0D] text-white text-xs font-semibold px-5 py-3"
            >
              Connexion administrateur (Google)
            </button>
          ) : (
            <p className="text-xs text-[#991B1B] font-medium">
              Compte connecté ({user.email}) non habilité pour l&apos;administration.
            </p>
          )}
        </div>
      </div>
    );
  }

  const handleSeed = async () => {
    setBusy(true);
    try {
      const count = await adminSeedDemoCollections(user.uid);
      await loadAllAdmin();
      setFeedback(
        `Initialisation réussie : ${count} documents de démonstration synchronisés dans Firestore.`
      );
    } finally {
      setBusy(false);
    }
  };

  const handleDownloadBackup = () => {
    const snapshot = {
      schemaVersion: "1.0",
      exportedAt: new Date().toISOString(),
      collections: {
        stockVehicles: stocks,
        tariffVersions: tariffs,
        dealers: DEMO_DEALERS,
        testDriveRequests: testDrives.map((t) => ({
          id: t.id,
          modelSlug: t.modelSlug,
          dealerId: t.dealerId,
          slotId: t.slotId,
          status: t.status,
        })),
      },
    };
    const blob = new Blob([JSON.stringify(snapshot, null, 2)], {
      type: "application/json",
    });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `renault-concept-backup-${Date.now()}.json`;
    a.click();
    URL.revokeObjectURL(url);
    setFeedback("Sauvegarde JSON expurgée téléchargée.");
  };

  const handleValidateRestore = async () => {
    try {
      const parsed = JSON.parse(restoreJson);
      const token = await getIdToken();
      const res = await fetch("/api/backup", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({ mode: "validate_snapshot", snapshot: parsed }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Erreur de validation.");
      setFeedback(
        `Sauvegarde vérifiée côté serveur (${JSON.stringify(data.counts)}).`
      );
    } catch (err) {
      setFeedback(
        err instanceof Error ? err.message : "JSON de sauvegarde invalide."
      );
    }
  };

  return (
    <div className="max-w-[1440px] mx-auto px-4 sm:px-8 py-10 space-y-8">
      <div className="border-b border-[#E2E2DE] pb-6 flex flex-col lg:flex-row lg:items-end justify-between gap-4">
        <div>
          <p className="text-xs font-bold tracking-[0.14em] text-[#595959] inline-flex items-center gap-1.5">
            <ShieldCheck className="w-4 h-4" aria-hidden="true" />
            <span>BACK-OFFICE ADMINISTRATION · {user.email}</span>
          </p>
          <h1 className="font-display text-3xl sm:text-4xl font-extrabold text-[#0D0D0D]">
            Pilotage Catalogue, Tarifs, Essais &amp; Audit
          </h1>
        </div>

        <button
          type="button"
          onClick={handleSeed}
          disabled={busy}
          className="inline-flex items-center gap-2 bg-[#0D0D0D] text-white text-xs font-semibold px-4 py-2.5 hover:bg-[#262626] disabled:opacity-50"
        >
          <Database className="w-4 h-4" aria-hidden="true" />
          <span>Initialiser / synchroniser le jeu démo Firestore</span>
        </button>
      </div>

      {/* Onglets */}
      <div className="flex flex-wrap gap-2 border-b border-[#E2E2DE] pb-4">
        {[
          { id: "requests", label: `Demandes & Essais (${testDrives.length})` },
          { id: "stock", label: `Stocks (${stocks.length})` },
          { id: "tariffs", label: "Tarifs & Règles" },
          { id: "dealers", label: "Concessionnaires & Créneaux" },
          { id: "catalog", label: "Catalogue & Médias" },
          { id: "audit", label: `Audit & Sauvegarde (${auditLogs.length})` },
        ].map((t) => (
          <button
            key={t.id}
            type="button"
            onClick={() => setTab(t.id as AdminTab)}
            className={`px-4 py-2 text-xs font-semibold border transition-colors ${
              tab === t.id
                ? "bg-[#0D0D0D] text-white border-[#0D0D0D]"
                : "bg-white text-[#0D0D0D] border-[#E2E2DE] hover:border-[#0D0D0D]"
            }`}
          >
            {t.label}
          </button>
        ))}
      </div>

      {feedback && (
        <div
          role="status"
          className="border border-[#0D0D0D] bg-[#F7E300]/25 px-4 py-3 text-sm font-medium"
        >
          {feedback}
        </div>
      )}

      {/* 1. Demandes & Essais */}
      {tab === "requests" && (
        <div className="space-y-8">
          <section className="space-y-4">
            <h2 className="font-display text-2xl font-bold">
              Demandes d&apos;essai routier
            </h2>
            {testDrives.length === 0 ? (
              <p className="text-sm text-[#595959] bg-white border border-[#E2E2DE] p-5">
                Aucune demande d&apos;essai reçue pour le moment.
              </p>
            ) : (
              <div className="space-y-3">
                {testDrives.map((td) => (
                  <div
                    key={td.id}
                    className="bg-white border border-[#E2E2DE] p-5 space-y-3"
                  >
                    <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                      <div>
                        <p className="text-xs text-[#595959]">
                          {td.id} · {td.dealerId} · {td.slotLabel}
                        </p>
                        <p className="font-display text-lg font-bold">
                          {td.customerName} — {td.modelSlug}
                        </p>
                        <p className="text-xs text-[#595959]">
                          {td.customerEmail} · {td.customerPhone}
                        </p>
                      </div>
                      <span className="text-xs font-bold px-3 py-1 border border-[#0D0D0D] bg-[#FAF9F6] self-start">
                        Statut :{" "}
                        {td.status === "received"
                          ? "Demande reçue"
                          : td.status === "confirmed"
                          ? "Rendez-vous confirmé"
                          : td.status}
                      </span>
                    </div>

                    <div className="flex flex-wrap items-center gap-3 pt-2 border-t border-[#E2E2DE]">
                      <input
                        type="text"
                        placeholder="Note de confirmation ou motif..."
                        value={adminNoteMap[td.id] ?? td.adminNote ?? ""}
                        onChange={(e) =>
                          setAdminNoteMap((p) => ({
                            ...p,
                            [td.id]: e.target.value,
                          }))
                        }
                        className="border border-[#E2E2DE] px-3 py-2 text-xs flex-1 min-w-[220px]"
                      />
                      <button
                        type="button"
                        onClick={async () => {
                          await adminUpdateTestDriveStatus({
                            requestId: td.id,
                            slotId: td.slotId,
                            status: "confirmed",
                            adminNote:
                              adminNoteMap[td.id] ||
                              "Rendez-vous confirmé par le conseiller.",
                            actorUid: user.uid,
                          });
                          await loadAllAdmin();
                          setFeedback(
                            `Essai ${td.id} confirmé (« Rendez-vous confirmé »).`
                          );
                        }}
                        className="inline-flex items-center gap-1.5 bg-[#0D0D0D] text-white text-xs font-semibold px-4 py-2"
                      >
                        <CheckCircle2 className="w-3.5 h-3.5" aria-hidden="true" />
                        <span>Confirmer le rendez-vous</span>
                      </button>
                      <button
                        type="button"
                        onClick={async () => {
                          await adminUpdateTestDriveStatus({
                            requestId: td.id,
                            slotId: td.slotId,
                            status: "declined",
                            adminNote:
                              adminNoteMap[td.id] || "Créneau indisponible.",
                            actorUid: user.uid,
                          });
                          await loadAllAdmin();
                          setFeedback(`Essai ${td.id} refusé et créneau libéré.`);
                        }}
                        className="border border-[#B91C1C] text-[#991B1B] text-xs font-semibold px-4 py-2"
                      >
                        Refuser
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </section>

          <section className="space-y-4">
            <h2 className="font-display text-2xl font-bold">
              Demandes commerciales &amp; réservations stock ({commercials.length})
            </h2>
            <div className="space-y-3">
              {commercials.map((c) => (
                <div
                  key={c.id}
                  className="bg-white border border-[#E2E2DE] p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-4 text-sm"
                >
                  <div>
                    <p className="font-semibold">
                      {c.customerName} · {c.requestType} · {c.modelSlug}
                    </p>
                    <p className="text-xs text-[#595959]">
                      {c.customerEmail} · Statut : {c.status}
                    </p>
                  </div>
                  <div className="flex gap-2">
                    <button
                      type="button"
                      onClick={async () => {
                        await adminUpdateCommercialStatus({
                          requestId: c.id,
                          status: "confirmed",
                          actorUid: user.uid,
                        });
                        await loadAllAdmin();
                      }}
                      className="bg-[#0D0D0D] text-white text-xs font-semibold px-3 py-2"
                    >
                      Valider
                    </button>
                    <button
                      type="button"
                      onClick={async () => {
                        await adminUpdateCommercialStatus({
                          requestId: c.id,
                          status: "declined",
                          actorUid: user.uid,
                        });
                        await loadAllAdmin();
                      }}
                      className="border border-[#E2E2DE] text-xs px-3 py-2"
                    >
                      Clôturer
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </section>
        </div>
      )}

      {/* 2. Stocks */}
      {tab === "stock" && (
        <div className="space-y-4">
          <h2 className="font-display text-2xl font-bold">
            Gestion des stocks physiques
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {stocks.map((s) => (
              <div
                key={s.id}
                className="bg-white border border-[#E2E2DE] p-5 space-y-3"
              >
                <div className="flex justify-between gap-4">
                  <div>
                    <p className="text-xs font-mono-tabular text-[#595959]">
                      {s.vinDemo}
                    </p>
                    <p className="font-bold">
                      {s.modelSlug} · {s.trimName}
                    </p>
                  </div>
                  <span className="font-mono-tabular font-bold">
                    {formatCentsEUR(s.priceCents)}
                  </span>
                </div>
                <div className="flex flex-wrap gap-2">
                  {(["available", "reserved", "sold"] as const).map((st) => (
                    <button
                      key={st}
                      type="button"
                      onClick={async () => {
                        await adminUpdateStockStatus({
                          vehicleId: s.id,
                          status: st,
                          priceCents: s.priceCents,
                          stock: s,
                          actorUid: user.uid,
                        });
                        await loadAllAdmin();
                        setFeedback(`Stock ${s.vinDemo} mis à jour (${st}).`);
                      }}
                      className={`text-xs font-semibold px-3 py-1.5 border ${
                        s.status === st
                          ? "bg-[#0D0D0D] text-white border-[#0D0D0D]"
                          : "bg-white border-[#E2E2DE]"
                      }`}
                    >
                      {st === "available"
                        ? "Disponible"
                        : st === "reserved"
                        ? "Réservé"
                        : "Vendu"}
                    </button>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* 3. Tarifs & Règles */}
      {tab === "tariffs" && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          <div className="bg-white border border-[#E2E2DE] p-6 space-y-4">
            <h2 className="font-display text-xl font-bold">
              Tarifs versionnés &amp; dates d&apos;effet
            </h2>
            <div className="space-y-2 text-xs">
              {tariffs.map((t) => (
                <div
                  key={t.version}
                  className="border border-[#E2E2DE] p-3 flex justify-between"
                >
                  <div>
                    <p className="font-bold">{t.version}</p>
                    <p className="text-[#595959]">
                      Effet : {t.effectiveDate} · Livraison{" "}
                      {formatCentsEUR(t.deliveryFeeCents, true)}
                    </p>
                  </div>
                  <span className="font-semibold">
                    {t.isActive ? "Actif" : "Archivé"}
                  </span>
                </div>
              ))}
            </div>
            <form
              onSubmit={async (e) => {
                e.preventDefault();
                await adminPublishTariff({
                  tariff: {
                    version: newTariffVersion,
                    label: newTariffVersion,
                    effectiveDate: newTariffDate,
                    market: "FR",
                    deliveryFeeCents: Math.round(newDeliveryEuros * 100),
                    mandatoryAdminFeeCents: 1376,
                    discountDemoCents: Math.round(newDiscountEuros * 100),
                    isActive: true,
                  },
                  actorUid: user.uid,
                });
                await loadAllAdmin();
                setFeedback(`Tarif ${newTariffVersion} publié.`);
              }}
              className="pt-4 border-t border-[#E2E2DE] space-y-3 text-xs"
            >
              <p className="font-bold">Publier une nouvelle version tarifaire</p>
              <div className="grid grid-cols-2 gap-2">
                <input
                  type="text"
                  value={newTariffVersion}
                  onChange={(e) => setNewTariffVersion(e.target.value)}
                  className="border border-[#E2E2DE] px-2.5 py-2"
                  placeholder="Code version"
                />
                <input
                  type="date"
                  value={newTariffDate}
                  onChange={(e) => setNewTariffDate(e.target.value)}
                  className="border border-[#E2E2DE] px-2.5 py-2"
                />
                <input
                  type="number"
                  value={newDeliveryEuros}
                  onChange={(e) => setNewDeliveryEuros(Number(e.target.value))}
                  className="border border-[#E2E2DE] px-2.5 py-2"
                  placeholder="Livraison (€)"
                />
                <input
                  type="number"
                  value={newDiscountEuros}
                  onChange={(e) => setNewDiscountEuros(Number(e.target.value))}
                  className="border border-[#E2E2DE] px-2.5 py-2"
                  placeholder="Remise démo (€)"
                />
              </div>
              <button
                type="submit"
                className="bg-[#0D0D0D] text-white font-semibold px-4 py-2"
              >
                Publier le tarif
              </button>
            </form>
          </div>

          <div className="bg-white border border-[#E2E2DE] p-6 space-y-4">
            <h2 className="font-display text-xl font-bold">
              Règles du configurateur
            </h2>
            <div className="space-y-2.5 text-xs">
              {CONFIGURATOR_RULES.map((rule) => {
                const enabled = ruleStates[rule.code] ?? true;
                return (
                  <div
                    key={rule.code}
                    className="border border-[#E2E2DE] p-3 flex items-start justify-between gap-3"
                  >
                    <div>
                      <p className="font-mono-tabular font-bold">{rule.code}</p>
                      <p className="font-semibold">{rule.title}</p>
                      <p className="text-[#595959]">{rule.description}</p>
                    </div>
                    <button
                      type="button"
                      onClick={async () => {
                        const next = !enabled;
                        setRuleStates((p) => ({ ...p, [rule.code]: next }));
                        await adminToggleRule({
                          ruleCode: rule.code,
                          modelSlug: rule.modelSlug,
                          description: rule.description,
                          enabled: next,
                          actorUid: user.uid,
                        });
                      }}
                      className={`px-3 py-1.5 border font-semibold shrink-0 ${
                        enabled
                          ? "bg-[#0D0D0D] text-white border-[#0D0D0D]"
                          : "bg-white text-[#595959] border-[#E2E2DE]"
                      }`}
                    >
                      {enabled ? "Active" : "Inactive"}
                    </button>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      )}

      {/* 4. Concessionnaires & Créneaux */}
      {tab === "dealers" && (
        <div className="space-y-4">
          <h2 className="font-display text-2xl font-bold">
            Concessionnaires &amp; créneaux d&apos;essai
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {DEMO_DEALERS.map((d) => {
              const dealerSeeds = INITIAL_DEALER_SLOTS.filter(
                (s) => s.dealerId === d.id
              ).slice(0, 6);
              return (
                <div
                  key={d.id}
                  className="bg-white border border-[#E2E2DE] p-5 space-y-3"
                >
                  <p className="font-bold">{d.name}</p>
                  <p className="text-xs text-[#595959]">{d.address}</p>
                  <div className="grid grid-cols-3 gap-2 text-xs">
                    {dealerSeeds.map((seed) => {
                      const live = slots.find((l) => l.id === seed.id);
                      const status = live?.status || seed.status;
                      return (
                        <button
                          key={seed.id}
                          type="button"
                          onClick={async () => {
                            const nextStatus =
                              status === "closed" ? "available" : "closed";
                            await adminUpdateSlotStatus({
                              slot: {
                                id: seed.id,
                                dealerId: seed.dealerId,
                                dateIso: seed.dateIso,
                                timeSlot: seed.timeSlot,
                                status,
                              },
                              status: nextStatus,
                              actorUid: user.uid,
                            });
                            await loadAllAdmin();
                          }}
                          className="border border-[#E2E2DE] p-2 text-left hover:border-[#0D0D0D]"
                        >
                          <span className="block font-mono-tabular">
                            {seed.dateIso.slice(5)} {seed.timeSlot}
                          </span>
                          <span className="text-[11px] text-[#595959]">
                            {status}
                          </span>
                        </button>
                      );
                    })}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* 5. Catalogue & Médias */}
      {tab === "catalog" && (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {VEHICLE_MODELS.map((m) => (
            <div
              key={m.slug}
              className="bg-white border border-[#E2E2DE] p-5 space-y-2 text-xs"
            >
              <p className="font-display text-lg font-bold">{m.name}</p>
              <p className="text-[#595959]">
                Source : {m.provenance.source}
              </p>
              <p>
                Statut : <strong>{m.provenance.verificationStatus}</strong>
              </p>
              <p className="font-mono-tabular text-[11px] text-[#595959] truncate">
                Média principal : {m.heroImage}
              </p>
            </div>
          ))}
        </div>
      )}

      {/* 6. Journal d'audit & Sauvegarde */}
      {tab === "audit" && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
          <div className="lg:col-span-7 bg-white border border-[#E2E2DE] p-6 space-y-4">
            <h2 className="font-display text-xl font-bold">
              Journal d&apos;audit expurgé
            </h2>
            {auditLogs.length === 0 ? (
              <p className="text-xs text-[#595959]">
                Aucune trace enregistrée pour l&apos;instant. Initialisez le jeu
                de démonstration ou confirmez un essai pour alimenter le journal.
              </p>
            ) : (
              <div className="divide-y divide-[#E2E2DE] text-xs max-h-[420px] overflow-y-auto">
                {auditLogs.map((log) => (
                  <div key={log.id} className="py-2.5 space-y-0.5">
                    <p className="font-mono-tabular font-bold">
                      {log.action} · {log.targetCollection}/{log.targetId}
                    </p>
                    <p className="text-[#595959]">{log.summary}</p>
                  </div>
                ))}
              </div>
            )}
          </div>

          <div className="lg:col-span-5 bg-white border border-[#E2E2DE] p-6 space-y-4">
            <h2 className="font-display text-xl font-bold">
              Sauvegarde &amp; Restauration
            </h2>
            <button
              type="button"
              onClick={handleDownloadBackup}
              className="w-full inline-flex items-center justify-center gap-2 bg-[#0D0D0D] text-white text-xs font-semibold px-4 py-3"
            >
              <Download className="w-4 h-4" aria-hidden="true" />
              <span>Exporter la sauvegarde JSON</span>
            </button>

            <div className="pt-3 border-t border-[#E2E2DE] space-y-2">
              <label
                htmlFor="restore-json"
                className="block text-xs font-semibold"
              >
                Vérifier une archive JSON avant restauration
              </label>
              <textarea
                id="restore-json"
                rows={5}
                value={restoreJson}
                onChange={(e) => setRestoreJson(e.target.value)}
                placeholder='{"schemaVersion":"1.0","exportedAt":"2026-11-28T12:00:00Z","collections":{...}}'
                className="w-full border border-[#E2E2DE] p-2 font-mono-tabular text-[11px]"
              />
              <button
                type="button"
                onClick={handleValidateRestore}
                className="inline-flex items-center gap-2 border border-[#0D0D0D] text-xs font-semibold px-4 py-2"
              >
                <Upload className="w-3.5 h-3.5" aria-hidden="true" />
                <span>Valider côté serveur (/api/backup)</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
