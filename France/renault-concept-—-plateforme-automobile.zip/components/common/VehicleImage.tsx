"use client";

import { useState } from "react";
import Image from "next/image";
import { CarFront } from "lucide-react";

interface VehicleImageProps {
  src: string;
  alt: string;
  width?: number;
  height?: number;
  fill?: boolean;
  priority?: boolean;
  className?: string;
  style?: React.CSSProperties;
  sizes?: string;
}

export function VehicleImage({
  src,
  alt,
  width,
  height,
  fill,
  priority = false,
  className = "",
  style,
  sizes,
}: VehicleImageProps) {
  const [hasError, setHasError] = useState(false);

  if (hasError || !src) {
    return (
      <div
        className={`flex flex-col items-center justify-center bg-[#ECECE9] text-[#595959] p-6 text-center ${
          fill ? "absolute inset-0" : "w-full h-full"
        }`}
      >
        <CarFront className="w-8 h-8 mb-2 stroke-[1.5]" aria-hidden="true" />
        <span className="text-xs font-medium">{alt}</span>
      </div>
    );
  }

  if (fill) {
    return (
      <Image
        src={src}
        alt={alt}
        fill
        priority={priority}
        sizes={sizes || "(max-width: 768px) 100vw, 50vw"}
        referrerPolicy="no-referrer"
        className={className}
        style={style}
        onError={() => setHasError(true)}
      />
    );
  }

  return (
    <Image
      src={src}
      alt={alt}
      width={width || 1200}
      height={height || 900}
      priority={priority}
      sizes={sizes || "(max-width: 768px) 100vw, 50vw"}
      referrerPolicy="no-referrer"
      className={className}
      style={style}
      onError={() => setHasError(true)}
    />
  );
}
