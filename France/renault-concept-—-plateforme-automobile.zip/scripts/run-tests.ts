import assert from "node:assert/strict";
import {
  getDefaultSelectionForModel,
  validateAndPriceConfiguration,
} from "../lib/configurator/engine";
import { ConfigSelectionSchema } from "../lib/configurator/rules";
import { formatCentsEUR } from "../lib/pricing/tariffs";
import { DIRTY_DOZEN_CASES } from "../firestore.rules.test";

let passed = 0;
function test(name: string, fn: () => void) {
  fn();
  passed++;
  console.log(`PASS: ${name}`);
}

test("1. Configuration par défaut Renault 5 valide et tarifée en centimes", () => {
  const sel = getDefaultSelectionForModel("renault-5-e-tech");
  const res = validateAndPriceConfiguration(sel);
  assert.equal(res.valid, true);
  assert.equal(res.issues.length, 0);
  assert.equal(res.pricing.tariffVersion, "TARIF-FR-2026-Q4");
  assert.equal(res.pricing.publicAidCents, 0);
  assert.equal(
    res.pricing.totalKnownCents,
    2790000 + 1376 + 69000
  );
  assert.ok(formatCentsEUR(res.pricing.totalKnownCents, true).includes("28"));
});

test("2. Rejet expliqué d'une option incompatible sans modification silencieuse", () => {
  const sel = getDefaultSelectionForModel("renault-5-e-tech");
  sel.trimId = "trim-r5-evolution";
  sel.optionIds = ["opt-r5-harman"];
  const res = validateAndPriceConfiguration(sel);
  assert.equal(res.valid, false);
  assert.equal(res.issues[0].ruleCode, "R5_HARMAN_NEEDS_TECHNO");
  // Vérifie que l'option incompatible n'a PAS été retirée silencieusement
  assert.deepEqual(res.selection.optionIds, ["opt-r5-harman"]);
  assert.equal(res.selection.trimId, "trim-r5-evolution");
});

test("3. Exclusivité Pack Hiver vs Kit Aéro Sport expliquée", () => {
  const sel = getDefaultSelectionForModel("renault-5-e-tech");
  sel.trimId = "trim-r5-techno";
  sel.optionIds = ["opt-r5-winter", "opt-r5-alpine-aero"];
  const res = validateAndPriceConfiguration(sel);
  assert.equal(res.valid, false);
  assert.ok(res.issues.some((i) => i.ruleCode === "R5_WINTER_VS_AERO"));
});

test("4. Équipement déjà inclus sur Rafale Atelier Alpine non facturé en double", () => {
  const sel = getDefaultSelectionForModel("rafale-e-tech");
  sel.trimId = "trim-rafale-atelier";
  sel.optionIds = ["opt-rafale-4control"];
  const res = validateAndPriceConfiguration(sel);
  assert.equal(res.valid, true);
  assert.equal(res.issues[0].severity, "included");
  assert.equal(res.pricing.optionsTotalCents, 0);
});

test("5. Versionnement tarifaire conservant les anciens tarifs (Q2 vs Q4)", () => {
  const q4 = validateAndPriceConfiguration({
    ...getDefaultSelectionForModel("scenic-e-tech"),
    tariffVersion: "TARIF-FR-2026-Q4",
  });
  const q2 = validateAndPriceConfiguration({
    ...getDefaultSelectionForModel("scenic-e-tech"),
    tariffVersion: "TARIF-FR-2026-Q2",
  });
  assert.notEqual(q4.pricing.totalKnownCents, q2.pricing.totalKnownCents);
  assert.equal(q2.pricing.discountDemoCents, 50000);
});

test("6. Validation Zod rejette les entrées malformées", () => {
  const bad = ConfigSelectionSchema.safeParse({
    modelSlug: "modele-inconnu",
    motorisationId: "",
    trimId: "x",
    colorId: "x",
    wheelId: "x",
    interiorId: "x",
    optionIds: [],
  });
  assert.equal(bad.success, false);
});

test("7. Couverture des 12 vecteurs de sécurité Dirty Dozen", () => {
  assert.equal(DIRTY_DOZEN_CASES.length, 12);
});

console.log(`\nTous les tests ont réussi (${passed}/${passed}).`);
