"use client";

import {
  collection,
  deleteDoc,
  doc,
  getDoc,
  getDocs,
  orderBy,
  query,
  runTransaction,
  serverTimestamp,
  setDoc,
  updateDoc,
  where,
  writeBatch,
} from "firebase/firestore";
import {
  OperationType,
  db,
  handleFirestoreError,
} from "@/lib/firebase/client";
import {
  INITIAL_STOCK_VEHICLES,
  VEHICLE_MODELS,
} from "@/lib/catalog/data";
import { StockVehicle } from "@/lib/catalog/types";
import { ConfigSelectionInput } from "@/lib/configurator/rules";
import { CONFIGURATOR_RULES } from "@/lib/configurator/rules";
import { ConfigurationValidationResult } from "@/lib/configurator/engine";
import {
  DEMO_DEALERS,
  DealerInfo,
  INITIAL_DEALER_SLOTS,
} from "@/lib/dealers/data";
import { TARIFF_VERSIONS, TariffVersionRecord } from "@/lib/pricing/tariffs";
import { UserProfileData } from "@/components/providers/AuthProvider";

export interface SavedConfigurationDoc {
  id: string;
  ownerUid: string;
  shareCode: string;
  isPublicShare: boolean;
  title: string;
  modelSlug: ConfigSelectionInput["modelSlug"];
  modelYear: number;
  motorisationId: string;
  trimId: string;
  batteryId: string;
  colorId: string;
  wheelId: string;
  interiorId: string;
  optionIds: string[];
  tariffVersion: string;
  totalKnownCents: number;
  pricingSnapshot: ConfigurationValidationResult["pricing"];
  createdAt?: { seconds: number } | string;
  updatedAt?: { seconds: number } | string;
}

export interface TestDriveRequestDoc {
  id: string;
  ownerUid: string;
  modelSlug: string;
  dealerId: string;
  slotId: string;
  slotLabel: string;
  customerName: string;
  customerEmail: string;
  customerPhone: string;
  notes?: string;
  status: "received" | "confirmed" | "declined" | "cancelled";
  adminNote?: string;
  idempotencyKey: string;
  createdAt?: { seconds: number } | string;
}

export interface CommercialRequestDoc {
  id: string;
  ownerUid: string;
  requestType: "quote" | "stock_reservation" | "fleet";
  modelSlug: string;
  dealerId: string;
  configId?: string;
  stockVehicleId?: string;
  estimatedTotalCents?: number;
  tariffVersion?: string;
  customerName: string;
  customerEmail: string;
  customerPhone?: string;
  message?: string;
  status: "received" | "confirmed" | "declined" | "cancelled";
  createdAt?: { seconds: number } | string;
}

export interface DealerSlotDoc {
  id: string;
  dealerId: string;
  dateIso: string;
  timeSlot: string;
  status: "available" | "held" | "booked" | "closed";
  bookedByUid?: string;
}

export interface AuditLogDoc {
  id: string;
  actorUid: string;
  action: string;
  targetCollection: string;
  targetId: string;
  summary: string;
  createdAt?: { seconds: number } | string;
}

function makeId(prefix: string): string {
  const rand = Math.random().toString(36).slice(2, 10);
  return `${prefix}_${Date.now()}_${rand}`;
}

export async function saveConfigurationToFirestore(params: {
  ownerUid: string;
  title: string;
  isPublicShare: boolean;
  validation: ConfigurationValidationResult;
  batteryId: string;
}): Promise<SavedConfigurationDoc> {
  const id = makeId("cfg");
  const shareCode = makeId("share").slice(0, 24);
  const path = `savedConfigurations/${id}`;

  const payload = {
    ownerUid: params.ownerUid,
    shareCode,
    isPublicShare: params.isPublicShare,
    title: params.title.slice(0, 120),
    modelSlug: params.validation.selection.modelSlug,
    modelYear: params.validation.resolvedLabels.modelYear,
    motorisationId: params.validation.selection.motorisationId,
    trimId: params.validation.selection.trimId,
    batteryId: params.batteryId,
    colorId: params.validation.selection.colorId,
    wheelId: params.validation.selection.wheelId,
    interiorId: params.validation.selection.interiorId,
    optionIds: params.validation.selection.optionIds.slice(0, 20),
    tariffVersion: params.validation.pricing.tariffVersion,
    totalKnownCents: params.validation.pricing.totalKnownCents,
    pricingSnapshot: params.validation.pricing,
    createdAt: serverTimestamp(),
    updatedAt: serverTimestamp(),
  };

  try {
    await setDoc(doc(db, "savedConfigurations", id), payload);
    return {
      id,
      ...payload,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
  } catch (error) {
    handleFirestoreError(error, OperationType.CREATE, path);
  }
}

export async function fetchUserConfigurations(
  ownerUid: string
): Promise<SavedConfigurationDoc[]> {
  const path = "savedConfigurations";
  try {
    const q = query(
      collection(db, "savedConfigurations"),
      where("ownerUid", "==", ownerUid)
    );
    const snap = await getDocs(q);
    return snap.docs.map((d) => ({
      id: d.id,
      ...(d.data() as Omit<SavedConfigurationDoc, "id">),
    }));
  } catch (error) {
    handleFirestoreError(error, OperationType.LIST, path);
  }
}

export async function fetchSavedConfigurationById(
  configId: string
): Promise<SavedConfigurationDoc | null> {
  const path = `savedConfigurations/${configId}`;
  try {
    const snap = await getDoc(doc(db, "savedConfigurations", configId));
    if (!snap.exists()) return null;
    return {
      id: snap.id,
      ...(snap.data() as Omit<SavedConfigurationDoc, "id">),
    };
  } catch (error) {
    handleFirestoreError(error, OperationType.GET, path);
  }
}

export async function deleteSavedConfiguration(configId: string): Promise<void> {
  const path = `savedConfigurations/${configId}`;
  try {
    await deleteDoc(doc(db, "savedConfigurations", configId));
  } catch (error) {
    handleFirestoreError(error, OperationType.DELETE, path);
  }
}

export async function toggleFavoriteModel(
  uid: string,
  modelSlug: string,
  currentFavorites: string[]
): Promise<string[]> {
  const path = `users/${uid}`;
  const exists = currentFavorites.includes(modelSlug);
  const nextFavorites = exists
    ? currentFavorites.filter((s) => s !== modelSlug)
    : [...currentFavorites, modelSlug].slice(0, 12);

  try {
    await updateDoc(doc(db, "users", uid), {
      favoriteModelSlugs: nextFavorites,
      updatedAt: serverTimestamp(),
    });
    return nextFavorites;
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, path);
  }
}

export async function updateUserPreferences(
  uid: string,
  patch: Partial<
    Pick<
      UserProfileData,
      "displayName" | "phone" | "postalCode" | "emailOptIn" | "smsOptIn" | "preferredDealerId"
    >
  >
): Promise<void> {
  const path = `users/${uid}`;
  try {
    await updateDoc(doc(db, "users", uid), {
      ...patch,
      updatedAt: serverTimestamp(),
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, path);
  }
}

export async function fetchDealerSlots(dealerId?: string): Promise<DealerSlotDoc[]> {
  const path = "dealerSlots";
  try {
    const q = dealerId
      ? query(collection(db, "dealerSlots"), where("dealerId", "==", dealerId))
      : collection(db, "dealerSlots");
    const snap = await getDocs(q);
    return snap.docs.map((d) => ({
      id: d.id,
      ...(d.data() as Omit<DealerSlotDoc, "id">),
    }));
  } catch (error) {
    handleFirestoreError(error, OperationType.LIST, path);
  }
}

export async function bookTestDriveAtomic(params: {
  ownerUid: string;
  modelSlug: string;
  dealerId: string;
  slotId: string;
  dateIso: string;
  timeSlot: string;
  slotLabel: string;
  customerName: string;
  customerEmail: string;
  customerPhone: string;
  notes?: string;
  idempotencyKey: string;
}): Promise<TestDriveRequestDoc> {
  // Prévenir les soumissions dupliquées côté utilisateur
  const existingUserRequests = await fetchUserTestDrives(params.ownerUid);
  const duplicate = existingUserRequests.find(
    (r) => r.idempotencyKey === params.idempotencyKey
  );
  if (duplicate) {
    return duplicate;
  }

  const reqId = makeId("td");
  const slotRef = doc(db, "dealerSlots", params.slotId);
  const reqRef = doc(db, "testDriveRequests", reqId);

  try {
    await runTransaction(db, async (tx) => {
      const slotSnap = await tx.get(slotRef);
      if (slotSnap.exists()) {
        const currentStatus = slotSnap.data().status;
        if (currentStatus !== "available") {
          throw new Error(
            "Ce créneau vient d'être réservé ou est fermé. Veuillez sélectionner un autre horaire."
          );
        }
        tx.update(slotRef, {
          status: "booked",
          bookedByUid: params.ownerUid,
          updatedAt: serverTimestamp(),
        });
      } else {
        tx.set(slotRef, {
          dealerId: params.dealerId,
          dateIso: params.dateIso,
          timeSlot: params.timeSlot,
          status: "booked",
          bookedByUid: params.ownerUid,
          updatedAt: serverTimestamp(),
        });
      }

      const reqData: Record<string, unknown> = {
        ownerUid: params.ownerUid,
        modelSlug: params.modelSlug,
        dealerId: params.dealerId,
        slotId: params.slotId,
        slotLabel: params.slotLabel,
        customerName: params.customerName.trim().slice(0, 120),
        customerEmail: params.customerEmail.trim().slice(0, 180),
        customerPhone: params.customerPhone.trim().slice(0, 32),
        status: "received",
        idempotencyKey: params.idempotencyKey,
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      };
      if (params.notes?.trim()) {
        reqData.notes = params.notes.trim().slice(0, 500);
      }
      tx.set(reqRef, reqData);
    });

    return {
      id: reqId,
      ownerUid: params.ownerUid,
      modelSlug: params.modelSlug,
      dealerId: params.dealerId,
      slotId: params.slotId,
      slotLabel: params.slotLabel,
      customerName: params.customerName,
      customerEmail: params.customerEmail,
      customerPhone: params.customerPhone,
      notes: params.notes,
      status: "received",
      idempotencyKey: params.idempotencyKey,
      createdAt: new Date().toISOString(),
    };
  } catch (error) {
    if (
      error instanceof Error &&
      error.message.includes("créneau vient d'être réservé")
    ) {
      throw error;
    }
    handleFirestoreError(error, OperationType.WRITE, `testDriveRequests/${reqId}`);
  }
}

export async function fetchUserTestDrives(
  ownerUid: string
): Promise<TestDriveRequestDoc[]> {
  const path = "testDriveRequests";
  try {
    const q = query(
      collection(db, "testDriveRequests"),
      where("ownerUid", "==", ownerUid)
    );
    const snap = await getDocs(q);
    return snap.docs.map((d) => ({
      id: d.id,
      ...(d.data() as Omit<TestDriveRequestDoc, "id">),
    }));
  } catch (error) {
    handleFirestoreError(error, OperationType.LIST, path);
  }
}

export async function cancelUserTestDrive(requestId: string): Promise<void> {
  const path = `testDriveRequests/${requestId}`;
  try {
    await updateDoc(doc(db, "testDriveRequests", requestId), {
      status: "cancelled",
      updatedAt: serverTimestamp(),
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, path);
  }
}

export async function createCommercialRequest(params: {
  ownerUid: string;
  requestType: "quote" | "stock_reservation" | "fleet";
  modelSlug: string;
  dealerId: string;
  configId?: string;
  stockVehicleId?: string;
  estimatedTotalCents?: number;
  tariffVersion?: string;
  customerName: string;
  customerEmail: string;
  customerPhone?: string;
  message?: string;
}): Promise<CommercialRequestDoc> {
  const id = makeId("com");
  const path = `commercialRequests/${id}`;
  const payload: Record<string, unknown> = {
    ownerUid: params.ownerUid,
    requestType: params.requestType,
    modelSlug: params.modelSlug,
    dealerId: params.dealerId,
    customerName: params.customerName.trim().slice(0, 120),
    customerEmail: params.customerEmail.trim().slice(0, 180),
    status: "received",
    createdAt: serverTimestamp(),
    updatedAt: serverTimestamp(),
  };

  if (params.configId) payload.configId = params.configId;
  if (params.stockVehicleId) payload.stockVehicleId = params.stockVehicleId;
  if (typeof params.estimatedTotalCents === "number") {
    payload.estimatedTotalCents = params.estimatedTotalCents;
  }
  if (params.tariffVersion) payload.tariffVersion = params.tariffVersion;
  if (params.customerPhone?.trim()) {
    payload.customerPhone = params.customerPhone.trim().slice(0, 32);
  }
  if (params.message?.trim()) {
    payload.message = params.message.trim().slice(0, 600);
  }

  try {
    await setDoc(doc(db, "commercialRequests", id), payload);
    return {
      id,
      ownerUid: params.ownerUid,
      requestType: params.requestType,
      modelSlug: params.modelSlug,
      dealerId: params.dealerId,
      configId: params.configId,
      stockVehicleId: params.stockVehicleId,
      estimatedTotalCents: params.estimatedTotalCents,
      tariffVersion: params.tariffVersion,
      customerName: params.customerName,
      customerEmail: params.customerEmail,
      customerPhone: params.customerPhone,
      message: params.message,
      status: "received",
      createdAt: new Date().toISOString(),
    };
  } catch (error) {
    handleFirestoreError(error, OperationType.CREATE, path);
  }
}

export async function fetchUserCommercialRequests(
  ownerUid: string
): Promise<CommercialRequestDoc[]> {
  const path = "commercialRequests";
  try {
    const q = query(
      collection(db, "commercialRequests"),
      where("ownerUid", "==", ownerUid)
    );
    const snap = await getDocs(q);
    return snap.docs.map((d) => ({
      id: d.id,
      ...(d.data() as Omit<CommercialRequestDoc, "id">),
    }));
  } catch (error) {
    handleFirestoreError(error, OperationType.LIST, path);
  }
}

// --- Lectures publiques ---
export async function fetchStockVehicles(): Promise<StockVehicle[]> {
  try {
    const snap = await getDocs(collection(db, "stockVehicles"));
    if (snap.empty) return INITIAL_STOCK_VEHICLES;
    return snap.docs.map((d) => {
      const data = d.data();
      const base = INITIAL_STOCK_VEHICLES.find((s) => s.id === d.id);
      return {
        id: d.id,
        modelSlug: data.modelSlug,
        dealerId: data.dealerId,
        vinDemo: data.vinDemo,
        modelYear: base?.modelYear ?? 2026,
        trimId: base?.trimId ?? "",
        trimName: data.trimName,
        motorisationId: base?.motorisationId ?? "",
        motorisationName: data.motorisationName,
        colorId: base?.colorId ?? "",
        colorName: data.colorName,
        colorHex: base?.colorHex ?? "#0D0D0D",
        priceCents: data.priceCents,
        mileageKm: data.mileageKm ?? 0,
        status: data.status,
        stockUpdatedAt:
          typeof data.stockUpdatedAt === "string"
            ? data.stockUpdatedAt
            : new Date().toISOString(),
        provenance: base?.provenance ?? VEHICLE_MODELS[0].provenance,
      } as StockVehicle;
    });
  } catch {
    return INITIAL_STOCK_VEHICLES;
  }
}

export async function fetchDealers(): Promise<DealerInfo[]> {
  try {
    const snap = await getDocs(collection(db, "dealers"));
    if (snap.empty) return DEMO_DEALERS;
    return snap.docs.map((d) => ({
      id: d.id,
      ...(d.data() as Omit<DealerInfo, "id">),
    }));
  } catch {
    return DEMO_DEALERS;
  }
}

// --- Opérations d'administration ---
export async function adminWriteAuditLog(params: {
  actorUid: string;
  action: string;
  targetCollection: string;
  targetId: string;
  summary: string;
}) {
  const id = makeId("audit");
  const path = `auditLogs/${id}`;
  try {
    await setDoc(doc(db, "auditLogs", id), {
      actorUid: params.actorUid,
      action: params.action.slice(0, 80),
      targetCollection: params.targetCollection.slice(0, 64),
      targetId: params.targetId.slice(0, 128),
      summary: params.summary.slice(0, 300),
      createdAt: serverTimestamp(),
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.CREATE, path);
  }
}

export async function adminFetchAllTestDrives(): Promise<TestDriveRequestDoc[]> {
  try {
    const snap = await getDocs(collection(db, "testDriveRequests"));
    return snap.docs.map((d) => ({
      id: d.id,
      ...(d.data() as Omit<TestDriveRequestDoc, "id">),
    }));
  } catch (error) {
    handleFirestoreError(error, OperationType.LIST, "testDriveRequests");
  }
}

export async function adminFetchAllCommercialRequests(): Promise<
  CommercialRequestDoc[]
> {
  try {
    const snap = await getDocs(collection(db, "commercialRequests"));
    return snap.docs.map((d) => ({
      id: d.id,
      ...(d.data() as Omit<CommercialRequestDoc, "id">),
    }));
  } catch (error) {
    handleFirestoreError(error, OperationType.LIST, "commercialRequests");
  }
}

export async function adminUpdateTestDriveStatus(params: {
  requestId: string;
  slotId: string;
  status: "confirmed" | "declined" | "cancelled";
  adminNote: string;
  actorUid: string;
}) {
  const path = `testDriveRequests/${params.requestId}`;
  try {
    const batch = writeBatch(db);
    batch.update(doc(db, "testDriveRequests", params.requestId), {
      status: params.status,
      adminNote: params.adminNote.slice(0, 400),
      updatedAt: serverTimestamp(),
    });

    if (params.status === "declined" || params.status === "cancelled") {
      batch.update(doc(db, "dealerSlots", params.slotId), {
        status: "available",
        bookedByUid: "",
        updatedAt: serverTimestamp(),
      });
    }

    const auditId = makeId("audit");
    batch.set(doc(db, "auditLogs", auditId), {
      actorUid: params.actorUid,
      action: `TEST_DRIVE_${params.status.toUpperCase()}`,
      targetCollection: "testDriveRequests",
      targetId: params.requestId,
      summary: `Statut essai mis à jour vers ${params.status} (créneau ${params.slotId})`,
      createdAt: serverTimestamp(),
    });

    await batch.commit();
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, path);
  }
}

export async function adminUpdateCommercialStatus(params: {
  requestId: string;
  status: "confirmed" | "declined" | "cancelled";
  actorUid: string;
}) {
  const path = `commercialRequests/${params.requestId}`;
  try {
    await updateDoc(doc(db, "commercialRequests", params.requestId), {
      status: params.status,
      updatedAt: serverTimestamp(),
    });
    await adminWriteAuditLog({
      actorUid: params.actorUid,
      action: `COMMERCIAL_${params.status.toUpperCase()}`,
      targetCollection: "commercialRequests",
      targetId: params.requestId,
      summary: `Demande commerciale passée à ${params.status}`,
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, path);
  }
}

export async function adminSeedDemoCollections(actorUid: string): Promise<number> {
  try {
    const batch = writeBatch(db);
    let count = 0;

    for (const dealer of DEMO_DEALERS) {
      batch.set(doc(db, "dealers", dealer.id), {
        name: dealer.name,
        city: dealer.city,
        postalCode: dealer.postalCode,
        address: dealer.address,
        phone: dealer.phone,
        hours: dealer.hours,
        lat: dealer.lat,
        lng: dealer.lng,
        services: dealer.services,
        active: dealer.active,
        updatedAt: serverTimestamp(),
      });
      count++;
    }

    for (const slot of INITIAL_DEALER_SLOTS) {
      batch.set(doc(db, "dealerSlots", slot.id), {
        dealerId: slot.dealerId,
        dateIso: slot.dateIso,
        timeSlot: slot.timeSlot,
        status: slot.status,
        updatedAt: serverTimestamp(),
      });
      count++;
    }

    for (const stock of INITIAL_STOCK_VEHICLES) {
      batch.set(doc(db, "stockVehicles", stock.id), {
        modelSlug: stock.modelSlug,
        dealerId: stock.dealerId,
        vinDemo: stock.vinDemo,
        trimName: stock.trimName,
        motorisationName: stock.motorisationName,
        colorName: stock.colorName,
        priceCents: stock.priceCents,
        mileageKm: stock.mileageKm,
        status: stock.status,
        stockUpdatedAt: serverTimestamp(),
      });
      count++;
    }

    for (const tariff of TARIFF_VERSIONS) {
      batch.set(doc(db, "tariffVersions", tariff.version), {
        version: tariff.version,
        effectiveDate: tariff.effectiveDate,
        market: tariff.market,
        deliveryFeeCents: tariff.deliveryFeeCents,
        mandatoryAdminFeeCents: tariff.mandatoryAdminFeeCents,
        discountDemoCents: tariff.discountDemoCents,
        isActive: tariff.isActive,
        updatedAt: serverTimestamp(),
      });
      count++;
    }

    for (const rule of CONFIGURATOR_RULES) {
      batch.set(doc(db, "configuratorRules", rule.code), {
        ruleCode: rule.code,
        modelSlug: rule.modelSlug,
        description: rule.description,
        enabled: true,
        updatedAt: serverTimestamp(),
      });
      count++;
    }

    for (const model of VEHICLE_MODELS) {
      batch.set(doc(db, "catalogOverrides", model.slug), {
        modelSlug: model.slug,
        verificationStatus: model.provenance.verificationStatus,
        heroImage: model.heroImage,
        marketNote: `Marché ${model.provenance.market} · Effet ${model.provenance.effectiveDate}`,
        updatedAt: serverTimestamp(),
      });
      count++;
    }

    const auditId = makeId("audit");
    batch.set(doc(db, "auditLogs", auditId), {
      actorUid,
      action: "SEED_DEMO_COLLECTIONS",
      targetCollection: "all",
      targetId: "demo-seed",
      summary: `Initialisation des données de démonstration (${count} documents).`,
      createdAt: serverTimestamp(),
    });

    await batch.commit();
    return count;
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, "adminSeedDemoCollections");
  }
}

export async function adminUpdateStockStatus(params: {
  vehicleId: string;
  status: "available" | "reserved" | "sold";
  priceCents: number;
  stock: StockVehicle;
  actorUid: string;
}) {
  const path = `stockVehicles/${params.vehicleId}`;
  try {
    await setDoc(doc(db, "stockVehicles", params.vehicleId), {
      modelSlug: params.stock.modelSlug,
      dealerId: params.stock.dealerId,
      vinDemo: params.stock.vinDemo,
      trimName: params.stock.trimName,
      motorisationName: params.stock.motorisationName,
      colorName: params.stock.colorName,
      priceCents: params.priceCents,
      mileageKm: params.stock.mileageKm,
      status: params.status,
      stockUpdatedAt: serverTimestamp(),
    });
    await adminWriteAuditLog({
      actorUid: params.actorUid,
      action: "STOCK_UPDATE",
      targetCollection: "stockVehicles",
      targetId: params.vehicleId,
      summary: `Stock ${params.stock.vinDemo} -> ${params.status} (${params.priceCents} cts)`,
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, path);
  }
}

export async function adminPublishTariff(params: {
  tariff: TariffVersionRecord;
  actorUid: string;
}) {
  const path = `tariffVersions/${params.tariff.version}`;
  try {
    await setDoc(doc(db, "tariffVersions", params.tariff.version), {
      version: params.tariff.version,
      effectiveDate: params.tariff.effectiveDate,
      market: params.tariff.market,
      deliveryFeeCents: params.tariff.deliveryFeeCents,
      mandatoryAdminFeeCents: params.tariff.mandatoryAdminFeeCents,
      discountDemoCents: params.tariff.discountDemoCents,
      isActive: params.tariff.isActive,
      updatedAt: serverTimestamp(),
    });
    await adminWriteAuditLog({
      actorUid: params.actorUid,
      action: "TARIFF_UPSERT",
      targetCollection: "tariffVersions",
      targetId: params.tariff.version,
      summary: `Tarif ${params.tariff.version} publié (effet ${params.tariff.effectiveDate})`,
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, path);
  }
}

export async function adminFetchTariffs(): Promise<TariffVersionRecord[]> {
  try {
    const snap = await getDocs(collection(db, "tariffVersions"));
    if (snap.empty) return TARIFF_VERSIONS;
    return snap.docs.map((d) => ({
      version: d.id,
      label: d.id,
      ...(d.data() as Omit<TariffVersionRecord, "version" | "label">),
    }));
  } catch {
    return TARIFF_VERSIONS;
  }
}

export async function adminToggleRule(params: {
  ruleCode: string;
  modelSlug: string;
  description: string;
  enabled: boolean;
  actorUid: string;
}) {
  const path = `configuratorRules/${params.ruleCode}`;
  try {
    await setDoc(doc(db, "configuratorRules", params.ruleCode), {
      ruleCode: params.ruleCode,
      modelSlug: params.modelSlug,
      description: params.description.slice(0, 300),
      enabled: params.enabled,
      updatedAt: serverTimestamp(),
    });
    await adminWriteAuditLog({
      actorUid: params.actorUid,
      action: "RULE_TOGGLE",
      targetCollection: "configuratorRules",
      targetId: params.ruleCode,
      summary: `Règle ${params.ruleCode} -> ${params.enabled ? "activée" : "désactivée"}`,
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, path);
  }
}

export async function adminUpdateSlotStatus(params: {
  slot: DealerSlotDoc;
  status: "available" | "closed";
  actorUid: string;
}) {
  const path = `dealerSlots/${params.slot.id}`;
  try {
    await setDoc(doc(db, "dealerSlots", params.slot.id), {
      dealerId: params.slot.dealerId,
      dateIso: params.slot.dateIso,
      timeSlot: params.slot.timeSlot,
      status: params.status,
      bookedByUid: "",
      updatedAt: serverTimestamp(),
    });
    await adminWriteAuditLog({
      actorUid: params.actorUid,
      action: "SLOT_UPDATE",
      targetCollection: "dealerSlots",
      targetId: params.slot.id,
      summary: `Créneau ${params.slot.id} -> ${params.status}`,
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, path);
  }
}

export async function adminFetchAuditLogs(): Promise<AuditLogDoc[]> {
  try {
    const q = query(collection(db, "auditLogs"), orderBy("createdAt", "desc"));
    const snap = await getDocs(q);
    return snap.docs.map((d) => ({
      id: d.id,
      ...(d.data() as Omit<AuditLogDoc, "id">),
    }));
  } catch {
    const snap = await getDocs(collection(db, "auditLogs"));
    return snap.docs.map((d) => ({
      id: d.id,
      ...(d.data() as Omit<AuditLogDoc, "id">),
    }));
  }
}
