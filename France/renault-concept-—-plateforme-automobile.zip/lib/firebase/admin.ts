import { initializeApp, getApps, getApp } from "firebase-admin/app";
import { getAuth, DecodedIdToken } from "firebase-admin/auth";
import { NextRequest } from "next/server";
import firebaseConfig from "../../firebase-applet-config.json";

const adminApp = getApps().length
  ? getApp()
  : initializeApp({
      projectId: firebaseConfig.projectId,
    });

export const adminAuth = getAuth(adminApp);

export const ADMIN_EMAILS = new Set(["tom@ahyx.org"]);

export async function verifyBearerToken(
  req: NextRequest
): Promise<DecodedIdToken | null> {
  const authHeader = req.headers.get("authorization");
  if (!authHeader || !authHeader.startsWith("Bearer ")) {
    return null;
  }
  const token = authHeader.slice("Bearer ".length).trim();
  if (!token) return null;

  try {
    return await adminAuth.verifyIdToken(token);
  } catch {
    return null;
  }
}

export function isVerifiedAdminToken(decoded: DecodedIdToken | null): boolean {
  if (!decoded) return false;
  return Boolean(
    decoded.email_verified &&
      decoded.email &&
      ADMIN_EMAILS.has(decoded.email.toLowerCase())
  );
}
