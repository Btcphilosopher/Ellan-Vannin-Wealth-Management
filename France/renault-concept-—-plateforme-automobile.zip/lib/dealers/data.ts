export interface DealerInfo {
  id: string;
  name: string;
  city: string;
  postalCode: string;
  address: string;
  phone: string;
  hours: string;
  lat: number;
  lng: number;
  services: string[];
  active: boolean;
}

export interface DealerSlotSeed {
  id: string;
  dealerId: string;
  dateIso: string;
  timeSlot: string;
  status: "available" | "booked" | "closed";
}

export const DEMO_DEALERS: DealerInfo[] = [
  {
    id: "dealer-paris-champs",
    name: "Atelier Concept Paris — Champs-Élysées",
    city: "Paris",
    postalCode: "75008",
    address: "51 Avenue des Champs-Élysées, 75008 Paris (Démonstration)",
    phone: "01 40 00 00 01",
    hours: "Lun–Sam 09:30–19:30 · Dim 11:00–18:00",
    lat: 48.8707,
    lng: 2.3078,
    services: ["Essais E-Tech", "Configuration Studio", "Livraison Paris"],
    active: true,
  },
  {
    id: "dealer-boulogne",
    name: "Concession Concept Boulogne-Billancourt",
    city: "Boulogne-Billancourt",
    postalCode: "92100",
    address: "18 Quai Georges Gorse, 92100 Boulogne-Billancourt (Démonstration)",
    phone: "01 40 00 00 02",
    hours: "Lun–Sam 08:30–19:00",
    lat: 48.8266,
    lng: 2.2385,
    services: ["Atelier Électrique", "Borne 150 kW", "Centre Pro+"],
    active: true,
  },
  {
    id: "dealer-lyon-confluence",
    name: "Espace Mobilité Lyon Confluence",
    city: "Lyon",
    postalCode: "69002",
    address: "112 Cours Charlemagne, 69002 Lyon (Démonstration)",
    phone: "04 72 00 00 03",
    hours: "Lun–Sam 09:00–19:00",
    lat: 45.7418,
    lng: 4.8154,
    services: ["Essais E-Tech", "Atelier Électrique", "Centre Pro+"],
    active: true,
  },
  {
    id: "dealer-bordeaux-merignac",
    name: "Pôle Automobile Bordeaux Mérignac",
    city: "Mérignac",
    postalCode: "33700",
    address: "44 Avenue de la Marne, 33700 Mérignac (Démonstration)",
    phone: "05 56 00 00 04",
    hours: "Lun–Sam 08:30–19:00",
    lat: 44.8357,
    lng: -0.6426,
    services: ["Essais E-Tech", "Borne 150 kW", "Stock Régional"],
    active: true,
  },
  {
    id: "dealer-lille-ascq",
    name: "Concession Concept Lille Métropole",
    city: "Villeneuve-d'Ascq",
    postalCode: "59650",
    address: "24 Boulevard de Valmy, 59650 Villeneuve-d'Ascq (Démonstration)",
    phone: "03 20 00 00 05",
    hours: "Lun–Sam 09:00–18:30",
    lat: 50.6292,
    lng: 3.1332,
    services: ["Essais E-Tech", "Atelier Électrique", "Centre Pro+"],
    active: true,
  },
  {
    id: "dealer-marseille-prado",
    name: "Espace Littoral Marseille Prado",
    city: "Marseille",
    postalCode: "13008",
    address: "210 Avenue du Prado, 13008 Marseille (Démonstration)",
    phone: "04 91 00 00 06",
    hours: "Lun–Sam 09:00–19:00",
    lat: 43.2768,
    lng: 5.3886,
    services: ["Essais E-Tech", "Borne 150 kW", "Livraison Sud"],
    active: true,
  },
];

export const INITIAL_DEALER_SLOTS: DealerSlotSeed[] = DEMO_DEALERS.flatMap(
  (dealer) => {
    const dates = ["2026-12-01", "2026-12-02", "2026-12-03"];
    const times = ["10:00", "14:00", "16:30"];
    return dates.flatMap((dateIso) =>
      times.map((timeSlot) => ({
        id: `${dealer.id}_${dateIso}_${timeSlot.replace(":", "")}`,
        dealerId: dealer.id,
        dateIso,
        timeSlot,
        status: "available" as const,
      }))
    );
  }
);

export function calculateDistanceKm(
  lat1: number,
  lng1: number,
  lat2: number,
  lng2: number
): number {
  const R = 6371;
  const dLat = ((lat2 - lat1) * Math.PI) / 180;
  const dLng = ((lng2 - lng1) * Math.PI) / 180;
  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos((lat1 * Math.PI) / 180) *
      Math.cos((lat2 * Math.PI) / 180) *
      Math.sin(dLng / 2) *
      Math.sin(dLng / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return Math.round(R * c);
}

// Coordonnées de référence par préfixe départemental français pour filtrage par code postal
export const POSTAL_PREFIX_COORDS: Record<string, { lat: number; lng: number }> = {
  "75": { lat: 48.8566, lng: 2.3522 },
  "92": { lat: 48.8266, lng: 2.2385 },
  "93": { lat: 48.9102, lng: 2.4822 },
  "94": { lat: 48.7904, lng: 2.4556 },
  "69": { lat: 45.764, lng: 4.8357 },
  "33": { lat: 44.8378, lng: -0.5792 },
  "59": { lat: 50.6292, lng: 3.0573 },
  "13": { lat: 43.2965, lng: 5.3698 },
};
