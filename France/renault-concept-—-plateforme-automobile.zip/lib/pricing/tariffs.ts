export interface TariffVersionRecord {
  version: string;
  label: string;
  effectiveDate: string;
  market: "FR";
  deliveryFeeCents: number;
  mandatoryAdminFeeCents: number;
  discountDemoCents: number;
  isActive: boolean;
}

export const TARIFF_VERSIONS: TariffVersionRecord[] = [
  {
    version: "TARIF-FR-2026-Q4",
    label: "Tarif Démonstration France — T4 2026 (Actif)",
    effectiveDate: "2026-11-01",
    market: "FR",
    deliveryFeeCents: 69000, // 690,00 € mise à la route & livraison
    mandatoryAdminFeeCents: 1376, // 13,76 € redevance d'acheminement indicative
    discountDemoCents: 0,
    isActive: true,
  },
  {
    version: "TARIF-FR-2026-Q2",
    label: "Tarif Démonstration France — T2 2026 (Archivé)",
    effectiveDate: "2026-04-01",
    market: "FR",
    deliveryFeeCents: 65000,
    mandatoryAdminFeeCents: 1376,
    discountDemoCents: 50000, // 500,00 € remise salon démo archivée
    isActive: false,
  },
];

export function getTariffByVersion(version?: string): TariffVersionRecord {
  if (version) {
    const found = TARIFF_VERSIONS.find((t) => t.version === version);
    if (found) return found;
  }
  return TARIFF_VERSIONS.find((t) => t.isActive) ?? TARIFF_VERSIONS[0];
}

export interface PricingBreakdown {
  tariffVersion: string;
  tariffEffectiveDate: string;
  market: "FR";
  baseVehicleCents: number;
  motorisationDeltaCents: number;
  trimDeltaCents: number;
  colorDeltaCents: number;
  wheelDeltaCents: number;
  interiorDeltaCents: number;
  optionsTotalCents: number;
  vehicleConfiguredSubtotalCents: number;
  mandatoryFeesCents: number;
  deliveryFeeCents: number;
  vatIncludedCents: number;
  discountDemoCents: number;
  publicAidCents: number;
  publicAidNotice: string;
  totalKnownCents: number;
  legalDisclaimer: string;
}

export function formatCentsEUR(cents: number, includeDecimals = false): string {
  const euros = cents / 100;
  return new Intl.NumberFormat("fr-FR", {
    style: "currency",
    currency: "EUR",
    minimumFractionDigits: includeDecimals ? 2 : cents % 100 === 0 ? 0 : 2,
    maximumFractionDigits: 2,
  }).format(euros);
}
