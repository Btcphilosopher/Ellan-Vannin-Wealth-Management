export type VerificationStatus =
  | "Démonstration vérifiée"
  | "Données indicatives de démonstration"
  | "Non communiqué";

export interface CatalogProvenance {
  source: string;
  market: "FR";
  effectiveDate: string;
  verificationStatus: VerificationStatus;
}

export interface VehicleModel {
  slug: "renault-5-e-tech" | "scenic-e-tech" | "rafale-e-tech";
  name: string;
  shortName: string;
  tagline: string;
  kicker: string;
  description: string;
  modelYear: number;
  segment: string;
  energyCategory: "electrique" | "hybride";
  proEligible: boolean;
  basePriceCents: number;
  heroImage: string;
  cardImage: string;
  interiorImage: string;
  detailImage: string;
  exteriorHighlights: string[];
  interiorHighlights: string[];
  dimensions: {
    lengthMm: number;
    widthMm: number;
    heightMm: number;
    bootVolumeLiters: number | null;
    bootStandard: string;
    curbWeightKg: number | null;
    towingCapacityKg: number | null;
  };
  warrantySummary: string | null;
  provenance: CatalogProvenance;
}

export interface Motorisation {
  id: string;
  modelSlug: VehicleModel["slug"];
  name: string;
  energy: "100 % Électrique" | "Hybride Rechargeable" | "Full Hybrid E-Tech";
  powerCh: number;
  powerKw: number;
  torqueNm: number | null;
  transmission: string;
  drivetrain: "Traction avant" | "Transmission intégrale 4x4";
  wltpRangeKm: number | null;
  wltpElectricRangeKm: number | null;
  measurementStandard: "WLTP cycle mixte (démonstration)";
  consumptionLabel: string | null;
  zeroToHundredSec: number | null;
  batteryId: string;
  priceDeltaCents: number;
  provenance: CatalogProvenance;
}

export interface BatterySpec {
  id: string;
  modelSlug: VehicleModel["slug"];
  name: string;
  chemistry: string;
  usableKwh: number;
  acMaxKw: number;
  dcMaxKw: number | null;
  charge15to80Min: number | null;
  provenance: CatalogProvenance;
}

export interface TrimLevel {
  id: string;
  modelSlug: VehicleModel["slug"];
  name: string;
  rank: number;
  subtitle: string;
  priceDeltaCents: number;
  includedEquipment: string[];
  provenance: CatalogProvenance;
}

export interface ExteriorColor {
  id: string;
  modelSlug: VehicleModel["slug"];
  name: string;
  hex: string;
  roofHex?: string;
  finishType: "Opaque" | "Métallisée" | "Nacrée" | "Bi-ton";
  priceDeltaCents: number;
  previewTintCss: string;
  provenance: CatalogProvenance;
}

export interface WheelOption {
  id: string;
  modelSlug: VehicleModel["slug"];
  name: string;
  sizeInches: number;
  finish: string;
  priceDeltaCents: number;
  provenance: CatalogProvenance;
}

export interface InteriorOption {
  id: string;
  modelSlug: VehicleModel["slug"];
  name: string;
  material: string;
  colorTheme: string;
  swatchHex: string;
  priceDeltaCents: number;
  provenance: CatalogProvenance;
}

export interface PackOption {
  id: string;
  modelSlug: VehicleModel["slug"];
  name: string;
  category: "Confort" | "Audio & Tech" | "Conduite" | "Style & Hiver";
  description: string;
  includedItems: string[];
  priceDeltaCents: number;
  provenance: CatalogProvenance;
}

export interface StockVehicle {
  id: string;
  modelSlug: VehicleModel["slug"];
  dealerId: string;
  vinDemo: string;
  modelYear: number;
  trimId: string;
  trimName: string;
  motorisationId: string;
  motorisationName: string;
  colorId: string;
  colorName: string;
  colorHex: string;
  priceCents: number;
  mileageKm: number;
  status: "available" | "reserved" | "sold";
  stockUpdatedAt: string;
  provenance: CatalogProvenance;
}
