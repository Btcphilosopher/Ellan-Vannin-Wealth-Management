import {
  BATTERIES,
  COLORS,
  INTERIORS,
  MOTORISATIONS,
  PACK_OPTIONS,
  TRIMS,
  VEHICLE_MODELS,
  WHEELS,
} from "../catalog/data";
import { getTariffByVersion, PricingBreakdown } from "../pricing/tariffs";
import { ConfigSelectionInput } from "./rules";

export interface ResolutionAction {
  label: string;
  patch: Partial<ConfigSelectionInput>;
}

export interface CompatibilityIssue {
  ruleCode: string;
  severity: "conflict" | "included";
  title: string;
  explanation: string;
  resolutionActions: ResolutionAction[];
}

export interface ConfigurationValidationResult {
  valid: boolean;
  issues: CompatibilityIssue[];
  selection: ConfigSelectionInput;
  resolvedLabels: {
    modelName: string;
    modelYear: number;
    motorisationName: string;
    batteryName: string;
    trimName: string;
    colorName: string;
    colorHex: string;
    wheelName: string;
    interiorName: string;
    optionNames: string[];
    includedEquipment: string[];
  };
  pricing: PricingBreakdown;
}

export function getDefaultSelectionForModel(
  modelSlug: ConfigSelectionInput["modelSlug"]
): ConfigSelectionInput {
  const moto = MOTORISATIONS.find((m) => m.modelSlug === modelSlug)!;
  const trim = TRIMS.find((t) => t.modelSlug === modelSlug)!;
  const color = COLORS.find((c) => c.modelSlug === modelSlug)!;
  const wheel = WHEELS.find((w) => w.modelSlug === modelSlug)!;
  const interior = INTERIORS.find((i) => i.modelSlug === modelSlug)!;

  return {
    modelSlug,
    motorisationId: moto.id,
    trimId: trim.id,
    colorId: color.id,
    wheelId: wheel.id,
    interiorId: interior.id,
    optionIds: [],
    applyDemoDiscount: false,
  };
}

export function validateAndPriceConfiguration(
  input: ConfigSelectionInput
): ConfigurationValidationResult {
  const model = VEHICLE_MODELS.find((m) => m.slug === input.modelSlug);
  if (!model) {
    throw new Error("Modèle introuvable.");
  }

  const moto = MOTORISATIONS.find(
    (m) => m.id === input.motorisationId && m.modelSlug === input.modelSlug
  );
  const trim = TRIMS.find(
    (t) => t.id === input.trimId && t.modelSlug === input.modelSlug
  );
  const color = COLORS.find(
    (c) => c.id === input.colorId && c.modelSlug === input.modelSlug
  );
  const wheel = WHEELS.find(
    (w) => w.id === input.wheelId && w.modelSlug === input.modelSlug
  );
  const interior = INTERIORS.find(
    (i) => i.id === input.interiorId && i.modelSlug === input.modelSlug
  );

  if (!moto || !trim || !color || !wheel || !interior) {
    throw new Error(
      "Sélection incohérente : un ou plusieurs éléments n'appartiennent pas au modèle sélectionné."
    );
  }

  const battery = BATTERIES.find((b) => b.id === moto.batteryId)!;
  const uniqueOptionIds = Array.from(new Set(input.optionIds));
  const selectedOptions = uniqueOptionIds
    .map((id) =>
      PACK_OPTIONS.find((p) => p.id === id && p.modelSlug === input.modelSlug)
    )
    .filter((p): p is NonNullable<typeof p> => Boolean(p));

  const issues: CompatibilityIssue[] = [];

  // Règles Renault 5
  if (input.modelSlug === "renault-5-e-tech") {
    if (
      uniqueOptionIds.includes("opt-r5-harman") &&
      trim.id === "trim-r5-evolution"
    ) {
      issues.push({
        ruleCode: "R5_HARMAN_NEEDS_TECHNO",
        severity: "conflict",
        title: "Système Audio Harman Kardon incompatible avec Evolution",
        explanation:
          "Le système audio Harman Kardon 9 HP nécessite la double dalle OpenR Link présente à partir de la finition Techno (+ 2 000 €). Aucun choix n'a été modifié automatiquement.",
        resolutionActions: [
          {
            label: "Passer à la finition Techno",
            patch: { trimId: "trim-r5-techno" },
          },
          {
            label: "Retirer l'option Harman Kardon",
            patch: {
              optionIds: uniqueOptionIds.filter((id) => id !== "opt-r5-harman"),
            },
          },
        ],
      });
    }

    if (
      wheel.id === "wheel-r5-18-chrono" &&
      moto.id !== "moto-r5-150"
    ) {
      issues.push({
        ruleCode: "R5_CHRONO_WHEELS_NEEDS_150",
        severity: "conflict",
        title: "Jantes 18\" Chrono incompatibles avec 120 ch",
        explanation:
          "Les jantes alliage 18\" Chrono exigent la motorisation E-Tech 150 ch (Batterie Comfort 52 kWh).",
        resolutionActions: [
          {
            label: "Passer à E-Tech 150 ch",
            patch: { motorisationId: "moto-r5-150" },
          },
          {
            label: "Revenir aux jantes 18\" Disco",
            patch: { wheelId: "wheel-r5-18-disco" },
          },
        ],
      });
    }

    if (
      uniqueOptionIds.includes("opt-r5-winter") &&
      uniqueOptionIds.includes("opt-r5-alpine-aero")
    ) {
      issues.push({
        ruleCode: "R5_WINTER_VS_AERO",
        severity: "conflict",
        title: "Pack Hiver Confort et Kit Aéro Sport exclusifs",
        explanation:
          "Ces deux packs partagent le même faisceau bouclier avant et ne peuvent être commandés simultanément.",
        resolutionActions: [
          {
            label: "Conserver uniquement Pack Hiver",
            patch: {
              optionIds: uniqueOptionIds.filter(
                (id) => id !== "opt-r5-alpine-aero"
              ),
            },
          },
          {
            label: "Conserver uniquement Kit Aéro Sport",
            patch: {
              optionIds: uniqueOptionIds.filter((id) => id !== "opt-r5-winter"),
            },
          },
        ],
      });
    }

    if (
      interior.id === "int-r5-jaune-denim" &&
      trim.id === "trim-r5-evolution"
    ) {
      issues.push({
        ruleCode: "R5_DENIM_NEEDS_TECHNO",
        severity: "conflict",
        title: "Sellerie Denim incompatible avec Evolution",
        explanation:
          "La sellerie Denim & Surpiqûres Jaunes est disponible uniquement à partir de la finition Techno.",
        resolutionActions: [
          {
            label: "Passer à la finition Techno",
            patch: { trimId: "trim-r5-techno" },
          },
          {
            label: "Choisir Sellerie Textile Gris Chiné",
            patch: { interiorId: "int-r5-gris-tissu" },
          },
        ],
      });
    }
  }

  // Règles Scénic
  if (input.modelSlug === "scenic-e-tech") {
    if (
      uniqueOptionIds.includes("opt-scenic-solarbay") &&
      trim.id === "trim-scenic-evolution"
    ) {
      issues.push({
        ruleCode: "SCENIC_SOLARBAY_NEEDS_TECHNO",
        severity: "conflict",
        title: "Toit Solarbay incompatible avec Evolution",
        explanation:
          "Le toit panoramique opacifiant Solarbay nécessite la finition Techno ou Iconic.",
        resolutionActions: [
          {
            label: "Passer à la finition Techno",
            patch: { trimId: "trim-scenic-techno" },
          },
          {
            label: "Retirer l'option Solarbay",
            patch: {
              optionIds: uniqueOptionIds.filter(
                (id) => id !== "opt-scenic-solarbay"
              ),
            },
          },
        ],
      });
    }

    if (
      wheel.id === "wheel-scenic-20-oracle" &&
      moto.id !== "moto-scenic-220"
    ) {
      issues.push({
        ruleCode: "SCENIC_20_WHEELS_NEEDS_220",
        severity: "conflict",
        title: "Jantes 20\" Oracle incompatibles avec 170 ch",
        explanation:
          "Les jantes 20\" Oracle sont homologuées exclusivement avec la motorisation Grande Autonomie 220 ch.",
        resolutionActions: [
          {
            label: "Passer à E-Tech 220 ch",
            patch: { motorisationId: "moto-scenic-220" },
          },
          {
            label: "Choisir Jantes 19\" Streamline",
            patch: { wheelId: "wheel-scenic-19-stream" },
          },
        ],
      });
    }
  }

  // Règles Rafale
  if (input.modelSlug === "rafale-e-tech") {
    if (
      uniqueOptionIds.includes("opt-rafale-4control") &&
      trim.id === "trim-rafale-atelier"
    ) {
      issues.push({
        ruleCode: "RAFALE_4CONTROL_INCLUDED_ATELIER",
        severity: "included",
        title: "4Control Avancé déjà inclus de série sur Atelier Alpine",
        explanation:
          "Cet équipement fait partie de la dotation de série de la finition Atelier Alpine. Son montant n'est pas facturé en double.",
        resolutionActions: [
          {
            label: "Retirer le doublon d'option",
            patch: {
              optionIds: uniqueOptionIds.filter(
                (id) => id !== "opt-rafale-4control"
              ),
            },
          },
        ],
      });
    }

    if (
      wheel.id === "wheel-rafale-21-chicane" &&
      moto.id !== "moto-rafale-300-4x4"
    ) {
      issues.push({
        ruleCode: "RAFALE_21_CHICANE_NEEDS_300",
        severity: "conflict",
        title: "Jantes 21\" Chicane incompatibles avec Full Hybrid 200 ch",
        explanation:
          "Les jantes forgées 21\" Chicane sont réservées à la motorisation E-Tech 4x4 300 ch.",
        resolutionActions: [
          {
            label: "Passer à 4x4 300 ch",
            patch: { motorisationId: "moto-rafale-300-4x4" },
          },
          {
            label: "Revenir aux jantes 20\" Castellet",
            patch: { wheelId: "wheel-rafale-20-castellet" },
          },
        ],
      });
    }
  }

  const hasBlockingConflict = issues.some((i) => i.severity === "conflict");

  // Calcul strict en centimes entiers
  const tariff = getTariffByVersion(input.tariffVersion);
  const optionsTotalCents = selectedOptions.reduce((sum, opt) => {
    // Éviter toute double facturation si déjà inclus de série sur Atelier Alpine
    if (
      opt.id === "opt-rafale-4control" &&
      trim.id === "trim-rafale-atelier"
    ) {
      return sum;
    }
    return sum + opt.priceDeltaCents;
  }, 0);

  const vehicleConfiguredSubtotalCents =
    model.basePriceCents +
    moto.priceDeltaCents +
    trim.priceDeltaCents +
    color.priceDeltaCents +
    wheel.priceDeltaCents +
    interior.priceDeltaCents +
    optionsTotalCents;

  const discountDemoCents = input.applyDemoDiscount
    ? Math.max(tariff.discountDemoCents, 100000) // Remise commerciale démo 1 000 € si activée explicitement
    : tariff.discountDemoCents;

  const totalAfterDiscountCents = Math.max(
    0,
    vehicleConfiguredSubtotalCents - discountDemoCents
  );

  // TVA 20 % incluse dans le tarif véhicule TTC France (arithmétique entière)
  const vatIncludedCents = Math.round((totalAfterDiscountCents * 20) / 120);

  const totalKnownCents =
    totalAfterDiscountCents +
    tariff.mandatoryAdminFeeCents +
    tariff.deliveryFeeCents;

  const pricing: PricingBreakdown = {
    tariffVersion: tariff.version,
    tariffEffectiveDate: tariff.effectiveDate,
    market: tariff.market,
    baseVehicleCents: model.basePriceCents,
    motorisationDeltaCents: moto.priceDeltaCents,
    trimDeltaCents: trim.priceDeltaCents,
    colorDeltaCents: color.priceDeltaCents,
    wheelDeltaCents: wheel.priceDeltaCents,
    interiorDeltaCents: interior.priceDeltaCents,
    optionsTotalCents,
    vehicleConfiguredSubtotalCents,
    mandatoryFeesCents: tariff.mandatoryAdminFeeCents,
    deliveryFeeCents: tariff.deliveryFeeCents,
    vatIncludedCents,
    discountDemoCents,
    publicAidCents: 0,
    publicAidNotice:
      "Aucune aide publique (bonus écologique / prime) appliquée : éligibilité fiscale non vérifiée à ce stade.",
    totalKnownCents,
    legalDisclaimer:
      "Tarif estimatif de démonstration (hors immatriculation régionale définitive). Ne constitue pas une offre ferme du concessionnaire.",
  };

  return {
    valid: !hasBlockingConflict,
    issues,
    selection: {
      ...input,
      optionIds: uniqueOptionIds,
      tariffVersion: tariff.version,
    },
    resolvedLabels: {
      modelName: model.name,
      modelYear: model.modelYear,
      motorisationName: moto.name,
      batteryName: battery.name,
      trimName: trim.name,
      colorName: color.name,
      colorHex: color.hex,
      wheelName: wheel.name,
      interiorName: interior.name,
      optionNames: selectedOptions.map((o) => o.name),
      includedEquipment: trim.includedEquipment,
    },
    pricing,
  };
}
