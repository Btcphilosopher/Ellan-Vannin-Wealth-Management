import { z } from "zod";

export const ConfigSelectionSchema = z.object({
  modelSlug: z.enum(["renault-5-e-tech", "scenic-e-tech", "rafale-e-tech"]),
  motorisationId: z.string().min(1).max(64),
  trimId: z.string().min(1).max(64),
  colorId: z.string().min(1).max(64),
  wheelId: z.string().min(1).max(64),
  interiorId: z.string().min(1).max(64),
  optionIds: z.array(z.string().min(1).max(64)).max(20),
  tariffVersion: z.string().min(1).max(48).optional(),
  applyDemoDiscount: z.boolean().optional(),
});

export type ConfigSelectionInput = z.infer<typeof ConfigSelectionSchema>;

export interface ConfigRuleDefinition {
  code: string;
  modelSlug: "renault-5-e-tech" | "scenic-e-tech" | "rafale-e-tech";
  title: string;
  description: string;
  type: "dependency" | "exclusivity" | "included";
}

export const CONFIGURATOR_RULES: ConfigRuleDefinition[] = [
  {
    code: "R5_HARMAN_NEEDS_TECHNO",
    modelSlug: "renault-5-e-tech",
    title: "Audio Harman Kardon requiert Techno ou Iconic Cinq",
    description:
      "Le système audio Harman Kardon 9 HP nécessite l'architecture multimédia OpenR Link présente à partir de la finition Techno.",
    type: "dependency",
  },
  {
    code: "R5_CHRONO_WHEELS_NEEDS_150",
    modelSlug: "renault-5-e-tech",
    title: "Jantes 18\" Chrono incompatibles avec 120 ch",
    description:
      "Les jantes alliage 18\" Chrono sont homologuées uniquement avec la motorisation E-Tech 150 ch (Batterie 52 kWh).",
    type: "dependency",
  },
  {
    code: "R5_WINTER_VS_AERO",
    modelSlug: "renault-5-e-tech",
    title: "Exclusivité Pack Hiver / Kit Aéro Sport",
    description:
      "Le Pack Hiver Confort et le Kit Aéro Sport sont mutuellement exclusifs pour des raisons d'intégration thermique et aérodynamique.",
    type: "exclusivity",
  },
  {
    code: "R5_DENIM_NEEDS_TECHNO",
    modelSlug: "renault-5-e-tech",
    title: "Sellerie Denim & Surpiqûres Jaunes réservée dès Techno",
    description:
      "La sellerie Denim & Surpiqûres Jaunes n'est pas proposée sur la finition d'accès Evolution.",
    type: "dependency",
  },
  {
    code: "SCENIC_SOLARBAY_NEEDS_TECHNO",
    modelSlug: "scenic-e-tech",
    title: "Toit Solarbay incompatible avec finition Evolution",
    description:
      "Le toit panoramique opacifiant Solarbay requiert la finition Techno ou Iconic.",
    type: "dependency",
  },
  {
    code: "SCENIC_20_WHEELS_NEEDS_220",
    modelSlug: "scenic-e-tech",
    title: "Jantes 20\" Oracle réservées à Grande Autonomie 220 ch",
    description:
      "Les jantes 20\" Oracle requièrent la motorisation Grande Autonomie 220 ch (87 kWh).",
    type: "dependency",
  },
  {
    code: "RAFALE_4CONTROL_INCLUDED_ATELIER",
    modelSlug: "rafale-e-tech",
    title: "4Control avancé déjà inclus sur Atelier Alpine",
    description:
      "Le châssis à 4 roues directrices 4Control avancé est inclus de série sur Atelier Alpine (aucun supplément facturé).",
    type: "included",
  },
  {
    code: "RAFALE_21_CHICANE_NEEDS_300",
    modelSlug: "rafale-e-tech",
    title: "Jantes forgées 21\" Chicane réservées au 4x4 300 ch",
    description:
      "Les jantes forgées 21\" Chicane nécessitent la motorisation E-Tech 4x4 Hybride Rechargeable 300 ch.",
    type: "dependency",
  },
];
