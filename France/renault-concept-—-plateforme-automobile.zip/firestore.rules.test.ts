/**
 * Test runner spec verifying the "Dirty Dozen" security invariants against
 * @firebase/rules-unit-testing (executed against Firebase Emulator when available).
 */
export interface DirtyDozenCase {
  id: string;
  collection: string;
  operation: 'create' | 'update' | 'get' | 'list' | 'delete';
  expected: 'PERMISSION_DENIED';
  rationale: string;
}

export const DIRTY_DOZEN_CASES: DirtyDozenCase[] = [
  {
    id: 'DD-01-id-poisoning',
    collection: 'savedConfigurations',
    operation: 'create',
    expected: 'PERMISSION_DENIED',
    rationale: 'Document ID exceeding 128 chars or containing invalid characters rejected by isValidId().',
  },
  {
    id: 'DD-02-identity-spoofing',
    collection: 'savedConfigurations',
    operation: 'create',
    expected: 'PERMISSION_DENIED',
    rationale: 'ownerUid !== request.auth.uid rejected by isValidSavedConfiguration().',
  },
  {
    id: 'DD-03-shadow-field-role-escalation',
    collection: 'users',
    operation: 'create',
    expected: 'PERMISSION_DENIED',
    rationale: 'Extra keys such as role or isAdmin rejected by keys().hasOnly().',
  },
  {
    id: 'DD-04-unverified-email-admin-spoof',
    collection: 'stockVehicles',
    operation: 'update',
    expected: 'PERMISSION_DENIED',
    rationale: 'Unverified email token claiming admin email rejected by email_verified == true.',
  },
  {
    id: 'DD-05-pii-blanket-list',
    collection: 'testDriveRequests',
    operation: 'list',
    expected: 'PERMISSION_DENIED',
    rationale: 'Listing requests without resource.data.ownerUid == request.auth.uid rejected.',
  },
  {
    id: 'DD-06-timestamp-forgery',
    collection: 'savedConfigurations',
    operation: 'create',
    expected: 'PERMISSION_DENIED',
    rationale: 'Client-supplied timestamp != request.time rejected.',
  },
  {
    id: 'DD-07-terminal-state-shortcut',
    collection: 'testDriveRequests',
    operation: 'update',
    expected: 'PERMISSION_DENIED',
    rationale: 'Non-admin attempting to set status to confirmed rejected.',
  },
  {
    id: 'DD-08-double-booking-slot',
    collection: 'dealerSlots',
    operation: 'update',
    expected: 'PERMISSION_DENIED',
    rationale: 'Updating an already booked slot rejected by existing().status == "available".',
  },
  {
    id: 'DD-09-slot-close-by-client',
    collection: 'dealerSlots',
    operation: 'update',
    expected: 'PERMISSION_DENIED',
    rationale: 'Client attempting to set dealerSlot status to closed rejected.',
  },
  {
    id: 'DD-10-audit-log-tamper',
    collection: 'auditLogs',
    operation: 'delete',
    expected: 'PERMISSION_DENIED',
    rationale: 'Audit logs are strictly append-only (update and delete always denied).',
  },
  {
    id: 'DD-11-oversized-favorites-array',
    collection: 'users',
    operation: 'update',
    expected: 'PERMISSION_DENIED',
    rationale: 'favoriteModelSlugs exceeding 12 entries rejected by size guard.',
  },
  {
    id: 'DD-12-unauthorized-tariff-write',
    collection: 'tariffVersions',
    operation: 'create',
    expected: 'PERMISSION_DENIED',
    rationale: 'Non-admin attempting to publish tariff versions rejected.',
  },
];
