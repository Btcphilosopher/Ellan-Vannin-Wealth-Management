import next from "eslint-config-next";
import firebaseRulesPlugin from "@firebase/eslint-plugin-security-rules";

const config = [
  {
    ignores: ["dist/**/*", ".next/**/*", "node_modules/**/*"],
  },
  ...next,
  firebaseRulesPlugin.configs["flat/recommended"],
];

export default config;
