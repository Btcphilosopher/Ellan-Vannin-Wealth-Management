"""Génère docs/demonstration.md à partir des résultats RÉELS d'une exécution du parcours.

Usage : python scripts/generer_doc_demo.py exemples/resultats_demo.json docs/demonstration.md "<contexte d'exécution>"
"""
import json
import sys


def fmt(v):
    if isinstance(v, float):
        return f"{v:,.3f}".replace(",", " ").rstrip("0").rstrip(".")
    if isinstance(v, (dict, list)):
        return "`" + json.dumps(v, ensure_ascii=False)[:400] + "`"
    return str(v)


def main(src, dst, contexte):
    R = json.load(open(src, encoding="utf-8"))
    out = ["# Démonstration reproductible — résultats d'exécution", "",
           f"Contexte : {contexte}", "",
           "Commande : `cd backend && python -m app.demo.scenario` (ou service `demo` de Docker Compose). "
           "Toutes les étapes passent par l'API HTTP avec les comptes fictifs ; les valeurs ci-dessous sont "
           "celles **produites par l'exécution**, comparées à la « vérité » connue du simulateur.", ""]
    v = R.get("verite_simulateur", {})
    if v:
        out += ["## Vérité du simulateur (anomalies injectées connues)", "", "| Grandeur | Valeur |", "|---|---|"]
        out += [f"| {k} | {fmt(x)} |" for k, x in v.items()]
        out.append("")
    for num, e in R["etapes"].items():
        out += [f"## Étape {int(num)} — {e['titre']}", "", "| Élément | Résultat |", "|---|---|"]
        for k, x in e.items():
            if k == "titre":
                continue
            out.append(f"| {k.replace('_', ' ')} | {fmt(x).replace('|', '/')} |")
        out.append("")
    out += ["## Fichiers produits", "",
            "* `exemples/resultats_demo.json` — résultats complets de l'exécution",
            "* `exemples/rapport_parcours_solaire.json` / `.html` — rapport traçable (manifeste, empreintes "
            "SHA-256 par section, signature HMAC)", ""]
    open(dst, "w", encoding="utf-8").write("\n".join(out))


if __name__ == "__main__":
    main(sys.argv[1], sys.argv[2], sys.argv[3] if len(sys.argv) > 3 else "")
