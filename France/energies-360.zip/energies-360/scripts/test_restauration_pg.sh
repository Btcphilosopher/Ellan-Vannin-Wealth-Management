#!/usr/bin/env bash
# Test de restauration de bout en bout : dump de la source → restauration dans une base cible VIDE →
# comparaison du nombre de lignes et d'une empreinte de contenu, table par table.
# Usage : scripts/test_restauration_pg.sh <url_source> <url_cible_vide>
set -euo pipefail
SRC="${1:?url source}"; CIBLE="${2:?url cible (base vide existante)}"
TMP=$(mktemp -d)
DUMP=$("$(dirname "$0")/sauvegarde_pg.sh" "$SRC" "$TMP" | tail -1)
"$(dirname "$0")/restauration_pg.sh" "$DUMP" "$CIBLE" >/dev/null
empreintes() {
  for t in $(psql "$1" -At -c "SELECT table_name FROM information_schema.tables WHERE table_schema='public' AND table_type='BASE TABLE' AND table_name <> 'spatial_ref_sys' ORDER BY 1"); do
    echo "$t:$(psql "$1" -At -c "SELECT count(*) || ':' || md5(coalesce(string_agg(x::text, '|' ORDER BY x::text), '')) FROM \"$t\" x")"
  done
}
A=$(empreintes "$SRC"); B=$(empreintes "$CIBLE")
if [ "$A" = "$B" ]; then
  echo "RESTAURATION VÉRIFIÉE : $(echo "$A" | wc -l) tables identiques (comptage + empreinte MD5 du contenu)"
else
  echo "ÉCART DE RESTAURATION"; diff <(echo "$A") <(echo "$B"); exit 1
fi
