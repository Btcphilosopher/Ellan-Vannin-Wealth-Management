#!/usr/bin/env bash
# Génère les secrets locaux (jamais versionnés). Idempotent : ne remplace pas un secret existant.
set -euo pipefail
cd "$(dirname "$0")/../secrets"
umask 077
gen() { [ -s "$1" ] || head -c 48 /dev/urandom | base64 | tr -d '/+=\n' | head -c "${2:-48}" > "$1"; }
gen jwt_secret.txt 64
gen cle_chiffrement.txt 64
gen db_password.txt 32
gen s3_access_key.txt 20
gen s3_secret_key.txt 40
chmod 600 ./*.txt 2>/dev/null || true
# Les conteneurs s'exécutent avec l'UID 10001 : rendre lisibles les fichiers montés en secrets
chmod 644 jwt_secret.txt cle_chiffrement.txt db_password.txt
echo "Secrets générés dans $(pwd)"
