#!/usr/bin/env bash
# Sauvegarde PostgreSQL native (pg_dump format custom) + sauvegarde logique applicative.
# Usage : scripts/sauvegarde_pg.sh <url_postgres> <repertoire_sortie>
set -euo pipefail
URL="${1:?url postgresql://...}"; OUT="${2:?répertoire}"
mkdir -p "$OUT"; H=$(date -u +%Y%m%dT%H%M%SZ)
pg_dump --format=custom --no-owner --file "$OUT/e360_$H.dump" "$URL"
sha256sum "$OUT/e360_$H.dump" > "$OUT/e360_$H.dump.sha256"
echo "$OUT/e360_$H.dump"
