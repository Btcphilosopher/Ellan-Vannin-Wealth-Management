#!/usr/bin/env bash
# Restauration dans une base VIDE + vérification d'empreinte. Usage : restauration_pg.sh <dump> <url_cible>
set -euo pipefail
DUMP="${1:?fichier .dump}"; URL="${2:?url cible}"
sha256sum -c "$DUMP.sha256"
pg_restore --no-owner --exit-on-error --dbname "$URL" "$DUMP"
echo "Restauration terminée"
