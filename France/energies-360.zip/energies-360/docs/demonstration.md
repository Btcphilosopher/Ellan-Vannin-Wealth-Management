# Démonstration reproductible — résultats d'exécution

Contexte : exécution du 28/11/2026 sur PostgreSQL 16.15 + PostGIS 3.4, Python 3.13.18, horloge figée au 22/06/2026 00:05 UTC, base vide migrée par Alembic

Commande : `cd backend && python -m app.demo.scenario` (ou service `demo` de Docker Compose). Toutes les étapes passent par l'API HTTP avec les comptes fictifs ; les valeurs ci-dessous sont celles **produites par l'exécution**, comparées à la « vérité » connue du simulateur.

## Notes de lecture

* **Écart de bilan 10 710,3 kWh vs vérité 10 714,5 kWh** : différence de 4,2 kWh = consommation
  auxiliaire du premier pas de 10 min (25 kW × 1/6 h), due à la convention d'index (l'index lu à
  `t` inclut le pas qui se termine à `t`) ; l'écart n'est ni masqué ni ajusté.
* **Somme naïve 1 739 933 kWh** : addition indistincte de tous les compteurs d'énergie du site
  (production, onduleurs, batterie, poste) — affichée uniquement pour montrer le double comptage
  évité ; la plateforme publie 547 122 kWh (compteur principal).
* **Compteur réinitialisé** (onduleur 3, 17/06 13:20 UTC) : détecté ; 92,7 kWh non mesurés par ce
  compteur de contrôle (vérité du simulateur), sans effet sur le compteur principal.
* **Tentatives non autorisées** : lecture finance et modification d'actif par `m.fontaine`, OT
  hors périmètre par `l.martin`, retour en disponibilité par un technicien, autorisation
  opérationnelle par le compte IA, connexion MFA invalide — toutes refusées et journalisées.

## Vérité du simulateur (anomalies injectées connues)

| Grandeur | Valeur |
|---|---|
| production_pv_kwh | 547 122.393 |
| injection_kwh | 536 359.836 |
| soutirage_kwh | 1 488.777 |
| charge_kwh | 54 736.842 |
| decharge_kwh | 53 200 |
| auxiliaires_kwh | 4 200 |
| pertes_transfo_kwh | 6 514.492 |
| energie_ond3_avant_reset_non_comptee_kwh | 92.718 |
| soc_final_pct | 10 |
| doublons_exacts | 25 |
| doublons_conflictuels | 2 |

## Étape 1 — Enregistrement des actifs

| Élément | Résultat |
|---|---|
| actif cree | PV-GAR-METEO2 |
| second compteur principal refuse | Un compteur principal existe déjà pour le périmètre « injection_reseau » sur ce site (GAR-PDL-EI) : un second compteur p |
| etude figee | `{"instantane_integre": true, "ecarts_detectes": 1}` |
| requete spatiale | `{"methode": "PostGIS ST_DWithin / ST_Distance (géographie WGS 84)", "sites": ["SITE-IND-LYM", "SITE-DEP-SAU", "SITE-STA-TIL"]}` |

## Étape 2 — Ingestion de mesures simulées

| Élément | Résultat |
|---|---|
| lots | 1010 |
| recus | 25113 |
| inseres | 25088 |
| doublons exacts | 25 |
| doublons conflictuels | 2 |
| retards | 152 |
| hors bornes | 1 |
| rejets | 0 |

## Étape 3 — Calcul d'énergie sans double comptage

| Élément | Résultat |
|---|---|
| production pv kwh | 547 122.393 |
| verite simulateur kwh | 547 122.393 |
| injection reseau kwh | 536 359.836 |
| verite injection kwh | 536 359.836 |
| ecart bilan kwh | 10 710.325 |
| verite aux plus pertes kwh | 10 714.5 |
| interpretation | Écart compatible avec pertes de transformation et auxiliaires (non mesurés, non ajustés). |
| controle onduleurs kwh | 547 029.676 |
| remise a zero detectee | `["PV-GAR-OND3-E"]` |
| somme naive incorrecte kwh | 1 739 933.4 |
| portefeuille injection kwh | 536 359.836 |
| portefeuille production pv kwh | 547 122.393 |
| compteurs exclus du portefeuille | `["PV-GAR-OND1-E", "PV-GAR-OND2-E", "PV-GAR-OND3-E", "PV-GAR-OND4-E"]` |

## Étape 4 — Détection d'un capteur périmé

| Élément | Résultat |
|---|---|
| alerte | Capteur périmé — PV-GAR-METEO-GPOA |
| message | Aucune observation valide depuis 21/06/2026 10:50 UTC (seuil 30 min). Les indicateurs dépendants sont marqués « indéterminés ». |
| regle | Dernière observation plus ancienne que le seuil de péremption du point à l'instant de référence. |
| alertes par type | `{"capteur_perime": 1, "valeur_figee": 1, "donnees_manquantes": 3, "hors_bornes": 1, "panne_equipement": 1, "compteur_reinitialise": 1, "retard": 1, "doublon_conflictuel": 2}` |
| investigation proposee ia | `["Vérifier l'alimentation et la communication du capteur (passerelle, réseau)", "Comparer avec un capteur redondant ou une source satellite simulée", "Ne pas substituer de valeur sans estimation tracée et validée"]` |
| garde fous | Suggestion générée par règles / modèle simple, à vérifier par une personne compétente. Ne vaut ni autorisation d'intervention, ni commande de procédé, ni engagement de dépense, ni opération de marché. |

## Étape 5 — Création et suivi d'un ordre de maintenance

| Élément | Résultat |
|---|---|
| ordre | OT-2026-00001 |
| etat | cloture |
| parcours | `["signale", "evalue", "planifie", "en_intervention", "controle", "cloture"]` |
| cout total eur | 2 917.5 |
| trois actes | `{"cloture_administrative": true, "retour_disponibilite": true, "autorisation_operationnelle": true}` |
| refus hors perimetre | Permission « maintenance:ecrire » non accordée sur ce périmètre |
| refus sans permis | Référence du permis de travail (procédure externe) requise avant intervention. Énergies 36 |
| technicien ne peut remettre en disponibilite | Permission « maintenance:retour_disponibilite » absente de vos habilitations |
| ia ne peut autoriser | Permission « maintenance:autorisation_operationnelle » absente de vos habilitations |
| resume incident ia | Incident « Arrêt de l'onduleur 2 (défaut F-217) » (gravité majeure) ouvert le 18/06/2026 à 10:00 UTC. Durée constatée : 5.5 h. Alerte liée : Équipement en défaut — PV-GAR-OND2 — État « défaut » déclaré depuis 18/06 10:00 UTC jusqu'à 18/06 15:30 UTC. |

## Étape 6 — Réception et transfert de stock

| Élément | Résultat |
|---|---|
| refus compatibilite | DEP-Z-A n'accepte pas le groupe « gaz_inflammable » (groupes autorisés : lubrifiant, adblue) |
| reception | avec_ecart |
| ecarts | `["Transfert TR-2026-00001 : 118 reçus / 120 expédiés", "Reçu 36 fut pour 40 annoncés au document de transport", "2 fut non conformes (fûts cabossés, joint de bonde douteux) placés en quarantaine sous lot LOT-LUB-26-118-NC"]` |
| transfert | TR-2026-00001 |
| en transit pendant transfert | 120 |
| physique source apres expedition | 480 |
| reservations concurrentes 20 sur 34 | `[201, 409, 409]` |
| journal coherent | True |

## Étape 7 — Rapprochement d'une livraison

| Élément | Résultat |
|---|---|
| quantites L15 | `{"contractuelle": 360000.0, "prevue": 30000.0, "confirmee": 30000.0, "mesuree": 22000.0, "facturee": 22000.0}` |
| montants eur | `{"facture_ttc": 35344.32, "paye": 17672.16}` |
| ecarts | `["Livré 22000 pour 30000 L confirmés (tolérance 3 %)", "Payé 17672.16 pour 35344.32 EUR TTC facturés"]` |
| prix | 1.3388 EUR/L — PRIX INDICATIF — calculé sur indices simulés, non exécutable, ne constitue pas une offre |
| ordre marche reel refuse | Passage d'ordre réel interdit : la plateforme ne transmet aucun ordre de marché |
| cuves | `[{"cuve": "STA-TIL-CUVE-GO", "ecart_l15": -1.1, "interpretation": "Écart dans la tolérance indicative de ±0,5 % des ventes"}, {"cuve": "STA-TIL-CUVE-SP95", "ecart_l15": -1.3, "interpretation": "Écart dans la tolérance indicative de ±0,5 % des ventes"}]` |

## Étape 8 — Suivi d'une session de recharge

| Élément | Résultat |
|---|---|
| session | `{"transaction": 1001, "energie_kwh": 39.6, "montant_ttc": 20.23, "statut": "terminee", "badge": "c28fd47aedc40739", "tarification": {"tarif": "TARIF-STD-2026", "formule": "frais + énergie × prix_kWh + durée × prix_minute", "duree_min": 33.0, "energie_kwh": 39.6, "prix_kwh_ttc": 0.49, "source_energie": "différence d'index meterStop − meterStart (Wh)", "prix_minute_ttc": 0.01, "frais_session_ttc": 0` |
| paiement | capture |
| action non supportee | NotSupported |
| evaluation connecteurs | `[{"connecteur": "CP-PNF-01-C1", "joignable": true, "declare": "Available", "evalue": "disponible"}, {"connecteur": "CP-PNF-01-C2", "joignable": true, "declare": "Faulted", "evalue": "indisponible"}, {"connecteur": "CP-PNF-02-C1", "joignable": false, "declare": null, "evalue": "indeterminee"}, {"connecteur": "CP-PNF-02-C2", "joignable": false, "declare": null, "evalue": "indeterminee"}, {"connecteu` |

## Étape 9 — Simulation de batterie

| Élément | Résultat |
|---|---|
| etat observe soc | `{"valeur": 10.0, "unite": "%", "observe_le": "2026-06-21T23:50:00+00:00", "age_s": 600, "qualite": [], "perime": false}` |
| energie disponible | `{"valeur": 0.0, "methode": "(SoC − SoC_min) × E_nom × η_décharge", "nature": "calculee"}` |
| synthese scenario | `{"energie_chargee_kwh": 47894.7, "energie_dechargee_kwh": 47025.0, "cycles_equivalents": 5.878, "revenu_estime_eur": 2136.28, "nature_revenu": "estimation"}` |
| verifications | `{"soc_dans_bornes": true, "puissances_dans_limites": true, "pas_de_charge_decharge_simultanee": true, "bilan_energie_kwh": {"variation_stock": -4000.0, "eta_c_x_charge_moins_decharge_sur_eta_d": -4000.0}, "pertes_kwh": 4869.737, "bilan_conserve": true}` |
| avertissement | Scénario simulé, isolé des opérations observées. Les revenus affichés sont des estimations fondées sur des prix indicatifs simulés : ils ne constituent ni un résultat commercial ni une garantie. |

## Étape 10 — Calcul environnemental sourcé

| Élément | Résultat |
|---|---|
| totaux tco2e | `{"scope_1": 1.696, "scope_2": 0.077, "scope_3": 47.034}` |
| incertitudes | `{"scope_1": 0.086, "scope_2": 0.008, "scope_3": 2.399}` |
| par nature | `{"calculee": 48.807}` |
| doublon site equipement refuse | Double comptage : donnée #1 au niveau site couvre déjà cette catégorie et cette période ; ne pas cumuler site  |
| doublon scope1 scope3 refuse | Risque de double comptage scope 1 / scope 3 : la donnée #2 (combustion_flotte_propre) porte sur le même site e |
| volume observe vs facteur 15c refuse | Nature incompatible : activité observe, facteur exprimé par L corrige_15c ; une conversion explicite est néces |
| validation | valide_interne |
| mention | Tableau de bord de pilotage interne sur données synthétiques et facteurs fictifs. Ce n'est ni une déclaration réglementaire, ni un bilan vérifié, ni un audit environnemental. |

## Étape 11 — Analyse économique

| Élément | Résultat |
|---|---|
| cout maintenance eur par mwh | 5.332 |
| numerateur | 2 917.5 |
| denominateur mwh | 547.122 |
| revenus separes | `{"devise": "EUR", "revenu_estime": {"valeur": 39953.44, "methode": "énergie injectée (compteur principal) × IDX_ELEC_SPOT_SIM (indicatif simulé)", "nature": "estimation"}, "facture": {"valeur": 0, "nature": "factures émises HT"}, "encaisse": {"valeur": 0, "nature": "paiements reçus"}, "resultat": {"valeur": null, "nature": "hors périmètre", "message": "Le résultat comptable relève de la comptabili` |
| marge carburant | `[{"produit_id": 5, "volume_vendu_l_observe": 18411.6, "chiffre_affaires_ht": 26475.77, "cout_achat_eur_par_l": 1.3388, "marge_brute_ht": 1826.32, "source_cout": "coût moyen pondéré des factures fournisseur du contrat CTR-GO-TIL-2026 (L)"}, {"produit_id": 6, "volume_vendu_l_observe": 10208.6, "chiffre_affaires_ht": 15692.67, "cout_achat_eur_par_l": null, "marge_brute_ht": null, "source_cout": "aucu` |
| explication ecart prevision | `{"prevu_p50_kwh": 560128.2, "realise_kwh": 547122.4, "contributions": {"indisponibilite_estimee_kwh": 12183.3, "limitation_reseau_estimee_kwh": 6191.3, "ecretement_onduleur_estime_kwh": 1381.3}, "residu_non_explique_kwh": -6750.1}` |
| evaluation modeles prevision test disjoint | `{"persistance_j_1": 636.6, "climatologie_horaire": 462.2, "physique_prevision_meteo": 428.2}` |
| van tri | `{"van": -19375.01, "tri_pct": 5.962, "note_tri": "racine unique"}` |
| tentatives non autorisees | `{"finance": "Permission « finance:lire » absente de vos habilitations", "modification_actif": "Permission « patrimoine:ecrire » absente de vos habilitations", "refus_journalises": 5, "chaine_audit": {"integre": true, "entrees_verifiees": 34, "derniere_empreinte": "5a2923e5982b697b2fafe8ccc549c19225a0c30d931b902a5ca85fb6d08913b3"}}` |

## Étape 12 — Export d'un rapport traçable

| Élément | Résultat |
|---|---|
| rapport | Rapport parcours solaire — Parc solaire et stockage des Garrigues (fictif) — 15/06/2026 au 22/06/2026 |
| sha256 json | 210318516477aea98f186366cf55f1783a5e5bba869b51ac8ca2e5bf528d5afb |
| verification | `{"rapport_id": 1, "empreinte_fichier_ok": true, "empreinte_contenu_ok": true, "signature_ok": true}` |
| manifeste sections | `["bilan_energetique", "economie", "maintenance", "periode", "production", "qualite_donnees", "site", "sources"]` |
| indicateurs vue ensemble | `{"energie_pv_produite": "547.122 MWh", "energie_injectee_portefeuille": "536.36 MWh", "ecart_bilan_pv": "10.71 MWh", "disponibilite_pv": "99.182 %", "alertes_ouvertes": "11 alertes", "ordres_travail_ouverts": "0 OT", "stock_disponible_lubrifiant": "14.0 fût (208 L)", "sessions_recharge": "39.6 kWh", "connecteurs_disponibles": "5 sur 8 connecteurs", "emissions_scopes_1_2": "1.773 tCO2e", "cout_main` |

## Fichiers produits

* `exemples/resultats_demo.json` — résultats complets de l'exécution
* `exemples/rapport_parcours_solaire.json` / `.html` — rapport traçable (manifeste, empreintes SHA-256 par section, signature HMAC)
