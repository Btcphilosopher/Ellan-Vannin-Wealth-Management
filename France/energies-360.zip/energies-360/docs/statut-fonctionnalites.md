# Statut des fonctionnalités

Légende : **Opérationnel** = implémenté, exercé par les tests et/ou la démonstration ·
**Simulé** = fonctionne sur un simulateur ou des données synthétiques à la place d'un système réel ·
**Intégré** = branché sur un composant réel (base, stockage, protocole standard) ·
**Reporté** = conçu ou prévu, non implémenté.

| Domaine | Fonctionnalité | Statut |
|---|---|---|
| Référentiel | groupe → entités → sites → installations → équipements → points de mesure | Opérationnel |
| | capacités datées installée / disponible, provenance, états, dates d'effet | Opérationnel |
| | historique versionné, études approuvées figées (empreinte) | Opérationnel |
| | responsables, contrats de maintenance, documents (stockage objet) | Opérationnel |
| | requêtes spatiales PostGIS (`ST_DWithin`) | Intégré (PostgreSQL) / repli haversine (SQLite) |
| Mesures | ingestion, archive brute, doublons, retards, bornes, rejets | Opérationnel |
| | corrections / estimations séparées | Opérationnel (saisie API ; pas d'estimation automatique) |
| | qualité : manquants, périmé, figé, remise à zéro, conflit, panne | Opérationnel |
| | source SCADA | Simulé |
| Unités | validation dimensionnelle, natures, conversions à hypothèses | Opérationnel |
| | tables normalisées de correction de volume | Reporté |
| Production | énergie, bilan sans double comptage, disponibilité, prévision–réalisation, pertes estimées, réductions, incidents | Opérationnel |
| | météo et prévisions | Simulé |
| Maintenance | inspections, défauts, OT (parcours complet), pièces, prestataires, coûts, contrôles, 3 actes distincts | Opérationnel |
| | interface de saisie des transitions | Partiel (API complète ; UI : création et consultation) |
| Stocks / logistique | commandes, livraisons, réceptions partielles, lots, quarantaine, transferts, expéditions, réservations atomiques, corrections liées, documents de transport, règles validées | Opérationnel |
| Contrats | chaîne contrat → paiement, rapprochement, formules sûres, indices sourcés, prix indicatif | Opérationnel |
| | indices de marché | Simulé |
| | opérations de marché | Simulé (ordre réel refusé) |
| Distribution | prix datés, ventes, jaugeages, livraisons, rapprochement de cuves à 15 °C | Opérationnel (données simulées) |
| Mobilité | bornes, connecteurs, états déclarés vs disponibilité évaluée, sessions, tarifs, paiements | Opérationnel |
| | OCPP 1.6J (sous-ensemble borne → plateforme, HTTP + WebSocket) | Simulé (non certifié) |
| | OCPP 2.0.1, commandes plateforme → borne | Reporté (volontairement absent en V1) |
| Batterie | état observé, énergie disponible, scénarios isolés sous contraintes | Opérationnel |
| Environnement | registre activité / facteurs / calculs, incertitude, natures, anti double comptage, évitées séparées, validation à quatre yeux | Opérationnel (facteurs fictifs) |
| | déclaration réglementaire, vérification tierce | Reporté |
| Finance | budgets, engagements, réalisé, coûts unitaires, marges définies, trésorerie prévisionnelle, VAN/TRI | Opérationnel |
| | ERP / comptabilité générale | Simulé / hors périmètre |
| IA | recherche autorisée, résumé d'incident, anomalies, prévisions évaluées, investigation, explication d'écart | Opérationnel (règles et modèles simples) |
| | modèle génératif | Reporté (désactivé) |
| Sécurité | authentification (annuaire simulé), MFA TOTP, rôles × portées, audit chaîné, expurgation, limites d'import, en-têtes | Opérationnel |
| | OIDC / SAML d'entreprise | Reporté |
| | KMS pour secrets | Reporté |
| | TLS | Intégré (profil Caddy, certificat interne) |
| Résilience | sauvegarde / restauration logique et `pg_dump` testées | Opérationnel |
| Socle | tâches en arrière-plan (worker), WebSocket d'événements, stockage objet local / S3 | Opérationnel / Intégré (S3 : profil MinIO, non testé ici) |
| | partitionnement temporel, agrégats matérialisés | Reporté |
