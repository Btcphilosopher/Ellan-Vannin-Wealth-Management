# Stratégie de stockage des séries temporelles

## Principes

1. **Brut immuable** — la table `observation` conserve chaque valeur telle que reçue (valeur,
   unité reçue, valeur normalisée dans l'unité du point, heure d'observation, heure
   d'ingestion, source, lot, empreinte de valeur, indicateurs de qualité). Sous PostgreSQL, un
   déclencheur interdit la suppression et toute modification autre que les étiquettes de qualité.
2. **Archive du lot** — chaque lot reçu est déposé intégralement (JSON canonique) dans le stockage
   objet ; son empreinte SHA-256 est enregistrée dans `lot_ingestion`. Les doublons exacts ne sont
   donc pas réinsérés en table mais restent prouvables depuis l'archive.
3. **Corrections et estimations séparées** — table `correction` (nature `correction`,
   `estimation` ou `substitution`, méthode, justification, observations sources, statut de
   validation). Aucun agrégat ne mélange silencieusement brut et estimé.
4. **Agrégats calculés à la demande** en V1, avec couverture publiée ; les intervalles sans donnée
   valent `None`, jamais 0.

## Schéma physique (PostgreSQL)

| Élément | Rôle |
|---|---|
| `uq_observation_cle (point, observe_le, source, empreinte_valeur)` | déduplication exacte idempotente |
| `ix_observation_point_temps (point, observe_le)` | lecture d'une série sur une période |
| `ix_observation_observe_le_brin` (BRIN) | balayage temporel peu coûteux (insertion quasi chronologique) |
| `tr_observation_brute` | immutabilité de la valeur brute |

Volume de la démonstration : ~25 000 observations/semaine pour une centrale de 4 onduleurs au pas
de 10 min. Pour un parc réel (milliers de points au pas de 1 à 10 min), la feuille de route est :

* **partitionnement déclaratif mensuel** de `observation` (`PARTITION BY RANGE (observe_le)`),
  détachement/archivage des partitions froides vers le stockage objet (Parquet) ;
* **pré-agrégats** horaires et journaliers matérialisés (table `agregat` avec couverture, méthode,
  version de calcul), recalculés par le worker sur arrivée tardive ;
* évaluation de **TimescaleDB** (hypertables, agrégats continus, compression) — à valider au
  regard de sa licence et de son exploitation ; non requis par le prototype.

## Règles de qualité

| Règle | Condition | Effet |
|---|---|---|
| doublon exact | même point, heure, source, valeur | non réinséré, compté dans le lot |
| doublon conflictuel | même point, heure, source, valeur différente | les deux conservés et étiquetés ; première reçue retenue |
| retard | ingestion − observation > 15 min | étiqueté, alerte regroupée par site |
| hors bornes | hors bornes physiques du référentiel | conservé, exclu des agrégats |
| futur | observation > ingestion + 5 min | rejeté |
| valeur absente | `null` pour un signal numérique | rejeté (« une absence n'est pas un zéro ») |
| données manquantes | ≥ 2 pas attendus sans observation | alerte, intervalle « inconnu » |
| capteur périmé | dernière observation plus ancienne que le seuil du point | alerte critique |
| valeur figée | ≥ 4 valeurs identiques non nulles (éclairement, température) | alerte |
| compteur réinitialisé | index cumulatif décroissant | énergie recomptée depuis 0, alerte |
| panne d'équipement | état « defaut » déclaré | alerte, disponibilité impactée |
