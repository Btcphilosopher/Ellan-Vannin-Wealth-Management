# Sécurité et résilience

> Aucune certification (ISO/IEC 27001, IEC 62443, etc.) ni conformité réglementaire n'est
> revendiquée. Les mesures ci-dessous sont des choix de conception d'un prototype, non évalués
> par un tiers.

## Identité et accès

* **Authentification organisationnelle** via un adaptateur `FournisseurIdentite` : annuaire
  local simulé (comptes fictifs, mots de passe Argon2id) ; un adaptateur OIDC est prévu
  (`FournisseurOIDC`, non intégré).
* **MFA via adaptateur** `AdaptateurMFA` : implémentation TOTP RFC 6238 (vecteur de test RFC
  vérifié). Secrets MFA protégés au repos (dérivation de clé ; KMS prévu). En mode
  démonstration seulement, `GET /api/auth/demo/code-mfa/{id}` remplace l'application
  d'authentification.
* **Jetons** JWT HS256 (durée 120 min), secret lu depuis un fichier monté (`*_FILE`).
* **Permissions par rôle et par portée** (globale, entité ou site), vérifiées à chaque route et
  sur chaque objet (`verifier_portee`) ; les listes sont filtrées par périmètre.

| Rôle | Exemples de permissions |
|---|---|
| `admin_plateforme` | administration, audit, sauvegardes (pas d'actes métiers) |
| `direction`, `auditeur` | lecture de tous les domaines |
| `responsable_site` | référentiel, mesures, production, maintenance, **retour en disponibilité** |
| `technicien_maintenance` | OT, contrôles, documents |
| `exploitant_habilite` | **autorisation opérationnelle** (référence de procédure externe obligatoire) |
| `logisticien` | stocks, approvisionnements, distribution |
| `gestionnaire_contrats` | contrats, ordres de marché **simulés** |
| `analyste_finance` / `analyste_environnement` / `validateur_environnement` | domaines respectifs, séparation saisie / validation |
| `operateur_mobilite` | bornes, sessions |
| `service_ingestion` | écriture de mesures, rejeu simulé |
| `service_ia` | lecture seule (assertion au démarrage : aucune permission d'écriture) |

## Traçabilité

* **Journal d'audit chaîné** (empreinte SHA-256 de l'entrée précédente) : connexions, refus,
  écritures sensibles ; vérification `GET /api/admin/audit/verifier` ; sous PostgreSQL un
  déclencheur interdit `UPDATE`/`DELETE` (testé). Toute tentative non autorisée est journalisée.
* **Journaux expurgés** : filtre `FiltreExpurgation` (jetons, JWT, mots de passe, codes MFA,
  courriels) ; badges de recharge pseudonymisés (empreinte), jamais stockés en clair.

## Protection des flux et des données

* **Limitation des imports** : taille (5 Mo), lignes (50 000), types MIME, lots d'ingestion
  (20 000), débit par compte (fenêtre glissante), taille de requête.
* **En-têtes** : `nosniff`, `X-Frame-Options: DENY`, `no-referrer`, `no-store`, CORS restreint.
* **Connexions chiffrées** : profil `tls` (Caddy, certificat interne) devant l'API et le
  frontend ; base de données sans port publié (réseau interne Docker). En production : TLS de
  bout en bout y compris PostgreSQL (`sslmode=verify-full`).
* **Secrets** : fichiers montés en secrets Docker, générés localement, jamais versionnés.
* **Stockage objet** : intégrité SHA-256 vérifiée à la lecture, accès via l'API uniquement,
  chiffrement côté serveur demandé en S3.

## Sauvegarde et restauration (testées)

* Logique portable (`app/sauvegarde.py`) : archive JSONL + manifeste d'empreintes ; restauration
  dans une base vide, vérification d'empreintes, comparaison table par table.
* Native PostgreSQL : `scripts/sauvegarde_pg.sh`, `scripts/restauration_pg.sh`,
  `scripts/test_restauration_pg.sh` (comptage + empreinte MD5 de contenu par table).
* Les résultats d'exécution sont dans `docs/resultats-tests.md`.

## Limites connues

* Limiteur de débit en mémoire (mono-instance) ; à remplacer par un composant partagé.
* Protection du secret MFA par dérivation simple : prototype ; KMS requis.
* WebSocket OCPP de démonstration sans profil de sécurité OCPP (authentification de borne).
* Pas de tests d'intrusion ni d'analyse statique de sécurité réalisés.
