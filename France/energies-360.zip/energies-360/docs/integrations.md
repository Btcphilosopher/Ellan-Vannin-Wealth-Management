# Adaptateurs et intégrations

Toutes les intégrations passent par un adaptateur déclarant son **mode** (`simulation`,
`integre`, `non_integre`) et ses **capacités / interdits** (`GET /api/admin/adaptateurs`).

| Adaptateur | Mode V1 | Cible future | Interdits |
|---|---|---|---|
| Télémétrie SCADA | simulation (rejeu de lots, anomalies) | OPC UA, Modbus TCP, IEC 61850 en **lecture seule** via passerelle | écriture de consignes, commandes |
| OCPP | simulation, sous-ensemble 1.6J borne → plateforme | OCPP 1.6J / 2.0.1 avec profils de sécurité | RemoteStart/Stop, Reset, ChangeAvailability, UnlockConnector |
| Météo | simulation (observé + prévision bruitée) | fournisseur à sélectionner | — |
| ERP / comptabilité | simulation | API de l'ERP retenu | écriture comptable, paiement |
| Marché | simulation | aucune | tout ordre réel (403) |
| Identités | annuaire local simulé | OIDC / SAML | — |
| MFA | TOTP RFC 6238 (intégré) | fournisseur d'entreprise | — |
| Stockage objet | local (intégré) / S3 MinIO (profil) | stockage d'entreprise | — |
| Modèle génératif (LLM) | non intégré (désactivé) | à évaluer | autoriser, piloter, dépenser, opérer sur un marché |

## Vérification des dépendances et capacités

**Vérifié dans cet environnement (par installation et exécution)** : versions Python épinglées
(`backend/requirements.txt`) installées et suite de tests exécutée ; PostgreSQL 16 + PostGIS 3.4
(fonctions `ST_DWithin`, `ST_Distance`, colonnes générées) ; `pg_dump`/`pg_restore` ; build Next.js
(voir `docs/resultats-tests.md`) ; validation de `docker-compose.yml` par `docker compose config`.

**Non vérifié contre les documentations officielles dans le cadre de ce prototype** — à faire
avant toute intégration réelle :

* OCPP : spécifications Open Charge Alliance (1.6 édition 2, 2.0.1), profils de sécurité,
  programme de certification. Le sous-ensemble implémenté n'est pas certifié.
* OPC UA (OPC Foundation, OPC 10000), Modbus (Modbus Organization), IEC 61850 : profils de
  sécurité, modèles d'information, comportement en lecture seule.
* Fournisseur OIDC retenu : découverte, JWKS, PKCE, durée de vie des jetons.
* API S3 / MinIO : chiffrement côté serveur, politiques de bucket, verrouillage d'objets.
* TimescaleDB (si retenu) : licence et fonctionnalités par édition.
* Tables de correction de volume pétrolier (ISO 91 / API MPMS chapitre 11.1) : non implémentées.
* Bases officielles de facteurs d'émission : les facteurs fournis sont **fictifs**.

## Sous-ensemble OCPP 1.6J implémenté

| Action | Traitement |
|---|---|
| BootNotification | état de communication, firmware ; réponse `Accepted`, intervalle 300 s |
| Heartbeat | dernière communication |
| StatusNotification | état **déclaré** par connecteur (distinct de la disponibilité évaluée) |
| StartTransaction | session, badge pseudonymisé, index de début, tarif daté |
| MeterValues | dernier index, puissance max |
| StopTransaction | index de fin, énergie = différence d'index, tarification, paiement simulé |
| autre | `CALLERROR NotSupported`, message journalisé |

Disponibilité évaluée = joignable (communication < 2 heartbeats) ∧ état déclaré `Available`
récent (< 24 h) ∧ aucun défaut ∧ aucun OT ouvert ; sinon `indisponible`, `occupe`, `a_confirmer`
ou `indeterminee`, avec raisons.
