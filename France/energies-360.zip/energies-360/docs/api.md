# API REST — référence (générée depuis OpenAPI)

Documentation interactive : `http://localhost:8000/docs` (Swagger UI) et `/redoc`. Schéma complet : [openapi.json](openapi.json).

Authentification : `POST /api/auth/connexion` → `Authorization: Bearer <jeton>`. WebSockets : `/ws/evenements` (premier message `{"jeton": "…"}`), `/ws/ocpp/{identifiant}` (sous-protocole `ocpp1.6`, démonstration).

## Authentification

- `POST /api/auth/connexion` — Connexion
- `GET /api/auth/moi` — Moi
- `GET /api/auth/demo/comptes` — Comptes Demo
- `GET /api/auth/demo/code-mfa/{identifiant}` — Code Mfa Demo

## Vue d'ensemble

- `GET /api/indicateurs` — Vue Ensemble
- `GET /api/indicateurs/{code}` — Indicateur
- `GET /api/contexte` — Contexte

## Actifs

- `GET /api/patrimoine/arbre` — Arbre
- `GET /api/patrimoine/sites` — Sites
- `GET /api/patrimoine/carte` — Carte
- `GET /api/patrimoine/sites/proches` — Proches
- `GET /api/patrimoine/sites/{site_id}` — Site Detail
- `POST /api/patrimoine/actifs` — Creer Actif
- `PATCH /api/patrimoine/actifs/{actif_id}` — Modifier Actif
- `GET /api/patrimoine/actifs/{actif_id}/historique` — Historique
- `POST /api/patrimoine/capacites` — Creer Capacite
- `POST /api/patrimoine/points-mesure` — Creer Point
- `GET /api/patrimoine/etudes` — Etudes
- `POST /api/patrimoine/etudes` — Creer Etude
- `POST /api/patrimoine/etudes/{etude_id}/approuver` — Approuver
- `GET /api/patrimoine/etudes/{etude_id}/comparer` — Comparer
- `GET /api/industrie/bilans` — Bilans

## Production

- `POST /api/mesures/ingestion` — Ingerer
- `POST /api/mesures/import-csv` — Import Csv
- `GET /api/mesures/lots` — Lots
- `GET /api/mesures/points/{code}/observations` — Observations
- `GET /api/mesures/points/{code}/serie` — Serie
- `GET /api/mesures/points/{code}/energie` — Energie Pt
- `GET /api/mesures/sites/{site_id}/bilan` — Bilan
- `GET /api/mesures/portefeuille/{perimetre}` — Portefeuille
- `POST /api/mesures/qualite/analyser` — Analyser
- `GET /api/mesures/alertes` — Alertes
- `POST /api/mesures/alertes/{alerte_id}/acquitter` — Acquitter
- `POST /api/mesures/corrections` — Corriger
- `GET /api/production/sites/{site_id}/synthese` — Synthese Production
- `GET /api/production/previsions` — Previsions
- `POST /api/production/reductions` — Reduction
- `GET /api/production/incidents` — Incidents
- `POST /api/production/incidents` — Incident
- `GET /api/batterie/{actif_id}/etat` — Etat Batterie
- `GET /api/batterie/scenarios` — Scenarios
- `POST /api/batterie/scenarios` — Scenario
- `GET /api/batterie/scenarios/{sid}` — Scenario Detail

## Maintenance

- `GET /api/maintenance/ordres` — Ordres
- `POST /api/maintenance/ordres` — Creer Ordre
- `GET /api/maintenance/ordres/{ordre_id}` — Ordre
- `POST /api/maintenance/ordres/{ordre_id}/transition` — Transition
- `POST /api/maintenance/ordres/{ordre_id}/pieces` — Pieces Ot
- `POST /api/maintenance/ordres/{ordre_id}/controle` — Controle
- `POST /api/maintenance/ordres/{ordre_id}/cloture-administrative` — Cloture Adm
- `POST /api/maintenance/ordres/{ordre_id}/retour-disponibilite` — Retour
- `POST /api/maintenance/ordres/{ordre_id}/autorisation-operationnelle` — Autorisation
- `GET /api/maintenance/pieces` — Pieces
- `GET /api/maintenance/prestataires` — Prestataires
- `GET /api/maintenance/inspections` — Inspections

## Approvisionnements

- `GET /api/approvisionnements/commandes` — Commandes
- `POST /api/approvisionnements/receptions` — Reception

## Logistique

- `GET /api/logistique/stocks` — Stocks
- `GET /api/logistique/emplacements` — Emplacements
- `GET /api/logistique/mouvements` — Mouvements
- `GET /api/logistique/coherence` — Coherence
- `GET /api/logistique/transferts` — Transferts
- `POST /api/logistique/transferts` — Transfert
- `POST /api/logistique/transferts/{tid}/reception` — Recevoir Transfert
- `POST /api/logistique/reservations` — Reserver
- `POST /api/logistique/reservations/{rid}/annuler` — Annuler
- `POST /api/logistique/expeditions` — Expedier
- `POST /api/logistique/mouvements/{mid}/corriger` — Corriger
- `POST /api/logistique/lots/{lot_id}/statut` — Statut Lot
- `GET /api/logistique/regles` — Regles
- `GET /api/logistique/ecarts` — Ecarts
- `GET /api/logistique/documents-transport` — Docs Transport

## Contrats

- `GET /api/contrats` — Contrats
- `GET /api/contrats/indices` — Indices
- `GET /api/contrats/{cid}/rapprochement` — Rapprochement
- `GET /api/contrats/{cid}/cotation` — Cotation
- `POST /api/contrats/{cid}/engagements` — Engagement
- `POST /api/contrats/{cid}/livraisons-mesurees` — Livraison Mesuree
- `POST /api/contrats/factures` — Facture
- `POST /api/contrats/paiements` — Paiement
- `POST /api/contrats/ordres-marche` — Ordre Marche
- `GET /api/amont/titres` — Titres

## Distribution

- `GET /api/distribution/stations` — Stations
- `GET /api/distribution/stations/{site_id}/synthese` — Station
- `POST /api/distribution/prix` — Prix

## Mobilité

- `POST /api/mobilite/ocpp/{identifiant}` — Ocpp
- `GET /api/mobilite/bornes` — Bornes
- `GET /api/mobilite/sessions` — Sessions
- `GET /api/mobilite/sessions/{sid}` — Session Detail
- `GET /api/mobilite/tarifs` — Tarifs

## Environnement

- `GET /api/environnement/facteurs` — Facteurs
- `GET /api/environnement/activites` — Activites
- `POST /api/environnement/activites` — Activite
- `POST /api/environnement/calculs` — Calcul
- `POST /api/environnement/activites/{aid}/valider` — Valider
- `GET /api/environnement/inventaire` — Inventaire

## Finance

- `GET /api/finance/synthese` — Synthese
- `GET /api/finance/sites/{site_id}/cout-unitaire` — Cout Unitaire
- `GET /api/finance/sites/{site_id}/revenus` — Revenus
- `GET /api/finance/stations/{site_id}/marge` — Marge
- `GET /api/finance/tresorerie` — Tresorerie
- `GET /api/finance/investissements` — Investissements
- `POST /api/finance/investissements` — Investissement

## IA

- `GET /api/ia/recherche` — Recherche
- `GET /api/ia/incidents/{iid}/resume` — Resume
- `GET /api/ia/alertes/{aid}/investigation` — Investigation
- `GET /api/ia/sites/{site_id}/anomalies` — Anomalies
- `GET /api/ia/sites/{site_id}/evaluation-previsions` — Evaluation
- `GET /api/ia/sites/{site_id}/explication-ecart` — Explication

## Administration

- `POST /api/documents` — Deposer
- `GET /api/documents/{doc_id}/contenu` — Lire Document
- `GET /api/rapports` — Liste Rapports
- `POST /api/rapports` — Creer Rapport
- `GET /api/rapports/{rapport_id}/telecharger` — Telecharger
- `GET /api/rapports/{rapport_id}/verifier` — Verifier Rapport
- `GET /api/admin/utilisateurs` — Utilisateurs
- `GET /api/admin/audit` — Audit
- `GET /api/admin/audit/verifier` — Verifier Audit
- `GET /api/admin/taches` — Taches
- `POST /api/admin/taches/executer` — Executer
- `POST /api/admin/sauvegardes` — Sauvegarde
- `GET /api/admin/adaptateurs` — Adaptateurs
- `GET /api/admin/statut-fonctionnalites` — Statut Fonctionnalites
- `GET /api/sante` — Sante
