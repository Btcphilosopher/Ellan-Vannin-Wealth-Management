# IA et automatisations — gouvernance

Principe : **règles transparentes d'abord**. Les fonctions d'assistance (`/api/ia/*`) sont
exécutées sous un rôle en lecture seule et renvoient des *suggestions* accompagnées de garde-fous.

| Fonction | Méthode | Données |
|---|---|---|
| Recherche documentaire | TF-IDF ; filtrage des documents **avant** classement (périmètre, confidentialité « restreint » exclue) | documents autorisés |
| Résumé d'incident | gabarit extractif (alertes liées, durée, OT) | incident et sources citées |
| Détection d'anomalies | ratio de performance horaire, z-score robuste (médiane/MAD) > 3,5 | production, éclairement |
| Prévision de production | persistance J−1, climatologie horaire, modèle physique + prévision météo simulée | apprentissage 15–18/06, **test disjoint** 19–21/06 |
| Proposition d'investigation | table de règles par type d'alerte | règle déclenchée |
| Explication d'écart | décomposition P50 − réalisé : indisponibilité, limitation, écrêtement, résidu non réparti | estimations du module production |

Les modèles sont comparés à des références simples (persistance, climatologie) sur une période
de test distincte (`GET /api/ia/sites/{id}/evaluation-previsions`).

## Interdits (contrôlés par les permissions)

L'IA **ne peut pas** : autoriser une intervention, retourner un équipement en disponibilité,
piloter un procédé, engager une dépense, créer un OT, exécuter une opération de marché. Le rôle
`service_ia` ne contient aucune permission d'écriture (assertion au chargement + tests). Aucun
modèle génératif n'est activé ; un adaptateur `llm` est déclaré `non_integre`.
