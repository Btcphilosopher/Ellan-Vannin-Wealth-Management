# Résultats réels des tests et vérifications

Exécutions du 28/11/2026 dans l'environnement de développement (Linux, Python 3.13.18,
PostgreSQL 16.15 + PostGIS 3.4, Node.js 22 pour le build local, Docker 29.9 / Compose v5.7).
Journaux bruts : [`docs/journaux/`](journaux/).

## Synthèse

| Vérification | Résultat |
|---|---|
| `pytest` sur SQLite | **57 réussis, 4 ignorés** (tests spécifiques PostgreSQL), 0 échec — 65 s |
| `pytest` sur PostgreSQL + PostGIS (`E360_TESTS_SUR_PG=1`, base migrée par Alembic) | **60 réussis, 1 ignoré** (altération d'audit en SQLite, couverte sous PostgreSQL par le déclencheur), 0 échec — 131 s |
| Migration Alembic `0001` sur base vide PostgreSQL 16 + PostGIS | appliquée (82 tables, colonne géométrique, index GiST et BRIN, déclencheurs d'immutabilité) |
| Parcours de démonstration (12 étapes) sur PostgreSQL | réussi — voir [demonstration.md](demonstration.md) |
| `scripts/test_restauration_pg.sh` (pg_dump → pg_restore → comparaison) | « RESTAURATION VÉRIFIÉE : 82 tables identiques (comptage + empreinte MD5 du contenu) » |
| Sauvegarde / restauration logique (`app/sauvegarde.py`) | identique table par table (SQLite et PostgreSQL), archive corrompue rejetée |
| Frontend : `npm ci`, `tsc --noEmit`, `npm run build` (Next 14.2.35) | 0 erreur TypeScript, build réussi, 16 pages statiques générées |
| Frontend dans le navigateur (Playwright/Chromium) | 12 espaces + connexion affichés, aucune erreur JavaScript ; 403 attendus affichés en clair |
| `docker compose config` | valide (profils `s3`, `tls` compris) |
| Pile Docker Compose (db, init, api, worker, demo, frontend) | images construites, migration + initialisation, démonstration terminée (code 0), API saine, worker actif, événements WebSocket reçus, 12 pages servies sans erreur JS |

Réserves sur l'environnement de vérification :
* les images Docker ont été construites via un proxy réseau propre à l'environnement de test
  (certificat ajouté uniquement dans une copie de vérification du Dockerfile, non livrée) ;
* les images de base ont été obtenues via un miroir à cause d'une limitation de débit du registre ;
* le profil `s3` (MinIO) et le profil `tls` (Caddy) n'ont pas été démarrés ; seule leur
  configuration est validée ;
* aucun test de charge, d'intrusion ni d'accessibilité outillé n'a été réalisé.

## Couverture par thème demandé

| Thème | Tests |
|---|---|
| Unités | `test_unites.py` (13 tests : natures, conversions interdites, hypothèses, PCI/PCS, affines) |
| Agrégations | `test_energie_sans_double_comptage`, `test_compteur_reinitialise`, `test_perte_telemetrie_pas_zero` |
| Doublons | `test_doublons_exacts_et_conflictuels`, parcours (25 exacts, 2 conflictuels) |
| Données manquantes | `test_rejets_valeur_absente_unite_futur`, `test_perte_telemetrie_pas_zero`, `test_qualite_capteur_perime_et_autres` |
| Réservations concurrentes | `test_reservations_concurrentes` (8 fils, SQLite), `test_reservations_concurrentes_pg` (10 fils, PostgreSQL), parcours HTTP (3 requêtes parallèles) |
| Permissions | `test_securite.py` (rôle, portée site/entité, IA lecture seule, MFA, audit, expurgation, limites), `test_maintenance.py` |
| Méthodes de calcul | `test_calculs.py` (VAN/TRI, batterie, formules, émissions, bilan matière, OCPP, rapports, indicateurs) |
| Restauration | `test_sauvegarde.py`, `test_sauvegarde_restauration_pg`, `scripts/test_restauration_pg.sh` |

## Détail (SQLite / PostgreSQL)

| Fichier | Test | SQLite | PostgreSQL |
|---|---|---|---|
| `test_calculs.py` | `test_van_tri_valeurs_connues` | ✅ | ✅ |
| `test_calculs.py` | `test_batterie_contraintes_physiques` | ✅ | ✅ |
| `test_calculs.py` | `test_batterie_pas_d_arbitrage_non_rentable` | ✅ | ✅ |
| `test_calculs.py` | `test_batterie_parametres_invalides` | ✅ | ✅ |
| `test_calculs.py` | `test_formule_prix_sure_et_sans_regard_futur` | ✅ | ✅ |
| `test_calculs.py` | `test_emissions_double_comptage_et_unites` | ✅ | ✅ |
| `test_calculs.py` | `test_bilan_matiere` | ✅ | ✅ |
| `test_calculs.py` | `test_ocpp_joignable_n_est_pas_disponible` | ✅ | ✅ |
| `test_calculs.py` | `test_rapport_tracable_et_falsification` | ✅ | ✅ |
| `test_calculs.py` | `test_indicateurs_exposent_methode_et_sources` | ✅ | ✅ |
| `test_maintenance.py` | `test_parcours_et_actes_distincts` | ✅ | ✅ |
| `test_maintenance.py` | `test_portee_technicien` | ✅ | ✅ |
| `test_mesures.py` | `test_doublons_exacts_et_conflictuels` | ✅ | ✅ |
| `test_mesures.py` | `test_rejets_valeur_absente_unite_futur` | ✅ | ✅ |
| `test_mesures.py` | `test_retard_et_hors_bornes` | ✅ | ✅ |
| `test_mesures.py` | `test_lot_trop_volumineux` | ✅ | ✅ |
| `test_mesures.py` | `test_energie_sans_double_comptage` | ✅ | ✅ |
| `test_mesures.py` | `test_compteur_reinitialise` | ✅ | ✅ |
| `test_mesures.py` | `test_perte_telemetrie_pas_zero` | ✅ | ✅ |
| `test_mesures.py` | `test_qualite_capteur_perime_et_autres` | ✅ | ✅ |
| `test_mesures.py` | `test_second_compteur_principal_refuse` | ✅ | ✅ |
| `test_parcours_demo.py` | `test_parcours_complet` | ✅ | ✅ |
| `test_postgres.py` | `test_postgis_requete_spatiale` | ⏭️ ignoré | ✅ |
| `test_postgres.py` | `test_journaux_immuables_en_base` | ⏭️ ignoré | ✅ |
| `test_postgres.py` | `test_reservations_concurrentes_pg` | ⏭️ ignoré | ✅ |
| `test_postgres.py` | `test_sauvegarde_restauration_pg` | ⏭️ ignoré | ✅ |
| `test_sauvegarde.py` | `test_sauvegarde_restauration_identique` | ✅ | ✅ |
| `test_sauvegarde.py` | `test_archive_corrompue_refusee` | ✅ | ✅ |
| `test_securite.py` | `test_mfa_exige_et_code_invalide` | ✅ | ✅ |
| `test_securite.py` | `test_totp_rfc6238_vecteur` | ✅ | ✅ |
| `test_securite.py` | `test_role_sans_permission` | ✅ | ✅ |
| `test_securite.py` | `test_portee_site_et_entite` | ✅ | ✅ |
| `test_securite.py` | `test_ia_lecture_seule` | ✅ | ✅ |
| `test_securite.py` | `test_refus_audites_et_chaine_integre` | ✅ | ✅ |
| `test_securite.py` | `test_alteration_audit_detectee` | ✅ | ⏭️ ignoré |
| `test_securite.py` | `test_expurgation_des_journaux` | ✅ | ✅ |
| `test_securite.py` | `test_limitation_import` | ✅ | ✅ |
| `test_securite.py` | `test_limitation_debit` | ✅ | ✅ |
| `test_securite.py` | `test_rejeu_reserve_aux_comptes_de_service` | ✅ | ✅ |
| `test_securite.py` | `test_ordre_marche_reel_refuse` | ✅ | ✅ |
| `test_securite.py` | `test_entetes_securite_et_jeton_invalide` | ✅ | ✅ |
| `test_stocks.py` | `test_reception_partielle_et_quarantaine` | ✅ | ✅ |
| `test_stocks.py` | `test_compatibilite_et_regles_validees` | ✅ | ✅ |
| `test_stocks.py` | `test_capacite_et_unites` | ✅ | ✅ |
| `test_stocks.py` | `test_transfert_en_transit_puis_reception_partielle` | ✅ | ✅ |
| `test_stocks.py` | `test_lot_en_quarantaine_non_transferable` | ✅ | ✅ |
| `test_stocks.py` | `test_reservations_concurrentes` | ✅ | ✅ |
| `test_stocks.py` | `test_correction_liee_et_coherence` | ✅ | ✅ |
| `test_unites.py` | `test_conversion_echelle_energie` | ✅ | ✅ |
| `test_unites.py` | `test_puissance_et_energie_distinctes` | ✅ | ✅ |
| `test_unites.py` | `test_energie_sans_nature_refusee` | ✅ | ✅ |
| `test_unites.py` | `test_volume_sans_conditions_refuse` | ✅ | ✅ |
| `test_unites.py` | `test_aucun_coefficient_universel_m3_t_mwh` | ✅ | ✅ |
| `test_unites.py` | `test_natures_electrique_et_combustible_non_additionnables` | ✅ | ✅ |
| `test_unites.py` | `test_volume_observe_et_corrige_non_additionnables` | ✅ | ✅ |
| `test_unites.py` | `test_correction_15c_conserve_hypotheses` | ✅ | ✅ |
| `test_unites.py` | `test_correction_15c_seulement_depuis_observe` | ✅ | ✅ |
| `test_unites.py` | `test_densite_doit_correspondre_aux_conditions` | ✅ | ✅ |
| `test_unites.py` | `test_pci_pcs_explicites` | ✅ | ✅ |
| `test_unites.py` | `test_temperatures_affines` | ✅ | ✅ |
| `test_unites.py` | `test_unites_composees_et_inconnues` | ✅ | ✅ |
