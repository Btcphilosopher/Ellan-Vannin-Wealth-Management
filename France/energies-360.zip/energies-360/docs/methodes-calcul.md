# Unités, bilans physiques et méthodes de calcul

Chaque indicateur de l'application publie sa méthode (`GET /api/indicateurs/{code}`) ; ce document
en donne la référence.

## Validation dimensionnelle (`backend/app/unites/dimensions.py`)

* Une grandeur = valeur + unité + **nature**. Dimensions de base : M, L, T, Θ, N (unités
  dénombrées), une dimension par devise.
* Natures obligatoires : énergie (`electrique`, `combustible_pci`, `combustible_pcs`,
  `thermique`), volume (`observe`, `corrige_15c`, `normal_0c_101325`, `standard_15c_101325`),
  masse (`masse`, `co2e`).
* Conversion automatique **uniquement** entre unités de même dimension et même nature
  (kWh ↔ MWh, L ↔ m³ observés). Toute autre conversion passe par une fonction exigeant une
  `Hypothese` (nom, valeur, unité, source, condition) conservée dans le résultat :

| Fonction | Hypothèse requise | Garde-fou |
|---|---|---|
| `corriger_volume_15c` | coefficient de dilatation (1/K), température | méthode linéaire signalée comme simplifiée (tables ISO 91 / API MPMS 11.1 non implémentées) |
| `volume_vers_masse` | densité **aux mêmes conditions** que le volume | densité 15 °C refusée pour un volume observé |
| `masse_vers_energie` | pouvoir calorifique **PCI ou PCS** explicite | nature de l'énergie résultante = PCI ou PCS |
| `pcs_vers_pci` | ratio PCI/PCS | plage plausible [0,8 ; 1] |
| `combustible_vers_electrique` | rendement sur PCI | résultat de nature électrique, estimation |
| `convertir_devise` | taux daté et sourcé | aucune conversion implicite entre devises |

Il n'existe **aucun coefficient universel** m³ ↔ t ↔ MWh (testé).

## Énergie et bilans

* **Compteur cumulatif** : Σ des différences d'index positives ; sur index décroissant
  (remise à zéro) l'index suivant est compté depuis 0 et l'énergie non mesurée entre le
  dernier index et la remise à zéro est signalée (estimation séparée possible via la puissance).
* **Puissance** : Σ P(t) × pas ; intervalles sans donnée exclus, couverture publiée, statut
  `incomplet` / `indetermine`.
* **Anti double comptage** : un seul compteur principal par (site, périmètre, grandeur), imposé
  au référentiel ; les compteurs `controle` (onduleurs) ne servent qu'au recoupement ; le
  portefeuille somme les seuls compteurs principaux.
* **Bilan électrique du site** :
  `production_pv + décharge − charge − injection + soutirage = pertes et auxiliaires non mesurés`.
  L'écart est publié tel quel, avec interprétation (négatif → incohérence ; > 5 % → à investiguer).

## Production renouvelable

* **Disponibilité technique** = Σ(heures disponibles × kW AC) / Σ(heures à état connu × kW AC) ;
  la part indéterminée (états absents) est publiée à part.
* **Potentiel** = G_POA/1000 × Pdc × PR 0,86 × (1 + γ(Tmod − 25)), γ = −0,0037/K (hypothèses de
  modèle) ; **écrêtement** = potentiel brut au-delà de la puissance AC ; **limitation réseau** =
  potentiel − mesuré pendant les réductions enregistrées ; **indisponibilité** = potentiel pendant
  l'état défaut. Pas de potentiel sans éclairement valide (capteur périmé → non estimé).
* **Prévision–réalisation** : P50 de la prévision la plus récente émise avant l'heure cible ;
  heures sans mesure complète exclues ; MAE, biais, nMAE (% Pac).

## Distribution — rapprochement de cuve

`stock jaugé 15 °C − (stock initial 15 °C + livraisons BL 15 °C − ventes corrigées 15 °C) = écart`,
ventes corrigées avec la température moyenne de jaugeage (hypothèse publiée), tolérance
indicative ±0,5 % des ventes. Volumes observés et corrigés sont publiés séparément.

## Batterie

`E[t+1] = E[t] + η_c·P_c·Δt − P_d·Δt/η_d`, `SoC_min ≤ SoC ≤ SoC_max`, `P ≤ P_max`, pas de charge et
décharge simultanées. Arbitrage heuristique (classement journalier des prix, seuil de
rentabilité prix × η_c × η_d). Vérifications d'invariants retournées avec chaque scénario.
Revenus = estimations sur indice simulé, jamais un résultat commercial.

## Environnement

`émission = (activité − exclusions déclarées) convertie dans l'unité du facteur × facteur × part
consolidée` ; incertitude combinée quadratiquement (facteur ⊕ 1 % mesurée / 5 % estimée).
Contrôles : clé d'origine unique, chevauchement site/équipement, chevauchement de période,
scope 1 / scope 3 cat. 11 sans exclusion, nature de la quantité vs dénominateur du facteur.
Émissions évitées dans un registre séparé, jamais soustraites. Facteurs **fictifs**.

## Finance

* **VAN** = Σ F_i / (1 + r)^((d_i − d_0)/365) (convention « dates réelles ») ou exposant entier
  (« fin de période annuelle ») ; flux actualisés détaillés.
* **TRI** : balayage −99 % … 1000 % puis dichotomie ; racines multiples signalées.
* **Coût unitaire de maintenance** = coûts des OT liés à la période / production mesurée (MWh) ;
  numérateur et dénominateur publiés ; indicateur partiel.
* **Marge brute carburant** = CA HT − CMP facturé × volume vendu (limite de base volumique publiée).
* **Revenus** : estimé (production × indice), facturé, encaissé, résultat (hors périmètre).
