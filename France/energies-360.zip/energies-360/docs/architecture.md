# Architecture — monolithe modulaire

## Vue d'ensemble

```
┌──────────────── Navigateur (Next.js 14 · React 18 · TypeScript) ────────────────┐
│ Vue d'ensemble · Actifs · Production · Maintenance · Approvisionnements ·       │
│ Logistique · Contrats · Distribution · Mobilité · Environnement · Finance · Admin│
└───────────────┬──────────────────────────────────────────┬───────────────────────┘
          HTTPS REST (JWT)                           WebSocket /ws/evenements
┌───────────────▼──────────────────────────────────────────▼───────────────────────┐
│ API FastAPI (processus « api »)                                                  │
│  socle : sécurité · audit · stockage objet · événements · tâches · indicateurs   │
│  modules : patrimoine │ mesures │ production │ maintenance │ stocks │ contrats    │
│            distribution │ mobilité │ batterie │ environnement │ finance │ rapports│
│            ia (lecture seule) │ industrie / amont                                │
│  adaptateurs : télémétrie · OCPP · météo · ERP · marché · identités · MFA · S3   │
└───────┬───────────────────────────────┬───────────────────────────┬──────────────┘
        │ SQLAlchemy 2                  │ fichiers adressés par     │ file de tâches
┌───────▼─────────────┐      ┌──────────▼──────────┐     ┌─────────▼──────────────┐
│ PostgreSQL 16       │      │ Stockage objet      │     │ Worker (processus)      │
│ + PostGIS 3.4       │      │ local (volume) ou   │     │ analyses, rapports,     │
│ Alembic, BRIN,      │      │ S3/MinIO, SHA-256   │     │ sauvegardes, flux simulé│
│ déclencheurs        │      └─────────────────────┘     └────────────────────────┘
└─────────────────────┘
        ▲  frontière contrôlée (lecture seule, futur) : passerelle / DMZ industrielle
        │  aucune écriture vers SCADA, automates, vannes, pompes, bornes
┌───────┴──────────────────────────────────────────────────────────────────────────┐
│ Systèmes industriels et externes — SIMULÉS en V1 (simulateurs Python)            │
└──────────────────────────────────────────────────────────────────────────────────┘
```

Un seul déploiement (monolithe), mais des **modules séparés** : chaque module possède ses
modèles, ses règles et ses routes ; les dépendances vont des modules métiers vers le socle
et vers le référentiel (`patrimoine`), jamais l'inverse. Les échanges inter-modules passent
par des fonctions de service explicites (ex. `finance` lit `maintenance.cout_total`).

| Module | Responsabilité | Unités / contraintes propres |
|---|---|---|
| `patrimoine` | groupe, entités, sites, installations, équipements, points de mesure, capacités datées, responsables, contrats de maintenance, documents, versions, études figées | capacité installée ≠ disponible ; unicité du compteur principal |
| `mesures` | ingestion, observations brutes immuables, corrections séparées, qualité, énergie, bilans | absence ≠ zéro ; doublons ; remises à zéro |
| `production` | prévisions (horizon, modèle, émission, incertitude), réductions, incidents, disponibilité, pertes estimées | estimations séparées des mesures |
| `maintenance` | inspections, défauts, OT, pièces, prestataires, contrôles, 3 actes distincts | ne déclare jamais une installation sûre |
| `stocks` | commandes, livraisons, réceptions, lots, emplacements, transferts, expéditions, réservations, écarts, quarantaine, documents de transport | journal immuable, corrections liées, règles validées |
| `contrats` | tiers, contrats, échéanciers, engagements, livraisons mesurées, factures, paiements, indices, ordres de marché simulés | devise, unité, fuseau, source d'indice ; prix indicatif ≠ offre |
| `distribution` | stations : prix datés, ventes, jaugeages, livraisons, rapprochement de cuves | L observé ≠ L à 15 °C |
| `mobilite` | bornes, connecteurs, états déclarés, communication, sessions, tarifs, paiements | joignable ≠ disponible |
| `batterie` | paramètres datés, état observé, scénarios isolés | SoC, P, rendements, limites |
| `environnement` | activités, facteurs sourcés, calculs, évitées séparées, validation | anti double comptage |
| `finance` | budgets, engagements, réalisé, coûts unitaires, marges définies, trésorerie, VAN/TRI | estimé ≠ facturé ≠ encaissé ≠ résultat |
| `reporting` | indicateurs explorables, rapports traçables | manifeste, empreintes, signature |
| `ia` | recherche documentaire autorisée, résumés, anomalies, prévisions évaluées, explications | lecture seule, suggestions |
| `industrie` | bilans matière (t), titres amont fictifs (suivi administratif) | données disponibles uniquement |

## Choix techniques

* **Python 3.12 / FastAPI 0.115 / SQLAlchemy 2.0 / Alembic 1.14 / psycopg 3** — versions
  exactes épinglées dans `backend/requirements.txt`, installées et testées (voir
  `docs/resultats-tests.md`).
* **PostgreSQL 16 + PostGIS 3.4** : géométrie `geometry(Point, 4326)` générée à partir des
  coordonnées, index GiST, requêtes `ST_DWithin` / `ST_Distance` (géographie). SQLite reste
  utilisable pour les tests et la démonstration autonome (repli haversine signalé).
* **Horodatages** : tous stockés en UTC avec fuseau (type `HorodatageUTC` refusant les dates
  naïves) ; le fuseau du site est conservé au référentiel.
* **Traitements en arrière-plan** : table `tache` + processus `worker`
  (`FOR UPDATE SKIP LOCKED` sous PostgreSQL). Pas de courtier de messages supplémentaire en V1.
* **WebSockets** : `/ws/evenements` diffuse la table `evenement` (alimentée par toutes les
  instances), filtrée par périmètre d'habilitation.
* **Stockage objet protégé** : contenu adressé par empreinte SHA-256, vérifiée à chaque lecture,
  jamais exposé directement (accès uniquement via l'API, contrôle de permission et audit) ;
  adaptateur S3 (MinIO) optionnel.
* **Horloge métier** : `E360_HORLOGE_ORIGINE` fait démarrer l'horloge de démonstration à la fin
  du jeu synthétique (22/06/2026) ; l'audit et les jetons utilisent toujours l'heure réelle.

## Frontière informatique de gestion / systèmes industriels

* V1 : 100 % simulation. Aucun adaptateur ne sait écrire vers un équipement.
* Intégrations futures : **lecture seule**, via une passerelle de réplication placée en zone
  démilitarisée industrielle ; la plateforme ne s'y connecte qu'en sortie de la passerelle.
* Les commandes OCPP plateforme → borne (`RemoteStart`, `Reset`, `ChangeAvailability`…) ne sont
  pas implémentées ; une trame non prise en charge reçoit `CALLERROR NotSupported`.
* Les ordres de marché sont simulés ; un ordre `mode: reel` est refusé (403).
