Ce répertoire reçoit les secrets locaux générés par `scripts/generer_secrets.sh`.
Ne jamais versionner ni partager son contenu. En production : coffre de secrets / KMS.
