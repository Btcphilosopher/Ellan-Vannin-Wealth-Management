"""Environnement Alembic : métadonnées complètes de l'application."""
from alembic import context
from sqlalchemy import engine_from_config, pool

from app import modeles
from app.config import parametres

config = context.config
config.set_main_option("sqlalchemy.url", parametres().url_base.replace("%", "%%"))
cible = modeles.metadata

# Tables et objets gérés par PostGIS (hors périmètre applicatif)
IGNORES = {"spatial_ref_sys", "geometry_columns", "geography_columns"}


def inclure(objet, nom, type_, reflete, compare_a):
    if type_ == "table" and nom in IGNORES:
        return False
    if type_ == "column" and nom == "geom":
        return False
    return True


def hors_ligne():
    context.configure(url=config.get_main_option("sqlalchemy.url"), target_metadata=cible, literal_binds=True,
                      include_object=inclure, render_as_batch=True)
    with context.begin_transaction():
        context.run_migrations()


def en_ligne():
    moteur = engine_from_config(config.get_section(config.config_ini_section, {}), prefix="sqlalchemy.",
                                poolclass=pool.NullPool)
    with moteur.connect() as connexion:
        context.configure(connection=connexion, target_metadata=cible, include_object=inclure,
                          render_as_batch=connexion.dialect.name == "sqlite")
        with context.begin_transaction():
            context.run_migrations()


if context.is_offline_mode():
    hors_ligne()
else:
    en_ligne()
