"""Authentification, MFA, permissions par rôle / entité / site, audit, expurgation, limites."""
import logging

import pytest
from sqlalchemy import select, update

from app.core import securite as sec
from app.core.models import JournalAudit
from app.db import session_scope


def test_mfa_exige_et_code_invalide(client):
    r = client.c.post("/api/auth/connexion", json={"identifiant": "direction", "mot_de_passe": "Demo-E360!"})
    assert r.status_code == 401 and "MFA" in r.json()["detail"]
    r = client.c.post("/api/auth/connexion", json={"identifiant": "direction", "mot_de_passe": "Demo-E360!",
                                                   "code_mfa": "000000"})
    assert r.status_code == 401
    r = client.c.post("/api/auth/connexion", json={"identifiant": "direction", "mot_de_passe": "mauvais"})
    assert r.status_code == 401


def test_totp_rfc6238_vecteur():
    # Vecteur RFC 6238 (SHA-1, secret « 12345678901234567890 », T = 59 s → 94287082, 6 derniers chiffres)
    import base64

    secret = base64.b32encode(b"12345678901234567890").decode()
    assert sec.MFA.code(secret, 59) == "287082"


def test_role_sans_permission(client):
    r = client("m.fontaine", "GET", "/api/finance/synthese")
    assert r.status_code == 403 and "finance:lire" in r.json()["detail"]


def test_portee_site_et_entite(client):
    sites = {s["code"]: s["id"] for s in client("direction", "GET", "/api/patrimoine/sites").json()}
    vus = {s["code"] for s in client("c.durand", "GET", "/api/patrimoine/sites").json()}
    assert vus == {"SITE-PV-GAR"}
    assert client("c.durand", "GET", f"/api/patrimoine/sites/{sites['SITE-STA-TIL']}").status_code == 403
    assert client("n.petit", "GET", f"/api/patrimoine/sites/{sites['SITE-STA-TIL']}").status_code == 200
    assert client("n.petit", "GET", f"/api/patrimoine/sites/{sites['SITE-PV-GAR']}").status_code == 403


def test_ia_lecture_seule(client):
    perms = sec.ROLES["service_ia"]
    assert not any(p.endswith((":ecrire", ":simuler", ":valider", ":autorisation_operationnelle",
                               ":retour_disponibilite")) for p in perms)
    r = client("svc.ia", "POST", "/api/maintenance/ordres", json={"actif_id": 1, "titre": "x", "description": "y"})
    assert r.status_code == 403


def test_refus_audites_et_chaine_integre(client):
    client("m.fontaine", "GET", "/api/finance/synthese")
    with session_scope() as s:
        refus = s.scalars(select(JournalAudit).where(JournalAudit.resultat == "refus")).all()
        assert any(e.acteur == "m.fontaine" for e in refus)
        assert sec.verifier_chaine_audit(s)["integre"]


def test_alteration_audit_detectee(client):
    with session_scope() as s:
        if s.bind.dialect.name == "postgresql":
            pytest.skip("Sous PostgreSQL un déclencheur interdit déjà toute modification (testé ailleurs)")
        e = s.scalar(select(JournalAudit).order_by(JournalAudit.id))
        s.execute(update(JournalAudit).where(JournalAudit.id == e.id).values(acteur="pirate"))
        s.flush()
        res = sec.verifier_chaine_audit(s)
        assert not res["integre"] and res["premiere_rupture"] == e.id
        s.rollback()


def test_expurgation_des_journaux(caplog):
    texte = ('Authorization: Bearer eyJhbGciOi.eyJzdWIiOiIxIn0.abc mot_de_passe="Secret123" '
             "contact camille@exemple.fr code_mfa=123456")
    res = sec.expurger(texte)
    assert "Secret123" not in res and "camille@" not in res and "eyJhbGciOi" not in res and "123456" not in res
    f = sec.FiltreExpurgation()
    rec = logging.LogRecord("t", logging.INFO, "", 0, "jeton=%s", ("abc.def",), None)
    f.filter(rec)
    assert "abc.def" not in rec.getMessage()
    assert sec.expurger_dict({"idTag": "BADGE", "x": {"mot_de_passe": "a"}}) == {"idTag": "[EXPURGÉ]",
                                                                                 "x": {"mot_de_passe": "[EXPURGÉ]"}}


def test_limitation_import(client):
    gros = b"point,observe_le,valeur\n" + b"X,2026-06-15T00:00:00+00:00,1\n" * 200_000
    r = client("svc.ingestion", "POST", "/api/mesures/import-csv", files={"fichier": ("m.csv", gros, "text/csv")})
    assert r.status_code == 413
    r = client("svc.ingestion", "POST", "/api/mesures/import-csv", files={"fichier": ("m.exe", b"MZ", "application/x-msdownload")})
    assert r.status_code == 415


def test_limitation_debit():
    from fastapi import HTTPException

    sec._fenetres.clear()
    for _ in range(5):
        sec.limiter_debit("test-cle", 5)
    with pytest.raises(HTTPException) as e:
        sec.limiter_debit("test-cle", 5)
    assert e.value.status_code == 429


def test_rejeu_reserve_aux_comptes_de_service(client):
    r = client("c.durand", "POST", "/api/mesures/ingestion", json={"source": "x", "mode": "rejeu_simulation",
                                                                    "recu_le": "2026-06-15T00:00:00+00:00", "mesures": []})
    assert r.status_code == 403


def test_ordre_marche_reel_refuse(client):
    r = client("a.moreau", "POST", "/api/contrats/ordres-marche", json={
        "produit": "x", "sens": "achat", "quantite": 1, "unite": "MWh", "prix_limite": 90, "mode": "reel"})
    assert r.status_code == 403
    r = client("a.moreau", "POST", "/api/contrats/ordres-marche", json={
        "produit": "x", "sens": "achat", "quantite": 1, "unite": "MWh", "prix_limite": 90, "mode": "simulation"})
    assert r.status_code == 201 and r.json()["resultat_simulation"]["transmis"] is False


def test_entetes_securite_et_jeton_invalide(client):
    r = client.c.get("/api/sante")
    assert r.headers["X-Frame-Options"] == "DENY" and r.headers["X-Donnees"] == "synthetiques"
    r = client.c.get("/api/auth/moi", headers={"Authorization": "Bearer faux.jeton.x"})
    assert r.status_code == 401
