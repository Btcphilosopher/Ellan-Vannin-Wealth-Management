"""Fixtures : base isolée par module de test (SQLite fichier par défaut,
PostgreSQL + PostGIS si E360_TEST_PG_URL est défini)."""
from __future__ import annotations

import os
import tempfile
import uuid
from pathlib import Path

os.environ.setdefault("E360_HORLOGE_FIGEE", "2026-06-22T00:05:00+00:00")
os.environ.setdefault("E360_MODE_DEMO", "true")
_TMP = Path(tempfile.mkdtemp(prefix="e360_tests_"))
os.environ.setdefault("E360_STOCKAGE_REPERTOIRE", str(_TMP / "objets"))
os.environ.setdefault("E360_DATABASE_URL", f"sqlite:///{_TMP / 'defaut.db'}")

import pytest  # noqa: E402
from fastapi.testclient import TestClient  # noqa: E402
from sqlalchemy import create_engine, text  # noqa: E402
from sqlalchemy.engine import make_url  # noqa: E402

from app import modeles  # noqa: E402
from app.core import securite as sec  # noqa: E402
from app.core.services import reinitialiser_stockage  # noqa: E402
from app.db import configurer, moteur, session_scope  # noqa: E402
from app.demo.seed import initialiser  # noqa: E402

PG = os.environ.get("E360_TEST_PG_URL")


def nouvelle_base(nom: str | None = None, pg: bool = False) -> str:
    if pg and PG:
        base = f"e360_t_{uuid.uuid4().hex[:8]}"
        admin = create_engine(PG, isolation_level="AUTOCOMMIT")
        with admin.connect() as c:
            c.execute(text(f"CREATE DATABASE {base}"))
        admin.dispose()
        url = make_url(PG).set(database=base).render_as_string(hide_password=False)
        from alembic import command
        from alembic.config import Config

        os.environ["E360_DATABASE_URL"] = url
        from app.config import parametres

        parametres.cache_clear()
        cfg = Config(str(Path(__file__).resolve().parents[1] / "alembic.ini"))
        cfg.set_main_option("script_location", str(Path(__file__).resolve().parents[1] / "migrations"))
        command.upgrade(cfg, "head")
        return url
    return f"sqlite:///{_TMP / ((nom or uuid.uuid4().hex) + '.db')}"


def preparer(url: str, seed: bool = True):
    configurer(url)
    reinitialiser_stockage(str(_TMP / "objets"))
    sec.vider_cache_portees()
    sec._fenetres.clear()
    if url.startswith("sqlite"):
        modeles.metadata.create_all(moteur())
    if seed:
        with session_scope() as s:
            initialiser(s)


@pytest.fixture(scope="module")
def base():
    url = nouvelle_base(pg=bool(os.environ.get("E360_TESTS_SUR_PG")))
    preparer(url)
    return url


@pytest.fixture(scope="module")
def client(base):
    from app.main import app

    with TestClient(app) as c:
        yield Api(c)


class Api:
    MDP = "Demo-E360!"

    def __init__(self, c: TestClient):
        self.c = c
        self.jetons: dict[str, str] = {}

    def jeton(self, idt: str) -> str:
        if idt not in self.jetons:
            corps = {"identifiant": idt, "mot_de_passe": self.MDP}
            r = self.c.post("/api/auth/connexion", json=corps)
            if r.status_code == 401:
                code = self.c.get(f"/api/auth/demo/code-mfa/{idt}").json()["code"]
                r = self.c.post("/api/auth/connexion", json=corps | {"code_mfa": code})
            assert r.status_code == 200, r.text
            self.jetons[idt] = r.json()["jeton"]
        return self.jetons[idt]

    def __call__(self, qui: str, methode: str, chemin: str, **kw):
        return self.c.request(methode, chemin, headers={"Authorization": f"Bearer {self.jeton(qui)}"}, **kw)
