"""Parcours de maintenance et séparation des trois actes."""
import pytest
from fastapi import HTTPException
from sqlalchemy import select

from app.core.securite import Portee, Principal
from app.db import session_scope
from app.modules.maintenance import service as mnt
from app.modules.patrimoine.models import Actif, Site


def principal(role, site=None, entite=None):
    return Principal(1, f"test.{role}", role, [Portee(role, entite, site)])


@pytest.fixture()
def ctx(base):
    with session_scope() as s:
        site = s.scalar(select(Site).where(Site.code == "SITE-PV-GAR"))
        act = s.scalar(select(Actif).where(Actif.code == "PV-GAR-OND2"))
        return site.id, act.id


def test_parcours_et_actes_distincts(ctx):
    sid, aid = ctx
    tech, resp, expl = principal("technicien_maintenance", site=sid), principal("responsable_site", site=sid), \
        principal("exploitant_habilite", site=sid)
    with session_scope() as s:
        ot = mnt.creer_ordre(s, tech, actif_id=aid, titre="Test", description="d")
        with pytest.raises(HTTPException):
            mnt.transition(s, tech, ot, "en_intervention")  # saut d'étape
        with pytest.raises(HTTPException):
            mnt.transition(s, tech, ot, "evalue")  # évaluation obligatoire
        mnt.transition(s, tech, ot, "evalue", evaluation="diagnostic")
        from datetime import datetime, timezone

        mnt.transition(s, tech, ot, "planifie", date_planifiee=datetime(2026, 6, 19, tzinfo=timezone.utc))
        with pytest.raises(HTTPException) as e:
            mnt.transition(s, tech, ot, "en_intervention")
        assert "permis de travail" in e.value.detail
        mnt.transition(s, tech, ot, "en_intervention", reference_permis_travail="PT-1")
        mnt.transition(s, tech, ot, "controle")
        mnt.enregistrer_controle(s, tech, ot, [{"libelle": "essai", "resultat": "non_conforme"}])
        with pytest.raises(HTTPException):
            mnt.transition(s, tech, ot, "cloture")  # contrôle non conforme
        mnt.enregistrer_controle(s, tech, ot, [{"libelle": "essai", "resultat": "conforme"}])
        mnt.transition(s, tech, ot, "cloture")
        res = mnt.cloture_administrative(s, tech, ot)
        assert "N'emporte NI retour en disponibilité NI autorisation" in res["effet"]
        d = mnt.detail_ordre(s, ot)
        assert d["trois_actes_distincts"] == {"cloture_administrative": True, "retour_disponibilite": False,
                                              "autorisation_operationnelle": False}
        with pytest.raises(HTTPException):
            mnt.autorisation_operationnelle(s, expl, ot, "DECONS-1", "ok")  # avant retour en disponibilité
        with pytest.raises(HTTPException):
            mnt.retour_disponibilite(s, tech, ot, None)  # rôle insuffisant
        mnt.retour_disponibilite(s, resp, ot, "ok")
        with pytest.raises(HTTPException):
            mnt.autorisation_operationnelle(s, resp, ot, "DECONS-1", "ok")  # responsable non habilité
        with pytest.raises(HTTPException):
            mnt.autorisation_operationnelle(s, expl, ot, "", "ok")  # référence externe obligatoire
        a = mnt.autorisation_operationnelle(s, expl, ot, "DECONS-1", "Déconsignation réalisée")
        assert "ne déclare pas une installation sûre" in a.declaration


def test_portee_technicien(ctx):
    with session_scope() as s:
        autre = s.scalar(select(Actif).where(Actif.code == "STA-TIL-PMP1"))
        tech = principal("technicien_maintenance", entite=s.scalar(select(Site).where(Site.code == "SITE-PV-GAR")).entite_id)
        with pytest.raises(HTTPException) as e:
            mnt.creer_ordre(s, tech, actif_id=autre.id, titre="x", description="y")
        assert e.value.status_code == 403
