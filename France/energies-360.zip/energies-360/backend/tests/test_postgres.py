"""Tests spécifiques PostgreSQL + PostGIS (ignorés sans E360_TEST_PG_URL)."""
import os
import threading

import pytest
from sqlalchemy import select, text

from tests.conftest import nouvelle_base, preparer

pytestmark = [pytest.mark.postgres,
              pytest.mark.skipif(not os.environ.get("E360_TEST_PG_URL"), reason="E360_TEST_PG_URL non défini")]


@pytest.fixture(scope="module")
def pg():
    url = nouvelle_base(pg=True)
    preparer(url)
    return url


def test_postgis_requete_spatiale(pg):
    from app.db import session_scope
    from app.modules.patrimoine.service import sites_proches

    with session_scope() as s:
        r = sites_proches(s, 45.7, 4.9, 40, None)
        assert r["methode"].startswith("PostGIS")
        assert [x["code"] for x in r["sites"]][:1] == ["SITE-IND-LYM"]
        assert s.execute(text("SELECT ST_SRID(geom) FROM site LIMIT 1")).scalar() == 4326


def test_journaux_immuables_en_base(pg):
    from app.core.securite import auditer
    from app.db import session_scope

    with session_scope() as s:
        auditer(s, "t", "test", "x")
    with session_scope() as s, pytest.raises(Exception, match="immuable"):
        s.execute(text("UPDATE journal_audit SET acteur = 'pirate'"))
    with session_scope() as s, pytest.raises(Exception, match="Observation brute"):
        s.execute(text("INSERT INTO lot_ingestion (source, mode, recu_le, depose_par, nb_recus, nb_inseres, "
                       "nb_doublons_exacts, nb_doublons_conflictuels, nb_retards, nb_hors_bornes, nb_rejets) "
                       "VALUES ('t','t',now(),'t',0,0,0,0,0,0,0)"))
        s.execute(text("INSERT INTO observation (point_mesure_id, actif_id, grandeur, valeur, unite, observe_le, "
                       "ingere_le, source, empreinte_valeur, qualite) SELECT p.id, p.actif_id, 'x', 1, 'kW', now(), "
                       "now(), 't', 'e', '[]' FROM point_mesure p LIMIT 1"))
        s.flush()
        s.execute(text("UPDATE observation SET valeur = 2"))


def test_reservations_concurrentes_pg(pg):
    from fastapi import HTTPException

    from app.db import nouvelle_session, session_scope
    from app.modules.patrimoine.models import Produit
    from app.modules.stocks import service as stk
    from app.modules.stocks.models import Emplacement

    with session_scope() as s:
        p = s.scalar(select(Produit).where(Produit.code == "GAZ-BUT-13"))
        e = s.scalar(select(Emplacement).where(Emplacement.code == "DEP-Z-C"))
        stk._mouvement(s, type_="ajustement_inventaire", produit_id=p.id, lot_id=None, emplacement_id=e.id,
                       quantite=100, unite="bouteille", auteur="t")
        sid = stk.solde(s, e.id, p.id, None).id
    ok, barriere = [], threading.Barrier(10)

    def tenter():
        s = nouvelle_session()
        try:
            barriere.wait()
            stk.reserver(s, sid, 15, "r", "t")
            s.commit()
            ok.append(1)
        except HTTPException:
            s.rollback()
        finally:
            s.close()

    fils = [threading.Thread(target=tenter) for _ in range(10)]
    [f.start() for f in fils]
    [f.join() for f in fils]
    assert len(ok) == 6  # 6 × 15 = 90 ≤ 100 < 105


def test_sauvegarde_restauration_pg(pg):
    from app import modeles, sauvegarde
    from app.db import moteur
    from sqlalchemy import create_engine
    from tests.conftest import _TMP

    arch = _TMP / "pg.tar.gz"
    sauvegarde.sauvegarder(moteur(), arch)
    url2 = nouvelle_base(pg=True)
    cible = create_engine(url2)
    sauvegarde.restaurer(cible, arch)
    assert sauvegarde.comparer(moteur(), cible)["identiques"]
