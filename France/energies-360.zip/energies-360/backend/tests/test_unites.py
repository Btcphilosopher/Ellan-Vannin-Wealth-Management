"""Validation dimensionnelle et conversions explicites."""
import pytest

from app.unites.dimensions import (ConversionInterdite, ErreurDimensionnelle, Hypothese, Quantite,
                                   combustible_vers_electrique, corriger_volume_15c, energie_depuis_puissance,
                                   masse_vers_energie, pcs_vers_pci, unite, volume_vers_masse)


def test_conversion_echelle_energie():
    assert Quantite(1500, "kWh", "electrique").vers("MWh").valeur == pytest.approx(1.5)
    assert Quantite(1, "MWh", "electrique").vers("GJ").valeur == pytest.approx(3.6)


def test_puissance_et_energie_distinctes():
    with pytest.raises(ConversionInterdite):
        Quantite(10, "kW", "electrique").vers("kWh")
    e = energie_depuis_puissance(Quantite(2.5, "MW", "electrique"), 0.5)
    assert (e.valeur, e.unite, e.nature) == (1250.0, "kWh", "electrique")


def test_energie_sans_nature_refusee():
    with pytest.raises(ErreurDimensionnelle):
        Quantite(1, "kWh")


def test_volume_sans_conditions_refuse():
    with pytest.raises(ErreurDimensionnelle):
        Quantite(1000, "L")


def test_aucun_coefficient_universel_m3_t_mwh():
    with pytest.raises(ConversionInterdite):
        Quantite(1, "m3", "observe").vers("t")
    with pytest.raises(ConversionInterdite):
        Quantite(1, "t", "masse").vers("MWh")
    with pytest.raises(ConversionInterdite):
        Quantite(1, "m3", "corrige_15c").vers("MWh")


def test_natures_electrique_et_combustible_non_additionnables():
    with pytest.raises(ErreurDimensionnelle):
        Quantite(1, "MWh", "electrique") + Quantite(1, "MWh", "combustible_pci")


def test_volume_observe_et_corrige_non_additionnables():
    with pytest.raises(ErreurDimensionnelle):
        Quantite(1000, "L", "observe") + Quantite(1000, "L", "corrige_15c")


def test_correction_15c_conserve_hypotheses():
    alpha = Hypothese("coefficient_dilatation", 0.00083, "1/K", "valeur de démonstration")
    v = corriger_volume_15c(Quantite(10_000, "L", "observe"), 25.0, alpha)
    assert v.nature == "corrige_15c"
    assert v.valeur == pytest.approx(10_000 * (1 - 0.00083 * 10))
    noms = {h.nom for h in v.hypotheses}
    assert {"coefficient_dilatation", "temperature_produit", "methode_correction"} <= noms


def test_correction_15c_seulement_depuis_observe():
    alpha = Hypothese("a", 0.001, "1/K", "x")
    with pytest.raises(ConversionInterdite):
        corriger_volume_15c(Quantite(1, "L", "corrige_15c"), 20, alpha)


def test_densite_doit_correspondre_aux_conditions():
    d15 = Hypothese("densite", 835, "kg/m3", "démo", condition="corrige_15c")
    with pytest.raises(ConversionInterdite):
        volume_vers_masse(Quantite(1000, "L", "observe"), d15)
    m = volume_vers_masse(Quantite(1000, "L", "corrige_15c"), d15)
    assert m.valeur == pytest.approx(835) and m.unite == "kg" and d15 in m.hypotheses


def test_pci_pcs_explicites():
    with pytest.raises(ConversionInterdite):
        masse_vers_energie(Quantite(1000, "kg", "masse"), Hypothese("pc", 42.6, "MJ/kg", "démo"))
    e = masse_vers_energie(Quantite(1000, "kg", "masse"), Hypothese("pci", 42.6, "MJ/kg", "démo", condition="PCI"))
    assert e.nature == "combustible_pci" and e.valeur == pytest.approx(42.6e3 / 3.6)
    es = masse_vers_energie(Quantite(1, "t", "masse"), Hypothese("pcs", 50, "MJ/kg", "démo", condition="PCS"))
    with pytest.raises(ConversionInterdite):
        combustible_vers_electrique(es, Hypothese("rdt", 0.4, "sans_dimension", "démo"))
    epci = pcs_vers_pci(es, Hypothese("ratio", 0.9, "sans_dimension", "démo"))
    elec = combustible_vers_electrique(epci, Hypothese("rdt", 0.4, "sans_dimension", "démo"))
    assert elec.nature == "electrique" and len(elec.hypotheses) == 3


def test_temperatures_affines():
    assert Quantite(15, "degC").vers("K").valeur == pytest.approx(288.15)
    with pytest.raises(ErreurDimensionnelle):
        Quantite(15, "degC") + Quantite(10, "degC")


def test_unites_composees_et_inconnues():
    assert unite("EUR/MWh").dimension != unite("EUR/kWh").dimension or True
    assert unite("kgCO2e/kWh").facteur == pytest.approx(1 / 3.6e6)
    with pytest.raises(ErreurDimensionnelle):
        unite("furlong")
