"""Méthodes de calcul : finance, batterie, contrats, émissions, recharge, rapports."""
from datetime import datetime, timedelta, timezone

import pytest
from fastapi import HTTPException
from sqlalchemy import select

from app.db import session_scope
from app.modules.batterie.service import simuler
from app.modules.contrats import service as ctr
from app.modules.contrats.models import Contrat
from app.modules.environnement import service as env
from app.modules.environnement.models import FacteurEmission
from app.modules.finance.service import tri, van
from app.modules.industrie.service import evaluer_bilan
from app.modules.industrie.models import BilanMatiere

UTC = timezone.utc
D = lambda *a: datetime(*a, tzinfo=UTC)  # noqa: E731


def test_van_tri_valeurs_connues():
    flux = [(D(2026, 1, 1), -100.0), (D(2027, 1, 1), 110.0)]
    assert van(flux, 0.10, D(2026, 1, 1), "fin_de_periode_annuelle") == pytest.approx(0, abs=1e-9)
    t, note = tri(flux, D(2026, 1, 1), "fin_de_periode_annuelle")
    assert t == pytest.approx(0.10, abs=1e-6) and note == "racine unique"
    # convention dates réelles : 365 jours → même résultat
    t2, _ = tri(flux, D(2026, 1, 1), "dates_reelles_act365")
    assert t2 == pytest.approx(0.10, abs=1e-4)
    t3, n3 = tri([(D(2026, 1, 1), 100.0), (D(2027, 1, 1), 50.0)], D(2026, 1, 1), "fin_de_periode_annuelle")
    assert t3 is None and "indéfini" in n3
    _, n4 = tri([(D(2026, 1, 1), -100), (D(2027, 1, 1), 230), (D(2028, 1, 1), -132)], D(2026, 1, 1),
                "fin_de_periode_annuelle")
    assert "plusieurs TRI" in n4


PARAMS = {"energie_nominale_kwh": 10_000, "puissance_charge_max_kw": 5_000, "puissance_decharge_max_kw": 5_000,
          "soc_min_pct": 10, "soc_max_pct": 90, "rendement_charge": 0.95, "rendement_decharge": 0.95}


def test_batterie_contraintes_physiques():
    prix = [40, 35, 30, 30, 32, 45, 70, 90, 80, 60, 40, 20, 15, 18, 25, 50, 80, 120, 140, 110, 90, 70, 55, 45] * 3
    r = simuler(PARAMS, prix, 1.0, 50)
    v = r["verifications"]
    assert v["soc_dans_bornes"] and v["puissances_dans_limites"] and v["pas_de_charge_decharge_simultanee"]
    assert v["bilan_conserve"] and v["pertes_kwh"] > 0
    assert r["synthese"]["nature_revenu"] == "estimation" and "garantie" in r["avertissement"]
    assert all(t["soc_pct"] <= 90 + 1e-6 and t["soc_pct"] >= 10 - 1e-6 for t in r["trajectoire"])


def test_batterie_pas_d_arbitrage_non_rentable():
    r = simuler(PARAMS, [50.0] * 24, 1.0, 50)
    assert r["synthese"]["energie_dechargee_kwh"] == 0 and r["synthese"]["revenu_estime_eur"] == 0


def test_batterie_parametres_invalides():
    with pytest.raises(HTTPException):
        simuler(PARAMS | {"rendement_charge": 1.3}, [1, 2], 1.0)


def test_formule_prix_sure_et_sans_regard_futur(base):
    assert ctr.evaluer_formule("IDX * 0.97 - 1.5", {"IDX": 100}) == pytest.approx(95.5)
    for f in ("__import__('os').system('x')", "IDX.__class__", "[1,2]"):
        with pytest.raises(HTTPException):
            ctr.evaluer_formule(f, {"IDX": 1})
    with session_scope() as s:
        c = s.scalar(select(Contrat).where(Contrat.numero == "CTR-GO-TIL-2026"))
        cot = ctr.cotation(s, c, D(2026, 6, 17, 6, 30))
        assert "INDICATIF" in cot["nature"] and "non exécutable" in cot["nature"]
        for i in cot["indices"]:
            assert datetime.fromisoformat(i["publie_le"]) <= D(2026, 6, 17, 6, 30)


def _act(**kw):
    base = dict(entite_id=1, site_id=1, actif_id=None, categorie="electricite_soutiree", scope=2, quantite=1000.0,
                unite="kWh", nature_quantite="electrique", periode_debut=D(2026, 6, 1), periode_fin=D(2026, 7, 1),
                source_type="compteur", source_reference="GAR-PDL-ES", cle_origine="K1", nature="mesuree",
                part_consolidee_pct=100, exclusions=[])
    return base | kw


def test_emissions_double_comptage_et_unites(base):
    with session_scope() as s:
        a, ctrl = env.enregistrer_activite(s, _act(), "e.garnier")
        f = s.scalar(select(FacteurEmission).where(FacteurEmission.code == "FE-ELEC-RES-SIM"))
        c = env.calculer(s, a, f)
        assert c.emission_kgco2e == pytest.approx(52.0) and c.hypotheses[0]["source"].startswith("Facteur FICTIF")
        with pytest.raises(HTTPException):  # même clé d'origine
            env.enregistrer_activite(s, _act(), "e.garnier")
        with pytest.raises(HTTPException):  # sous-comptage d'équipement sur même période
            env.enregistrer_activite(s, _act(cle_origine="K2", actif_id=1), "e.garnier")
        with pytest.raises(HTTPException):  # chevauchement de période
            env.enregistrer_activite(s, _act(cle_origine="K3", periode_debut=D(2026, 6, 20),
                                             periode_fin=D(2026, 7, 10)), "e.garnier")
        b, _ = env.enregistrer_activite(s, _act(cle_origine="K4", quantite=2.0, unite="MWh", periode_debut=D(2026, 7, 1),
                                                periode_fin=D(2026, 8, 1)), "e.garnier")
        assert env.calculer(s, b, f).emission_kgco2e == pytest.approx(104.0)  # MWh → kWh explicite
        g = s.scalar(select(FacteurEmission).where(FacteurEmission.code == "FE-GO-COMB-SIM"))
        with pytest.raises(HTTPException):  # kWh × facteur par litre : dimensions incompatibles
            env.calculer(s, b, g)
        inv = env.inventaire(s, 2026, None)
        assert "ni une déclaration réglementaire" in inv["mention"]
        assert inv["regle_evitees"].startswith("Les émissions évitées sont publiées séparément")
        s.rollback()


def test_bilan_matiere(base):
    with session_scope() as s:
        b = evaluer_bilan(s.scalar(select(BilanMatiere)))
        assert b["total_entrees"] == pytest.approx(450.5) and b["ecart_non_explique"] == pytest.approx(2.2)
        bm = s.scalar(select(BilanMatiere))
        bm.entrees = bm.entrees + [{"produit": "x", "quantite": 3, "unite": "m3"}]
        with pytest.raises(HTTPException):
            evaluer_bilan(bm)
        s.rollback()


def test_ocpp_joignable_n_est_pas_disponible(client):
    def trame(borne, action, charge):
        return client("svc.ingestion", "POST", f"/api/mobilite/ocpp/{borne}", json=[2, "m1", action, charge]).json()

    trame("CP-TIL-02", "BootNotification", {"chargePointVendor": "F", "chargePointModel": "M"})
    trame("CP-TIL-02", "StatusNotification", {"connectorId": 1, "status": "Faulted", "errorCode": "GroundFailure",
                                             "timestamp": "2026-06-21T23:00:00+00:00"})
    bornes = client("m.fontaine", "GET", "/api/mobilite/bornes", params={"instant": "2026-06-22T00:06:00+00:00"}).json()
    cs = {c["connecteur"]: c for b in bornes["bornes"] for c in b["connecteurs"]}
    assert cs["CP-TIL-02-C1"]["joignable"] and cs["CP-TIL-02-C1"]["disponibilite_evaluee"] == "indisponible"
    assert cs["CP-TIL-02-C2"]["joignable"] and cs["CP-TIL-02-C2"]["disponibilite_evaluee"] == "indeterminee"
    assert cs["CP-PNF-02-C1"]["joignable"] is False and cs["CP-PNF-02-C1"]["disponibilite_evaluee"] == "indeterminee"
    r = trame("CP-TIL-02", "StartTransaction", {"connectorId": 2, "idTag": "SECRET-TAG", "meterStart": 1000,
                                               "timestamp": "2026-06-21T20:00:00+00:00"})
    tid = r[2]["transactionId"]
    trame("CP-TIL-02", "StopTransaction", {"transactionId": tid, "meterStop": 31_000,
                                          "timestamp": "2026-06-21T20:30:00+00:00"})
    sess = [x for x in client("m.fontaine", "GET", "/api/mobilite/sessions").json() if x["transaction_id"] == tid][0]
    assert sess["energie_kwh"] == 30.0 and sess["montant_ttc"] == pytest.approx(0.5 + 30 * 0.49 + 30 * 0.01)
    assert "SECRET-TAG" not in str(client("m.fontaine", "GET", f"/api/mobilite/sessions/{sess['id']}").json())
    assert trame("CP-TIL-02", "Reset", {"type": "Soft"})[2] == "NotSupported"


def test_rapport_tracable_et_falsification(client):
    sid = {s["code"]: s["id"] for s in client("direction", "GET", "/api/patrimoine/sites").json()}["SITE-PV-GAR"]
    r = client("c.durand", "POST", "/api/rapports", json={"site_id": sid}).json()
    v = client("c.durand", "GET", f"/api/rapports/{r['id']}/verifier").json()
    assert v["empreinte_contenu_ok"] and v["signature_ok"]
    assert client("n.petit", "GET", f"/api/rapports/{r['id']}/telecharger").status_code == 403
    from app.core.services import stockage
    from app.modules.reporting.models import Rapport

    with session_scope() as s:
        rp = s.get(Rapport, r["id"])
        chemin = stockage().racine / rp.cle_json
        chemin.write_bytes(chemin.read_bytes().replace(b'"Parc', b'"PARC'))
        with pytest.raises(ValueError):
            stockage().lire(rp.cle_json, rp.sha256_json)


def test_indicateurs_exposent_methode_et_sources(client):
    r = client("direction", "GET", "/api/indicateurs/energie_pv_produite").json()
    assert r["unite"] == "MWh" and r["methode"] and "sources" in r and r["nature"] == "mesure"
    vue = client("direction", "GET", "/api/indicateurs").json()["indicateurs"]
    assert all("methode" in i or i.get("statut") == "indisponible" for i in vue)
    assert client("m.fontaine", "GET", "/api/indicateurs/revenu_estime_pv").status_code == 403
