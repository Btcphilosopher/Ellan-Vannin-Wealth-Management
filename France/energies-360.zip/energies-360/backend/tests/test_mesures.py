"""Ingestion, doublons, données manquantes, compteurs, agrégations, bilans, qualité."""
from datetime import datetime, timedelta, timezone

import pytest
from sqlalchemy import select

from app.db import session_scope
from app.modules.mesures import energie, ingestion, qualite
from app.modules.mesures.models import Alerte, Observation
from app.modules.patrimoine.models import PointMesure, Site
from app.simulateurs.pv import ConfigScenario, generer

UTC = timezone.utc
T0 = datetime(2026, 6, 15, tzinfo=UTC)


def pt(s, code):
    return s.scalar(select(PointMesure).where(PointMesure.code == code))


def obs(code, t, v, **kw):
    return {"point": code, "observe_le": t.isoformat(), "valeur": v, **kw}


def test_doublons_exacts_et_conflictuels(base):
    with session_scope() as s:
        t = T0 + timedelta(days=30)
        l1 = ingestion.ingerer(s, [obs("PV-GAR-METEO-TAMB", t, 21.0)], "test", "t", "rejeu_simulation", t)
        l2 = ingestion.ingerer(s, [obs("PV-GAR-METEO-TAMB", t, 21.0), obs("PV-GAR-METEO-TAMB", t, 23.5)], "test", "t",
                               "rejeu_simulation", t)
        assert (l1.nb_inseres, l2.nb_doublons_exacts, l2.nb_doublons_conflictuels) == (1, 1, 1)
        lignes = s.scalars(select(Observation).where(Observation.point_mesure_id == pt(s, "PV-GAR-METEO-TAMB").id,
                                                     Observation.observe_le == t)).all()
        assert len(lignes) == 2 and all("doublon_conflictuel" in o.qualite for o in lignes)
        retenue = energie.observations_valides(s, lignes[0].point_mesure_id, t, t)
        assert len(retenue) == 1 and retenue[0].valeur == 21.0  # première reçue


def test_rejets_valeur_absente_unite_futur(base):
    with session_scope() as s:
        t = T0 + timedelta(days=31)
        l = ingestion.ingerer(s, [obs("PV-GAR-OND1-P", t, None), obs("PV-GAR-OND1-P", t, 5, unite="m3"),
                                  obs("PV-GAR-OND1-P", t + timedelta(days=2), 5), {"point": "INCONNU", "observe_le": t.isoformat()},
                                  obs("PV-GAR-OND1-P", t, 1.2, unite="MW")], "test", "t", "rejeu_simulation", t)
        motifs = " | ".join(r["motif"] for r in l.rejets)
        assert l.nb_rejets == 4 and l.nb_inseres == 1
        assert "absence n'est pas un zéro" in motifs and "unité incompatible" in motifs and "futur" in motifs
        o = s.scalar(select(Observation).where(Observation.lot_id == l.id))
        assert o.valeur == 1.2 and o.unite == "MW" and o.valeur_normalisee == pytest.approx(1200)  # brut conservé


def test_retard_et_hors_bornes(base):
    with session_scope() as s:
        t = T0 + timedelta(days=32)
        l = ingestion.ingerer(s, [obs("PV-GAR-OND2-P", t, 99999)], "test", "t", "rejeu_simulation", t + timedelta(hours=2))
        assert l.nb_retards == 1 and l.nb_hors_bornes == 1
        o = s.scalar(select(Observation).where(Observation.lot_id == l.id))
        assert set(o.qualite) == {"retard", "hors_bornes"}
        assert energie.observations_valides(s, o.point_mesure_id, t, t) == []  # exclue des agrégats


def test_lot_trop_volumineux(base):
    from fastapi import HTTPException

    with session_scope() as s, pytest.raises(HTTPException) as e:
        ingestion.ingerer(s, [obs("PV-GAR-OND1-P", T0, 1)] * 20_001, "test", "t")
    assert e.value.status_code == 413


@pytest.fixture(scope="module")
def jeu_pv(base):
    """Une semaine simulée (anomalies incluses) ingérée dans la base du module."""
    sim = generer(ConfigScenario())
    with session_scope() as s:
        for lot in sim["lots"]:
            ingestion.ingerer(s, lot["mesures"], "sim", "test", "rejeu_simulation",
                              datetime.fromisoformat(lot["recu_le"]))
    return sim


D0, D1 = datetime(2026, 6, 15, tzinfo=UTC), datetime(2026, 6, 22, tzinfo=UTC)


def site_pv(s):
    return s.scalar(select(Site).where(Site.code == "SITE-PV-GAR")).id


def test_energie_sans_double_comptage(jeu_pv):
    v = jeu_pv["verite"]
    with session_scope() as s:
        b = energie.bilan_site(s, site_pv(s), D0, D1)
        assert b["termes"]["production_pv"]["valeur"] == pytest.approx(v["production_pv_kwh"], abs=0.01)
        assert b["termes"]["injection_reseau"]["valeur"] == pytest.approx(v["injection_kwh"], abs=0.01)
        assert b["termes"]["charge_batterie"]["valeur"] == pytest.approx(v["charge_kwh"], abs=0.01)
        assert b["ecart_kwh"] == pytest.approx(v["auxiliaires_kwh"] + v["pertes_transfo_kwh"], rel=0.002)
        port = energie.energie_portefeuille(s, "production_pv", D0, D1, None)
        assert port["valeur"] == pytest.approx(v["production_pv_kwh"], abs=0.01)
        assert {x["point"] for x in port["points_exclus"]} == {f"PV-GAR-OND{i}-E" for i in range(1, 5)}


def test_compteur_reinitialise(jeu_pv):
    with session_scope() as s:
        e = energie.energie_compteur(s, pt(s, "PV-GAR-OND3-E"), D0, D1)
        assert len(e["remises_a_zero"]) == 1 and e["statut"] == "complet_avec_reserve"
        assert e["valeur"] > 0  # aucune énergie négative
        prod = energie.energie_puissance(s, pt(s, "PV-GAR-OND3-P"), D0, D1)
        manque = jeu_pv["verite"]["energie_ond3_avant_reset_non_comptee_kwh"]
        assert prod["valeur"] - e["valeur"] == pytest.approx(manque, abs=2.0)


def test_perte_telemetrie_pas_zero(jeu_pv):
    with session_scope() as s:
        p = pt(s, "GAR-PDL-P")
        e = energie.energie_puissance(s, p, D0, D1)
        assert e["statut"] == "incomplet" and e["intervalles_manquants"] == 12
        ser = energie.serie(s, p, datetime(2026, 6, 20, 8, tzinfo=UTC), datetime(2026, 6, 20, 12, tzinfo=UTC), 3600)
        valeurs = [x["v"] for x in ser["points"]]
        assert valeurs[1] is None and valeurs[2] is None and valeurs[0] is not None  # trou ≠ 0
        idx = energie.energie_compteur(s, pt(s, "GAR-PDL-EI"), D0, D1)
        assert idx["interruptions"] and idx["statut"] == "complet"  # total connu par index


def test_qualite_capteur_perime_et_autres(jeu_pv):
    with session_scope() as s:
        sid = site_pv(s)
        qualite.analyser_site(s, sid, D0, D1, D1)
        types = {a.type for a in s.scalars(select(Alerte).where(Alerte.site_id == sid))}
        assert {"capteur_perime", "valeur_figee", "donnees_manquantes", "hors_bornes", "compteur_reinitialise",
                "doublon_conflictuel", "panne_equipement", "retard"} <= types
        perime = s.scalars(select(Alerte).where(Alerte.type == "capteur_perime", Alerte.site_id == sid)).all()
        assert [s.get(PointMesure, a.point_mesure_id).code for a in perime] == ["PV-GAR-METEO-GPOA"]
        n = s.query(Alerte).count()
        qualite.analyser_site(s, sid, D0, D1, D1)  # idempotent
        assert s.query(Alerte).count() == n


def test_second_compteur_principal_refuse(base):
    from fastapi import HTTPException

    from app.modules.patrimoine import service as pat
    from app.modules.patrimoine.models import Actif

    with session_scope() as s:
        a = s.scalar(select(Actif).where(Actif.code == "GAR-PDL"))
        with pytest.raises(HTTPException) as e:
            pat.creer(s, PointMesure, "t", actif_id=a.id, code="X-EI", grandeur="energie", unite="kWh",
                      nature_grandeur="electrique", type_signal="cumul", role_comptage="principal",
                      perimetre_comptage="injection_reseau")
        assert e.value.status_code == 409 and "double comptage" in e.value.detail
