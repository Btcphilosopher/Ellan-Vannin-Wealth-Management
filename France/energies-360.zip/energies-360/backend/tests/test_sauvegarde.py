"""Sauvegarde et restauration testées (contenu identique, corruption détectée)."""
import tarfile

import pytest
from sqlalchemy import create_engine

from app import modeles, sauvegarde
from app.db import moteur, session_scope
from app.modules.mesures import ingestion
from tests.conftest import _TMP


def test_sauvegarde_restauration_identique(base):
    with session_scope() as s:
        ingestion.ingerer(s, [{"point": "PV-GAR-METEO-TAMB", "observe_le": "2026-06-15T12:00:00+00:00", "valeur": 25.1}],
                          "test", "t", "rejeu_simulation",
                          __import__("datetime").datetime.fromisoformat("2026-06-15T12:02:00+00:00"))
    arch = _TMP / "sauv.tar.gz"
    m = sauvegarde.sauvegarder(moteur(), arch)
    assert m["tables"] and sum(t["lignes"] for t in m["tables"]) > 100
    cible = create_engine(f"sqlite:///{_TMP / 'restauree.db'}")
    modeles.metadata.create_all(cible)
    r = sauvegarde.restaurer(cible, arch)
    assert r["restaure"]
    cmp = sauvegarde.comparer(moteur(), cible)
    assert cmp["identiques"], cmp["ecarts"]
    with pytest.raises(ValueError):  # restauration dans une base non vide refusée
        sauvegarde.restaurer(cible, arch)


def test_archive_corrompue_refusee(base):
    arch = _TMP / "sauv2.tar.gz"
    sauvegarde.sauvegarder(moteur(), arch)
    corrompue = _TMP / "corrompue.tar.gz"
    with tarfile.open(arch) as src, tarfile.open(corrompue, "w:gz") as dst:
        for membre in src.getmembers():
            contenu = src.extractfile(membre).read()
            if membre.name == "site.jsonl":
                contenu = contenu.replace(b"Garrigues", b"Garigues")
            import io

            membre.size = len(contenu)
            dst.addfile(membre, io.BytesIO(contenu))
    cible = create_engine(f"sqlite:///{_TMP / 'restauree2.db'}")
    modeles.metadata.create_all(cible)
    with pytest.raises(ValueError, match="Empreinte invalide"):
        sauvegarde.restaurer(cible, corrompue)
