"""Stocks : réception partielle, quarantaine, compatibilité, capacité, transferts,
réservations concurrentes, corrections liées, cohérence du journal."""
import threading

import pytest
from fastapi import HTTPException
from sqlalchemy import select

from app.db import nouvelle_session, session_scope
from app.modules.patrimoine.models import Produit
from app.modules.stocks import service as stk
from app.modules.stocks.models import Ecart, Emplacement, LigneCommande, Livraison, Lot, SoldeStock


def E(s, code):
    return s.scalar(select(Emplacement).where(Emplacement.code == code))


def P(s, code):
    return s.scalar(select(Produit).where(Produit.code == code))


@pytest.fixture(scope="module")
def recu(base):
    with session_scope() as s:
        liv = s.scalar(select(Livraison))
        lc = {s.get(Produit, l.produit_id).code: l for l in s.scalars(select(LigneCommande))}
        rec = stk.recevoir(s, liv, [
            {"ligne_commande_id": lc["LUB-5W30-208"].id, "quantite_recue": 36, "quantite_non_conforme": 2,
             "lot": "L-FUT", "emplacement_id": E(s, "DEP-Z-A").id, "emplacement_quarantaine_id": E(s, "DEP-Q").id},
            {"ligne_commande_id": lc["LUB-5W30-5L"].id, "quantite_recue": 600, "lot": "L-BID",
             "emplacement_id": E(s, "DEP-Z-B").id},
            {"ligne_commande_id": lc["GAZ-BUT-13"].id, "quantite_recue": 120, "lot": "L-BUT",
             "emplacement_id": E(s, "DEP-Z-C").id}], "test")
        return rec.statut


def test_reception_partielle_et_quarantaine(recu):
    assert recu == "avec_ecart"
    with session_scope() as s:
        types = sorted(e.type for e in s.scalars(select(Ecart)))
        assert types == ["qualite", "quantite"]
        etat = {(x["emplacement"], x["lot"]): x for x in stk.etat_stocks(s, None)}
        assert etat[("DEP-Z-A", "L-FUT")]["disponible"] == 34
        q = etat[("DEP-Q", "L-FUT-NC")]
        assert (q["physique"], q["quarantaine"], q["disponible"]) == (2, 2, 0)


def test_compatibilite_et_regles_validees(recu):
    with session_scope() as s:
        with pytest.raises(HTTPException) as e:
            stk.verifier_compatibilite(s, E(s, "DEP-Z-A"), P(s, "GAZ-BUT-13"), 1, "bouteille")
        assert "n'accepte pas le groupe" in e.value.detail
        za = E(s, "DEP-Z-A")
        za.groupes_autorises = ["lubrifiant", "adblue", "gaz_inflammable"]
        za.unite_capacite = "bouteille"
        P(s, "GAZ-BUT-13")  # règle validée gaz/lubrifiant = interdit
        with pytest.raises(HTTPException) as e2:
            stk.verifier_compatibilite(s, za, P(s, "GAZ-BUT-13"), 1, "bouteille")
        assert "interdite" in e2.value.detail
        s.rollback()
    with session_scope() as s:
        zc = E(s, "DEP-Z-C")
        zc.groupes_autorises = ["gaz_inflammable", "adblue"]
        zc.unite_capacite = "ibc"
        p = P(s, "ADB-IBC")
        with pytest.raises(HTTPException) as e3:  # règle adblue/gaz seulement « proposée »
            stk.verifier_compatibilite(s, zc, p, 1, "ibc")
        assert "VALIDÉE" in e3.value.detail
        s.rollback()


def test_capacite_et_unites(recu):
    with session_scope() as s:
        with pytest.raises(HTTPException) as e:
            stk.verifier_compatibilite(s, E(s, "DEP-Z-A"), P(s, "LUB-5W30-208"), 1000, "fut")
        assert "Capacité" in e.value.detail
        with pytest.raises(HTTPException) as e2:
            stk.verifier_compatibilite(s, E(s, "DEP-Z-A"), P(s, "LUB-5W30-208"), 1, "L")
        assert "Aucune conversion implicite" in e2.value.detail


def test_transfert_en_transit_puis_reception_partielle(recu):
    with session_scope() as s:
        lot = s.scalar(select(Lot).where(Lot.numero == "L-BID"))
        t = stk.creer_transfert(s, produit_id=lot.produit_id, lot_id=lot.id, source_id=E(s, "DEP-Z-B").id,
                                destination_id=E(s, "STA-TIL-BOUT").id, quantite=100, auteur="t")
        etat = {(x["emplacement"], x["lot"]): x for x in stk.etat_stocks(s, None)}
        assert etat[("DEP-Z-B", "L-BID")]["physique"] == 500
        assert t.statut == "en_transit"
        stk.recevoir_transfert(s, t, 97, "t")
        etat = {(x["emplacement"], x["lot"]): x for x in stk.etat_stocks(s, None)}
        assert etat[("STA-TIL-BOUT", "L-BID")]["physique"] == 97
        assert s.scalar(select(Ecart).where(Ecart.objet_type == "transfert")).quantite == 3


def test_lot_en_quarantaine_non_transferable(recu):
    with session_scope() as s:
        lot = s.scalar(select(Lot).where(Lot.numero == "L-FUT-NC"))
        with pytest.raises(HTTPException):
            stk.creer_transfert(s, produit_id=lot.produit_id, lot_id=lot.id, source_id=E(s, "DEP-Q").id,
                                destination_id=E(s, "DEP-Z-A").id, quantite=1, auteur="t")


def test_reservations_concurrentes(recu):
    with session_scope() as s:
        solde = s.scalar(select(SoldeStock).join(Lot, SoldeStock.lot_id == Lot.id).where(Lot.numero == "L-BUT"))
        sid, dispo = solde.id, solde.physique - solde.reserve - solde.quarantaine
    assert dispo == 120
    resultats, barriere = [], threading.Barrier(8)

    def tenter(i):
        s = nouvelle_session()
        try:
            barriere.wait()
            stk.reserver(s, sid, 25, f"R{i}", "t")
            s.commit()
            resultats.append("ok")
        except HTTPException:
            s.rollback()
            resultats.append("refus")
        except Exception as e:  # verrou SQLite occupé : compté comme refus sûr
            s.rollback()
            resultats.append(f"erreur:{type(e).__name__}")
        finally:
            s.close()

    fils = [threading.Thread(target=tenter, args=(i,)) for i in range(8)]
    [f.start() for f in fils]
    [f.join() for f in fils]
    with session_scope() as s:
        so = s.get(SoldeStock, sid)
        assert so.reserve <= so.physique  # jamais de sur-réservation
        assert so.reserve == 25 * resultats.count("ok")
        assert resultats.count("ok") == 4  # 4 × 25 ≤ 120 < 5 × 25


def test_correction_liee_et_coherence(recu):
    from app.modules.stocks.models import MouvementStock

    with session_scope() as s:
        m = s.scalar(select(MouvementStock).where(MouvementStock.type == "reception").order_by(MouvementStock.id))
        c = stk.corriger_mouvement(s, m.id, m.quantite - 1, "erreur de comptage", "t")
        assert c.corrige_mouvement_id == m.id and c.quantite == -1
        with pytest.raises(HTTPException):
            stk.corriger_mouvement(s, m.id, m.quantite - 2, "seconde correction", "t")
        assert stk.coherence_journal(s)["coherent"]
