"""Parcours de démonstration complet (12 étapes) via l'API — vérités du simulateur."""
import pytest

pytestmark = pytest.mark.integration


def test_parcours_complet(base, tmp_path):
    from app.demo.scenario import executer

    R = executer(None, str(tmp_path), initialiser_local=False)
    e, v = R["etapes"], R["verite_simulateur"]
    assert e["03"]["production_pv_kwh"] == pytest.approx(v["production_pv_kwh"], abs=0.01)
    assert e["03"]["injection_reseau_kwh"] == pytest.approx(v["injection_kwh"], abs=0.01)
    assert e["03"]["somme_naive_incorrecte_kwh"] > 3 * e["03"]["production_pv_kwh"]
    assert e["02"]["doublons_exacts"] == v["doublons_exacts"] and e["02"]["doublons_conflictuels"] == 2
    assert e["04"]["alerte"].startswith("Capteur périmé")
    assert e["05"]["trois_actes"] == {"cloture_administrative": True, "retour_disponibilite": True,
                                      "autorisation_operationnelle": True}
    assert sorted(e["06"]["reservations_concurrentes_20_sur_34"]) == [201, 409, 409]
    assert e["06"]["journal_coherent"] is True
    assert e["07"]["quantites_L15"]["mesuree"] == 22000 and e["07"]["quantites_L15"]["confirmee"] == 30000
    assert e["08"]["session"]["energie_kwh"] == pytest.approx(39.6)
    assert e["09"]["verifications"]["bilan_conserve"] is True
    assert e["11"]["tentatives_non_autorisees"]["chaine_audit"]["integre"] is True
    assert e["12"]["verification"]["signature_ok"] is True
