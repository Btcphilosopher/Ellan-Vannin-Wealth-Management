"""Sauvegarde et restauration logiques (portables SQLite ↔ PostgreSQL).

Format : archive ``.tar.gz`` contenant un fichier JSON Lines par table et un
manifeste (ordre des tables, nombre de lignes, empreintes SHA-256). La
restauration vérifie les empreintes puis réinsère dans l'ordre des dépendances.
Pour PostgreSQL, ``scripts/sauvegarde_pg.sh`` fournit en complément
``pg_dump``/``pg_restore`` (sauvegarde physique-logique native).
"""
from __future__ import annotations

import hashlib
import io
import json
import tarfile
from datetime import date, datetime
from pathlib import Path

from sqlalchemy import DateTime, insert, select, text
from sqlalchemy.engine import Engine

from . import modeles
from .db import HorodatageUTC, heure_reelle


def _ser(v):
    if isinstance(v, (datetime, date)):
        return v.isoformat()
    return v


def sauvegarder(moteur: Engine, destination: str | Path) -> dict:
    destination = Path(destination)
    destination.parent.mkdir(parents=True, exist_ok=True)
    manifeste = {"cree_le": heure_reelle().isoformat(), "dialecte_source": moteur.dialect.name, "tables": []}
    tampon = io.BytesIO()
    with tarfile.open(fileobj=tampon, mode="w:gz") as tar, moteur.connect() as c:
        for table in modeles.metadata.sorted_tables:
            lignes = [json.dumps({k: _ser(v) for k, v in r._mapping.items()}, ensure_ascii=False, sort_keys=True)
                      for r in c.execute(select(table).order_by(*table.primary_key.columns))]
            contenu = ("\n".join(lignes)).encode()
            info = tarfile.TarInfo(f"{table.name}.jsonl")
            info.size = len(contenu)
            tar.addfile(info, io.BytesIO(contenu))
            manifeste["tables"].append({"nom": table.name, "lignes": len(lignes),
                                        "sha256": hashlib.sha256(contenu).hexdigest()})
        m = json.dumps(manifeste, ensure_ascii=False, indent=2).encode()
        info = tarfile.TarInfo("manifeste.json")
        info.size = len(m)
        tar.addfile(info, io.BytesIO(m))
    destination.write_bytes(tampon.getvalue())
    manifeste["fichier"] = str(destination)
    manifeste["sha256_archive"] = hashlib.sha256(tampon.getvalue()).hexdigest()
    return manifeste


def restaurer(moteur: Engine, source: str | Path) -> dict:
    """Restaure dans une base VIDE au schéma à jour."""
    with tarfile.open(source, mode="r:gz") as tar:
        manifeste = json.loads(tar.extractfile("manifeste.json").read())
        donnees = {}
        for t in manifeste["tables"]:
            contenu = tar.extractfile(f"{t['nom']}.jsonl").read()
            if hashlib.sha256(contenu).hexdigest() != t["sha256"]:
                raise ValueError(f"Empreinte invalide pour {t['nom']} : sauvegarde corrompue")
            donnees[t["nom"]] = [json.loads(l) for l in contenu.decode().splitlines() if l]
    tables = {t.name: t for t in modeles.metadata.sorted_tables}
    with moteur.begin() as c:
        for t in modeles.metadata.sorted_tables:
            if c.execute(select(t).limit(1)).first() is not None:
                raise ValueError(f"Table {t.name} non vide : restauration refusée")
        for t in modeles.metadata.sorted_tables:
            lignes = donnees.get(t.name, [])
            if not lignes:
                continue
            for l in lignes:
                for col in t.columns:
                    if isinstance(col.type, (HorodatageUTC, DateTime)) and l.get(col.name):
                        l[col.name] = datetime.fromisoformat(l[col.name])
            # insertion par paquets ; auto-références (actif.parent_id) : ordre des clés primaires conservé
            for i in range(0, len(lignes), 2000):
                c.execute(insert(tables[t.name]), lignes[i:i + 2000])
        if moteur.dialect.name == "postgresql":
            for t in modeles.metadata.sorted_tables:
                pk = list(t.primary_key.columns)
                if len(pk) == 1 and pk[0].autoincrement in (True, "auto"):
                    c.execute(text(f"SELECT setval(pg_get_serial_sequence('{t.name}', '{pk[0].name}'), "
                                   f"COALESCE((SELECT MAX({pk[0].name}) FROM {t.name}), 1))"))
    return {"restaure": True, "tables": len(manifeste["tables"]),
            "lignes": sum(t["lignes"] for t in manifeste["tables"])}


def comparer(moteur_a: Engine, moteur_b: Engine) -> dict:
    """Compare nombre de lignes et empreinte du contenu, table par table."""
    ecarts = []
    for t in modeles.metadata.sorted_tables:
        def emp(m):
            with m.connect() as c:
                rows = [json.dumps({k: _ser(v) for k, v in r._mapping.items()}, sort_keys=True, default=str)
                        for r in c.execute(select(t).order_by(*t.primary_key.columns))]
            return len(rows), hashlib.sha256("\n".join(rows).encode()).hexdigest()

        a, b = emp(moteur_a), emp(moteur_b)
        if a != b:
            ecarts.append({"table": t.name, "source": a[0], "restauree": b[0]})
    return {"identiques": not ecarts, "ecarts": ecarts}
