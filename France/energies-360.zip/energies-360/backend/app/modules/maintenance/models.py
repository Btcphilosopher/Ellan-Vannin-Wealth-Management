from __future__ import annotations

from sqlalchemy import Boolean, Float, ForeignKey, Integer, String, Text
from sqlalchemy.orm import Mapped, mapped_column

from ...db import Base, HorodatageUTC, JSONType, maintenant


class Inspection(Base):
    __tablename__ = "inspection"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    actif_id: Mapped[int] = mapped_column(ForeignKey("actif.id"), index=True)
    type: Mapped[str] = mapped_column(String(60))
    realisee_le = mapped_column(HorodatageUTC)
    inspecteur: Mapped[str] = mapped_column(String(120))
    constats: Mapped[str] = mapped_column(Text)
    resultat: Mapped[str] = mapped_column(String(30))  # conforme | defaut_constate | a_suivre


class Defaut(Base):
    __tablename__ = "defaut"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    actif_id: Mapped[int] = mapped_column(ForeignKey("actif.id"), index=True)
    inspection_id: Mapped[int | None] = mapped_column(ForeignKey("inspection.id"), nullable=True)
    alerte_id: Mapped[int | None] = mapped_column(ForeignKey("alerte.id"), nullable=True)
    description: Mapped[str] = mapped_column(Text)
    gravite: Mapped[str] = mapped_column(String(20))
    statut: Mapped[str] = mapped_column(String(20), default="ouvert")
    signale_par: Mapped[str] = mapped_column(String(80))
    signale_le = mapped_column(HorodatageUTC, default=maintenant)


class OrdreTravail(Base):
    __tablename__ = "ordre_travail"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    numero: Mapped[str] = mapped_column(String(30), unique=True)
    site_id: Mapped[int] = mapped_column(ForeignKey("site.id"), index=True)
    actif_id: Mapped[int] = mapped_column(ForeignKey("actif.id"), index=True)
    defaut_id: Mapped[int | None] = mapped_column(ForeignKey("defaut.id"), nullable=True)
    alerte_id: Mapped[int | None] = mapped_column(ForeignKey("alerte.id"), nullable=True)
    titre: Mapped[str] = mapped_column(String(240))
    description: Mapped[str] = mapped_column(Text)
    type: Mapped[str] = mapped_column(String(20), default="correctif")
    priorite: Mapped[str] = mapped_column(String(10), default="P2")
    etat: Mapped[str] = mapped_column(String(20), default="signale")
    evaluation: Mapped[str | None] = mapped_column(Text, nullable=True)
    prestataire_id: Mapped[int | None] = mapped_column(ForeignKey("tiers.id"), nullable=True)
    contrat_maintenance_id: Mapped[int | None] = mapped_column(ForeignKey("contrat_maintenance.id"), nullable=True)
    date_planifiee = mapped_column(HorodatageUTC, nullable=True)
    debut_intervention = mapped_column(HorodatageUTC, nullable=True)
    fin_intervention = mapped_column(HorodatageUTC, nullable=True)
    heures_main_oeuvre: Mapped[float] = mapped_column(Float, default=0)
    taux_horaire: Mapped[float] = mapped_column(Float, default=0)
    cout_pieces: Mapped[float] = mapped_column(Float, default=0)
    cout_externe: Mapped[float] = mapped_column(Float, default=0)
    devise: Mapped[str] = mapped_column(String(3), default="EUR")
    reference_permis_travail: Mapped[str | None] = mapped_column(String(60), nullable=True)
    reference_consignation: Mapped[str | None] = mapped_column(String(60), nullable=True)
    cree_par: Mapped[str] = mapped_column(String(80))
    cree_le = mapped_column(HorodatageUTC, default=maintenant)
    cloture_administrative_le = mapped_column(HorodatageUTC, nullable=True)
    cloture_administrative_par: Mapped[str | None] = mapped_column(String(80), nullable=True)


class TransitionOT(Base):
    __tablename__ = "transition_ot"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    ordre_id: Mapped[int] = mapped_column(ForeignKey("ordre_travail.id"), index=True)
    de: Mapped[str] = mapped_column(String(20))
    vers: Mapped[str] = mapped_column(String(20))
    par: Mapped[str] = mapped_column(String(80))
    le = mapped_column(HorodatageUTC, default=maintenant)
    commentaire: Mapped[str | None] = mapped_column(Text, nullable=True)


class Piece(Base):
    __tablename__ = "piece"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    code: Mapped[str] = mapped_column(String(40), unique=True)
    libelle: Mapped[str] = mapped_column(String(200))
    unite: Mapped[str] = mapped_column(String(20), default="unite")
    quantite_stock: Mapped[float] = mapped_column(Float, default=0)
    cout_unitaire: Mapped[float] = mapped_column(Float)
    devise: Mapped[str] = mapped_column(String(3), default="EUR")


class ConsommationPiece(Base):
    __tablename__ = "consommation_piece"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    ordre_id: Mapped[int] = mapped_column(ForeignKey("ordre_travail.id"), index=True)
    piece_id: Mapped[int] = mapped_column(ForeignKey("piece.id"))
    quantite: Mapped[float] = mapped_column(Float)
    cout_unitaire: Mapped[float] = mapped_column(Float)
    le = mapped_column(HorodatageUTC, default=maintenant)


class ControleFinIntervention(Base):
    __tablename__ = "controle_fin_intervention"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    ordre_id: Mapped[int] = mapped_column(ForeignKey("ordre_travail.id"), index=True)
    points_controle = mapped_column(JSONType)  # [{libelle, resultat: conforme|non_conforme|sans_objet, commentaire}]
    conforme: Mapped[bool] = mapped_column(Boolean)
    realise_par: Mapped[str] = mapped_column(String(80))
    le = mapped_column(HorodatageUTC, default=maintenant)


class RetourDisponibilite(Base):
    """Remise à disposition technique de l'équipement (décision humaine)."""

    __tablename__ = "retour_disponibilite"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    ordre_id: Mapped[int] = mapped_column(ForeignKey("ordre_travail.id"), index=True)
    actif_id: Mapped[int] = mapped_column(ForeignKey("actif.id"))
    decide_par: Mapped[str] = mapped_column(String(80))
    le = mapped_column(HorodatageUTC, default=maintenant)
    commentaire: Mapped[str | None] = mapped_column(Text, nullable=True)


class AutorisationOperationnelle(Base):
    """Enregistrement d'une autorisation donnée par une personne habilitée selon
    une procédure externe (consignation / permis de travail). L'application ne
    décide pas et n'atteste pas la sécurité de l'installation."""

    __tablename__ = "autorisation_operationnelle"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    ordre_id: Mapped[int] = mapped_column(ForeignKey("ordre_travail.id"), index=True)
    actif_id: Mapped[int] = mapped_column(ForeignKey("actif.id"))
    accordee_par: Mapped[str] = mapped_column(String(80))
    le = mapped_column(HorodatageUTC, default=maintenant)
    reference_procedure_externe: Mapped[str] = mapped_column(String(80))
    declaration: Mapped[str] = mapped_column(Text)
