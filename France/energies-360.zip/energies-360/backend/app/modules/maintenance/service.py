"""Parcours : signalement → évaluation → planification → intervention → contrôle → clôture.

La clôture administrative, le retour en disponibilité et l'autorisation
opérationnelle sont trois actes distincts, tracés séparément, réalisés par des
personnes aux rôles différents. Aucun n'est déduit automatiquement.
"""
from __future__ import annotations

from datetime import datetime

from fastapi import HTTPException
from sqlalchemy import func, select
from sqlalchemy.orm import Session

from ...core.securite import Principal, verifier_portee
from ...core.services import en_dict, publier
from ...db import maintenant
from ..mesures.models import Alerte
from ..patrimoine.models import Actif, ContratMaintenance
from .models import (AutorisationOperationnelle, ConsommationPiece, ControleFinIntervention, Defaut, OrdreTravail,
                     Piece, RetourDisponibilite, TransitionOT)

TRANSITIONS = {
    "signale": {"evalue", "annule"},
    "evalue": {"planifie", "annule"},
    "planifie": {"en_intervention", "annule"},
    "en_intervention": {"controle"},
    "controle": {"cloture", "en_intervention"},
    "cloture": set(),
    "annule": set(),
}

AVERTISSEMENT_SECURITE = ("Énergies 360 enregistre des décisions humaines. Il ne déclare pas une installation "
                          "sûre et ne remplace ni la consignation ni le permis de travail, gérés selon les "
                          "procédures du site.")


def creer_ordre(session: Session, principal: Principal, *, actif_id: int, titre: str, description: str,
                alerte_id: int | None = None, defaut_id: int | None = None, priorite: str = "P2",
                type_: str = "correctif") -> OrdreTravail:
    actif = session.get(Actif, actif_id)
    if not actif:
        raise HTTPException(404, "Actif introuvable")
    verifier_portee(session, principal, "maintenance:ecrire", site_id=actif.site_id, ressource=f"actif:{actif_id}")
    n = (session.scalar(select(func.count(OrdreTravail.id))) or 0) + 1
    ot = OrdreTravail(numero=f"OT-{maintenant():%Y}-{n:05d}", site_id=actif.site_id, actif_id=actif_id,
                      alerte_id=alerte_id, defaut_id=defaut_id, titre=titre, description=description,
                      priorite=priorite, type=type_, cree_par=principal.identifiant, cree_le=maintenant())
    session.add(ot)
    session.flush()
    session.add(TransitionOT(ordre_id=ot.id, de="", vers="signale", par=principal.identifiant, le=maintenant(),
                             commentaire="Signalement"))
    if alerte_id:
        al = session.get(Alerte, alerte_id)
        if al:
            al.ordre_travail_id = ot.id
            al.statut = "prise_en_charge"
    publier(session, "maintenance", f"Ordre de travail {ot.numero} créé : {titre}", site_id=actif.site_id,
            ordre_id=ot.id)
    return ot


def transition(session: Session, principal: Principal, ot: OrdreTravail, vers: str, commentaire: str | None = None,
               **champs) -> OrdreTravail:
    verifier_portee(session, principal, "maintenance:ecrire", site_id=ot.site_id, ressource=f"ot:{ot.id}")
    if vers not in TRANSITIONS.get(ot.etat, set()):
        raise HTTPException(409, f"Transition {ot.etat} → {vers} non autorisée "
                                 f"(possibles : {sorted(TRANSITIONS.get(ot.etat, set()))})")
    if vers == "evalue" and not (champs.get("evaluation") or ot.evaluation):
        raise HTTPException(422, "L'évaluation doit être renseignée")
    if vers == "planifie":
        if not champs.get("date_planifiee") and not ot.date_planifiee:
            raise HTTPException(422, "Date planifiée requise")
    if vers == "en_intervention":
        ref = champs.get("reference_permis_travail") or ot.reference_permis_travail
        if not ref:
            raise HTTPException(422, ("Référence du permis de travail (procédure externe) requise avant "
                                      "intervention. " + AVERTISSEMENT_SECURITE))
        champs.setdefault("debut_intervention", maintenant())
    if vers == "controle":
        champs.setdefault("fin_intervention", maintenant())
    if vers == "cloture":
        ctrl = dernier_controle(session, ot.id)
        if ctrl is None or not ctrl.conforme:
            raise HTTPException(409, "Clôture impossible : contrôle de fin d'intervention absent ou non conforme")
    for k, v in champs.items():
        if v is not None and hasattr(ot, k):
            setattr(ot, k, v)
    session.add(TransitionOT(ordre_id=ot.id, de=ot.etat, vers=vers, par=principal.identifiant, le=maintenant(),
                             commentaire=commentaire))
    ot.etat = vers
    session.flush()
    publier(session, "maintenance", f"{ot.numero} : {vers}", site_id=ot.site_id, ordre_id=ot.id)
    return ot


def consommer_piece(session, principal, ot: OrdreTravail, piece_id: int, quantite: float):
    verifier_portee(session, principal, "maintenance:ecrire", site_id=ot.site_id)
    if ot.etat not in ("planifie", "en_intervention"):
        raise HTTPException(409, "Consommation de pièces possible en planification ou intervention uniquement")
    p = session.get(Piece, piece_id)
    if p is None or quantite <= 0:
        raise HTTPException(422, "Pièce ou quantité invalide")
    if p.quantite_stock < quantite:
        raise HTTPException(409, f"Stock insuffisant pour {p.code} ({p.quantite_stock} {p.unite})")
    p.quantite_stock -= quantite
    session.add(ConsommationPiece(ordre_id=ot.id, piece_id=p.id, quantite=quantite, cout_unitaire=p.cout_unitaire,
                                  le=maintenant()))
    ot.cout_pieces = (ot.cout_pieces or 0) + quantite * p.cout_unitaire
    session.flush()


def dernier_controle(session, ordre_id) -> ControleFinIntervention | None:
    return session.scalar(select(ControleFinIntervention).where(ControleFinIntervention.ordre_id == ordre_id)
                          .order_by(ControleFinIntervention.id.desc()))


def enregistrer_controle(session, principal, ot: OrdreTravail, points: list[dict]) -> ControleFinIntervention:
    verifier_portee(session, principal, "maintenance:ecrire", site_id=ot.site_id)
    if ot.etat != "controle":
        raise HTTPException(409, "Le contrôle se saisit à l'état « controle »")
    if not points:
        raise HTTPException(422, "Liste de points de contrôle vide")
    conforme = all(p.get("resultat") in ("conforme", "sans_objet") for p in points)
    c = ControleFinIntervention(ordre_id=ot.id, points_controle=points, conforme=conforme,
                                realise_par=principal.identifiant, le=maintenant())
    session.add(c)
    session.flush()
    return c


def cloture_administrative(session, principal, ot: OrdreTravail):
    verifier_portee(session, principal, "maintenance:ecrire", site_id=ot.site_id)
    if ot.etat != "cloture":
        raise HTTPException(409, "Clôture administrative après clôture technique uniquement")
    if ot.cloture_administrative_le:
        raise HTTPException(409, "Déjà clôturé administrativement")
    ot.cloture_administrative_le = maintenant()
    ot.cloture_administrative_par = principal.identifiant
    session.flush()
    return {"ordre": ot.numero, "cloture_administrative": True,
            "effet": "Coûts figés pour la finance. N'emporte NI retour en disponibilité NI autorisation opérationnelle."}


def retour_disponibilite(session, principal, ot: OrdreTravail, commentaire: str | None):
    verifier_portee(session, principal, "maintenance:retour_disponibilite", site_id=ot.site_id)
    ctrl = dernier_controle(session, ot.id)
    if ot.etat != "cloture" or not ctrl or not ctrl.conforme:
        raise HTTPException(409, "Retour en disponibilité : OT clôturé avec contrôle conforme requis")
    r = RetourDisponibilite(ordre_id=ot.id, actif_id=ot.actif_id, decide_par=principal.identifiant, le=maintenant(),
                            commentaire=commentaire)
    session.add(r)
    session.flush()
    return r


def autorisation_operationnelle(session, principal, ot: OrdreTravail, reference: str, declaration: str):
    verifier_portee(session, principal, "maintenance:autorisation_operationnelle", site_id=ot.site_id)
    if not reference or len(reference) < 4:
        raise HTTPException(422, "Référence de la procédure externe (consignation / déconsignation) obligatoire")
    if not session.scalar(select(RetourDisponibilite).where(RetourDisponibilite.ordre_id == ot.id)):
        raise HTTPException(409, "Autorisation opérationnelle après retour en disponibilité uniquement")
    a = AutorisationOperationnelle(ordre_id=ot.id, actif_id=ot.actif_id, accordee_par=principal.identifiant,
                                   le=maintenant(), reference_procedure_externe=reference,
                                   declaration=f"{declaration.strip()} — {AVERTISSEMENT_SECURITE}")
    session.add(a)
    session.flush()
    return a


def cout_total(ot: OrdreTravail) -> float:
    return round((ot.heures_main_oeuvre or 0) * (ot.taux_horaire or 0) + (ot.cout_pieces or 0) + (ot.cout_externe or 0), 2)


def detail_ordre(session, ot: OrdreTravail) -> dict:
    d = en_dict(ot)
    d["transitions"] = [en_dict(t) for t in session.scalars(select(TransitionOT).where(TransitionOT.ordre_id == ot.id)
                                                            .order_by(TransitionOT.id))]
    d["pieces"] = [en_dict(c) for c in session.scalars(select(ConsommationPiece).where(ConsommationPiece.ordre_id == ot.id))]
    d["controles"] = [en_dict(c) for c in session.scalars(select(ControleFinIntervention)
                                                          .where(ControleFinIntervention.ordre_id == ot.id))]
    d["retour_disponibilite"] = [en_dict(r) for r in session.scalars(select(RetourDisponibilite)
                                                                     .where(RetourDisponibilite.ordre_id == ot.id))]
    d["autorisations_operationnelles"] = [en_dict(a) for a in session.scalars(
        select(AutorisationOperationnelle).where(AutorisationOperationnelle.ordre_id == ot.id))]
    d["cout_total"] = cout_total(ot)
    d["cout_detail"] = {"main_oeuvre": round((ot.heures_main_oeuvre or 0) * (ot.taux_horaire or 0), 2),
                        "pieces": round(ot.cout_pieces or 0, 2), "externe": round(ot.cout_externe or 0, 2),
                        "devise": ot.devise}
    d["trois_actes_distincts"] = {
        "cloture_administrative": bool(ot.cloture_administrative_le),
        "retour_disponibilite": bool(d["retour_disponibilite"]),
        "autorisation_operationnelle": bool(d["autorisations_operationnelles"]),
    }
    d["avertissement"] = AVERTISSEMENT_SECURITE
    if ot.contrat_maintenance_id:
        d["contrat_maintenance"] = en_dict(session.get(ContratMaintenance, ot.contrat_maintenance_id))
    return d
