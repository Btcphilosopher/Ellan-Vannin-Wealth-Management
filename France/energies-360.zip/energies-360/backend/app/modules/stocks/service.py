"""Règles de stock : physique, réservé, quarantaine, disponible, en transit.

* disponible = physique − réservé − quarantaine ;
* en transit = quantités expédiées par transfert et non encore reçues
  (comptées hors stock physique des deux emplacements) ;
* chaque mise à jour de solde est un UPDATE conditionnel atomique : deux
  réservations concurrentes ne peuvent pas dépasser le disponible.
"""
from __future__ import annotations

from collections import defaultdict
from datetime import datetime

from fastapi import HTTPException
from sqlalchemy import and_, func, select, update
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session

from ...core.services import en_dict, publier
from ...db import maintenant
from ..patrimoine.models import Produit
from .models import (CommandeAchat, DocumentTransport, Ecart, Emplacement, Expedition, LigneCommande, Livraison, Lot,
                     MouvementStock, RegleCompatibilite, Reception, Reservation, SoldeStock, Transfert)

EPS = 1e-9


def solde(session: Session, emplacement_id: int, produit_id: int, lot_id: int | None) -> SoldeStock:
    q = select(SoldeStock).where(SoldeStock.emplacement_id == emplacement_id, SoldeStock.produit_id == produit_id,
                                 SoldeStock.lot_id.is_(None) if lot_id is None else SoldeStock.lot_id == lot_id)
    s = session.scalar(q)
    if s:
        return s
    p = session.get(Produit, produit_id)
    try:
        with session.begin_nested():
            s = SoldeStock(emplacement_id=emplacement_id, produit_id=produit_id, lot_id=lot_id, unite=p.unite_gestion,
                           physique=0, reserve=0, quarantaine=0, version=0)
            session.add(s)
            session.flush()
    except IntegrityError:
        s = session.scalar(q)
    return s


def verifier_compatibilite(session: Session, emplacement: Emplacement, produit: Produit, quantite: float,
                           unite: str) -> list[str]:
    """Retourne la liste des règles appliquées ; lève 409 si une contrainte échoue."""
    appliquees = []
    if produit.groupe_compatibilite not in (emplacement.groupes_autorises or []):
        raise HTTPException(409, (f"{emplacement.code} n'accepte pas le groupe « {produit.groupe_compatibilite} » "
                                  f"(groupes autorisés : {', '.join(emplacement.groupes_autorises or [])})"))
    appliquees.append(f"groupe {produit.groupe_compatibilite} autorisé sur {emplacement.code}")
    if unite != produit.unite_gestion or unite != emplacement.unite_capacite:
        raise HTTPException(409, (f"Unité {unite} incompatible : produit géré en {produit.unite_gestion}, "
                                  f"capacité de {emplacement.code} en {emplacement.unite_capacite}. Aucune conversion "
                                  "implicite n'est appliquée."))
    presents = set(session.scalars(select(Produit.groupe_compatibilite).join(SoldeStock, SoldeStock.produit_id == Produit.id)
                                   .where(SoldeStock.emplacement_id == emplacement.id, SoldeStock.physique > EPS)))
    for g in presents - {produit.groupe_compatibilite}:
        a, b = sorted((g, produit.groupe_compatibilite))
        r = session.scalar(select(RegleCompatibilite).where(RegleCompatibilite.groupe_a == a,
                                                            RegleCompatibilite.groupe_b == b,
                                                            RegleCompatibilite.statut == "validee"))
        if r is None:
            raise HTTPException(409, (f"Aucune règle de cohabitation VALIDÉE entre « {a} » et « {b} » : "
                                      "stockage refusé par défaut."))
        if not r.autorise:
            raise HTTPException(409, f"Cohabitation interdite {a} / {b} : {r.justification} ({r.reference_documentaire})")
        appliquees.append(f"règle #{r.id} {a}/{b} validée par {r.valide_par}")
    occupe = session.scalar(select(func.coalesce(func.sum(SoldeStock.physique), 0.0))
                            .where(SoldeStock.emplacement_id == emplacement.id)) or 0.0
    entrant = session.scalar(select(func.coalesce(func.sum(Transfert.quantite), 0.0)).where(
        Transfert.destination_id == emplacement.id, Transfert.statut == "en_transit")) or 0.0
    if occupe + entrant + quantite > emplacement.capacite + EPS:
        raise HTTPException(409, (f"Capacité de {emplacement.code} dépassée : {occupe:g} occupés + {entrant:g} en "
                                  f"transit + {quantite:g} > {emplacement.capacite:g} {emplacement.unite_capacite}"))
    appliquees.append(f"capacité {occupe + entrant + quantite:g}/{emplacement.capacite:g} {emplacement.unite_capacite}")
    return appliquees


def _mouvement(session: Session, *, type_: str, produit_id: int, lot_id: int | None, emplacement_id: int,
               quantite: float, unite: str, auteur: str, reference_type=None, reference_id=None,
               corrige=None, commentaire=None, quarantaine: bool = False) -> MouvementStock:
    s = solde(session, emplacement_id, produit_id, lot_id)
    if unite != s.unite:
        raise HTTPException(409, f"Unité {unite} ≠ unité du solde {s.unite}")
    valeurs = {"physique": SoldeStock.physique + quantite, "version": SoldeStock.version + 1}
    if quarantaine:
        valeurs["quarantaine"] = SoldeStock.quarantaine + quantite
        condition = SoldeStock.physique + quantite >= SoldeStock.reserve + SoldeStock.quarantaine + quantite - EPS
    else:
        condition = SoldeStock.physique + quantite >= SoldeStock.reserve + SoldeStock.quarantaine - EPS
    n = session.execute(update(SoldeStock).where(SoldeStock.id == s.id, condition).values(**valeurs)
                        .execution_options(synchronize_session=False)).rowcount
    if n != 1:
        session.refresh(s)
        raise HTTPException(409, (f"Mouvement refusé : disponible insuffisant sur l'emplacement "
                                  f"(physique {s.physique:g}, réservé {s.reserve:g}, quarantaine {s.quarantaine:g})"))
    m = MouvementStock(horodatage=maintenant(), type=type_, produit_id=produit_id, lot_id=lot_id,
                       emplacement_id=emplacement_id, quantite=quantite, unite=unite, auteur=auteur,
                       reference_type=reference_type, reference_id=reference_id, corrige_mouvement_id=corrige,
                       commentaire=commentaire)
    session.add(m)
    session.flush()
    session.refresh(s)
    return m


def recevoir(session: Session, livraison: Livraison, lignes: list[dict], auteur: str,
             emplacement_quarantaine_id: int | None = None) -> Reception:
    """Réception (éventuellement partielle) avec écarts et mise en quarantaine."""
    commande = session.get(CommandeAchat, livraison.commande_id)
    annonces = {a["ligne_commande_id"]: a for a in (livraison.lignes_annoncees or [])}
    statut, resume = "conforme", []
    for l in lignes:
        lc = session.get(LigneCommande, l["ligne_commande_id"])
        if lc is None or lc.commande_id != commande.id:
            raise HTTPException(422, "Ligne de commande étrangère à la livraison")
        produit = session.get(Produit, lc.produit_id)
        emp = session.get(Emplacement, l["emplacement_id"])
        recu, nc = float(l["quantite_recue"]), float(l.get("quantite_non_conforme", 0))
        if recu < 0 or nc < 0 or nc > recu:
            raise HTTPException(422, "Quantités incohérentes")
        lot = Lot(produit_id=produit.id, numero=l["lot"], fournisseur_id=commande.fournisseur_id,
                  statut_qualite="libre")
        session.add(lot)
        session.flush()
        bon = recu - nc
        regles = []
        if bon > 0:
            regles = verifier_compatibilite(session, emp, produit, bon, lc.unite)
            _mouvement(session, type_="reception", produit_id=produit.id, lot_id=lot.id, emplacement_id=emp.id,
                       quantite=bon, unite=lc.unite, auteur=auteur, reference_type="livraison",
                       reference_id=livraison.id)
        if nc > 0:
            qid = emplacement_quarantaine_id or l.get("emplacement_quarantaine_id")
            if not qid:
                raise HTTPException(422, "Emplacement de quarantaine requis pour la quantité non conforme")
            empq = session.get(Emplacement, qid)
            verifier_compatibilite(session, empq, produit, nc, lc.unite)
            lot_nc = Lot(produit_id=produit.id, numero=f"{l['lot']}-NC", fournisseur_id=commande.fournisseur_id,
                         statut_qualite="quarantaine", motif_statut=l.get("motif_non_conformite", "non conforme à réception"))
            session.add(lot_nc)
            session.flush()
            _mouvement(session, type_="reception_quarantaine", produit_id=produit.id, lot_id=lot_nc.id,
                       emplacement_id=empq.id, quantite=nc, unite=lc.unite, auteur=auteur, reference_type="livraison",
                       reference_id=livraison.id, quarantaine=True)
            session.add(Ecart(objet_type="livraison", objet_id=livraison.id, type="qualite", produit_id=produit.id,
                              quantite=nc, unite=lc.unite, cree_le=maintenant(),
                              description=f"{nc:g} {lc.unite} non conformes ({l.get('motif_non_conformite', 'n.c.')}) "
                                          f"placés en quarantaine sous lot {lot_nc.numero}"))
            statut = "avec_ecart"
        annonce = float(annonces.get(lc.id, {}).get("quantite", recu))
        if recu + EPS < annonce:
            session.add(Ecart(objet_type="livraison", objet_id=livraison.id, type="quantite", produit_id=produit.id,
                              quantite=annonce - recu, unite=lc.unite, cree_le=maintenant(),
                              description=f"Reçu {recu:g} {lc.unite} pour {annonce:g} annoncés au document de transport"))
            statut = "partielle" if statut == "conforme" else statut
        lc.quantite_recue = (lc.quantite_recue or 0) + recu
        resume.append({"ligne_commande_id": lc.id, "produit": produit.code, "annonce": annonce, "recu": recu,
                       "non_conforme": nc, "lot": lot.numero, "emplacement": emp.code, "regles_appliquees": regles})
    rec = Reception(livraison_id=livraison.id, recue_le=maintenant(), recue_par=auteur, statut=statut, lignes=resume)
    session.add(rec)
    toutes = session.scalars(select(LigneCommande).where(LigneCommande.commande_id == commande.id)).all()
    commande.statut = "recue" if all(x.quantite_recue + EPS >= x.quantite for x in toutes) else "partiellement_recue"
    livraison.statut = "recue" if statut == "conforme" else "recue_avec_ecart"
    session.flush()
    publier(session, "logistique", f"Réception {statut} de la livraison #{livraison.id}", site_id=commande.site_id)
    return rec


def creer_transfert(session: Session, *, produit_id: int, lot_id: int | None, source_id: int, destination_id: int,
                    quantite: float, auteur: str) -> Transfert:
    if quantite <= 0:
        raise HTTPException(422, "Quantité positive requise")
    produit = session.get(Produit, produit_id)
    src, dst = session.get(Emplacement, source_id), session.get(Emplacement, destination_id)
    if lot_id:
        lot = session.get(Lot, lot_id)
        if lot.statut_qualite != "libre":
            raise HTTPException(409, f"Lot {lot.numero} en {lot.statut_qualite} : transfert interdit")
    verifier_compatibilite(session, dst, produit, quantite, produit.unite_gestion)
    n = (session.scalar(select(func.count(Transfert.id))) or 0) + 1
    t = Transfert(numero=f"TR-{maintenant():%Y}-{n:05d}", produit_id=produit_id, lot_id=lot_id, source_id=src.id,
                  destination_id=dst.id, quantite=quantite, unite=produit.unite_gestion, statut="en_transit",
                  expedie_le=maintenant())
    session.add(t)
    session.flush()
    _mouvement(session, type_="transfert_sortie", produit_id=produit_id, lot_id=lot_id, emplacement_id=src.id,
               quantite=-quantite, unite=produit.unite_gestion, auteur=auteur, reference_type="transfert",
               reference_id=t.id)
    return t


def recevoir_transfert(session: Session, t: Transfert, quantite_recue: float, auteur: str) -> Transfert:
    if t.statut != "en_transit":
        raise HTTPException(409, "Transfert déjà soldé")
    if quantite_recue < 0 or quantite_recue > t.quantite + EPS:
        raise HTTPException(422, "Quantité reçue incohérente")
    t.statut = "recu"
    session.flush()  # libère la capacité « en transit » avant contrôle
    dst = session.get(Emplacement, t.destination_id)
    verifier_compatibilite(session, dst, session.get(Produit, t.produit_id), quantite_recue, t.unite)
    _mouvement(session, type_="transfert_entree", produit_id=t.produit_id, lot_id=t.lot_id, emplacement_id=dst.id,
               quantite=quantite_recue, unite=t.unite, auteur=auteur, reference_type="transfert", reference_id=t.id)
    t.recu_le, t.quantite_recue = maintenant(), quantite_recue
    if quantite_recue + EPS < t.quantite:
        session.add(Ecart(objet_type="transfert", objet_id=t.id, type="quantite", produit_id=t.produit_id,
                          quantite=t.quantite - quantite_recue, unite=t.unite, cree_le=maintenant(),
                          description=f"Transfert {t.numero} : {quantite_recue:g} reçus / {t.quantite:g} expédiés"))
    session.flush()
    return t


def reserver(session: Session, solde_id: int, quantite: float, reference: str, auteur: str) -> Reservation:
    if quantite <= 0:
        raise HTTPException(422, "Quantité positive requise")
    n = session.execute(update(SoldeStock).where(
        SoldeStock.id == solde_id,
        SoldeStock.physique - SoldeStock.reserve - SoldeStock.quarantaine >= quantite - EPS)
        .values(reserve=SoldeStock.reserve + quantite, version=SoldeStock.version + 1)
        .execution_options(synchronize_session=False)).rowcount
    if n != 1:
        raise HTTPException(409, "Réservation refusée : quantité disponible insuffisante")
    r = Reservation(solde_id=solde_id, quantite=quantite, reference=reference, cree_par=auteur, cree_le=maintenant())
    session.add(r)
    session.flush()
    return r


def annuler_reservation(session: Session, r: Reservation):
    if r.statut != "active":
        raise HTTPException(409, "Réservation non active")
    session.execute(update(SoldeStock).where(SoldeStock.id == r.solde_id)
                    .values(reserve=SoldeStock.reserve - r.quantite, version=SoldeStock.version + 1)
                    .execution_options(synchronize_session=False))
    r.statut = "annulee"
    session.flush()


def expedier(session: Session, r: Reservation, client_id: int, auteur: str, transporteur_id: int | None = None) -> Expedition:
    if r.statut != "active":
        raise HTTPException(409, "Réservation non active")
    s = session.get(SoldeStock, r.solde_id)
    emp = session.get(Emplacement, s.emplacement_id)
    session.execute(update(SoldeStock).where(SoldeStock.id == s.id)
                    .values(reserve=SoldeStock.reserve - r.quantite).execution_options(synchronize_session=False))
    r.statut = "consommee"
    n = (session.scalar(select(func.count(Expedition.id))) or 0) + 1
    doc = DocumentTransport(type="bon_expedition", numero=f"BE-{maintenant():%Y}-{n:05d}", transporteur_id=transporteur_id,
                            contenu={"produit_id": s.produit_id, "lot_id": s.lot_id, "quantite": r.quantite,
                                     "unite": s.unite, "origine": emp.code, "mention": "document fictif de démonstration"},
                            emis_le=maintenant())
    session.add(doc)
    session.flush()
    e = Expedition(numero=f"EX-{maintenant():%Y}-{n:05d}", client_id=client_id, site_id=emp.site_id,
                   reservation_id=r.id, expediee_le=maintenant(), document_transport_id=doc.id)
    session.add(e)
    session.flush()
    _mouvement(session, type_="expedition", produit_id=s.produit_id, lot_id=s.lot_id, emplacement_id=s.emplacement_id,
               quantite=-r.quantite, unite=s.unite, auteur=auteur, reference_type="expedition", reference_id=e.id)
    return e


def corriger_mouvement(session: Session, mouvement_id: int, quantite_correcte: float, motif: str, auteur: str):
    m = session.get(MouvementStock, mouvement_id)
    if m is None:
        raise HTTPException(404, "Mouvement introuvable")
    if session.scalar(select(MouvementStock).where(MouvementStock.corrige_mouvement_id == m.id)):
        raise HTTPException(409, "Mouvement déjà corrigé : corriger la correction")
    delta = quantite_correcte - m.quantite
    if abs(delta) < EPS:
        raise HTTPException(422, "Aucune différence à corriger")
    return _mouvement(session, type_="correction", produit_id=m.produit_id, lot_id=m.lot_id,
                      emplacement_id=m.emplacement_id, quantite=delta, unite=m.unite, auteur=auteur,
                      reference_type=m.reference_type, reference_id=m.reference_id, corrige=m.id,
                      commentaire=f"Correction de #{m.id} ({m.quantite:g} → {quantite_correcte:g}) : {motif}")


def changer_statut_lot(session: Session, lot: Lot, statut: str, motif: str, auteur: str):
    if statut not in ("libre", "quarantaine", "bloque"):
        raise HTTPException(422, "Statut inconnu")
    for s in session.scalars(select(SoldeStock).where(SoldeStock.lot_id == lot.id)):
        cible = s.physique if statut != "libre" else 0.0
        if statut != "libre" and s.reserve > EPS:
            raise HTTPException(409, "Lot partiellement réservé : annuler les réservations avant quarantaine")
        s.quarantaine = cible
        s.version += 1
    lot.statut_qualite, lot.motif_statut = statut, f"{motif} (par {auteur}, {maintenant():%Y-%m-%d %H:%M} UTC)"
    session.flush()


def etat_stocks(session: Session, site_ids: set[int] | None) -> list[dict]:
    q = (select(SoldeStock, Emplacement, Produit).join(Emplacement, SoldeStock.emplacement_id == Emplacement.id)
         .join(Produit, SoldeStock.produit_id == Produit.id))
    transit = defaultdict(float)
    for t in session.scalars(select(Transfert).where(Transfert.statut == "en_transit")):
        transit[(t.destination_id, t.produit_id)] += t.quantite
    res = []
    for s, e, p in session.execute(q).all():
        if site_ids is not None and e.site_id not in site_ids:
            continue
        lot = session.get(Lot, s.lot_id) if s.lot_id else None
        res.append({"solde_id": s.id, "site_id": e.site_id, "emplacement": e.code, "emplacement_nom": e.nom,
                    "emplacement_id": e.id, "produit_id": p.id, "produit": p.code, "produit_nom": p.nom,
                    "lot_id": s.lot_id, "lot": lot.numero if lot else None,
                    "statut_lot": lot.statut_qualite if lot else None, "unite": s.unite,
                    "physique": round(s.physique, 3), "reserve": round(s.reserve, 3),
                    "quarantaine": round(s.quarantaine, 3),
                    "disponible": round(s.physique - s.reserve - s.quarantaine, 3),
                    "en_transit_entrant": round(transit.get((e.id, p.id), 0.0), 3)})
    return res


def coherence_journal(session: Session) -> dict:
    """Recalcule les soldes physiques depuis le journal et compare à la projection."""
    attendu = defaultdict(float)
    for m in session.scalars(select(MouvementStock)):
        attendu[(m.emplacement_id, m.produit_id, m.lot_id)] += m.quantite
    ecarts = []
    for s in session.scalars(select(SoldeStock)):
        a = attendu.get((s.emplacement_id, s.produit_id, s.lot_id), 0.0)
        if abs(a - s.physique) > 1e-6:
            ecarts.append({"solde_id": s.id, "journal": a, "projection": s.physique})
    return {"coherent": not ecarts, "soldes_verifies": len(attendu), "ecarts": ecarts}
