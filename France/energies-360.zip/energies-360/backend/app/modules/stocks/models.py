"""Approvisionnements, stocks et logistique : journal de mouvements immuable,
projection de soldes, réservations, transferts, quarantaine, écarts."""
from __future__ import annotations

from sqlalchemy import Boolean, Float, ForeignKey, Integer, String, Text, UniqueConstraint
from sqlalchemy.orm import Mapped, mapped_column

from ...db import Base, HorodatageUTC, JSONType, maintenant


class Emplacement(Base):
    __tablename__ = "emplacement"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    site_id: Mapped[int] = mapped_column(ForeignKey("site.id"), index=True)
    actif_id: Mapped[int | None] = mapped_column(ForeignKey("actif.id"), nullable=True)
    code: Mapped[str] = mapped_column(String(40), unique=True)
    nom: Mapped[str] = mapped_column(String(200))
    type: Mapped[str] = mapped_column(String(20))  # zone | rack | cuve | reservoir | quai | quarantaine
    capacite: Mapped[float] = mapped_column(Float)
    unite_capacite: Mapped[str] = mapped_column(String(20))
    groupes_autorises = mapped_column(JSONType, default=list)
    est_quarantaine: Mapped[bool] = mapped_column(Boolean, default=False)
    statut: Mapped[str] = mapped_column(String(20), default="actif")


class Lot(Base):
    __tablename__ = "lot"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    produit_id: Mapped[int] = mapped_column(ForeignKey("produit.id"))
    numero: Mapped[str] = mapped_column(String(60), unique=True)
    fournisseur_id: Mapped[int | None] = mapped_column(ForeignKey("tiers.id"), nullable=True)
    date_fabrication = mapped_column(HorodatageUTC, nullable=True)
    statut_qualite: Mapped[str] = mapped_column(String(20), default="libre")  # libre | quarantaine | bloque
    motif_statut: Mapped[str | None] = mapped_column(Text, nullable=True)


class RegleCompatibilite(Base):
    """Règle de cohabitation entre groupes de produits. Seules les règles
    validées par une personne habilitée sont appliquées."""

    __tablename__ = "regle_compatibilite"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    groupe_a: Mapped[str] = mapped_column(String(40))
    groupe_b: Mapped[str] = mapped_column(String(40))
    autorise: Mapped[bool] = mapped_column(Boolean)
    justification: Mapped[str] = mapped_column(Text)
    reference_documentaire: Mapped[str] = mapped_column(String(200))
    statut: Mapped[str] = mapped_column(String(20), default="proposee")  # proposee | validee
    valide_par: Mapped[str | None] = mapped_column(String(80), nullable=True)
    valide_le = mapped_column(HorodatageUTC, nullable=True)


class CommandeAchat(Base):
    __tablename__ = "commande_achat"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    numero: Mapped[str] = mapped_column(String(40), unique=True)
    fournisseur_id: Mapped[int] = mapped_column(ForeignKey("tiers.id"))
    site_id: Mapped[int] = mapped_column(ForeignKey("site.id"))
    contrat_id: Mapped[int | None] = mapped_column(ForeignKey("contrat.id"), nullable=True)
    statut: Mapped[str] = mapped_column(String(20), default="emise")  # emise | partiellement_recue | recue | soldee
    emise_le = mapped_column(HorodatageUTC, default=maintenant)
    cree_par: Mapped[str] = mapped_column(String(80))


class LigneCommande(Base):
    __tablename__ = "ligne_commande"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    commande_id: Mapped[int] = mapped_column(ForeignKey("commande_achat.id"), index=True)
    produit_id: Mapped[int] = mapped_column(ForeignKey("produit.id"))
    quantite: Mapped[float] = mapped_column(Float)
    unite: Mapped[str] = mapped_column(String(20))
    nature_quantite: Mapped[str | None] = mapped_column(String(30), nullable=True)
    prix_unitaire: Mapped[float] = mapped_column(Float)
    devise: Mapped[str] = mapped_column(String(3), default="EUR")
    quantite_recue: Mapped[float] = mapped_column(Float, default=0)


class DocumentTransport(Base):
    __tablename__ = "document_transport"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    type: Mapped[str] = mapped_column(String(30))  # bon_livraison | lettre_voiture | bon_expedition
    numero: Mapped[str] = mapped_column(String(60), unique=True)
    transporteur_id: Mapped[int | None] = mapped_column(ForeignKey("tiers.id"), nullable=True)
    contenu = mapped_column(JSONType, default=dict)
    document_id: Mapped[int | None] = mapped_column(ForeignKey("document.id"), nullable=True)
    emis_le = mapped_column(HorodatageUTC, default=maintenant)


class Livraison(Base):
    """Livraison annoncée par le fournisseur (avant réception)."""

    __tablename__ = "livraison"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    commande_id: Mapped[int] = mapped_column(ForeignKey("commande_achat.id"), index=True)
    document_transport_id: Mapped[int | None] = mapped_column(ForeignKey("document_transport.id"), nullable=True)
    date_prevue = mapped_column(HorodatageUTC)
    statut: Mapped[str] = mapped_column(String(20), default="annoncee")
    lignes_annoncees = mapped_column(JSONType, default=list)  # [{ligne_commande_id, quantite, lot}]


class Reception(Base):
    __tablename__ = "reception"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    livraison_id: Mapped[int] = mapped_column(ForeignKey("livraison.id"), index=True)
    recue_le = mapped_column(HorodatageUTC)
    recue_par: Mapped[str] = mapped_column(String(80))
    statut: Mapped[str] = mapped_column(String(20))  # conforme | partielle | avec_ecart
    lignes = mapped_column(JSONType, default=list)


class Ecart(Base):
    __tablename__ = "ecart"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    objet_type: Mapped[str] = mapped_column(String(30))
    objet_id: Mapped[int] = mapped_column(Integer)
    type: Mapped[str] = mapped_column(String(20))  # quantite | qualite | documentaire | inventaire
    produit_id: Mapped[int | None] = mapped_column(ForeignKey("produit.id"), nullable=True)
    quantite: Mapped[float | None] = mapped_column(Float, nullable=True)
    unite: Mapped[str | None] = mapped_column(String(20), nullable=True)
    description: Mapped[str] = mapped_column(Text)
    statut: Mapped[str] = mapped_column(String(20), default="ouvert")
    cree_le = mapped_column(HorodatageUTC, default=maintenant)


class Transfert(Base):
    __tablename__ = "transfert"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    numero: Mapped[str] = mapped_column(String(40), unique=True)
    produit_id: Mapped[int] = mapped_column(ForeignKey("produit.id"))
    lot_id: Mapped[int | None] = mapped_column(ForeignKey("lot.id"), nullable=True)
    source_id: Mapped[int] = mapped_column(ForeignKey("emplacement.id"))
    destination_id: Mapped[int] = mapped_column(ForeignKey("emplacement.id"))
    quantite: Mapped[float] = mapped_column(Float)
    unite: Mapped[str] = mapped_column(String(20))
    statut: Mapped[str] = mapped_column(String(20), default="en_transit")
    expedie_le = mapped_column(HorodatageUTC)
    recu_le = mapped_column(HorodatageUTC, nullable=True)
    quantite_recue: Mapped[float | None] = mapped_column(Float, nullable=True)
    document_transport_id: Mapped[int | None] = mapped_column(ForeignKey("document_transport.id"), nullable=True)


class Expedition(Base):
    __tablename__ = "expedition"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    numero: Mapped[str] = mapped_column(String(40), unique=True)
    client_id: Mapped[int] = mapped_column(ForeignKey("tiers.id"))
    site_id: Mapped[int] = mapped_column(ForeignKey("site.id"))
    reservation_id: Mapped[int | None] = mapped_column(ForeignKey("reservation.id"), nullable=True)
    statut: Mapped[str] = mapped_column(String(20), default="expediee")
    expediee_le = mapped_column(HorodatageUTC)
    document_transport_id: Mapped[int | None] = mapped_column(ForeignKey("document_transport.id"), nullable=True)


class Reservation(Base):
    __tablename__ = "reservation"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    solde_id: Mapped[int] = mapped_column(ForeignKey("solde_stock.id"))
    quantite: Mapped[float] = mapped_column(Float)
    statut: Mapped[str] = mapped_column(String(20), default="active")  # active | consommee | annulee
    reference: Mapped[str] = mapped_column(String(120))
    cree_par: Mapped[str] = mapped_column(String(80))
    cree_le = mapped_column(HorodatageUTC, default=maintenant)


class MouvementStock(Base):
    """Journal immuable. Une erreur se corrige par un mouvement de correction
    lié (``corrige_mouvement_id``), jamais par modification."""

    __tablename__ = "mouvement_stock"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    horodatage = mapped_column(HorodatageUTC, index=True)
    type: Mapped[str] = mapped_column(String(30))
    produit_id: Mapped[int] = mapped_column(ForeignKey("produit.id"))
    lot_id: Mapped[int | None] = mapped_column(ForeignKey("lot.id"), nullable=True)
    emplacement_id: Mapped[int] = mapped_column(ForeignKey("emplacement.id"), index=True)
    quantite: Mapped[float] = mapped_column(Float)  # signée : + entrée, − sortie
    unite: Mapped[str] = mapped_column(String(20))
    reference_type: Mapped[str | None] = mapped_column(String(30), nullable=True)
    reference_id: Mapped[int | None] = mapped_column(Integer, nullable=True)
    corrige_mouvement_id: Mapped[int | None] = mapped_column(ForeignKey("mouvement_stock.id"), nullable=True)
    auteur: Mapped[str] = mapped_column(String(80))
    commentaire: Mapped[str | None] = mapped_column(Text, nullable=True)


class SoldeStock(Base):
    """Projection des soldes, mise à jour dans la même transaction que le
    journal par des UPDATE conditionnels atomiques."""

    __tablename__ = "solde_stock"
    __table_args__ = (UniqueConstraint("emplacement_id", "produit_id", "lot_id", name="uq_solde_cle"),)
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    emplacement_id: Mapped[int] = mapped_column(ForeignKey("emplacement.id"))
    produit_id: Mapped[int] = mapped_column(ForeignKey("produit.id"))
    lot_id: Mapped[int | None] = mapped_column(ForeignKey("lot.id"), nullable=True)
    physique: Mapped[float] = mapped_column(Float, default=0)
    reserve: Mapped[float] = mapped_column(Float, default=0)
    quarantaine: Mapped[float] = mapped_column(Float, default=0)
    unite: Mapped[str] = mapped_column(String(20))
    version: Mapped[int] = mapped_column(Integer, default=0)
