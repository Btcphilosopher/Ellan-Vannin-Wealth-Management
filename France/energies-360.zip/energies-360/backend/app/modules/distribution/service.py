"""Réseau de stations : prix datés, ventes, livraisons, stocks de cuves et
rapprochement physique en volume corrigé à 15 °C (hypothèses publiées)."""
from __future__ import annotations

from datetime import datetime

from sqlalchemy import and_, or_, select
from sqlalchemy.orm import Session

from ...core.services import en_dict
from ...unites.dimensions import Hypothese, Quantite, corriger_volume_15c
from ..patrimoine.models import Produit
from ..stocks.models import Emplacement
from .models import Jaugeage, LivraisonCarburant, PrixAffiche, VenteCarburant


def coefficient_dilatation(produit: Produit) -> Hypothese:
    p = produit.proprietes or {}
    c = p.get("coefficient_dilatation_1_K")
    if c is None:
        raise ValueError(f"Coefficient de dilatation non renseigné pour {produit.code}")
    return Hypothese("coefficient_dilatation", c["valeur"], "1/K", c["source"], "autour de 15 °C")


def prix_a_date(session: Session, site_id: int, produit_id: int, instant: datetime) -> PrixAffiche | None:
    return session.scalar(select(PrixAffiche).where(
        PrixAffiche.site_id == site_id, PrixAffiche.produit_id == produit_id, PrixAffiche.valide_de <= instant,
        or_(PrixAffiche.valide_a.is_(None), PrixAffiche.valide_a > instant)).order_by(PrixAffiche.valide_de.desc()))


def rapprochement_cuve(session: Session, cuve: Emplacement, debut: datetime, fin: datetime) -> dict:
    j = session.scalars(select(Jaugeage).where(Jaugeage.cuve_id == cuve.id, Jaugeage.horodatage >= debut,
                                               Jaugeage.horodatage <= fin).order_by(Jaugeage.horodatage)).all()
    if len(j) < 2:
        return {"cuve": cuve.code, "statut": "indetermine", "message": "Deux jaugeages au moins sont nécessaires"}
    ventes = session.scalars(select(VenteCarburant).where(VenteCarburant.cuve_id == cuve.id,
                                                          VenteCarburant.horodatage > j[0].horodatage,
                                                          VenteCarburant.horodatage <= j[-1].horodatage)).all()
    livs = session.scalars(select(LivraisonCarburant).where(LivraisonCarburant.cuve_id == cuve.id,
                                                            LivraisonCarburant.horodatage > j[0].horodatage,
                                                            LivraisonCarburant.horodatage <= j[-1].horodatage)).all()
    produit = session.get(Produit, ventes[0].produit_id if ventes else (livs[0].produit_id if livs else None)) \
        if (ventes or livs) else None
    if produit is None:
        return {"cuve": cuve.code, "statut": "sans_mouvement"}
    alpha = coefficient_dilatation(produit)
    t_moy = sum(x.temperature_c for x in j) / len(j)

    def v15(vol, t):
        return corriger_volume_15c(Quantite(vol, "L", "observe"), t, alpha).valeur

    debut15, fin15 = v15(j[0].volume_observe_l, j[0].temperature_c), v15(j[-1].volume_observe_l, j[-1].temperature_c)
    ventes_obs = sum(v.volume_observe_l for v in ventes)
    ventes15 = v15(ventes_obs, t_moy)
    livs15 = sum(l.volume_15c_bl_l for l in livs)
    livs_obs = sum(l.volume_observe_l for l in livs)
    theorique = debut15 + livs15 - ventes15
    ecart = fin15 - theorique
    return {
        "cuve": cuve.code, "produit": produit.code, "periode": {"debut": j[0].horodatage.isoformat(),
                                                               "fin": j[-1].horodatage.isoformat()},
        "volumes_observes_l": {"stock_initial": j[0].volume_observe_l, "livraisons": round(livs_obs, 1),
                               "ventes": round(ventes_obs, 1), "stock_final": j[-1].volume_observe_l,
                               "note": "volumes à température ambiante : non additionnables entre eux sans correction"},
        "volumes_15c_l": {"stock_initial": round(debut15, 1), "livraisons_bl": round(livs15, 1),
                          "ventes_corrigees": round(ventes15, 1), "stock_theorique": round(theorique, 1),
                          "stock_jauge": round(fin15, 1)},
        "ecart_l15": round(ecart, 1), "ecart_pct_ventes": round(100 * ecart / ventes15, 3) if ventes15 else None,
        "interpretation": ("Écart dans la tolérance indicative de ±0,5 % des ventes" if ventes15 and
                           abs(ecart / ventes15) <= 0.005 else "Écart à investiguer (fuite, étalonnage, vol, erreur de "
                                                               "saisie, hypothèse de température)"),
        "hypotheses": [alpha.en_dict(), {"nom": "temperature_ventes", "valeur": round(t_moy, 2), "unite": "degC",
                                         "source": "moyenne des températures de jaugeage (approximation)"},
                       {"nom": "methode", "source": "correction linéaire simplifiée ; usage fiscal : tables normalisées"}],
        "sources": {"jaugeages": [x.id for x in j], "ventes": len(ventes), "livraisons": [l.id for l in livs]},
    }


def synthese_station(session: Session, site_id: int, debut: datetime, fin: datetime) -> dict:
    cuves = session.scalars(select(Emplacement).where(Emplacement.site_id == site_id, Emplacement.type == "cuve")).all()
    ventes = session.scalars(select(VenteCarburant).where(VenteCarburant.site_id == site_id,
                                                          VenteCarburant.horodatage >= debut,
                                                          VenteCarburant.horodatage < fin)).all()
    par_produit: dict[int, dict] = {}
    for v in ventes:
        d = par_produit.setdefault(v.produit_id, {"volume_observe_l": 0.0, "montant_ttc": 0.0, "transactions": 0})
        d["volume_observe_l"] += v.volume_observe_l
        d["montant_ttc"] += v.montant_ttc
        d["transactions"] += 1
    produits = {p.id: p for p in session.scalars(select(Produit))}
    prix = [en_dict(p) | {"produit": produits[p.produit_id].code} for p in session.scalars(
        select(PrixAffiche).where(PrixAffiche.site_id == site_id).order_by(PrixAffiche.valide_de))]
    return {"site_id": site_id, "ventes": [{"produit": produits[k].code, **{x: round(y, 2) for x, y in d.items()}}
                                           for k, d in par_produit.items()],
            "prix_dates": prix, "cuves": [rapprochement_cuve(session, c, debut, fin) for c in cuves],
            "livraisons": [en_dict(l) for l in session.scalars(select(LivraisonCarburant)
                                                               .where(LivraisonCarburant.site_id == site_id))]}
