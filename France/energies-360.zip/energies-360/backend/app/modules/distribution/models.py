from __future__ import annotations

from sqlalchemy import Float, ForeignKey, Integer, String
from sqlalchemy.orm import Mapped, mapped_column

from ...db import Base, HorodatageUTC, JSONType


class PrixAffiche(Base):
    __tablename__ = "prix_affiche"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    site_id: Mapped[int] = mapped_column(ForeignKey("site.id"), index=True)
    produit_id: Mapped[int] = mapped_column(ForeignKey("produit.id"))
    prix_ttc: Mapped[float] = mapped_column(Float)
    unite_prix: Mapped[str] = mapped_column(String(20), default="EUR/L")
    devise: Mapped[str] = mapped_column(String(3), default="EUR")
    valide_de = mapped_column(HorodatageUTC)
    valide_a = mapped_column(HorodatageUTC, nullable=True)
    source: Mapped[str] = mapped_column(String(120))


class VenteCarburant(Base):
    """Vente à la pompe : volume mesuré par le volucompteur, à température ambiante."""

    __tablename__ = "vente_carburant"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    site_id: Mapped[int] = mapped_column(ForeignKey("site.id"), index=True)
    produit_id: Mapped[int] = mapped_column(ForeignKey("produit.id"))
    pompe_id: Mapped[int] = mapped_column(ForeignKey("actif.id"))
    cuve_id: Mapped[int] = mapped_column(ForeignKey("emplacement.id"))
    horodatage = mapped_column(HorodatageUTC, index=True)
    volume_observe_l: Mapped[float] = mapped_column(Float)
    prix_applique_ttc: Mapped[float] = mapped_column(Float)
    montant_ttc: Mapped[float] = mapped_column(Float)
    taux_tva_pct: Mapped[float] = mapped_column(Float, default=20)
    devise: Mapped[str] = mapped_column(String(3), default="EUR")


class Jaugeage(Base):
    __tablename__ = "jaugeage"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    cuve_id: Mapped[int] = mapped_column(ForeignKey("emplacement.id"), index=True)
    horodatage = mapped_column(HorodatageUTC)
    volume_observe_l: Mapped[float] = mapped_column(Float)
    temperature_c: Mapped[float] = mapped_column(Float)
    source: Mapped[str] = mapped_column(String(60), default="jauge_automatique_simulee")


class LivraisonCarburant(Base):
    __tablename__ = "livraison_carburant"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    site_id: Mapped[int] = mapped_column(ForeignKey("site.id"), index=True)
    cuve_id: Mapped[int] = mapped_column(ForeignKey("emplacement.id"))
    produit_id: Mapped[int] = mapped_column(ForeignKey("produit.id"))
    horodatage = mapped_column(HorodatageUTC)
    volume_observe_l: Mapped[float] = mapped_column(Float)
    temperature_c: Mapped[float] = mapped_column(Float)
    volume_15c_bl_l: Mapped[float] = mapped_column(Float)  # tel que porté au bon de livraison
    contrat_id: Mapped[int | None] = mapped_column(ForeignKey("contrat.id"), nullable=True)
    document_transport_id: Mapped[int | None] = mapped_column(ForeignKey("document_transport.id"), nullable=True)
    hypotheses = mapped_column(JSONType, default=list)
