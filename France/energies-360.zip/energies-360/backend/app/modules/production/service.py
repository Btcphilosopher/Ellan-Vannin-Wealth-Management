"""Production renouvelable : disponibilité, prévision–réalisation, météo,
écrêtement, réductions enregistrées et incidents."""
from __future__ import annotations

from datetime import datetime, timedelta

from sqlalchemy import select
from sqlalchemy.orm import Session

from ...core.services import en_dict
from ..mesures.energie import energie_point, observations_valides, points_principaux, serie
from ..patrimoine.models import Actif, PointMesure
from ..patrimoine.service import capacite
from .models import EvenementReduction, Incident, Prevision, ValeurPrevision

PR_REFERENCE = 0.86  # ratio de performance de référence (hypothèse du modèle physique simplifié)
GAMMA = -0.0037  # coefficient de température du module (1/K), hypothèse fabricant fictive


def puissance_potentielle_kw(g_wm2: float, t_module_c: float | None, pdc_kw: float, pac_max_kw: float) -> float:
    """P = G/1000 × Pdc × PR × (1 + γ(Tmod − 25)), plafonnée à la puissance AC."""
    corr = 1 + GAMMA * ((t_module_c if t_module_c is not None else 25.0) - 25.0)
    return max(0.0, min(pac_max_kw, g_wm2 / 1000.0 * pdc_kw * PR_REFERENCE * corr))


def _point(session, actif_id, grandeur, type_signal=None):
    q = select(PointMesure).where(PointMesure.actif_id == actif_id, PointMesure.grandeur == grandeur)
    if type_signal:
        q = q.where(PointMesure.type_signal == type_signal)
    return session.scalar(q)


def centrale(session: Session, site_id: int) -> Actif | None:
    return session.scalar(select(Actif).where(Actif.site_id == site_id, Actif.type_actif == "centrale_pv"))


def onduleurs(session: Session, centrale_id: int) -> list[Actif]:
    return list(session.scalars(select(Actif).where(Actif.parent_id == centrale_id,
                                                    Actif.type_actif == "onduleur").order_by(Actif.code)))


def points_meteo(session: Session, site_id: int) -> dict[str, PointMesure]:
    st = session.scalar(select(Actif).where(Actif.site_id == site_id, Actif.type_actif == "station_meteo"))
    if not st:
        return {}
    return {p.code.rsplit("-", 1)[1]: p for p in session.scalars(select(PointMesure).where(PointMesure.actif_id == st.id))}


def disponibilite(session: Session, site_id: int, debut: datetime, fin: datetime) -> dict:
    """Disponibilité technique pondérée par la puissance AC des onduleurs.

    Pas « disponible » : état ≠ defaut ; pas sans état reçu : indéterminé (exclu
    du dénominateur et publié séparément, jamais compté comme disponible)."""
    c = centrale(session, site_id)
    if not c:
        return {"applicable": False}
    total_dispo = total_connu = total_indet = 0.0
    detail = []
    for o in onduleurs(session, c.id):
        cap = capacite(session, o.id, "installee", "puissance_ac", debut)
        kw = cap.valeur if cap else 0
        pt = _point(session, o.id, "etat")
        obs = {x.observe_le: x.valeur_texte for x in observations_valides(session, pt.id, debut, fin)} if pt else {}
        pas = pt.pas_attendu_s if pt else 600
        n_d = n_i = n_ind = 0
        t = debut
        while t < fin:
            e = obs.get(t)
            if e is None:
                n_ind += 1
            elif e == "defaut":
                n_i += 1
            else:
                n_d += 1
            t += timedelta(seconds=pas)
        h = pas / 3600
        total_dispo += n_d * h * kw
        total_connu += (n_d + n_i) * h * kw
        total_indet += n_ind * h * kw
        detail.append({"onduleur": o.code, "puissance_ac_kw": kw, "heures_disponibles": round(n_d * h, 2),
                       "heures_indisponibles": round(n_i * h, 2), "heures_indeterminees": round(n_ind * h, 2)})
    return {"applicable": True, "valeur_pct": round(100 * total_dispo / total_connu, 3) if total_connu else None,
            "unite": "%", "part_indeterminee_pct": round(100 * total_indet / (total_connu + total_indet), 3)
            if (total_connu + total_indet) else None,
            "methode": "Σ(heures disponibles × kW AC) / Σ(heures à état connu × kW AC) ; états manquants exclus",
            "onduleurs": detail}


def derniere_prevision(session: Session, actif_id: int, debut: datetime) -> Prevision | None:
    return session.scalar(select(Prevision).where(Prevision.actif_id == actif_id, Prevision.emise_le <= debut,
                                                  Prevision.scenario.is_(False))
                          .order_by(Prevision.emise_le.desc()))


def prevision_vs_realise(session: Session, site_id: int, debut: datetime, fin: datetime) -> dict:
    c = centrale(session, site_id)
    pp = points_principaux(session, site_id).get("production_pv")
    if not c or not pp:
        return {"applicable": False}
    previsions = list(session.scalars(select(Prevision).where(
        Prevision.actif_id == c.id, Prevision.scenario.is_(False), Prevision.debut < fin, Prevision.fin > debut)
        .order_by(Prevision.emise_le)))
    valeurs: dict[datetime, tuple[ValeurPrevision, Prevision]] = {}
    for pv in previsions:  # la plus récente émise avant l'heure cible l'emporte
        for v in session.scalars(select(ValeurPrevision).where(ValeurPrevision.prevision_id == pv.id)):
            if pv.emise_le <= v.debut and debut <= v.debut < fin:
                valeurs[v.debut] = (v, pv)
    mesure = serie(session, pp, debut, fin, 3600)
    lignes, erreurs = [], []
    for p in mesure["points"]:
        t = datetime.fromisoformat(p["t"])
        vp = valeurs.get(t)
        ligne = {"t": p["t"], "realise_kwh": p["v"], "p50_kwh": vp[0].p50 if vp else None,
                 "p10_kwh": vp[0].p10 if vp else None, "p90_kwh": vp[0].p90 if vp else None,
                 "prevision_id": vp[1].id if vp else None, "couverture_pct": p["couverture_pct"]}
        if vp and p["v"] is not None and p["couverture_pct"] >= 99:
            erreurs.append(p["v"] - vp[0].p50)
        lignes.append(ligne)
    mae = sum(abs(e) for e in erreurs) / len(erreurs) if erreurs else None
    cap = capacite(session, c.id, "installee", "puissance_ac", debut)
    return {"applicable": True, "unite": "kWh par heure", "lignes": lignes,
            "previsions": [{"id": p.id, "modele": p.modele, "version": p.version_modele,
                            "emise_le": p.emise_le.isoformat(), "horizon_h": p.horizon_h,
                            "incertitude": p.methode_incertitude} for p in previsions],
            "indicateurs": {"heures_comparees": len(erreurs), "mae_kwh": None if mae is None else round(mae, 2),
                            "biais_kwh": round(sum(erreurs) / len(erreurs), 2) if erreurs else None,
                            "nmae_pct_capacite": round(100 * mae / cap.valeur, 3) if mae is not None and cap else None,
                            "exclusions": "heures sans mesure complète ou sans prévision exclues"}}


def pertes_estimees(session: Session, site_id: int, debut: datetime, fin: datetime) -> dict:
    """Énergie non produite estimée : écrêtement onduleur, limitation réseau
    enregistrée, indisponibilité. Estimation par modèle physique simplifié,
    impossible sans éclairement valide (indéterminé)."""
    c = centrale(session, site_id)
    if not c:
        return {"applicable": False}
    m = points_meteo(session, site_id)
    g = {o.observe_le: o.valeur_normalisee for o in observations_valides(session, m["GPOA"].id, debut, fin)} if "GPOA" in m else {}
    tm = {o.observe_le: o.valeur_normalisee for o in observations_valides(session, m["TMOD"].id, debut, fin)} if "TMOD" in m else {}
    reductions = list(session.scalars(select(EvenementReduction).where(
        EvenementReduction.actif_id == c.id, EvenementReduction.debut < fin, EvenementReduction.fin > debut)))
    res = {"ecretement_onduleur_kwh": 0.0, "limitation_reseau_kwh": 0.0, "indisponibilite_kwh": 0.0,
           "pas_sans_eclairement": 0}
    for o in onduleurs(session, c.id):
        cap = capacite(session, o.id, "installee", "puissance_ac", debut)
        pdc = (o.attributs or {}).get("puissance_dc_kw", cap.valeur * 1.2)
        p_pt, e_pt = _point(session, o.id, "puissance"), _point(session, o.id, "etat")
        pw = {x.observe_le: x.valeur_normalisee for x in observations_valides(session, p_pt.id, debut, fin)}
        et = {x.observe_le: x.valeur_texte for x in observations_valides(session, e_pt.id, debut, fin)}
        h = p_pt.pas_attendu_s / 3600
        t = debut
        while t < fin:
            if t in pw:
                if t not in g:
                    res["pas_sans_eclairement"] += 1
                else:
                    pot_brut = max(0.0, g[t] / 1000 * pdc * PR_REFERENCE * (1 + GAMMA * ((tm.get(t) or 25) - 25)))
                    pot = min(cap.valeur, pot_brut)
                    lim = next((r for r in reductions if r.type == "limitation_reseau" and r.debut <= t < r.fin), None)
                    if et.get(t) == "defaut":
                        res["indisponibilite_kwh"] += pot * h
                    elif lim is not None:
                        res["limitation_reseau_kwh"] += max(0.0, pot - pw[t]) * h
                    if pot_brut > cap.valeur and pw[t] >= 0.985 * cap.valeur:
                        res["ecretement_onduleur_kwh"] += (pot_brut - cap.valeur) * h
            t += timedelta(seconds=p_pt.pas_attendu_s)
    return {"applicable": True, **{k: round(v, 1) if isinstance(v, float) else v for k, v in res.items()},
            "unite": "kWh", "nature": "estimation",
            "methode": (f"Potentiel = G_POA/1000 × Pdc × PR {PR_REFERENCE} × (1 + γ(Tmod−25)), γ = {GAMMA}/K ; "
                        "écrêtement = potentiel brut au-delà de la puissance AC ; limitation = potentiel − mesuré "
                        "pendant les réductions enregistrées ; indisponibilité = potentiel pendant l'état défaut."),
            "avertissement": ("Estimations de modèle, distinctes des mesures. Les pas sans éclairement valide "
                              "(capteur périmé) ne sont pas estimés."),
            "reductions_enregistrees": [en_dict(r) for r in reductions]}


def synthese(session: Session, site_id: int, debut: datetime, fin: datetime) -> dict:
    c = centrale(session, site_id)
    pp = points_principaux(session, site_id)
    prod = energie_point(session, pp["production_pv"], debut, fin) if "production_pv" in pp else None
    m = points_meteo(session, site_id)
    meteo = {k: serie(session, p, debut, fin, 3600) for k, p in m.items()}
    capacites = {}
    if c:
        for nat in ("installee", "disponible"):
            for gr in ("puissance_ac", "puissance_dc"):
                cp = capacite(session, c.id, nat, gr, fin - timedelta(seconds=1))
                if cp:
                    capacites[f"{nat}_{gr}"] = {"valeur": cp.valeur, "unite": cp.unite, "provenance": cp.provenance,
                                                "motif": cp.motif}
    incidents = [en_dict(i) for i in session.scalars(select(Incident).where(
        Incident.site_id == site_id, Incident.debut < fin))]
    return {"site_id": site_id, "periode": {"debut": debut.isoformat(), "fin": fin.isoformat()},
            "capacites": capacites, "production_mesuree": prod,
            "production_serie": serie(session, pp["production_pv"], debut, fin, 3600) if "production_pv" in pp else None,
            "disponibilite": disponibilite(session, site_id, debut, fin),
            "prevision_vs_realise": prevision_vs_realise(session, site_id, debut, fin),
            "pertes_estimees": pertes_estimees(session, site_id, debut, fin), "meteo": meteo, "incidents": incidents,
            "distinction": {"capacite_installee": "puissance plaque du référentiel",
                            "capacite_disponible": "capacité après restrictions déclarées",
                            "production_prevue": "valeurs P50 de la prévision la plus récente émise avant l'heure",
                            "production_observee": "compteur principal production_pv"}}
