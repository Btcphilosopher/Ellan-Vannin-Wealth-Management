from __future__ import annotations

from sqlalchemy import Float, ForeignKey, Integer, String, Text
from sqlalchemy.orm import Mapped, mapped_column

from ...db import Base, HorodatageUTC, JSONType, maintenant


class Prevision(Base):
    """Prévision émise : horizon, modèle, date d'émission et incertitude explicites."""

    __tablename__ = "prevision"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    actif_id: Mapped[int] = mapped_column(ForeignKey("actif.id"), index=True)
    grandeur: Mapped[str] = mapped_column(String(40), default="energie")
    unite: Mapped[str] = mapped_column(String(20), default="kWh")
    modele: Mapped[str] = mapped_column(String(80))
    version_modele: Mapped[str] = mapped_column(String(20))
    emise_le = mapped_column(HorodatageUTC)
    horizon_h: Mapped[int] = mapped_column(Integer)
    debut = mapped_column(HorodatageUTC)
    fin = mapped_column(HorodatageUTC)
    pas_s: Mapped[int] = mapped_column(Integer, default=3600)
    methode_incertitude: Mapped[str] = mapped_column(Text)
    donnees_entree = mapped_column(JSONType, default=dict)
    scenario: Mapped[bool] = mapped_column(default=False)


class ValeurPrevision(Base):
    __tablename__ = "valeur_prevision"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    prevision_id: Mapped[int] = mapped_column(ForeignKey("prevision.id"), index=True)
    debut = mapped_column(HorodatageUTC)
    p10: Mapped[float] = mapped_column(Float)
    p50: Mapped[float] = mapped_column(Float)
    p90: Mapped[float] = mapped_column(Float)


class EvenementReduction(Base):
    """Écrêtement ou réduction de production enregistrée (ex. ordre du
    gestionnaire de réseau, simulé)."""

    __tablename__ = "evenement_reduction"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    actif_id: Mapped[int] = mapped_column(ForeignKey("actif.id"), index=True)
    type: Mapped[str] = mapped_column(String(40))  # limitation_reseau | ecretement_onduleur | arret_volontaire
    debut = mapped_column(HorodatageUTC)
    fin = mapped_column(HorodatageUTC)
    puissance_limite_kw: Mapped[float | None] = mapped_column(Float, nullable=True)
    source: Mapped[str] = mapped_column(String(120))
    reference_externe: Mapped[str | None] = mapped_column(String(80), nullable=True)
    commentaire: Mapped[str | None] = mapped_column(Text, nullable=True)
    enregistre_par: Mapped[str] = mapped_column(String(80))
    enregistre_le = mapped_column(HorodatageUTC, default=maintenant)


class Incident(Base):
    __tablename__ = "incident"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    site_id: Mapped[int] = mapped_column(ForeignKey("site.id"), index=True)
    actif_id: Mapped[int | None] = mapped_column(ForeignKey("actif.id"), nullable=True)
    titre: Mapped[str] = mapped_column(String(240))
    description: Mapped[str] = mapped_column(Text)
    gravite: Mapped[str] = mapped_column(String(20))
    debut = mapped_column(HorodatageUTC)
    fin = mapped_column(HorodatageUTC, nullable=True)
    statut: Mapped[str] = mapped_column(String(20), default="ouvert")
    alerte_ids = mapped_column(JSONType, default=list)
    ordre_travail_id: Mapped[int | None] = mapped_column(Integer, nullable=True)
    cree_par: Mapped[str] = mapped_column(String(80))
    cree_le = mapped_column(HorodatageUTC, default=maintenant)
