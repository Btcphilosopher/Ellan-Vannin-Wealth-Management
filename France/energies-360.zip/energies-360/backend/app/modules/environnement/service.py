"""Calculs d'émissions sourcés et prévention du double comptage.

Contrôles anti-double comptage :
1. unicité de la clé d'origine (même relevé/facture/compteur et période) ;
2. chevauchement de période pour un même site, une même catégorie et un même scope ;
3. hiérarchie : une donnée d'équipement est refusée si une donnée de site couvre
   déjà la même catégorie et la même période (et inversement) ;
4. un même flux de carburant ne peut figurer à la fois en scope 1 (consommation
   propre) et en scope 3 catégorie 11 (produits vendus) sans exclusion déclarée.
"""
from __future__ import annotations

from datetime import datetime, timezone

from fastapi import HTTPException
from sqlalchemy import and_, select
from sqlalchemy.orm import Session

from ...core.services import en_dict
from ...unites.dimensions import ErreurDimensionnelle, Quantite, unite
from .models import CalculEmission, DonneeActivite, EmissionEvitee, FacteurEmission

MENTION = ("Tableau de bord de pilotage interne sur données synthétiques et facteurs fictifs. Ce n'est ni une "
           "déclaration réglementaire, ni un bilan vérifié, ni un audit environnemental.")


def controler_double_comptage(session: Session, d: dict) -> list[str]:
    controles = []
    if session.scalar(select(DonneeActivite).where(DonneeActivite.cle_origine == d["cle_origine"])):
        raise HTTPException(409, f"Double comptage : la clé d'origine « {d['cle_origine']} » est déjà enregistrée")
    controles.append("clé d'origine unique")
    chevauchement = and_(DonneeActivite.periode_debut < d["periode_fin"], DonneeActivite.periode_fin > d["periode_debut"])
    meme = session.scalars(select(DonneeActivite).where(DonneeActivite.site_id == d.get("site_id"),
                                                        DonneeActivite.categorie == d["categorie"],
                                                        DonneeActivite.scope == d["scope"], chevauchement)).all()
    for m in meme:
        if (m.actif_id is None) != (d.get("actif_id") is None):
            raise HTTPException(409, (f"Double comptage : donnée #{m.id} au niveau "
                                      f"{'site' if m.actif_id is None else 'équipement'} couvre déjà cette catégorie et "
                                      "cette période ; ne pas cumuler site et sous-comptage"))
        if m.actif_id == d.get("actif_id"):
            raise HTTPException(409, f"Double comptage : période chevauchant la donnée #{m.id}")
    controles.append("pas de chevauchement site/équipement ni de période")
    if d["categorie"] in ("carburant_vendu",) or d["categorie"].startswith("combustion_"):
        autre = "combustion_flotte_propre" if d["categorie"] == "carburant_vendu" else "carburant_vendu"
        conflit = session.scalars(select(DonneeActivite).where(DonneeActivite.site_id == d.get("site_id"),
                                                               DonneeActivite.categorie == autre, chevauchement)).all()
        for c in conflit:
            declare = any(e.get("cle_origine") == c.cle_origine for e in (d.get("exclusions") or [])) or \
                any(e.get("cle_origine") == d["cle_origine"] for e in (c.exclusions or []))
            if not declare:
                raise HTTPException(409, (
                    f"Risque de double comptage scope 1 / scope 3 : la donnée #{c.id} ({c.categorie}) porte sur le "
                    "même site et la même période. Déclarer l'exclusion du volume auto-consommé "
                    f"(exclusions: [{{'cle_origine': '{c.cle_origine}', 'quantite': …}}])."))
        controles.append("contrôle scope 1 / scope 3 cat. 11")
    return controles


def enregistrer_activite(session: Session, d: dict, auteur: str) -> tuple[DonneeActivite, list[str]]:
    try:
        Quantite(d["quantite"], d["unite"], d.get("nature_quantite"))
    except ErreurDimensionnelle as e:
        raise HTTPException(422, str(e))
    controles = controler_double_comptage(session, d)
    a = DonneeActivite(**d, saisi_par=auteur)
    session.add(a)
    session.flush()
    return a, controles


def calculer(session: Session, a: DonneeActivite, f: FacteurEmission) -> CalculEmission:
    num, den = f.unite.split("/", 1)
    if unite(num).dimension != unite("kgCO2e").dimension:
        raise HTTPException(422, "Numérateur du facteur : masse CO2e attendue")
    try:
        q = Quantite(a.quantite, a.unite, a.nature_quantite)
        if f.nature_denominateur and a.nature_quantite and f.nature_denominateur != a.nature_quantite:
            raise HTTPException(422, (f"Nature incompatible : activité {a.nature_quantite}, facteur exprimé par "
                                      f"{den} {f.nature_denominateur} ; une conversion explicite est nécessaire"))
        qd = q.vers(den)
    except ErreurDimensionnelle as e:
        raise HTTPException(422, f"Unités incompatibles : {e}")
    except Exception as e:  # ConversionInterdite
        if isinstance(e, HTTPException):
            raise
        raise HTTPException(422, f"Conversion refusée : {e}")
    part = a.part_consolidee_pct / 100
    excl = sum(float(x.get("quantite", 0)) for x in (a.exclusions or []))
    base = qd.valeur - Quantite(excl, a.unite, a.nature_quantite).vers(den).valeur if excl else qd.valeur
    kg = base * f.valeur * part * unite(num).facteur
    incert = (f.incertitude_pct ** 2 + (5.0 if a.nature == "estimee" else 1.0) ** 2) ** 0.5
    existant = session.scalar(select(CalculEmission).where(CalculEmission.donnee_activite_id == a.id))
    if existant:
        session.delete(existant)
        session.flush()
    c = CalculEmission(donnee_activite_id=a.id, facteur_id=f.id, emission_kgco2e=round(kg, 3),
                       incertitude_pct=round(incert, 2), nature="estimee" if a.nature == "estimee" else "calculee",
                       methode=f"({a.quantite:g} {a.unite} − exclusions {excl:g}) → {den} × {f.valeur} {f.unite} × "
                               f"part consolidée {a.part_consolidee_pct:g} %",
                       hypotheses=[{"facteur": f.code, "source": f.source, "annee": f.annee_reference,
                                    "geographie": f.geographie, "perimetre_facteur": f.perimetre},
                                   {"incertitude": "combinaison quadratique facteur ⊕ donnée d'activité "
                                                   "(1 % mesurée, 5 % estimée)"}])
    session.add(c)
    session.flush()
    return c


def inventaire(session: Session, annee: int, sites: set[int] | None) -> dict:
    debut, fin = datetime(annee, 1, 1, tzinfo=timezone.utc), datetime(annee + 1, 1, 1, tzinfo=timezone.utc)
    lignes, totaux = [], {1: 0.0, 2: 0.0, 3: 0.0}
    var = {1: 0.0, 2: 0.0, 3: 0.0}
    for a, c, f in session.execute(select(DonneeActivite, CalculEmission, FacteurEmission)
                                   .join(CalculEmission, CalculEmission.donnee_activite_id == DonneeActivite.id)
                                   .join(FacteurEmission, CalculEmission.facteur_id == FacteurEmission.id)
                                   .where(DonneeActivite.periode_debut >= debut, DonneeActivite.periode_debut < fin)).all():
        if sites is not None and a.site_id not in sites:
            continue
        totaux[a.scope] += c.emission_kgco2e
        var[a.scope] += (c.emission_kgco2e * c.incertitude_pct / 100) ** 2
        lignes.append({"activite": en_dict(a), "calcul": en_dict(c), "facteur": en_dict(f)})
    evitees = [en_dict(e) for e in session.scalars(select(EmissionEvitee))
               if sites is None or e.site_id in sites]
    return {"annee": annee, "unite": "tCO2e",
            "totaux_par_scope": {f"scope_{k}": round(v / 1000, 3) for k, v in totaux.items()},
            "incertitude_par_scope_tco2e": {f"scope_{k}": round(v ** 0.5 / 1000, 3) for k, v in var.items()},
            "total_scopes_1_2": round((totaux[1] + totaux[2]) / 1000, 3),
            "par_nature": _par_nature(lignes), "lignes": lignes,
            "emissions_evitees_registre_separe": evitees,
            "regle_evitees": "Les émissions évitées sont publiées séparément et ne sont jamais soustraites.",
            "statuts_validation": sorted({l["activite"]["statut_validation"] for l in lignes}),
            "mention": MENTION}


def _par_nature(lignes):
    res: dict[str, float] = {}
    for l in lignes:
        res[l["calcul"]["nature"]] = res.get(l["calcul"]["nature"], 0) + l["calcul"]["emission_kgco2e"] / 1000
    return {k: round(v, 3) for k, v in res.items()}
