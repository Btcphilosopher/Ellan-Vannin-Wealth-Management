"""Registre environnemental : données d'activité, facteurs sourcés, calculs,
émissions évitées (registre séparé, jamais soustrait) et validation."""
from __future__ import annotations

from sqlalchemy import Float, ForeignKey, Integer, String, Text, UniqueConstraint
from sqlalchemy.orm import Mapped, mapped_column

from ...db import Base, HorodatageUTC, JSONType, maintenant


class FacteurEmission(Base):
    __tablename__ = "facteur_emission"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    code: Mapped[str] = mapped_column(String(60), unique=True)
    libelle: Mapped[str] = mapped_column(String(240))
    valeur: Mapped[float] = mapped_column(Float)
    unite: Mapped[str] = mapped_column(String(30))  # ex. kgCO2e/kWh, kgCO2e/L
    nature_denominateur: Mapped[str | None] = mapped_column(String(40), nullable=True)
    source: Mapped[str] = mapped_column(Text)
    annee_reference: Mapped[int] = mapped_column(Integer)
    geographie: Mapped[str] = mapped_column(String(60))
    incertitude_pct: Mapped[float] = mapped_column(Float)
    perimetre: Mapped[str] = mapped_column(String(80))  # ex. combustion seule, amont inclus
    statut: Mapped[str] = mapped_column(String(20), default="actif")


class DonneeActivite(Base):
    __tablename__ = "donnee_activite"
    __table_args__ = (UniqueConstraint("cle_origine", name="uq_donnee_activite_origine"),)
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    entite_id: Mapped[int] = mapped_column(ForeignKey("entite.id"))
    site_id: Mapped[int | None] = mapped_column(ForeignKey("site.id"), nullable=True)
    actif_id: Mapped[int | None] = mapped_column(ForeignKey("actif.id"), nullable=True)
    categorie: Mapped[str] = mapped_column(String(60))
    scope: Mapped[int] = mapped_column(Integer)
    categorie_scope3: Mapped[int | None] = mapped_column(Integer, nullable=True)
    quantite: Mapped[float] = mapped_column(Float)
    unite: Mapped[str] = mapped_column(String(20))
    nature_quantite: Mapped[str | None] = mapped_column(String(40), nullable=True)
    periode_debut = mapped_column(HorodatageUTC)
    periode_fin = mapped_column(HorodatageUTC)
    source_type: Mapped[str] = mapped_column(String(30))  # compteur | facture | releve | estimation
    source_reference: Mapped[str] = mapped_column(String(200))
    cle_origine: Mapped[str] = mapped_column(String(200))
    nature: Mapped[str] = mapped_column(String(20))  # mesuree | calculee | estimee
    perimetre_organisationnel: Mapped[str] = mapped_column(String(40), default="controle_operationnel")
    part_consolidee_pct: Mapped[float] = mapped_column(Float, default=100)
    exclusions = mapped_column(JSONType, default=list)
    statut_validation: Mapped[str] = mapped_column(String(20), default="brouillon")
    valide_par: Mapped[str | None] = mapped_column(String(80), nullable=True)
    saisi_par: Mapped[str] = mapped_column(String(80))
    saisi_le = mapped_column(HorodatageUTC, default=maintenant)


class CalculEmission(Base):
    __tablename__ = "calcul_emission"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    donnee_activite_id: Mapped[int] = mapped_column(ForeignKey("donnee_activite.id"), unique=True)
    facteur_id: Mapped[int] = mapped_column(ForeignKey("facteur_emission.id"))
    emission_kgco2e: Mapped[float] = mapped_column(Float)
    incertitude_pct: Mapped[float] = mapped_column(Float)
    nature: Mapped[str] = mapped_column(String(20))  # mesuree | calculee | estimee
    methode: Mapped[str] = mapped_column(Text)
    hypotheses = mapped_column(JSONType, default=list)
    version_methode: Mapped[str] = mapped_column(String(20), default="1.0")
    calcule_le = mapped_column(HorodatageUTC, default=maintenant)


class EmissionEvitee(Base):
    """Registre séparé : jamais déduit des émissions de l'inventaire."""

    __tablename__ = "emission_evitee"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    site_id: Mapped[int] = mapped_column(ForeignKey("site.id"))
    libelle: Mapped[str] = mapped_column(String(240))
    quantite_activite: Mapped[float] = mapped_column(Float)
    unite: Mapped[str] = mapped_column(String(20))
    scenario_reference: Mapped[str] = mapped_column(Text)
    facteur_reference_id: Mapped[int] = mapped_column(ForeignKey("facteur_emission.id"))
    estimation_kgco2e: Mapped[float] = mapped_column(Float)
    methode: Mapped[str] = mapped_column(Text)
    periode_debut = mapped_column(HorodatageUTC)
    periode_fin = mapped_column(HorodatageUTC)
    mention: Mapped[str] = mapped_column(Text)
