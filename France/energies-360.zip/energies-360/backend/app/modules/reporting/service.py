"""Rapports traçables : contenu JSON + rendu HTML + manifeste (paramètres,
sources, méthodes, empreintes SHA-256, signature HMAC), stockés dans le
stockage objet protégé."""
from __future__ import annotations

import hashlib
import hmac
import html
import json
from datetime import datetime

from sqlalchemy import func, select
from sqlalchemy.orm import Session

from ... import __version__
from ...config import parametres
from ...core.services import en_dict, json_stable, sha256, stockage
from ...db import maintenant
from ..finance import service as finance
from ..maintenance.models import OrdreTravail
from ..maintenance.service import detail_ordre
from ..mesures.energie import bilan_site
from ..mesures.models import Alerte, LotIngestion, Observation
from ..patrimoine.models import Actif, PointMesure, Site
from ..production import service as production
from .models import Rapport

AVERTISSEMENT = ("Prototype indépendant Énergies 360 — données exclusivement synthétiques. Sans affiliation ni accès "
                 "aux systèmes d'un quelconque groupe énergétique. Document non contractuel, non réglementaire, "
                 "non audité.")


def _sources_mesures(session: Session, site_id: int, debut: datetime, fin: datetime) -> dict:
    pts = [p.id for p in session.scalars(select(PointMesure).join(Actif, PointMesure.actif_id == Actif.id)
                                         .where(Actif.site_id == site_id))]
    q = select(func.count(Observation.id), func.min(Observation.id), func.max(Observation.id)).where(
        Observation.point_mesure_id.in_(pts), Observation.observe_le >= debut, Observation.observe_le < fin)
    n, mi, ma = session.execute(q).one()
    lots = session.execute(select(LotIngestion.id, LotIngestion.sha256_archive, LotIngestion.cle_archive)
                           .where(LotIngestion.id.in_(select(Observation.lot_id).where(
                               Observation.point_mesure_id.in_(pts), Observation.observe_le >= debut,
                               Observation.observe_le < fin).distinct()))).all()
    return {"observations": {"nombre": n, "id_min": mi, "id_max": ma},
            "lots_ingestion": [{"id": l[0], "sha256_archive_brute": l[1], "cle_archive": l[2]} for l in lots]}


def contenu_parcours_solaire(session: Session, site_id: int, debut: datetime, fin: datetime, indice: str) -> dict:
    site = session.get(Site, site_id)
    ots = session.scalars(select(OrdreTravail).where(OrdreTravail.site_id == site_id)).all()
    alertes = session.scalars(select(Alerte).where(Alerte.site_id == site_id, Alerte.debut >= debut,
                                                   Alerte.debut < fin)).all()
    synth = production.synthese(session, site_id, debut, fin)
    synth.pop("meteo", None)
    return {
        "site": en_dict(site),
        "periode": {"debut": debut.isoformat(), "fin": fin.isoformat(), "fuseau_stockage": "UTC",
                    "fuseau_site": site.fuseau_horaire},
        "bilan_energetique": bilan_site(session, site_id, debut, fin),
        "production": synth,
        "qualite_donnees": [{"id": a.id, "type": a.type, "gravite": a.gravite, "titre": a.titre, "message": a.message,
                             "regle": a.regle, "debut": a.debut.isoformat(), "statut": a.statut} for a in alertes],
        "maintenance": [detail_ordre(session, o) for o in ots],
        "economie": {"cout_unitaire_maintenance": finance.cout_unitaire_maintenance(session, site_id, debut, fin),
                     "revenus": finance.revenus_separes(session, site_id, debut, fin, indice)},
        "sources": _sources_mesures(session, site_id, debut, fin),
    }


def _rendu_html(titre: str, contenu: dict, manifeste: dict) -> str:
    def bloc(nom, val):
        return (f"<section><h2>{html.escape(nom)}</h2><pre>"
                f"{html.escape(json.dumps(val, ensure_ascii=False, indent=2, default=str))}</pre></section>")

    b = contenu.get("bilan_energetique", {})
    resume = ""
    if b.get("applicable"):
        lignes = "".join(f"<tr><td>{html.escape(k)}</td><td>{v['valeur'] if v['valeur'] is not None else 'indéterminé'}"
                         f"</td><td>kWh</td><td>{html.escape(v['statut'])}</td></tr>" for k, v in b["termes"].items())
        resume = (f"<table><tr><th>Terme</th><th>Valeur</th><th>Unité</th><th>Statut</th></tr>{lignes}"
                  f"<tr><td><b>Écart non mesuré</b></td><td>{b['ecart_kwh']}</td><td>kWh</td>"
                  f"<td>{html.escape(b['interpretation_ecart'])}</td></tr></table>")
    return (f"<!doctype html><html lang='fr'><head><meta charset='utf-8'><title>{html.escape(titre)}</title>"
            "<style>body{font-family:system-ui,sans-serif;margin:2rem;color:#0b1b3f}h1{color:#0b1b3f}"
            "h2{border-bottom:3px solid #e4002b;padding-bottom:.2rem}.av{background:#fff4e5;border-left:4px solid #f39200;"
            "padding:.6rem}pre{background:#f5f7fb;padding:1rem;overflow:auto;font-size:12px}table{border-collapse:collapse}"
            "td,th{border:1px solid #ccd;padding:.3rem .6rem}</style></head><body>"
            f"<h1>{html.escape(titre)}</h1><p class='av'>{html.escape(AVERTISSEMENT)}</p>{resume}"
            + "".join(bloc(k, v) for k, v in contenu.items()) + bloc("Manifeste de traçabilité", manifeste)
            + "</body></html>")


def generer(session: Session, type_: str, site_id: int, debut: datetime, fin: datetime, auteur: str,
            indice: str = "IDX_ELEC_SPOT_SIM") -> Rapport:
    if type_ != "parcours_solaire":
        raise ValueError("Type de rapport non pris en charge")
    contenu = contenu_parcours_solaire(session, site_id, debut, fin, indice)
    sections = {k: sha256(json_stable(v)) for k, v in contenu.items()}
    corps = json_stable(contenu)
    manifeste = {
        "application": "Énergies 360 (prototype)", "version": __version__, "type": type_,
        "parametres": {"site_id": site_id, "debut": debut.isoformat(), "fin": fin.isoformat(), "indice": indice},
        "genere_le": maintenant().isoformat(), "genere_par": auteur,
        "methodes": {"bilan": "mesures.energie.bilan_site v1", "disponibilite": "production.disponibilite v1",
                     "pertes": "production.pertes_estimees v1 (estimation)", "cout_unitaire": "finance v1"},
        "empreintes_sections_sha256": sections, "empreinte_contenu_sha256": sha256(corps),
        "avertissement": AVERTISSEMENT,
    }
    manifeste["signature_hmac_sha256"] = hmac.new(parametres().jwt_secret.encode(),
                                                  manifeste["empreinte_contenu_sha256"].encode(),
                                                  hashlib.sha256).hexdigest()
    doc = json_stable({"manifeste": manifeste, "contenu": contenu})
    titre = f"Rapport parcours solaire — {contenu['site']['nom']} — {debut:%d/%m/%Y} au {fin:%d/%m/%Y}"
    cle_j, h_j = stockage().deposer("rapports", f"{type_}.json", doc.encode())
    cle_h, h_h = stockage().deposer("rapports", f"{type_}.html", _rendu_html(titre, contenu, manifeste).encode())
    r = Rapport(type=type_, titre=titre, site_id=site_id, parametres=manifeste["parametres"], genere_par=auteur,
                genere_le=maintenant(), cle_json=cle_j, sha256_json=h_j, cle_html=cle_h, sha256_html=h_h,
                manifeste=manifeste)
    session.add(r)
    session.flush()
    return r


def verifier(session: Session, r: Rapport) -> dict:
    brut = stockage().lire(r.cle_json, r.sha256_json)
    doc = json.loads(brut)
    recalc = sha256(json_stable(doc["contenu"]))
    sig = hmac.new(parametres().jwt_secret.encode(), recalc.encode(), hashlib.sha256).hexdigest()
    return {"rapport_id": r.id, "empreinte_fichier_ok": True,
            "empreinte_contenu_ok": recalc == r.manifeste["empreinte_contenu_sha256"],
            "signature_ok": hmac.compare_digest(sig, r.manifeste["signature_hmac_sha256"])}
