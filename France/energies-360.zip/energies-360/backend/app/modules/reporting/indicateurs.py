"""Registre des indicateurs : chaque indicateur publie sa valeur, son unité,
sa nature, sa méthode de calcul et ses données sources (exploration)."""
from __future__ import annotations

from datetime import datetime
from typing import Callable

from fastapi import HTTPException
from sqlalchemy import func, select
from sqlalchemy.orm import Session

from ...core.securite import Principal
from ...core.services import en_dict
from ..environnement.service import inventaire
from ..finance import service as finance
from ..maintenance.models import OrdreTravail
from ..mesures.energie import bilan_site, energie_portefeuille
from ..mesures.models import Alerte
from ..mobilite.models import SessionRecharge
from ..mobilite.service import evaluer_connecteur
from ..patrimoine.models import Actif, Site
from ..production import service as production
from ..stocks.service import etat_stocks

REGISTRE: dict[str, dict] = {}


def indicateur(code: str, libelle: str, domaine: str, permission: str):
    def deco(fn: Callable):
        REGISTRE[code] = {"fn": fn, "libelle": libelle, "domaine": domaine, "permission": permission}
        return fn

    return deco


def _site(session, code) -> Site:
    s = session.scalar(select(Site).where(Site.code == code))
    if not s:
        raise HTTPException(404, f"Site {code} absent (lancer l'initialisation de démonstration)")
    return s


@indicateur("energie_pv_produite", "Production PV mesurée", "production", "production:lire")
def _pv(session, p, debut, fin, instant):
    s = _site(session, "SITE-PV-GAR")
    b = bilan_site(session, s.id, debut, fin)
    t = b["termes"]["production_pv"]
    return {"valeur": None if t["valeur"] is None else round(t["valeur"] / 1000, 3), "unite": "MWh",
            "nature": "mesure", "site_id": s.id, "methode": t["methode"] + " — compteur principal production_pv",
            "statut": t["statut"], "avertissements": t["avertissements"],
            "sources": {"terme": t, "controle": b["controle"]}}


@indicateur("energie_injectee_portefeuille", "Énergie injectée au réseau (portefeuille)", "production", "mesures:lire")
def _inj(session, p, debut, fin, instant):
    r = energie_portefeuille(session, "injection_reseau", debut, fin, p.sites_autorises(session, "mesures:lire"))
    return {"valeur": round(r["valeur"] / 1000, 3), "unite": "MWh", "nature": "mesure", "methode": r["methode"],
            "statut": r["statut"], "avertissements": [], "sources": r}


@indicateur("ecart_bilan_pv", "Écart de bilan électrique (pertes et auxiliaires non mesurés)", "production", "mesures:lire")
def _ecart(session, p, debut, fin, instant):
    s = _site(session, "SITE-PV-GAR")
    b = bilan_site(session, s.id, debut, fin)
    return {"valeur": None if b["ecart_kwh"] is None else round(b["ecart_kwh"] / 1000, 3), "unite": "MWh",
            "nature": "calcul", "site_id": s.id, "methode": b["equation"], "statut": b["statut"],
            "avertissements": [b["interpretation_ecart"]], "sources": b}


@indicateur("disponibilite_pv", "Disponibilité technique PV", "production", "production:lire")
def _dispo(session, p, debut, fin, instant):
    s = _site(session, "SITE-PV-GAR")
    d = production.disponibilite(session, s.id, debut, fin)
    return {"valeur": d["valeur_pct"], "unite": "%", "nature": "calcul", "site_id": s.id, "methode": d["methode"],
            "statut": "complet" if not d["part_indeterminee_pct"] else "avec_reserves",
            "avertissements": [f"Part indéterminée : {d['part_indeterminee_pct']} %"] if d["part_indeterminee_pct"] else [],
            "sources": d}


@indicateur("alertes_ouvertes", "Alertes de qualité et d'exploitation ouvertes", "production", "mesures:lire")
def _alertes(session, p, debut, fin, instant):
    sites = p.sites_autorises(session, "mesures:lire")
    al = [a for a in session.scalars(select(Alerte).where(Alerte.statut != "close"))
          if sites is None or a.site_id in sites]
    return {"valeur": len(al), "unite": "alertes", "nature": "comptage",
            "methode": "nombre d'alertes au statut ouverte ou prise_en_charge, sur les sites autorisés",
            "statut": "complet", "avertissements": [],
            "sources": {"alertes": [{"id": a.id, "type": a.type, "gravite": a.gravite, "titre": a.titre,
                                     "message": a.message, "regle": a.regle} for a in al]}}


@indicateur("ordres_travail_ouverts", "Ordres de travail non clôturés", "maintenance", "maintenance:lire")
def _ot(session, p, debut, fin, instant):
    sites = p.sites_autorises(session, "maintenance:lire")
    ots = [o for o in session.scalars(select(OrdreTravail).where(OrdreTravail.etat.notin_(["cloture", "annule"])))
           if sites is None or o.site_id in sites]
    return {"valeur": len(ots), "unite": "OT", "nature": "comptage", "methode": "OT à un état autre que clôturé / annulé",
            "statut": "complet", "avertissements": [],
            "sources": {"ordres": [{"numero": o.numero, "etat": o.etat, "titre": o.titre} for o in ots]}}


@indicateur("stock_disponible_lubrifiant", "Lubrifiant 5W-30 disponible au dépôt", "logistique", "stocks:lire")
def _stock(session, p, debut, fin, instant):
    s = _site(session, "SITE-DEP-SAU")
    lignes = [l for l in etat_stocks(session, {s.id}) if l["produit"] == "LUB-5W30-208"]
    return {"valeur": sum(l["disponible"] for l in lignes), "unite": "fût (208 L)", "nature": "calcul",
            "site_id": s.id, "methode": "Σ (physique − réservé − quarantaine) des soldes du produit",
            "statut": "complet", "avertissements": [], "sources": {"soldes": lignes}}


@indicateur("sessions_recharge", "Énergie délivrée en recharge", "mobilite", "mobilite:lire")
def _rech(session, p, debut, fin, instant):
    ss = session.scalars(select(SessionRecharge).where(SessionRecharge.debut >= debut,
                                                       SessionRecharge.debut < fin)).all()
    e = sum(s.energie_kwh or 0 for s in ss)
    inc = [s.id for s in ss if s.statut != "terminee"]
    return {"valeur": round(e, 1), "unite": "kWh", "nature": "mesure",
            "methode": "Σ (meterStop − meterStart) des sessions terminées", "statut": "complet" if not inc else "avec_reserves",
            "avertissements": [f"{len(inc)} session(s) incomplète(s) ou en cours exclue(s)"] if inc else [],
            "sources": {"sessions": [{"id": s.id, "transaction": s.transaction_id, "energie_kwh": s.energie_kwh,
                                      "statut": s.statut, "montant_ttc": s.montant_ttc} for s in ss]}}


@indicateur("connecteurs_disponibles", "Connecteurs de recharge évalués disponibles", "mobilite", "mobilite:lire")
def _conn(session, p, debut, fin, instant):
    cs = session.scalars(select(Actif).where(Actif.type_actif == "connecteur")).all()
    ev = [evaluer_connecteur(session, c, instant) for c in cs]
    n = sum(1 for e in ev if e["disponibilite_evaluee"] == "disponible")
    return {"valeur": n, "unite": f"sur {len(ev)} connecteurs", "nature": "evaluation",
            "methode": ev[0]["regle"] if ev else "", "statut": "complet",
            "avertissements": ["Un connecteur joignable n'est pas automatiquement disponible."], "sources": {"connecteurs": ev}}


@indicateur("emissions_scopes_1_2", "Émissions scopes 1 + 2 (pilotage interne)", "environnement", "environnement:lire")
def _env(session, p, debut, fin, instant):
    inv = inventaire(session, debut.year, p.sites_autorises(session, "environnement:lire"))
    return {"valeur": inv["total_scopes_1_2"], "unite": "tCO2e", "nature": "calcul",
            "methode": "Σ activité × facteur sourcé × part consolidée ; incertitude combinée",
            "statut": ",".join(inv["statuts_validation"]) or "vide", "avertissements": [inv["mention"]], "sources": inv}


@indicateur("cout_maintenance_unitaire", "Coût de maintenance rapporté à la production PV", "finance", "finance:lire")
def _cu(session, p, debut, fin, instant):
    s = _site(session, "SITE-PV-GAR")
    c = finance.cout_unitaire_maintenance(session, s.id, debut, fin)
    return {"valeur": c["valeur"], "unite": c["unite"], "nature": "calcul", "site_id": s.id,
            "methode": "coût maintenance / production mesurée", "statut": c["denominateur"]["statut"] or "indetermine",
            "avertissements": [c["limite"]], "sources": c}


@indicateur("revenu_estime_pv", "Revenu estimé de l'énergie injectée", "finance", "finance:lire")
def _rev(session, p, debut, fin, instant):
    s = _site(session, "SITE-PV-GAR")
    r = finance.revenus_separes(session, s.id, debut, fin, "IDX_ELEC_SPOT_SIM")
    return {"valeur": r["revenu_estime"]["valeur"], "unite": "EUR", "nature": "estimation", "site_id": s.id,
            "methode": r["revenu_estime"]["methode"], "statut": "estimation",
            "avertissements": ["Estimation sur indice simulé ; distincte du facturé, de l'encaissé et du résultat."],
            "sources": r}


def calculer(session: Session, principal: Principal, code: str, debut: datetime, fin: datetime,
             instant: datetime) -> dict:
    if code not in REGISTRE:
        raise HTTPException(404, "Indicateur inconnu")
    e = REGISTRE[code]
    if e["permission"] not in principal.permissions():
        raise HTTPException(403, f"Permission « {e['permission']} » requise")
    r = e["fn"](session, principal, debut, fin, instant)
    return {"code": code, "libelle": e["libelle"], "domaine": e["domaine"],
            "periode": {"debut": debut.isoformat(), "fin": fin.isoformat()}, "instant_reference": instant.isoformat(),
            **r}


def vue_ensemble(session: Session, principal: Principal, debut, fin, instant) -> list[dict]:
    res = []
    perms = principal.permissions()
    for code, e in REGISTRE.items():
        if e["permission"] not in perms:
            continue
        try:
            r = calculer(session, principal, code, debut, fin, instant)
            r.pop("sources", None)
            res.append(r)
        except HTTPException as ex:
            res.append({"code": code, "libelle": e["libelle"], "domaine": e["domaine"], "valeur": None,
                        "statut": "indisponible", "avertissements": [ex.detail]})
    return res
