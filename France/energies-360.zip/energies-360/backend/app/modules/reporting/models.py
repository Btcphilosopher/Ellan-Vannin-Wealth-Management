from __future__ import annotations

from sqlalchemy import ForeignKey, Integer, String
from sqlalchemy.orm import Mapped, mapped_column

from ...db import Base, HorodatageUTC, JSONType, maintenant


class Rapport(Base):
    __tablename__ = "rapport"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    type: Mapped[str] = mapped_column(String(60))
    titre: Mapped[str] = mapped_column(String(240))
    site_id: Mapped[int | None] = mapped_column(ForeignKey("site.id"), nullable=True)
    parametres = mapped_column(JSONType)
    genere_par: Mapped[str] = mapped_column(String(80))
    genere_le = mapped_column(HorodatageUTC, default=maintenant)
    cle_json: Mapped[str] = mapped_column(String(300))
    sha256_json: Mapped[str] = mapped_column(String(64))
    cle_html: Mapped[str] = mapped_column(String(300))
    sha256_html: Mapped[str] = mapped_column(String(64))
    manifeste = mapped_column(JSONType)
