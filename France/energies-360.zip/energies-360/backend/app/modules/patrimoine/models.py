"""Référentiel des actifs : groupe → entités → sites → installations → équipements
→ points de mesure, avec responsables, contrats de maintenance, documents et
historique versionné."""
from __future__ import annotations

from sqlalchemy import Boolean, Float, ForeignKey, Integer, String, Text, UniqueConstraint
from sqlalchemy.orm import Mapped, mapped_column

from ...db import Base, HorodatageUTC, JSONType, maintenant


class Groupe(Base):
    __tablename__ = "groupe"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    code: Mapped[str] = mapped_column(String(40), unique=True)
    nom: Mapped[str] = mapped_column(String(200))


class Entite(Base):
    __tablename__ = "entite"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    groupe_id: Mapped[int] = mapped_column(ForeignKey("groupe.id"))
    code: Mapped[str] = mapped_column(String(40), unique=True)
    nom: Mapped[str] = mapped_column(String(200))
    domaine: Mapped[str] = mapped_column(String(40))
    responsabilites: Mapped[str | None] = mapped_column(Text, nullable=True)


class Site(Base):
    __tablename__ = "site"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    entite_id: Mapped[int] = mapped_column(ForeignKey("entite.id"), index=True)
    code: Mapped[str] = mapped_column(String(40), unique=True)
    nom: Mapped[str] = mapped_column(String(200))
    domaine: Mapped[str] = mapped_column(String(40))  # renouvelable, stockage, depot, distribution, mobilite, industrie, amont
    latitude: Mapped[float] = mapped_column(Float)
    longitude: Mapped[float] = mapped_column(Float)
    commune: Mapped[str | None] = mapped_column(String(120), nullable=True)
    fuseau_horaire: Mapped[str] = mapped_column(String(40), default="Europe/Paris")
    etat: Mapped[str] = mapped_column(String(30), default="en_service")
    date_effet_debut = mapped_column(HorodatageUTC)
    date_effet_fin = mapped_column(HorodatageUTC, nullable=True)
    provenance: Mapped[str] = mapped_column(String(200), default="données synthétiques")
    version: Mapped[int] = mapped_column(Integer, default=1)


class Actif(Base):
    """Installation ou équipement (hiérarchie par ``parent_id``)."""

    __tablename__ = "actif"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    site_id: Mapped[int] = mapped_column(ForeignKey("site.id"), index=True)
    parent_id: Mapped[int | None] = mapped_column(ForeignKey("actif.id"), nullable=True)
    code: Mapped[str] = mapped_column(String(60), unique=True)
    nom: Mapped[str] = mapped_column(String(200))
    niveau: Mapped[str] = mapped_column(String(20))  # installation | equipement
    type_actif: Mapped[str] = mapped_column(String(40))
    etat: Mapped[str] = mapped_column(String(30), default="en_service")
    fabricant: Mapped[str | None] = mapped_column(String(120), nullable=True)
    modele: Mapped[str | None] = mapped_column(String(120), nullable=True)
    numero_serie: Mapped[str | None] = mapped_column(String(120), nullable=True)
    mise_en_service = mapped_column(HorodatageUTC, nullable=True)
    latitude: Mapped[float | None] = mapped_column(Float, nullable=True)
    longitude: Mapped[float | None] = mapped_column(Float, nullable=True)
    date_effet_debut = mapped_column(HorodatageUTC)
    date_effet_fin = mapped_column(HorodatageUTC, nullable=True)
    provenance: Mapped[str] = mapped_column(String(200), default="données synthétiques")
    attributs = mapped_column(JSONType, default=dict)
    version: Mapped[int] = mapped_column(Integer, default=1)


class Capacite(Base):
    """Capacité datée : *installée* (plaque) ou *disponible* (après restrictions)."""

    __tablename__ = "capacite"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    actif_id: Mapped[int] = mapped_column(ForeignKey("actif.id"), index=True)
    nature: Mapped[str] = mapped_column(String(20))  # installee | disponible
    grandeur: Mapped[str] = mapped_column(String(40))  # puissance_ac, puissance_dc, energie, volume...
    valeur: Mapped[float] = mapped_column(Float)
    unite: Mapped[str] = mapped_column(String(20))
    nature_grandeur: Mapped[str | None] = mapped_column(String(40), nullable=True)
    date_effet_debut = mapped_column(HorodatageUTC)
    date_effet_fin = mapped_column(HorodatageUTC, nullable=True)
    provenance: Mapped[str] = mapped_column(String(200))
    motif: Mapped[str | None] = mapped_column(Text, nullable=True)


class PointMesure(Base):
    __tablename__ = "point_mesure"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    actif_id: Mapped[int] = mapped_column(ForeignKey("actif.id"), index=True)
    code: Mapped[str] = mapped_column(String(80), unique=True)
    grandeur: Mapped[str] = mapped_column(String(40))  # puissance, energie, irradiance, temperature, soc, etat...
    unite: Mapped[str] = mapped_column(String(20))
    nature_grandeur: Mapped[str | None] = mapped_column(String(40), nullable=True)  # electrique, observe...
    type_signal: Mapped[str] = mapped_column(String(20))  # instantane | cumul | etat
    role_comptage: Mapped[str] = mapped_column(String(20), default="information")  # principal | controle | sous_comptage | information
    perimetre_comptage: Mapped[str | None] = mapped_column(String(40), nullable=True)
    pas_attendu_s: Mapped[int] = mapped_column(Integer, default=600)
    seuil_peremption_s: Mapped[int] = mapped_column(Integer, default=1800)
    borne_min: Mapped[float | None] = mapped_column(Float, nullable=True)
    borne_max: Mapped[float | None] = mapped_column(Float, nullable=True)
    source_defaut: Mapped[str] = mapped_column(String(60), default="simulateur_scada")
    actif_flag: Mapped[bool] = mapped_column(Boolean, default=True)


class Tiers(Base):
    __tablename__ = "tiers"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    code: Mapped[str] = mapped_column(String(40), unique=True)
    nom: Mapped[str] = mapped_column(String(200))
    roles = mapped_column(JSONType, default=list)  # fournisseur, client, prestataire, transporteur
    pays: Mapped[str] = mapped_column(String(2), default="FR")
    fictif: Mapped[bool] = mapped_column(Boolean, default=True)


class Produit(Base):
    __tablename__ = "produit"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    code: Mapped[str] = mapped_column(String(40), unique=True)
    nom: Mapped[str] = mapped_column(String(200))
    categorie: Mapped[str] = mapped_column(String(40))
    unite_gestion: Mapped[str] = mapped_column(String(20))
    nature_unite: Mapped[str | None] = mapped_column(String(40), nullable=True)
    conditionnement: Mapped[str | None] = mapped_column(String(120), nullable=True)
    groupe_compatibilite: Mapped[str] = mapped_column(String(40))
    proprietes = mapped_column(JSONType, default=dict)  # hypothèses sourcées (densité, PCI...)


class Responsable(Base):
    __tablename__ = "responsable"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    nom: Mapped[str] = mapped_column(String(160))
    fonction: Mapped[str] = mapped_column(String(160))
    responsabilite: Mapped[str] = mapped_column(String(40))  # exploitation, maintenance, hse, commercial, donnees
    utilisateur_id: Mapped[int | None] = mapped_column(ForeignKey("utilisateur.id"), nullable=True)
    site_id: Mapped[int | None] = mapped_column(ForeignKey("site.id"), nullable=True)
    actif_id: Mapped[int | None] = mapped_column(ForeignKey("actif.id"), nullable=True)
    date_debut = mapped_column(HorodatageUTC)
    date_fin = mapped_column(HorodatageUTC, nullable=True)


class ContratMaintenance(Base):
    __tablename__ = "contrat_maintenance"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    numero: Mapped[str] = mapped_column(String(40), unique=True)
    prestataire_id: Mapped[int] = mapped_column(ForeignKey("tiers.id"))
    site_id: Mapped[int] = mapped_column(ForeignKey("site.id"))
    perimetre: Mapped[str] = mapped_column(Text)
    delai_intervention_h: Mapped[int] = mapped_column(Integer)
    taux_horaire: Mapped[float] = mapped_column(Float)
    devise: Mapped[str] = mapped_column(String(3), default="EUR")
    date_debut = mapped_column(HorodatageUTC)
    date_fin = mapped_column(HorodatageUTC)


class Document(Base):
    __tablename__ = "document"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    titre: Mapped[str] = mapped_column(String(240))
    type_document: Mapped[str] = mapped_column(String(60))
    objet_type: Mapped[str | None] = mapped_column(String(40), nullable=True)
    objet_id: Mapped[int | None] = mapped_column(Integer, nullable=True)
    site_id: Mapped[int | None] = mapped_column(ForeignKey("site.id"), nullable=True)
    cle_stockage: Mapped[str] = mapped_column(String(300))
    sha256: Mapped[str] = mapped_column(String(64))
    taille_octets: Mapped[int] = mapped_column(Integer)
    type_mime: Mapped[str] = mapped_column(String(100))
    confidentialite: Mapped[str] = mapped_column(String(20), default="interne")
    texte_indexable: Mapped[str | None] = mapped_column(Text, nullable=True)
    depose_par: Mapped[str] = mapped_column(String(80))
    depose_le = mapped_column(HorodatageUTC, default=maintenant)


class VersionObjet(Base):
    """Historique : instantané complet à chaque modification du référentiel."""

    __tablename__ = "version_objet"
    __table_args__ = (UniqueConstraint("objet_type", "objet_id", "version"),)
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    objet_type: Mapped[str] = mapped_column(String(40))
    objet_id: Mapped[int] = mapped_column(Integer, index=True)
    version: Mapped[int] = mapped_column(Integer)
    donnees = mapped_column(JSONType)
    valide_de = mapped_column(HorodatageUTC)
    valide_a = mapped_column(HorodatageUTC, nullable=True)
    enregistre_le = mapped_column(HorodatageUTC, default=maintenant)
    enregistre_par: Mapped[str] = mapped_column(String(80))
    motif: Mapped[str | None] = mapped_column(Text, nullable=True)


class Etude(Base):
    """Étude approuvée : fige les versions du référentiel utilisées."""

    __tablename__ = "etude"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    titre: Mapped[str] = mapped_column(String(240))
    objet: Mapped[str] = mapped_column(Text)
    statut: Mapped[str] = mapped_column(String(20), default="brouillon")
    references = mapped_column(JSONType, default=list)  # [{objet_type, objet_id, version}]
    instantane = mapped_column(JSONType, nullable=True)
    empreinte: Mapped[str | None] = mapped_column(String(64), nullable=True)
    approuvee_par: Mapped[str | None] = mapped_column(String(80), nullable=True)
    approuvee_le = mapped_column(HorodatageUTC, nullable=True)
    cree_par: Mapped[str] = mapped_column(String(80))
