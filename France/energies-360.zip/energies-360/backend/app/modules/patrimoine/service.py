from __future__ import annotations

import math
from datetime import datetime

from fastapi import HTTPException
from sqlalchemy import and_, or_, select, text
from sqlalchemy.orm import Session

from ...core.services import en_dict, json_stable, sha256
from ...db import maintenant
from ...unites.dimensions import ErreurDimensionnelle, unite
from .models import Actif, Capacite, Etude, PointMesure, Site, VersionObjet

TYPES_VERSIONNES = {"site": Site, "actif": Actif, "point_mesure": PointMesure, "capacite": Capacite}


def enregistrer_version(session: Session, objet_type: str, obj, auteur: str, motif: str | None = None,
                        valide_de: datetime | None = None) -> VersionObjet:
    valide_de = valide_de or maintenant()
    precedente = session.scalar(select(VersionObjet).where(
        VersionObjet.objet_type == objet_type, VersionObjet.objet_id == obj.id,
        VersionObjet.valide_a.is_(None)))
    numero = 1
    if precedente:
        precedente.valide_a = valide_de
        numero = precedente.version + 1
    if hasattr(obj, "version"):
        obj.version = numero
    v = VersionObjet(objet_type=objet_type, objet_id=obj.id, version=numero, donnees=en_dict(obj),
                     valide_de=valide_de, enregistre_par=auteur, motif=motif, enregistre_le=maintenant())
    session.add(v)
    session.flush()
    return v


def creer(session: Session, classe, auteur: str, motif: str = "création", **champs):
    objet_type = next(k for k, v in TYPES_VERSIONNES.items() if v is classe)
    if classe is PointMesure:
        _valider_point_mesure(session, champs)
    if classe is Capacite:
        unite(champs["unite"])  # validation de l'unité
    obj = classe(**champs)
    session.add(obj)
    session.flush()
    enregistrer_version(session, objet_type, obj, auteur, motif, champs.get("date_effet_debut"))
    return obj


def modifier(session: Session, classe, objet_id: int, auteur: str, motif: str, **champs):
    objet_type = next(k for k, v in TYPES_VERSIONNES.items() if v is classe)
    obj = session.get(classe, objet_id)
    if obj is None:
        raise HTTPException(404, f"{objet_type} introuvable")
    interdits = {"id", "version"}
    for k, v in champs.items():
        if k in interdits or not hasattr(obj, k):
            raise HTTPException(422, f"Champ non modifiable : {k}")
        setattr(obj, k, v)
    session.flush()
    return obj, enregistrer_version(session, objet_type, obj, auteur, motif)


def _valider_point_mesure(session: Session, champs: dict):
    try:
        unite(champs["unite"])
    except ErreurDimensionnelle as e:
        raise HTTPException(422, str(e))
    if champs.get("role_comptage") == "principal":
        actif = session.get(Actif, champs["actif_id"])
        existant = session.scalar(
            select(PointMesure).join(Actif, PointMesure.actif_id == Actif.id).where(
                Actif.site_id == actif.site_id, PointMesure.role_comptage == "principal",
                PointMesure.perimetre_comptage == champs.get("perimetre_comptage"),
                PointMesure.grandeur == champs["grandeur"]))
        if existant:
            raise HTTPException(409, (
                f"Un compteur principal existe déjà pour le périmètre « {champs.get('perimetre_comptage')} » "
                f"sur ce site ({existant.code}) : un second compteur principal créerait un double comptage. "
                "Déclarer ce point en « controle » ou « sous_comptage »."))


def capacites_a_date(session: Session, actif_id: int, instant: datetime) -> list[Capacite]:
    return list(session.scalars(select(Capacite).where(
        Capacite.actif_id == actif_id, Capacite.date_effet_debut <= instant,
        or_(Capacite.date_effet_fin.is_(None), Capacite.date_effet_fin > instant))))


def capacite(session: Session, actif_id: int, nature: str, grandeur: str, instant: datetime) -> Capacite | None:
    for c in capacites_a_date(session, actif_id, instant):
        if c.nature == nature and c.grandeur == grandeur:
            return c
    return None


def version_a_date(session: Session, objet_type: str, objet_id: int, instant: datetime) -> VersionObjet | None:
    return session.scalar(select(VersionObjet).where(
        VersionObjet.objet_type == objet_type, VersionObjet.objet_id == objet_id,
        VersionObjet.valide_de <= instant,
        or_(VersionObjet.valide_a.is_(None), VersionObjet.valide_a > instant)).order_by(VersionObjet.version.desc()))


def approuver_etude(session: Session, etude: Etude, auteur: str) -> Etude:
    if etude.statut == "approuvee":
        raise HTTPException(409, "Étude déjà approuvée : son instantané est figé")
    refs, inst = [], []
    for r in etude.references:
        v = session.scalar(select(VersionObjet).where(
            VersionObjet.objet_type == r["objet_type"], VersionObjet.objet_id == r["objet_id"],
            VersionObjet.valide_a.is_(None)))
        if v is None:
            raise HTTPException(422, f"Aucune version pour {r}")
        refs.append({"objet_type": r["objet_type"], "objet_id": r["objet_id"], "version": v.version})
        inst.append({"objet_type": r["objet_type"], "objet_id": r["objet_id"], "version": v.version,
                     "donnees": v.donnees})
    etude.references = refs
    etude.instantane = inst
    etude.empreinte = sha256(json_stable(inst))
    etude.statut = "approuvee"
    etude.approuvee_par = auteur
    etude.approuvee_le = maintenant()
    session.flush()
    return etude


def comparer_etude(session: Session, etude: Etude) -> dict:
    """Compare l'instantané approuvé au référentiel courant, sans le réécrire."""
    integre = etude.empreinte == sha256(json_stable(etude.instantane or []))
    ecarts = []
    for item in etude.instantane or []:
        courante = session.scalar(select(VersionObjet).where(
            VersionObjet.objet_type == item["objet_type"], VersionObjet.objet_id == item["objet_id"],
            VersionObjet.valide_a.is_(None)))
        if courante and courante.version != item["version"]:
            diff = {k: {"etude": item["donnees"].get(k), "courant": courante.donnees.get(k)}
                    for k in courante.donnees if k not in ("version",)
                    and courante.donnees.get(k) != item["donnees"].get(k)}
            ecarts.append({"objet_type": item["objet_type"], "objet_id": item["objet_id"],
                           "version_etude": item["version"], "version_courante": courante.version,
                           "differences": diff})
    return {"etude_id": etude.id, "instantane_integre": integre, "empreinte": etude.empreinte,
            "ecarts_avec_referentiel_courant": ecarts,
            "note": "L'étude approuvée conserve les versions figées ; le référentiel courant n'est pas réinjecté."}


def distance_km(lat1, lon1, lat2, lon2) -> float:
    r = 6371.0088
    p1, p2 = math.radians(lat1), math.radians(lat2)
    dp, dl = p2 - p1, math.radians(lon2 - lon1)
    a = math.sin(dp / 2) ** 2 + math.cos(p1) * math.cos(p2) * math.sin(dl / 2) ** 2
    return 2 * r * math.asin(math.sqrt(a))


def sites_proches(session: Session, lat: float, lon: float, rayon_km: float, ids_autorises: set[int] | None):
    if session.bind.dialect.name == "postgresql":
        lignes = session.execute(text(
            "SELECT id, ST_Distance(geom::geography, ST_SetSRID(ST_MakePoint(:lon,:lat),4326)::geography)/1000 AS d "
            "FROM site WHERE ST_DWithin(geom::geography, ST_SetSRID(ST_MakePoint(:lon,:lat),4326)::geography, :r) "
            "ORDER BY d"), {"lat": lat, "lon": lon, "r": rayon_km * 1000}).all()
        methode = "PostGIS ST_DWithin / ST_Distance (géographie WGS 84)"
    else:
        lignes = sorted(((s.id, distance_km(lat, lon, s.latitude, s.longitude)) for s in session.scalars(select(Site))),
                        key=lambda x: x[1])
        lignes = [x for x in lignes if x[1] <= rayon_km]
        methode = "haversine (repli hors PostGIS, sphère R = 6371 km)"
    res = []
    for sid, d in lignes:
        if ids_autorises is not None and sid not in ids_autorises:
            continue
        s = session.get(Site, sid)
        res.append({**en_dict(s), "distance_km": round(float(d), 3)})
    return {"methode": methode, "sites": res}
