from __future__ import annotations

import ast
import operator
from datetime import datetime

from fastapi import HTTPException
from sqlalchemy import select
from sqlalchemy.orm import Session

from ...core.services import en_dict
from .models import (Contrat, EcheanceContrat, EngagementConfirme, Facture, Indice, LivraisonMesuree, Paiement,
                     ValeurIndice)

_OPS = {ast.Add: operator.add, ast.Sub: operator.sub, ast.Mult: operator.mul, ast.Div: operator.truediv,
        ast.USub: operator.neg}


def evaluer_formule(formule: str, variables: dict[str, float]) -> float:
    """Évaluateur arithmétique sûr (+ − × ÷, constantes, codes d'indices)."""

    def ev(n):
        if isinstance(n, ast.Expression):
            return ev(n.body)
        if isinstance(n, ast.Constant) and isinstance(n.value, (int, float)):
            return float(n.value)
        if isinstance(n, ast.Name):
            if n.id not in variables:
                raise HTTPException(422, f"Indice {n.id} sans valeur à la date demandée")
            return variables[n.id]
        if isinstance(n, ast.BinOp) and type(n.op) in _OPS:
            return _OPS[type(n.op)](ev(n.left), ev(n.right))
        if isinstance(n, ast.UnaryOp) and type(n.op) in _OPS:
            return _OPS[type(n.op)](ev(n.operand))
        raise HTTPException(422, "Formule de prix non autorisée (opérations arithmétiques uniquement)")

    return ev(ast.parse(formule, mode="eval"))


def noms_formule(formule: str) -> set[str]:
    return {n.id for n in ast.walk(ast.parse(formule, mode="eval")) if isinstance(n, ast.Name)}


def valeur_indice(session: Session, code: str, date: datetime) -> tuple[ValeurIndice, Indice] | None:
    ind = session.scalar(select(Indice).where(Indice.code == code))
    if not ind:
        return None
    # Valeur connue à la date : publiée au plus tard à cette date (pas de regard vers le futur)
    v = session.scalar(select(ValeurIndice).where(ValeurIndice.indice_id == ind.id, ValeurIndice.date_valeur <= date,
                                                  ValeurIndice.publie_le <= date)
                       .order_by(ValeurIndice.date_valeur.desc()))
    return (v, ind) if v else None


def cotation(session: Session, contrat: Contrat, date: datetime) -> dict:
    vars_, sources = {}, []
    for code in noms_formule(contrat.formule_prix):
        r = valeur_indice(session, code, date)
        if r is None:
            raise HTTPException(422, f"Aucune valeur publiée pour {code} au {date:%Y-%m-%d}")
        v, ind = r
        vars_[code] = v.valeur
        sources.append({"indice": code, "valeur": v.valeur, "unite": ind.unite, "date_valeur": v.date_valeur.isoformat(),
                        "publie_le": v.publie_le.isoformat(), "source": ind.source, "fuseau": ind.fuseau_horaire})
    prix = evaluer_formule(contrat.formule_prix, vars_)
    return {"contrat": contrat.numero, "prix": round(prix, 4), "unite": contrat.unite_prix, "devise": contrat.devise,
            "formule": contrat.formule_prix, "indices": sources, "date": date.isoformat(),
            "nature": "PRIX INDICATIF — calculé sur indices simulés, non exécutable, ne constitue pas une offre"}


def rapprochement(session: Session, contrat: Contrat) -> dict:
    ech = session.scalars(select(EcheanceContrat).where(EcheanceContrat.contrat_id == contrat.id)).all()
    eng = session.scalars(select(EngagementConfirme).where(EngagementConfirme.contrat_id == contrat.id)).all()
    liv = session.scalars(select(LivraisonMesuree).where(LivraisonMesuree.contrat_id == contrat.id)).all()
    fac = session.scalars(select(Facture).where(Facture.contrat_id == contrat.id)).all()
    pai = session.scalars(select(Paiement).where(Paiement.facture_id.in_([f.id for f in fac]))).all() if fac else []
    for groupe in (ech, eng, liv, fac):
        for x in groupe:
            if x.unite != contrat.unite:
                raise HTTPException(409, f"Unité {x.unite} ≠ unité contractuelle {contrat.unite} : rapprochement refusé")
    q = {"contractuelle": contrat.quantite_contractuelle, "prevue": sum(e.quantite_prevue for e in ech),
         "confirmee": sum(e.quantite for e in eng), "mesuree": sum(l.quantite for l in liv),
         "facturee": sum(f.quantite_facturee for f in fac)}
    montants = {"facture_ttc": round(sum(f.montant_ttc for f in fac), 2), "paye": round(sum(p.montant for p in pai), 2)}
    ecarts = []
    if q["confirmee"] and abs(q["mesuree"] - q["confirmee"]) > q["confirmee"] * contrat.tolerance_pct / 100:
        ecarts.append({"type": "livraison_vs_engagement", "ecart": round(q["mesuree"] - q["confirmee"], 3),
                       "message": f"Livré {q['mesuree']:g} pour {q['confirmee']:g} {contrat.unite} confirmés "
                                  f"(tolérance {contrat.tolerance_pct:g} %)"})
    if abs(q["facturee"] - q["mesuree"]) > 1e-6:
        ecarts.append({"type": "facture_vs_mesure", "ecart": round(q["facturee"] - q["mesuree"], 3),
                       "message": f"Facturé {q['facturee']:g} pour {q['mesuree']:g} {contrat.unite} mesurés"})
    if abs(montants["paye"] - montants["facture_ttc"]) > 0.01:
        ecarts.append({"type": "paiement_vs_facture", "ecart": round(montants["paye"] - montants["facture_ttc"], 2),
                       "message": f"Payé {montants['paye']:.2f} pour {montants['facture_ttc']:.2f} {contrat.devise} TTC facturés"})
    return {"contrat": en_dict(contrat), "unite": contrat.unite, "devise": contrat.devise, "quantites": q,
            "montants": montants, "ecarts": ecarts,
            "chaine": ["contrat", "prévision", "engagement confirmé", "livraison mesurée", "facture", "paiement"],
            "detail": {"echeances": [en_dict(x) for x in ech], "engagements": [en_dict(x) for x in eng],
                       "livraisons_mesurees": [en_dict(x) for x in liv], "factures": [en_dict(x) for x in fac],
                       "paiements": [en_dict(x) for x in pai]}}
