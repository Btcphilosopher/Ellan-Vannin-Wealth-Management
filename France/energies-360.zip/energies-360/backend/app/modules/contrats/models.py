"""Contrats et opérations commerciales.

Chaîne distincte : contrat → prévision (échéancier) → engagement confirmé →
livraison mesurée → facture → paiement.
"""
from __future__ import annotations

from sqlalchemy import Boolean, Float, ForeignKey, Integer, String, Text, UniqueConstraint
from sqlalchemy.orm import Mapped, mapped_column

from ...db import Base, HorodatageUTC, JSONType, maintenant


class Indice(Base):
    __tablename__ = "indice"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    code: Mapped[str] = mapped_column(String(40), unique=True)
    libelle: Mapped[str] = mapped_column(String(200))
    unite: Mapped[str] = mapped_column(String(20))  # EUR/MWh, EUR/m3...
    devise: Mapped[str] = mapped_column(String(3))
    source: Mapped[str] = mapped_column(String(200))
    fuseau_horaire: Mapped[str] = mapped_column(String(40), default="Europe/Paris")
    nature: Mapped[str] = mapped_column(String(30))  # indicatif_simule | publication_simulee


class ValeurIndice(Base):
    __tablename__ = "valeur_indice"
    __table_args__ = (UniqueConstraint("indice_id", "date_valeur"),)
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    indice_id: Mapped[int] = mapped_column(ForeignKey("indice.id"), index=True)
    date_valeur = mapped_column(HorodatageUTC)
    valeur: Mapped[float] = mapped_column(Float)
    publie_le = mapped_column(HorodatageUTC)


class Contrat(Base):
    __tablename__ = "contrat"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    numero: Mapped[str] = mapped_column(String(40), unique=True)
    type: Mapped[str] = mapped_column(String(10))  # achat | vente
    tiers_id: Mapped[int] = mapped_column(ForeignKey("tiers.id"))
    entite_id: Mapped[int] = mapped_column(ForeignKey("entite.id"))
    site_id: Mapped[int | None] = mapped_column(ForeignKey("site.id"), nullable=True)
    produit_id: Mapped[int] = mapped_column(ForeignKey("produit.id"))
    quantite_contractuelle: Mapped[float] = mapped_column(Float)
    unite: Mapped[str] = mapped_column(String(20))
    nature_quantite: Mapped[str | None] = mapped_column(String(30), nullable=True)
    tolerance_pct: Mapped[float] = mapped_column(Float, default=5)
    date_debut = mapped_column(HorodatageUTC)
    date_fin = mapped_column(HorodatageUTC)
    fuseau_horaire: Mapped[str] = mapped_column(String(40), default="Europe/Paris")
    devise: Mapped[str] = mapped_column(String(3), default="EUR")
    formule_prix: Mapped[str] = mapped_column(Text)
    unite_prix: Mapped[str] = mapped_column(String(20))
    conditions_livraison: Mapped[str | None] = mapped_column(Text, nullable=True)
    statut: Mapped[str] = mapped_column(String(20), default="actif")
    mention: Mapped[str] = mapped_column(Text, default="Contrat fictif — données synthétiques")


class EcheanceContrat(Base):
    """Calendrier / prévision de quantités (non engageante)."""

    __tablename__ = "echeance_contrat"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    contrat_id: Mapped[int] = mapped_column(ForeignKey("contrat.id"), index=True)
    periode_debut = mapped_column(HorodatageUTC)
    periode_fin = mapped_column(HorodatageUTC)
    quantite_prevue: Mapped[float] = mapped_column(Float)
    unite: Mapped[str] = mapped_column(String(20))


class EngagementConfirme(Base):
    __tablename__ = "engagement_confirme"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    contrat_id: Mapped[int] = mapped_column(ForeignKey("contrat.id"), index=True)
    echeance_id: Mapped[int | None] = mapped_column(ForeignKey("echeance_contrat.id"), nullable=True)
    quantite: Mapped[float] = mapped_column(Float)
    unite: Mapped[str] = mapped_column(String(20))
    reference: Mapped[str] = mapped_column(String(60))
    confirme_par: Mapped[str] = mapped_column(String(80))
    confirme_le = mapped_column(HorodatageUTC, default=maintenant)


class LivraisonMesuree(Base):
    __tablename__ = "livraison_mesuree"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    contrat_id: Mapped[int] = mapped_column(ForeignKey("contrat.id"), index=True)
    engagement_id: Mapped[int | None] = mapped_column(ForeignKey("engagement_confirme.id"), nullable=True)
    quantite: Mapped[float] = mapped_column(Float)
    unite: Mapped[str] = mapped_column(String(20))
    nature_quantite: Mapped[str | None] = mapped_column(String(30), nullable=True)
    source_type: Mapped[str] = mapped_column(String(30))  # reception | compteur | jaugeage
    source_id: Mapped[int | None] = mapped_column(Integer, nullable=True)
    mesure_le = mapped_column(HorodatageUTC)
    hypotheses = mapped_column(JSONType, default=list)


class Facture(Base):
    __tablename__ = "facture"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    numero: Mapped[str] = mapped_column(String(40), unique=True)
    contrat_id: Mapped[int] = mapped_column(ForeignKey("contrat.id"), index=True)
    sens: Mapped[str] = mapped_column(String(10))  # recue | emise
    date_facture = mapped_column(HorodatageUTC)
    date_echeance = mapped_column(HorodatageUTC)
    quantite_facturee: Mapped[float] = mapped_column(Float)
    unite: Mapped[str] = mapped_column(String(20))
    prix_unitaire: Mapped[float] = mapped_column(Float)
    montant_ht: Mapped[float] = mapped_column(Float)
    taux_tva_pct: Mapped[float] = mapped_column(Float, default=20)
    montant_ttc: Mapped[float] = mapped_column(Float)
    devise: Mapped[str] = mapped_column(String(3))
    base_prix = mapped_column(JSONType, default=dict)
    statut: Mapped[str] = mapped_column(String(20), default="a_payer")


class Paiement(Base):
    __tablename__ = "paiement"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    facture_id: Mapped[int] = mapped_column(ForeignKey("facture.id"), index=True)
    date_paiement = mapped_column(HorodatageUTC)
    montant: Mapped[float] = mapped_column(Float)
    devise: Mapped[str] = mapped_column(String(3))
    reference: Mapped[str] = mapped_column(String(60))


class OrdreMarcheSimule(Base):
    """Opération de marché SIMULÉE. Aucun ordre réel n'est transmis."""

    __tablename__ = "ordre_marche_simule"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    produit: Mapped[str] = mapped_column(String(60))
    sens: Mapped[str] = mapped_column(String(10))
    quantite: Mapped[float] = mapped_column(Float)
    unite: Mapped[str] = mapped_column(String(20))
    prix_limite: Mapped[float] = mapped_column(Float)
    devise: Mapped[str] = mapped_column(String(3))
    statut: Mapped[str] = mapped_column(String(30), default="simule_non_transmis")
    simulation: Mapped[bool] = mapped_column(Boolean, default=True)
    cree_par: Mapped[str] = mapped_column(String(80))
    cree_le = mapped_column(HorodatageUTC, default=maintenant)
    resultat_simulation = mapped_column(JSONType, default=dict)
