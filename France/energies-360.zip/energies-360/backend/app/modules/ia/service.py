"""Assistance analytique (règles transparentes et modèles simples).

Garde-fous : chaque sortie est une *suggestion* qui exige une validation
humaine. Le compte de service IA n'a que des permissions de lecture ; aucune
fonction de ce module n'écrit d'ordre de travail, de dépense, d'autorisation ou
d'opération de marché.
"""
from __future__ import annotations

import math
import re
from collections import Counter
from datetime import datetime, timedelta

from sqlalchemy import select
from sqlalchemy.orm import Session

from ...core.services import en_dict
from ..maintenance.models import OrdreTravail
from ..mesures.energie import observations_valides, points_principaux, serie
from ..mesures.models import Alerte
from ..patrimoine.models import Document
from ..production import service as prod
from ..production.models import Incident

GARDE_FOUS = ("Suggestion générée par règles / modèle simple, à vérifier par une personne compétente. "
              "Ne vaut ni autorisation d'intervention, ni commande de procédé, ni engagement de dépense, ni "
              "opération de marché.")

_MOTS_VIDES = set("le la les de des du un une et en à au aux pour par sur dans est sont avec ce cette ces qui que "
                  "ou d l".split())


def _jetons(t: str) -> list[str]:
    return [m for m in re.findall(r"[a-zàâäçéèêëîïôöùûüÿœ0-9]+", (t or "").lower()) if m not in _MOTS_VIDES and len(m) > 1]


def rechercher_documents(session: Session, requete: str, sites_autorises: set[int] | None, limite: int = 10) -> dict:
    """Recherche TF-IDF dans les seuls documents autorisés (filtrage AVANT classement)."""
    docs = [d for d in session.scalars(select(Document))
            if d.texte_indexable and (sites_autorises is None or d.site_id is None or d.site_id in sites_autorises)
            and d.confidentialite != "restreint"]
    q = _jetons(requete)
    if not q or not docs:
        return {"requete": requete, "resultats": [], "documents_consultables": len(docs), "garde_fous": GARDE_FOUS}
    corpus = [Counter(_jetons(d.titre + " " + d.texte_indexable)) for d in docs]
    n = len(docs)
    idf = {t: math.log((n + 1) / (1 + sum(1 for c in corpus if t in c))) + 1 for t in q}
    scores = []
    for d, c in zip(docs, corpus):
        total = sum(c.values()) or 1
        s = sum((c[t] / total) * idf[t] for t in q)
        if s > 0:
            extrait = next((p.strip() for p in re.split(r"(?<=[.!?])\s+", d.texte_indexable)
                            if any(t in p.lower() for t in q)), d.texte_indexable[:200])
            scores.append({"document_id": d.id, "titre": d.titre, "type": d.type_document, "score": round(s, 4),
                           "extrait": extrait[:300]})
    scores.sort(key=lambda x: -x["score"])
    return {"requete": requete, "methode": "TF-IDF sur documents autorisés", "resultats": scores[:limite],
            "documents_consultables": n, "garde_fous": GARDE_FOUS}


def resumer_incident(session: Session, incident: Incident) -> dict:
    alertes = [session.get(Alerte, i) for i in (incident.alerte_ids or [])]
    alertes = [a for a in alertes if a]
    ot = session.get(OrdreTravail, incident.ordre_travail_id) if incident.ordre_travail_id else None
    duree = ((incident.fin or incident.debut) - incident.debut).total_seconds() / 3600 if incident.fin else None
    phrases = [f"Incident « {incident.titre} » (gravité {incident.gravite}) ouvert le {incident.debut:%d/%m/%Y à %H:%M} UTC."]
    if duree is not None:
        phrases.append(f"Durée constatée : {duree:.1f} h.")
    else:
        phrases.append("Incident toujours en cours.")
    for a in alertes:
        phrases.append(f"Alerte liée : {a.titre} — {a.message}")
    if ot:
        phrases.append(f"Ordre de travail {ot.numero} à l'état « {ot.etat} ».")
    return {"incident_id": incident.id, "resume": " ".join(phrases), "methode": "résumé extractif par gabarit",
            "sources": {"alertes": [a.id for a in alertes], "ordre_travail": ot.id if ot else None},
            "garde_fous": GARDE_FOUS}


INVESTIGATIONS = {
    "capteur_perime": ["Vérifier l'alimentation et la communication du capteur (passerelle, réseau)",
                       "Comparer avec un capteur redondant ou une source satellite simulée",
                       "Ne pas substituer de valeur sans estimation tracée et validée"],
    "valeur_figee": ["Contrôler l'encrassement / la fixation du capteur",
                     "Vérifier la chaîne d'acquisition (convertisseur, horodatage)"],
    "panne_equipement": ["Consulter le journal d'événements de l'onduleur (code défaut)",
                         "Vérifier protections AC/DC selon la procédure du site",
                         "Créer un ordre de travail si non existant (action humaine)"],
    "compteur_reinitialise": ["Vérifier une intervention / mise à jour firmware à l'heure indiquée",
                              "Recouper avec le compteur principal du site"],
    "donnees_manquantes": ["Vérifier la liaison de télémétrie", "Récupérer l'historique local de l'équipement",
                           "Laisser les intervalles « inconnus » tant que la donnée n'est pas récupérée"],
    "hors_bornes": ["Vérifier l'échelle / l'unité configurée", "Contrôler un éventuel pic transitoire"],
    "doublon_conflictuel": ["Identifier la source émettant deux valeurs", "Corriger la configuration de rejeu"],
    "retard": ["Vérifier la file d'attente de la passerelle", "Surveiller la latence d'ingestion"],
}


def proposer_investigation(session: Session, alerte: Alerte) -> dict:
    return {"alerte_id": alerte.id, "type": alerte.type, "regle_declenchee": alerte.regle,
            "etapes_proposees": INVESTIGATIONS.get(alerte.type, ["Analyse manuelle requise"]),
            "requiert_validation_humaine": True, "garde_fous": GARDE_FOUS}


def detecter_anomalies(session: Session, site_id: int, debut: datetime, fin: datetime) -> dict:
    """Ratio de performance horaire (énergie mesurée / potentiel) et z-score robuste."""
    pp = points_principaux(session, site_id).get("production_pv")
    m = prod.points_meteo(session, site_id)
    c = prod.centrale(session, site_id)
    if not pp or "GPOA" not in m or not c:
        return {"applicable": False}
    s = serie(session, pp, debut, fin, 3600)
    g = serie(session, m["GPOA"], debut, fin, 3600)
    cap = prod.capacite(session, c.id, "installee", "puissance_dc", debut)
    lignes = []
    for a, b in zip(s["points"], g["points"]):
        if a["v"] is None or b["v"] is None or b["v"] < 200:
            continue
        pr = a["v"] / (b["v"] / 1000 * cap.valeur)
        lignes.append({"t": a["t"], "pr": round(pr, 4)})
    if len(lignes) < 5:
        return {"applicable": True, "anomalies": [], "message": "données insuffisantes"}
    vals = sorted(l["pr"] for l in lignes)
    med = vals[len(vals) // 2]
    mad = sorted(abs(v - med) for v in vals)[len(vals) // 2] or 1e-6
    anomalies = [dict(l, z_robuste=round((l["pr"] - med) / (1.4826 * mad), 2)) for l in lignes
                 if abs(l["pr"] - med) / (1.4826 * mad) > 3.5]
    return {"applicable": True, "methode": "PR = E_horaire / (G_POA/1000 × Pdc) ; |z robuste| > 3,5 (médiane/MAD), "
                                           "heures avec G_POA ≥ 200 W/m²", "pr_median": med,
            "heures_analysees": len(lignes), "anomalies": anomalies, "garde_fous": GARDE_FOUS}


# ---------------------------------------------------------------------------
# Prévision de production et évaluation sur données distinctes
# ---------------------------------------------------------------------------

def _horaire(session, point, debut, fin):
    return {datetime.fromisoformat(p["t"]): p["v"] for p in serie(session, point, debut, fin, 3600)["points"]}


def evaluer_modeles(session: Session, site_id: int, debut_apprentissage: datetime, fin_apprentissage: datetime,
                    debut_test: datetime, fin_test: datetime) -> dict:
    """Compare sur une période de TEST distincte : persistance J−1, climatologie
    horaire (apprise sur la période d'apprentissage) et modèle physique alimenté
    par une prévision d'éclairement simulée (bruitée)."""
    pp = points_principaux(session, site_id)["production_pv"]
    reel = _horaire(session, pp, debut_apprentissage, fin_test)
    appr = {t: v for t, v in reel.items() if debut_apprentissage <= t < fin_apprentissage and v is not None}
    clim: dict[int, list[float]] = {}
    for t, v in appr.items():
        clim.setdefault(t.hour, []).append(v)
    clim_m = {h: sum(v) / len(v) for h, v in clim.items()}
    from ...simulateurs.pv import prevision_eclairement  # simulateur météo (adaptateur)

    c = prod.centrale(session, site_id)
    pdc = prod.capacite(session, c.id, "installee", "puissance_dc", debut_test).valeur
    pac = prod.capacite(session, c.id, "installee", "puissance_ac", debut_test).valeur
    erreurs = {"persistance_j_1": [], "climatologie_horaire": [], "physique_prevision_meteo": []}
    t = debut_test
    while t < fin_test:
        v = reel.get(t)
        if v is not None:
            p1 = reel.get(t - timedelta(days=1))
            if p1 is not None:
                erreurs["persistance_j_1"].append(v - p1)
            erreurs["climatologie_horaire"].append(v - clim_m.get(t.hour, 0.0))
            g = prevision_eclairement(t)
            erreurs["physique_prevision_meteo"].append(v - prod.puissance_potentielle_kw(g, 25 + g / 40, pdc, pac))
        t += timedelta(hours=1)

    def met(e):
        if not e:
            return None
        mae = sum(abs(x) for x in e) / len(e)
        return {"n": len(e), "mae_kwh": round(mae, 1), "rmse_kwh": round(math.sqrt(sum(x * x for x in e) / len(e)), 1),
                "biais_kwh": round(sum(e) / len(e), 1), "nmae_pct_pac": round(100 * mae / pac, 2)}

    res = {k: met(v) for k, v in erreurs.items()}
    meilleur = min((k for k in res if res[k]), key=lambda k: res[k]["mae_kwh"])
    return {"periode_apprentissage": [debut_apprentissage.isoformat(), fin_apprentissage.isoformat()],
            "periode_test": [debut_test.isoformat(), fin_test.isoformat()], "resultats": res,
            "meilleur_mae": meilleur, "references_simples": ["persistance_j_1", "climatologie_horaire"],
            "note": "Évaluation sur période de test disjointe de l'apprentissage ; heures sans mesure exclues.",
            "garde_fous": GARDE_FOUS}


def expliquer_ecart(session: Session, site_id: int, debut: datetime, fin: datetime) -> dict:
    """Décompose l'écart prévision P50 − réalisé en contributions estimées."""
    pvr = prod.prevision_vs_realise(session, site_id, debut, fin)
    pertes = prod.pertes_estimees(session, site_id, debut, fin)
    prevu = sum(l["p50_kwh"] or 0 for l in pvr["lignes"] if l["p50_kwh"] is not None and l["realise_kwh"] is not None)
    realise = sum(l["realise_kwh"] for l in pvr["lignes"] if l["p50_kwh"] is not None and l["realise_kwh"] is not None)
    inconnu_h = sum(1 for l in pvr["lignes"] if l["realise_kwh"] is None)
    ecart = prevu - realise
    contrib = {"indisponibilite_estimee_kwh": pertes["indisponibilite_kwh"],
               "limitation_reseau_estimee_kwh": pertes["limitation_reseau_kwh"],
               "ecretement_onduleur_estime_kwh": pertes["ecretement_onduleur_kwh"]}
    residu = ecart - sum(contrib.values())
    return {"periode": [debut.isoformat(), fin.isoformat()], "prevu_p50_kwh": round(prevu, 1),
            "realise_kwh": round(realise, 1), "ecart_kwh": round(ecart, 1), "contributions": contrib,
            "residu_non_explique_kwh": round(residu, 1),
            "heures_sans_mesure_exclues": inconnu_h,
            "lecture": ("Résidu attribuable à l'erreur de prévision météo, aux pertes non modélisées et aux "
                        "incertitudes du modèle ; non réparti artificiellement."),
            "garde_fous": GARDE_FOUS}
