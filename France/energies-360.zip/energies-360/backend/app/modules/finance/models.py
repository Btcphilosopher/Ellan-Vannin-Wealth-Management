from __future__ import annotations

from sqlalchemy import Float, ForeignKey, Integer, String, Text
from sqlalchemy.orm import Mapped, mapped_column

from ...db import Base, HorodatageUTC, JSONType, maintenant


class LigneBudget(Base):
    __tablename__ = "ligne_budget"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    entite_id: Mapped[int] = mapped_column(ForeignKey("entite.id"))
    site_id: Mapped[int | None] = mapped_column(ForeignKey("site.id"), nullable=True)
    annee: Mapped[int] = mapped_column(Integer)
    poste: Mapped[str] = mapped_column(String(40))  # maintenance | exploitation | investissement | achats
    montant: Mapped[float] = mapped_column(Float)
    devise: Mapped[str] = mapped_column(String(3), default="EUR")


class EngagementFinancier(Base):
    __tablename__ = "engagement_financier"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    ligne_budget_id: Mapped[int] = mapped_column(ForeignKey("ligne_budget.id"), index=True)
    reference_type: Mapped[str] = mapped_column(String(30))  # ordre_travail | commande | contrat
    reference_id: Mapped[int] = mapped_column(Integer)
    montant: Mapped[float] = mapped_column(Float)
    devise: Mapped[str] = mapped_column(String(3), default="EUR")
    le = mapped_column(HorodatageUTC, default=maintenant)


class DepenseReelle(Base):
    __tablename__ = "depense_reelle"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    ligne_budget_id: Mapped[int] = mapped_column(ForeignKey("ligne_budget.id"), index=True)
    reference_type: Mapped[str] = mapped_column(String(30))
    reference_id: Mapped[int] = mapped_column(Integer)
    facture_id: Mapped[int | None] = mapped_column(ForeignKey("facture.id"), nullable=True)
    montant: Mapped[float] = mapped_column(Float)
    devise: Mapped[str] = mapped_column(String(3), default="EUR")
    le = mapped_column(HorodatageUTC, default=maintenant)


class ScenarioInvestissement(Base):
    __tablename__ = "scenario_investissement"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    nom: Mapped[str] = mapped_column(String(200))
    site_id: Mapped[int | None] = mapped_column(ForeignKey("site.id"), nullable=True)
    devise: Mapped[str] = mapped_column(String(3), default="EUR")
    taux_actualisation_pct: Mapped[float] = mapped_column(Float)
    convention: Mapped[str] = mapped_column(String(40))  # dates_reelles_act365 | fin_de_periode_annuelle
    base: Mapped[str] = mapped_column(String(10))  # nominal | reel
    date_reference = mapped_column(HorodatageUTC)
    flux = mapped_column(JSONType)  # [{date, montant, libelle, nature}]
    hypotheses = mapped_column(JSONType, default=list)
    limites: Mapped[str] = mapped_column(Text)
    resultats = mapped_column(JSONType, nullable=True)
    cree_par: Mapped[str] = mapped_column(String(80))
    cree_le = mapped_column(HorodatageUTC, default=maintenant)
