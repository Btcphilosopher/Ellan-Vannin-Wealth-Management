"""Finance : budgets, engagements, réalisé, coûts unitaires, marges définies,
trésorerie prévisionnelle, VAN / TRI explicites.

Séparation stricte : revenu estimé (production × prix indicatif) ≠ facturé ≠
encaissé ≠ résultat comptable (hors périmètre du prototype).
"""
from __future__ import annotations

from datetime import datetime, timedelta, timezone

from fastapi import HTTPException
from sqlalchemy import select
from sqlalchemy.orm import Session

from ...core.services import en_dict
from ..contrats.models import Contrat, Facture, Paiement
from ..contrats.service import valeur_indice
from ..distribution.models import VenteCarburant
from ..maintenance.models import OrdreTravail
from ..maintenance.service import cout_total
from ..mesures.energie import energie_point, points_principaux
from .models import DepenseReelle, EngagementFinancier, LigneBudget, ScenarioInvestissement


def _annees(d0: datetime, d: datetime) -> float:
    return (d - d0).days / 365.0


def van(flux: list[tuple[datetime, float]], taux: float, d0: datetime, convention: str) -> float:
    if convention == "fin_de_periode_annuelle":
        return sum(m / (1 + taux) ** max(0, round(_annees(d0, d))) for d, m in flux)
    return sum(m / (1 + taux) ** _annees(d0, d) for d, m in flux)


def tri(flux: list[tuple[datetime, float]], d0: datetime, convention: str) -> tuple[float | None, str]:
    """TRI par balayage de taux (−99 % à 1000 %) puis dichotomie dans chaque
    intervalle de changement de signe de la VAN ; signale les racines multiples."""
    signes = [m for _, m in sorted(flux) if m != 0]
    changements = sum(1 for a, b in zip(signes, signes[1:]) if (a > 0) != (b > 0))
    if changements == 0:
        return None, "TRI indéfini : pas de changement de signe des flux"
    grille = [-0.99 + k * 0.0025 for k in range(int((10.0 + 0.99) / 0.0025) + 1)]
    racines = []
    prec_r, prec_v = grille[0], van(flux, grille[0], d0, convention)
    for r in grille[1:]:
        v = van(flux, r, d0, convention)
        if prec_v == 0:
            racines.append(prec_r)
        elif prec_v * v < 0:
            lo, hi, flo = prec_r, r, prec_v
            for _ in range(100):
                mid = (lo + hi) / 2
                fm = van(flux, mid, d0, convention)
                if flo * fm <= 0:
                    hi = mid
                else:
                    lo, flo = mid, fm
            racines.append((lo + hi) / 2)
        prec_r, prec_v = r, v
    if not racines:
        return None, "TRI introuvable dans [−99 % ; 1000 %]"
    if len(racines) == 1 and changements == 1:
        return racines[0], "racine unique"
    if len(racines) == 1:
        return racines[0], f"{changements} changements de signe des flux ; une seule racine trouvée — interpréter avec prudence"
    liste = ", ".join(f"{100 * r:.2f} %" for r in racines)
    return racines[0], f"plusieurs TRI possibles ({liste}) : valeur non interprétable seule, utiliser la VAN"


def evaluer_investissement(sc: ScenarioInvestissement) -> dict:
    flux = [(datetime.fromisoformat(f["date"]).replace(tzinfo=timezone.utc) if "T" not in f["date"]
             else datetime.fromisoformat(f["date"]), float(f["montant"])) for f in sc.flux]
    d0 = sc.date_reference
    taux = sc.taux_actualisation_pct / 100
    v = van(flux, taux, d0, sc.convention)
    t, note = tri(flux, d0, sc.convention)
    cumul, retour = 0.0, None
    for d, m in sorted(flux):
        cumul += m
        if cumul >= 0 and retour is None and m > 0:
            retour = d
    detail = [{"date": d.date().isoformat(), "montant": m,
               "facteur_actualisation": round(1 / (1 + taux) ** (_annees(d0, d) if sc.convention != "fin_de_periode_annuelle"
                                                                 else max(0, round(_annees(d0, d)))), 6),
               "valeur_actualisee": round(m / (1 + taux) ** (_annees(d0, d) if sc.convention != "fin_de_periode_annuelle"
                                                            else max(0, round(_annees(d0, d)))), 2)}
              for d, m in sorted(flux)]
    return {"van": round(v, 2), "devise": sc.devise, "tri_pct": None if t is None else round(100 * t, 3),
            "note_tri": note, "retour_sur_investissement_non_actualise": retour.date().isoformat() if retour else None,
            "conventions": {"taux_actualisation_pct": sc.taux_actualisation_pct, "convention": sc.convention,
                            "base": sc.base, "date_reference": d0.date().isoformat(),
                            "formule": ("VAN = Σ F_i / (1+r)^((d_i − d_0)/365)" if sc.convention != "fin_de_periode_annuelle"
                                        else "VAN = Σ F_i / (1+r)^n_i, n_i = année entière")},
            "flux_actualises": detail, "hypotheses": sc.hypotheses, "limites": sc.limites,
            "avertissement": ("Calcul d'aide à la décision sur hypothèses synthétiques. Ne déduit pas la rentabilité "
                              "globale d'une activité ; ne remplace pas une évaluation financière complète.")}


def cout_unitaire_maintenance(session: Session, site_id: int, debut: datetime, fin: datetime) -> dict:
    from ..mesures.models import Alerte

    def dans_periode(o: OrdreTravail) -> bool:
        if o.alerte_id:
            a = session.get(Alerte, o.alerte_id)
            if a and debut <= a.debut < fin:
                return True
        return debut <= o.cree_le < fin

    ots = [o for o in session.scalars(select(OrdreTravail).where(OrdreTravail.site_id == site_id)) if dans_periode(o)]
    cout = sum(cout_total(o) for o in ots)
    pp = points_principaux(session, site_id).get("production_pv")
    e = energie_point(session, pp, debut, fin) if pp else None
    mwh = (e["valeur"] or 0) / 1000 if e else 0
    return {"valeur": round(cout / mwh, 3) if mwh else None, "unite": "EUR/MWh",
            "numerateur": {"cout_maintenance_eur": round(cout, 2), "ordres": [o.numero for o in ots],
                           "definition": "main d'œuvre + pièces + prestations externes des OT du site"},
            "denominateur": {"production_mwh": round(mwh, 3), "source": e["point"] if e else None,
                             "statut": e["statut"] if e else None},
            "limite": "Indicateur opérationnel partiel : n'intègre ni amortissements, ni frais de structure, ni "
                      "coûts de raccordement ; ne mesure pas la rentabilité."}


def marge_carburant(session: Session, site_id: int, debut: datetime, fin: datetime) -> dict:
    ventes = session.scalars(select(VenteCarburant).where(VenteCarburant.site_id == site_id,
                                                          VenteCarburant.horodatage >= debut,
                                                          VenteCarburant.horodatage < fin)).all()
    contrats = {c.produit_id: c for c in session.scalars(select(Contrat).where(Contrat.type == "achat",
                                                                                Contrat.site_id == site_id))}
    par_produit = {}
    for v in ventes:
        d = par_produit.setdefault(v.produit_id, {"volume_l": 0.0, "ca_ht": 0.0})
        d["volume_l"] += v.volume_observe_l
        d["ca_ht"] += v.montant_ttc / (1 + v.taux_tva_pct / 100)
    res = []
    for pid, d in par_produit.items():
        c = contrats.get(pid)
        cout_l = None
        source = None
        if c:
            fac = session.scalars(select(Facture).where(Facture.contrat_id == c.id)).all()
            q = sum(f.quantite_facturee for f in fac)
            if q:
                cout_l = sum(f.montant_ht for f in fac) / q
                source = f"coût moyen pondéré des factures fournisseur du contrat {c.numero} ({c.unite})"
        marge = None if cout_l is None else d["ca_ht"] - cout_l * d["volume_l"]
        res.append({"produit_id": pid, "volume_vendu_l_observe": round(d["volume_l"], 1),
                    "chiffre_affaires_ht": round(d["ca_ht"], 2), "cout_achat_eur_par_l": None if cout_l is None
                    else round(cout_l, 4), "marge_brute_ht": None if marge is None else round(marge, 2),
                    "source_cout": source or "aucune facture fournisseur : marge non calculée"})
    return {"site_id": site_id, "devise": "EUR", "lignes": res,
            "definition": ("Marge brute carburant = CA HT des ventes − coût d'achat HT (CMP facturé, accises simulées "
                           "incluses) × volume vendu."),
            "limites": ("Volumes vendus observés (ambiants) et achats facturés à 15 °C : écart de base volumique non "
                        "corrigé dans cette marge, publié par le rapprochement de cuves. Hors frais de site.")}


def synthese(session: Session, annee: int, entite_ids: set[int] | None) -> dict:
    lignes = session.scalars(select(LigneBudget).where(LigneBudget.annee == annee)).all()
    res = []
    for l in lignes:
        if entite_ids is not None and l.entite_id not in entite_ids:
            continue
        eng = sum(e.montant for e in session.scalars(select(EngagementFinancier)
                                                     .where(EngagementFinancier.ligne_budget_id == l.id)))
        dep = sum(e.montant for e in session.scalars(select(DepenseReelle).where(DepenseReelle.ligne_budget_id == l.id)))
        res.append({**en_dict(l), "engage": round(eng, 2), "realise": round(dep, 2),
                    "reste_a_engager": round(l.montant - eng - dep, 2)})
    return {"annee": annee, "lignes": res,
            "definitions": {"budget": "montant alloué", "engage": "commandes / OT émis non facturés",
                            "realise": "dépenses facturées", "reste_a_engager": "budget − engagé − réalisé"}}


def revenus_separes(session: Session, site_id: int, debut: datetime, fin: datetime, indice_code: str) -> dict:
    pp = points_principaux(session, site_id).get("injection_reseau")
    e = energie_point(session, pp, debut, fin) if pp else None
    r = valeur_indice(session, indice_code, fin)
    estime = None
    if e and e["valeur"] is not None and r:
        estime = e["valeur"] / 1000 * r[0].valeur
    contrats = session.scalars(select(Contrat).where(Contrat.site_id == site_id, Contrat.type == "vente")).all()
    fac = session.scalars(select(Facture).where(Facture.contrat_id.in_([c.id for c in contrats]))).all() if contrats else []
    pai = session.scalars(select(Paiement).where(Paiement.facture_id.in_([f.id for f in fac]))).all() if fac else []
    return {"devise": "EUR",
            "revenu_estime": {"valeur": None if estime is None else round(estime, 2),
                              "methode": f"énergie injectée (compteur principal) × {indice_code} (indicatif simulé)",
                              "nature": "estimation"},
            "facture": {"valeur": round(sum(f.montant_ht for f in fac), 2), "nature": "factures émises HT"},
            "encaisse": {"valeur": round(sum(p.montant for p in pai), 2), "nature": "paiements reçus"},
            "resultat": {"valeur": None, "nature": "hors périmètre",
                         "message": "Le résultat comptable relève de la comptabilité générale ; non calculé ici."}}


def tresorerie_previsionnelle(session: Session, debut: datetime, semaines: int = 8) -> dict:
    fac = session.scalars(select(Facture)).all()
    payes = {}
    for p in session.scalars(select(Paiement)):
        payes[p.facture_id] = payes.get(p.facture_id, 0) + p.montant
    semaines_l = []
    for i in range(semaines):
        a, b = debut + timedelta(weeks=i), debut + timedelta(weeks=i + 1)
        ent = sum(f.montant_ttc - payes.get(f.id, 0) for f in fac if f.sens == "emise" and a <= f.date_echeance < b)
        sor = sum(f.montant_ttc - payes.get(f.id, 0) for f in fac if f.sens == "recue" and a <= f.date_echeance < b)
        semaines_l.append({"semaine_debut": a.date().isoformat(), "encaissements_attendus": round(ent, 2),
                           "decaissements_attendus": round(sor, 2), "solde_net": round(ent - sor, 2)})
    return {"devise": "EUR", "semaines": semaines_l,
            "methode": "restes à payer / encaisser des factures par semaine d'échéance (hors flux non facturés)"}
