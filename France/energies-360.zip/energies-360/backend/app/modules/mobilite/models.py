"""Recharge : borne, connecteur, session, énergie délivrée, tarif, paiement et
état de communication — enregistrés séparément."""
from __future__ import annotations

from sqlalchemy import Float, ForeignKey, Integer, String
from sqlalchemy.orm import Mapped, mapped_column

from ...db import Base, HorodatageUTC, JSONType


class MessageOCPP(Base):
    __tablename__ = "message_ocpp"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    borne_id: Mapped[int] = mapped_column(ForeignKey("actif.id"), index=True)
    recu_le = mapped_column(HorodatageUTC, index=True)
    type_message: Mapped[int] = mapped_column(Integer)  # 2 CALL, 3 CALLRESULT, 4 CALLERROR
    identifiant_message: Mapped[str] = mapped_column(String(64))
    action: Mapped[str | None] = mapped_column(String(40), nullable=True)
    charge_utile = mapped_column(JSONType)
    traitement: Mapped[str] = mapped_column(String(30))  # accepte | ignore_non_supporte | rejete


class EtatCommunication(Base):
    __tablename__ = "etat_communication"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    borne_id: Mapped[int] = mapped_column(ForeignKey("actif.id"), unique=True)
    derniere_communication = mapped_column(HorodatageUTC, nullable=True)
    dernier_heartbeat = mapped_column(HorodatageUTC, nullable=True)
    intervalle_heartbeat_s: Mapped[int] = mapped_column(Integer, default=300)
    boot_le = mapped_column(HorodatageUTC, nullable=True)
    firmware: Mapped[str | None] = mapped_column(String(60), nullable=True)


class EtatConnecteur(Base):
    """État DÉCLARÉ par la borne (StatusNotification) — distinct de la
    disponibilité évaluée par la plateforme."""

    __tablename__ = "etat_connecteur"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    connecteur_id: Mapped[int] = mapped_column(ForeignKey("actif.id"), index=True)
    statut_declare: Mapped[str] = mapped_column(String(30))
    code_erreur: Mapped[str] = mapped_column(String(40), default="NoError")
    declare_le = mapped_column(HorodatageUTC)
    recu_le = mapped_column(HorodatageUTC)


class Tarif(Base):
    __tablename__ = "tarif"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    code: Mapped[str] = mapped_column(String(40), unique=True)
    libelle: Mapped[str] = mapped_column(String(200))
    prix_kwh_ttc: Mapped[float] = mapped_column(Float)
    prix_minute_ttc: Mapped[float] = mapped_column(Float, default=0)
    frais_session_ttc: Mapped[float] = mapped_column(Float, default=0)
    devise: Mapped[str] = mapped_column(String(3), default="EUR")
    valide_de = mapped_column(HorodatageUTC)
    valide_a = mapped_column(HorodatageUTC, nullable=True)


class SessionRecharge(Base):
    __tablename__ = "session_recharge"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    borne_id: Mapped[int] = mapped_column(ForeignKey("actif.id"), index=True)
    connecteur_id: Mapped[int] = mapped_column(ForeignKey("actif.id"))
    transaction_id: Mapped[int] = mapped_column(Integer)
    badge_pseudonyme: Mapped[str] = mapped_column(String(64))  # empreinte de l'idTag, jamais l'idTag en clair
    debut = mapped_column(HorodatageUTC)
    fin = mapped_column(HorodatageUTC, nullable=True)
    index_debut_wh: Mapped[float] = mapped_column(Float)
    index_fin_wh: Mapped[float | None] = mapped_column(Float, nullable=True)
    dernier_index_wh: Mapped[float | None] = mapped_column(Float, nullable=True)
    puissance_max_kw: Mapped[float | None] = mapped_column(Float, nullable=True)
    statut: Mapped[str] = mapped_column(String(20), default="en_cours")
    motif_arret: Mapped[str | None] = mapped_column(String(40), nullable=True)
    tarif_id: Mapped[int | None] = mapped_column(ForeignKey("tarif.id"), nullable=True)
    energie_kwh: Mapped[float | None] = mapped_column(Float, nullable=True)
    montant_ttc: Mapped[float | None] = mapped_column(Float, nullable=True)
    devise: Mapped[str] = mapped_column(String(3), default="EUR")
    detail_tarification = mapped_column(JSONType, default=dict)


class PaiementRecharge(Base):
    __tablename__ = "paiement_recharge"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    session_id: Mapped[int] = mapped_column(ForeignKey("session_recharge.id"), index=True)
    montant_ttc: Mapped[float] = mapped_column(Float)
    devise: Mapped[str] = mapped_column(String(3))
    statut: Mapped[str] = mapped_column(String(20))  # autorise | capture | echec | rembourse
    prestataire: Mapped[str] = mapped_column(String(60), default="prestataire_paiement_simule")
    reference: Mapped[str] = mapped_column(String(60))
    le = mapped_column(HorodatageUTC)
