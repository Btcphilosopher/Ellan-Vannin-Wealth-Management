"""Adaptateur OCPP-J (sous-ensemble OCPP 1.6J, lecture seule) et évaluation de
disponibilité des connecteurs.

Messages pris en charge (borne → plateforme) : BootNotification, Heartbeat,
StatusNotification, StartTransaction, MeterValues, StopTransaction.
Aucune commande plateforme → borne (RemoteStart/Stop, Reset,
ChangeAvailability, UnlockConnector…) n'est implémentée : la première version
est en lecture seule. Ce sous-ensemble n'est pas certifié ; vérifier toute
intégration réelle avec la spécification officielle de l'Open Charge Alliance.
"""
from __future__ import annotations

import hashlib
from datetime import datetime, timedelta

from fastapi import HTTPException
from sqlalchemy import select
from sqlalchemy.orm import Session

from ...core.services import en_dict, publier
from ...db import maintenant
from ..maintenance.models import OrdreTravail
from ..patrimoine.models import Actif
from .models import EtatCommunication, EtatConnecteur, MessageOCPP, PaiementRecharge, SessionRecharge, Tarif

ACTIONS_SUPPORTEES = {"BootNotification", "Heartbeat", "StatusNotification", "StartTransaction", "MeterValues",
                      "StopTransaction"}
COMMANDES_NON_IMPLEMENTEES = ["RemoteStartTransaction", "RemoteStopTransaction", "Reset", "ChangeAvailability",
                              "UnlockConnector", "ChangeConfiguration", "UpdateFirmware"]


def _dt(v: str | None, defaut: datetime) -> datetime:
    if not v:
        return defaut
    return datetime.fromisoformat(v.replace("Z", "+00:00"))


def _connecteur(session: Session, borne: Actif, connector_id: int) -> Actif:
    c = session.scalar(select(Actif).where(Actif.parent_id == borne.id, Actif.type_actif == "connecteur",
                                           Actif.code == f"{borne.code}-C{connector_id}"))
    if c is None:
        raise HTTPException(422, f"Connecteur {connector_id} inconnu pour {borne.code}")
    return c


def traiter_trame(session: Session, identifiant_borne: str, trame: list, recu_le: datetime | None = None) -> list:
    """Traite une trame OCPP-J ``[2, id, action, payload]`` et renvoie la réponse."""
    recu_le = recu_le or maintenant()
    # L'identifiant OCPP (chargePointId) est le code de la borne au référentiel
    borne = session.scalar(select(Actif).where(Actif.type_actif == "borne", Actif.code == identifiant_borne))
    if borne is None:
        raise HTTPException(404, "Borne inconnue")
    if not isinstance(trame, list) or len(trame) != 4 or trame[0] != 2:
        return [4, trame[1] if isinstance(trame, list) and len(trame) > 1 else "", "ProtocolError",
                "Trame CALL attendue", {}]
    _, mid, action, payload = trame
    payload_journal = dict(payload)
    if "idTag" in payload_journal:
        payload_journal["idTag"] = "[PSEUDONYMISÉ]"
    msg = MessageOCPP(borne_id=borne.id, recu_le=recu_le, type_message=2, identifiant_message=str(mid), action=action,
                      charge_utile=payload_journal, traitement="accepte")
    session.add(msg)
    etat = session.scalar(select(EtatCommunication).where(EtatCommunication.borne_id == borne.id))
    if etat is None:
        etat = EtatCommunication(borne_id=borne.id)
        session.add(etat)
    etat.derniere_communication = recu_le
    if action not in ACTIONS_SUPPORTEES:
        msg.traitement = "ignore_non_supporte"
        session.flush()
        return [4, mid, "NotSupported", f"Action {action} non prise en charge par ce prototype", {}]

    if action == "BootNotification":
        etat.boot_le, etat.firmware = recu_le, payload.get("firmwareVersion")
        rep = {"status": "Accepted", "currentTime": recu_le.isoformat(), "interval": etat.intervalle_heartbeat_s}
    elif action == "Heartbeat":
        etat.dernier_heartbeat = recu_le
        rep = {"currentTime": recu_le.isoformat()}
    elif action == "StatusNotification":
        cid = int(payload["connectorId"])
        if cid == 0:
            rep = {}
        else:
            c = _connecteur(session, borne, cid)
            session.add(EtatConnecteur(connecteur_id=c.id, statut_declare=payload["status"],
                                       code_erreur=payload.get("errorCode", "NoError"),
                                       declare_le=_dt(payload.get("timestamp"), recu_le), recu_le=recu_le))
            if payload["status"] == "Faulted":
                publier(session, "mobilite", f"Connecteur {c.code} en défaut ({payload.get('errorCode')})",
                        site_id=borne.site_id, connecteur=c.code)
            rep = {}
    elif action == "StartTransaction":
        c = _connecteur(session, borne, int(payload["connectorId"]))
        tarif = session.scalar(select(Tarif).where(Tarif.valide_de <= recu_le).order_by(Tarif.valide_de.desc()))
        n = (session.scalar(select(SessionRecharge.transaction_id).order_by(SessionRecharge.transaction_id.desc())
                            .limit(1)) or 1000) + 1
        s = SessionRecharge(borne_id=borne.id, connecteur_id=c.id, transaction_id=n,
                            badge_pseudonyme=hashlib.sha256(("e360:" + payload["idTag"]).encode()).hexdigest()[:16],
                            debut=_dt(payload.get("timestamp"), recu_le), index_debut_wh=float(payload["meterStart"]),
                            dernier_index_wh=float(payload["meterStart"]), tarif_id=tarif.id if tarif else None)
        session.add(s)
        session.flush()
        publier(session, "mobilite", f"Session {n} démarrée sur {c.code}", site_id=borne.site_id, session_id=s.id)
        rep = {"transactionId": n, "idTagInfo": {"status": "Accepted"}}
    elif action == "MeterValues":
        tid = payload.get("transactionId")
        s = session.scalar(select(SessionRecharge).where(SessionRecharge.transaction_id == tid)) if tid else None
        for mv in payload.get("meterValue", []):
            for sv in mv.get("sampledValue", []):
                mesurande = sv.get("measurand", "Energy.Active.Import.Register")
                if s and mesurande == "Energy.Active.Import.Register":
                    v = float(sv["value"]) * (1000 if sv.get("unit") == "kWh" else 1)
                    s.dernier_index_wh = max(s.dernier_index_wh or 0, v)
                if s and mesurande == "Power.Active.Import":
                    kw = float(sv["value"]) / (1 if sv.get("unit") == "kW" else 1000)
                    s.puissance_max_kw = max(s.puissance_max_kw or 0, kw)
        rep = {}
    else:  # StopTransaction
        s = session.scalar(select(SessionRecharge).where(SessionRecharge.transaction_id == payload["transactionId"]))
        if s is None:
            msg.traitement = "rejete"
            session.flush()
            return [4, mid, "PropertyConstraintViolation", "Transaction inconnue", {}]
        s.fin = _dt(payload.get("timestamp"), recu_le)
        s.index_fin_wh = float(payload["meterStop"])
        s.motif_arret = payload.get("reason", "Local")
        cloturer_session(session, s)
        publier(session, "mobilite", f"Session {s.transaction_id} terminée : {s.energie_kwh} kWh",
                site_id=borne.site_id, session_id=s.id)
        rep = {"idTagInfo": {"status": "Accepted"}}
    session.flush()
    return [3, mid, rep]


def cloturer_session(session: Session, s: SessionRecharge):
    if s.index_fin_wh is None or s.index_fin_wh < s.index_debut_wh:
        s.statut = "incomplete"
        s.detail_tarification = {"motif": "index de fin absent ou inférieur à l'index de début : énergie non facturable"}
        return
    s.energie_kwh = round((s.index_fin_wh - s.index_debut_wh) / 1000, 3)
    t = session.get(Tarif, s.tarif_id) if s.tarif_id else None
    if t is None:
        s.statut = "terminee"
        s.detail_tarification = {"motif": "aucun tarif applicable"}
        return
    minutes = (s.fin - s.debut).total_seconds() / 60
    montant = t.frais_session_ttc + s.energie_kwh * t.prix_kwh_ttc + minutes * t.prix_minute_ttc
    s.montant_ttc = round(montant, 2)
    s.detail_tarification = {"tarif": t.code, "energie_kwh": s.energie_kwh, "prix_kwh_ttc": t.prix_kwh_ttc,
                             "duree_min": round(minutes, 1), "prix_minute_ttc": t.prix_minute_ttc,
                             "frais_session_ttc": t.frais_session_ttc,
                             "formule": "frais + énergie × prix_kWh + durée × prix_minute",
                             "source_energie": "différence d'index meterStop − meterStart (Wh)"}
    s.statut = "terminee"
    session.add(PaiementRecharge(session_id=s.id, montant_ttc=s.montant_ttc, devise=t.devise, statut="capture",
                                 reference=f"PAY-SIM-{s.transaction_id}", le=s.fin))


def evaluer_connecteur(session: Session, c: Actif, instant: datetime | None = None) -> dict:
    """Un connecteur joignable n'est pas automatiquement disponible."""
    instant = instant or maintenant()
    borne = session.get(Actif, c.parent_id)
    com = session.scalar(select(EtatCommunication).where(EtatCommunication.borne_id == borne.id))
    etat = session.scalar(select(EtatConnecteur).where(EtatConnecteur.connecteur_id == c.id)
                          .order_by(EtatConnecteur.declare_le.desc(), EtatConnecteur.id.desc()))
    raisons = []
    joignable = bool(com and com.derniere_communication and
                     (instant - com.derniere_communication).total_seconds() <= 2 * com.intervalle_heartbeat_s)
    if not joignable:
        raisons.append("borne non joignable (aucune communication dans 2 intervalles de heartbeat)")
    ot_ouvert = session.scalar(select(OrdreTravail).where(OrdreTravail.actif_id.in_([c.id, borne.id]),
                                                          OrdreTravail.etat.notin_(["cloture", "annule"])))
    if ot_ouvert:
        raisons.append(f"ordre de travail ouvert {ot_ouvert.numero}")
    if etat is None:
        raisons.append("aucun état déclaré reçu")
        dispo = "indeterminee"
    elif not joignable:
        dispo = "indeterminee"
    elif etat.statut_declare == "Faulted" or etat.code_erreur != "NoError":
        raisons.append(f"état déclaré {etat.statut_declare} / {etat.code_erreur}")
        dispo = "indisponible"
    elif etat.statut_declare in ("Unavailable",):
        raisons.append("déclaré indisponible par la borne")
        dispo = "indisponible"
    elif ot_ouvert:
        dispo = "indisponible"
    elif etat.statut_declare == "Available":
        if (instant - etat.declare_le) > timedelta(hours=24):
            raisons.append("état « Available » datant de plus de 24 h : à confirmer")
            dispo = "a_confirmer"
        else:
            dispo = "disponible"
    else:
        dispo = "occupe" if etat.statut_declare in ("Charging", "Preparing", "SuspendedEV", "SuspendedEVSE",
                                                     "Finishing") else "indeterminee"
    return {"connecteur": c.code, "type": (c.attributs or {}).get("type"),
            "puissance_max_kw": (c.attributs or {}).get("puissance_max_kw"),
            "joignable": joignable, "derniere_communication": com.derniere_communication.isoformat()
            if com and com.derniere_communication else None,
            "statut_declare": etat.statut_declare if etat else None,
            "code_erreur": etat.code_erreur if etat else None,
            "declare_le": etat.declare_le.isoformat() if etat else None,
            "disponibilite_evaluee": dispo, "raisons": raisons,
            "regle": "disponible = joignable ∧ état déclaré Available récent (< 24 h) ∧ aucun défaut ∧ aucun OT ouvert"}


def detail_session(session: Session, s: SessionRecharge) -> dict:
    d = en_dict(s)
    d["paiements"] = [en_dict(p) for p in session.scalars(select(PaiementRecharge)
                                                         .where(PaiementRecharge.session_id == s.id))]
    d["messages_ocpp"] = [en_dict(m) for m in session.scalars(select(MessageOCPP).where(
        MessageOCPP.borne_id == s.borne_id, MessageOCPP.recu_le >= s.debut - timedelta(minutes=1),
        MessageOCPP.recu_le <= (s.fin or maintenant()) + timedelta(minutes=1)).order_by(MessageOCPP.id))]
    d["distinction"] = {"energie_delivree": "différence d'index du compteur de la borne",
                        "tarif": "grille datée appliquée", "paiement": "transaction simulée distincte"}
    return d
