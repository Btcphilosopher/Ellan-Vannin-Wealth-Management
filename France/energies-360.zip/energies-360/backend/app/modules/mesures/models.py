"""Mesures brutes (immuables), corrections/estimations séparées, lots d'ingestion
et alertes de qualité."""
from __future__ import annotations

from sqlalchemy import BigInteger, Float, ForeignKey, Index, Integer, String, Text, UniqueConstraint
from sqlalchemy.orm import Mapped, mapped_column

from ...db import Base, HorodatageUTC, JSONType, maintenant

_BIGINT = BigInteger().with_variant(Integer, "sqlite")


class LotIngestion(Base):
    __tablename__ = "lot_ingestion"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    source: Mapped[str] = mapped_column(String(60))
    mode: Mapped[str] = mapped_column(String(30), default="temps_reel")  # temps_reel | rejeu_simulation | import_fichier
    recu_le = mapped_column(HorodatageUTC, default=maintenant)
    depose_par: Mapped[str] = mapped_column(String(80))
    nb_recus: Mapped[int] = mapped_column(Integer, default=0)
    nb_inseres: Mapped[int] = mapped_column(Integer, default=0)
    nb_doublons_exacts: Mapped[int] = mapped_column(Integer, default=0)
    nb_doublons_conflictuels: Mapped[int] = mapped_column(Integer, default=0)
    nb_retards: Mapped[int] = mapped_column(Integer, default=0)
    nb_hors_bornes: Mapped[int] = mapped_column(Integer, default=0)
    nb_rejets: Mapped[int] = mapped_column(Integer, default=0)
    rejets = mapped_column(JSONType, default=list)
    cle_archive: Mapped[str | None] = mapped_column(String(300), nullable=True)
    sha256_archive: Mapped[str | None] = mapped_column(String(64), nullable=True)


class Observation(Base):
    """Observation brute telle que reçue. Jamais modifiée après insertion
    (seuls les indicateurs de qualité peuvent être complétés par l'analyse)."""

    __tablename__ = "observation"
    __table_args__ = (
        UniqueConstraint("point_mesure_id", "observe_le", "source", "empreinte_valeur", name="uq_observation_cle"),
        Index("ix_observation_point_temps", "point_mesure_id", "observe_le"),
    )
    id: Mapped[int] = mapped_column(_BIGINT, primary_key=True)
    point_mesure_id: Mapped[int] = mapped_column(ForeignKey("point_mesure.id"))
    actif_id: Mapped[int] = mapped_column(ForeignKey("actif.id"))
    grandeur: Mapped[str] = mapped_column(String(40))
    valeur: Mapped[float | None] = mapped_column(Float, nullable=True)
    valeur_texte: Mapped[str | None] = mapped_column(String(60), nullable=True)
    unite: Mapped[str] = mapped_column(String(20))
    valeur_normalisee: Mapped[float | None] = mapped_column(Float, nullable=True)  # dans l'unité du point
    observe_le = mapped_column(HorodatageUTC)
    ingere_le = mapped_column(HorodatageUTC)
    source: Mapped[str] = mapped_column(String(60))
    lot_id: Mapped[int | None] = mapped_column(ForeignKey("lot_ingestion.id"), nullable=True)
    empreinte_valeur: Mapped[str] = mapped_column(String(16))
    qualite = mapped_column(JSONType, default=list)  # ex. ["retard", "hors_bornes", "doublon_conflictuel"]


class Correction(Base):
    """Correction ou estimation, stockée à part des mesures brutes."""

    __tablename__ = "correction"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    point_mesure_id: Mapped[int] = mapped_column(ForeignKey("point_mesure.id"), index=True)
    observation_id: Mapped[int | None] = mapped_column(ForeignKey("observation.id"), nullable=True)
    debut = mapped_column(HorodatageUTC)
    fin = mapped_column(HorodatageUTC)
    valeur: Mapped[float] = mapped_column(Float)
    unite: Mapped[str] = mapped_column(String(20))
    nature: Mapped[str] = mapped_column(String(20))  # correction | estimation | substitution
    methode: Mapped[str] = mapped_column(Text)
    justification: Mapped[str] = mapped_column(Text)
    observations_sources = mapped_column(JSONType, default=list)
    statut: Mapped[str] = mapped_column(String(20), default="proposee")  # proposee | validee | rejetee
    auteur: Mapped[str] = mapped_column(String(80))
    valide_par: Mapped[str | None] = mapped_column(String(80), nullable=True)
    cree_le = mapped_column(HorodatageUTC, default=maintenant)


class Alerte(Base):
    __tablename__ = "alerte"
    __table_args__ = (UniqueConstraint("type", "point_mesure_id", "actif_id", "debut", name="uq_alerte_cle"),)
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    type: Mapped[str] = mapped_column(String(40))
    gravite: Mapped[str] = mapped_column(String(20))  # information | avertissement | critique
    site_id: Mapped[int] = mapped_column(ForeignKey("site.id"), index=True)
    actif_id: Mapped[int | None] = mapped_column(ForeignKey("actif.id"), nullable=True)
    point_mesure_id: Mapped[int | None] = mapped_column(ForeignKey("point_mesure.id"), nullable=True)
    debut = mapped_column(HorodatageUTC)
    fin = mapped_column(HorodatageUTC, nullable=True)
    titre: Mapped[str] = mapped_column(String(240))
    message: Mapped[str] = mapped_column(Text)
    regle: Mapped[str] = mapped_column(Text)
    details = mapped_column(JSONType, default=dict)
    statut: Mapped[str] = mapped_column(String(20), default="ouverte")
    acquittee_par: Mapped[str | None] = mapped_column(String(80), nullable=True)
    ordre_travail_id: Mapped[int | None] = mapped_column(Integer, nullable=True)
    cree_le = mapped_column(HorodatageUTC, default=maintenant)
