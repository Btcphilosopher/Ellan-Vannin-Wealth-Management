"""Règles transparentes de qualité des données.

Chaque règle est décrite en clair dans ``REGLES`` ; chaque alerte reprend le
texte de la règle appliquée et les observations concernées.
"""
from __future__ import annotations

from datetime import datetime, timedelta

from sqlalchemy import select
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session

from ...core.services import publier
from ...db import maintenant
from ..patrimoine.models import Actif, PointMesure
from .energie import observations_valides
from .models import Alerte, Observation

REGLES = {
    "donnees_manquantes": "Au moins 2 pas consécutifs attendus sans observation valide.",
    "capteur_perime": "Dernière observation plus ancienne que le seuil de péremption du point à l'instant "
                      "de référence.",
    "valeur_figee": "Éclairement ou température : au moins 4 valeurs successives strictement identiques et "
                    "non nulles (signal physique censé fluctuer).",
    "hors_bornes": "Valeur hors des bornes physiques déclarées au référentiel (observation conservée, exclue "
                   "des agrégats).",
    "compteur_reinitialise": "Index cumulatif décroissant entre deux observations successives.",
    "doublon_conflictuel": "Même point, même horodatage, même source, valeurs différentes ; la première reçue "
                           "est retenue pour les agrégats.",
    "retard": "Ingestion plus de 15 minutes après l'heure d'observation.",
    "panne_equipement": "État déclaré « defaut » par l'équipement.",
}


def _alerte(session: Session, **champs) -> Alerte | None:
    existante = session.scalar(select(Alerte).where(
        Alerte.type == champs["type"], Alerte.point_mesure_id == champs.get("point_mesure_id"),
        Alerte.actif_id == champs.get("actif_id"), Alerte.debut == champs["debut"]))
    if existante:
        if champs.get("fin") and existante.fin != champs["fin"]:
            existante.fin = champs["fin"]
        return None
    a = Alerte(regle=REGLES[champs["type"]], cree_le=maintenant(), **champs)
    try:
        with session.begin_nested():
            session.add(a)
            session.flush()
    except IntegrityError:
        return None
    publier(session, "alerte", f"[{a.gravite.upper()}] {a.titre}", site_id=a.site_id, alerte_id=a.id, type=a.type)
    return a


def analyser_point(session: Session, pt: PointMesure, debut: datetime, fin: datetime,
                   instant_reference: datetime | None = None, inclure_retard: bool = True) -> list[Alerte]:
    actif = session.get(Actif, pt.actif_id)
    site_id = actif.site_id
    ref = instant_reference or fin
    nouvelles: list[Alerte] = []
    toutes = session.scalars(select(Observation).where(
        Observation.point_mesure_id == pt.id, Observation.observe_le >= debut, Observation.observe_le <= fin)
        .order_by(Observation.observe_le, Observation.id)).all()
    valides = observations_valides(session, pt.id, debut, fin)
    pas = timedelta(seconds=pt.pas_attendu_s)
    base = dict(site_id=site_id, actif_id=actif.id, point_mesure_id=pt.id)

    # Données manquantes (trous ≥ 2 pas)
    for a, b in zip(valides, valides[1:]):
        manque = int((b.observe_le - a.observe_le) / pas) - 1
        if manque >= 2:
            nouvelles.append(_alerte(session, type="donnees_manquantes", gravite="avertissement",
                                     debut=a.observe_le + pas, fin=b.observe_le,
                                     titre=f"Télémétrie interrompue — {pt.code}",
                                     message=(f"{manque} pas de {pt.pas_attendu_s // 60} min sans donnée entre "
                                              f"{a.observe_le:%d/%m %H:%M} et {b.observe_le:%d/%m %H:%M} UTC. "
                                              "La production de cet intervalle n'est pas nulle : elle est inconnue."),
                                     details={"pas_manquants": manque, "derniere_avant": a.id,
                                              "premiere_apres": b.id}, **base))

    # Capteur périmé
    dernier = valides[-1] if valides else None
    if dernier is None or (ref - dernier.observe_le).total_seconds() > pt.seuil_peremption_s:
        depuis = dernier.observe_le if dernier else debut
        nouvelles.append(_alerte(session, type="capteur_perime", gravite="critique" if pt.grandeur in
                                 ("irradiance", "energie") else "avertissement", debut=depuis, fin=None,
                                 titre=f"Capteur périmé — {pt.code}",
                                 message=(f"Aucune observation valide depuis {depuis:%d/%m/%Y %H:%M} UTC "
                                          f"(seuil {pt.seuil_peremption_s // 60} min). Les indicateurs dépendants "
                                          "sont marqués « indéterminés »."),
                                 details={"derniere_observation_id": dernier.id if dernier else None,
                                          "instant_reference": ref.isoformat()}, **base))

    # Valeur figée
    if pt.grandeur in ("irradiance", "temperature") and pt.type_signal == "instantane":
        serie, debut_serie = 1, None
        for a, b in zip(valides, valides[1:]):
            if b.valeur_normalisee == a.valeur_normalisee and a.valeur_normalisee not in (0, None):
                serie += 1
                debut_serie = debut_serie or a
            else:
                if serie >= 4 and debut_serie is not None:
                    nouvelles.append(_figee(session, pt, base, debut_serie, a, serie))
                serie, debut_serie = 1, None
        if serie >= 4 and debut_serie is not None:
            nouvelles.append(_figee(session, pt, base, debut_serie, valides[-1], serie))

    # Hors bornes
    hb = [o for o in toutes if "hors_bornes" in (o.qualite or [])]
    if hb:
        nouvelles.append(_alerte(session, type="hors_bornes", gravite="avertissement", debut=hb[0].observe_le,
                                 fin=hb[-1].observe_le, titre=f"Valeurs incohérentes — {pt.code}",
                                 message=(f"{len(hb)} valeur(s) hors bornes [{pt.borne_min} ; {pt.borne_max}] "
                                          f"{pt.unite}. Conservées en brut, exclues des agrégats."),
                                 details={"observation_ids": [o.id for o in hb][:50]}, **base))

    # Remise à zéro de compteur
    if pt.type_signal == "cumul":
        for a, b in zip(valides, valides[1:]):
            if b.valeur_normalisee < a.valeur_normalisee:
                nouvelles.append(_alerte(session, type="compteur_reinitialise", gravite="avertissement",
                                         debut=b.observe_le, fin=b.observe_le,
                                         titre=f"Compteur réinitialisé — {pt.code}",
                                         message=(f"Index passé de {a.valeur_normalisee:.1f} à "
                                                  f"{b.valeur_normalisee:.1f} {pt.unite} à {b.observe_le:%d/%m %H:%M} UTC. "
                                                  "Énergie recalculée depuis 0 ; aucune énergie négative comptée."),
                                         details={"observation_ids": [a.id, b.id]}, **base))

    # Doublons conflictuels
    dc = [o for o in toutes if "doublon_conflictuel" in (o.qualite or [])]
    if dc:
        nouvelles.append(_alerte(session, type="doublon_conflictuel", gravite="information",
                                 debut=dc[0].observe_le, fin=dc[-1].observe_le,
                                 titre=f"Doublons conflictuels — {pt.code}",
                                 message=f"{len(dc)} observation(s) en conflit ; première valeur reçue retenue.",
                                 details={"observation_ids": [o.id for o in dc][:50]}, **base))

    # Retards (regroupés par site dans analyser_site)
    rt = [o for o in toutes if "retard" in (o.qualite or [])] if inclure_retard else []
    if rt:
        nouvelles.append(_alerte(session, type="retard", gravite="information", debut=rt[0].observe_le,
                                 fin=rt[-1].observe_le, titre=f"Données reçues en retard — {pt.code}",
                                 message=f"{len(rt)} observation(s) ingérées plus de 15 min après observation.",
                                 details={"retard_max_min": round(max((o.ingere_le - o.observe_le).total_seconds()
                                                                      for o in rt) / 60, 1)}, **base))

    # Panne équipement (états)
    if pt.type_signal == "etat":
        en_defaut = None
        for o in valides:
            if o.valeur_texte == "defaut" and en_defaut is None:
                en_defaut = o
            elif o.valeur_texte != "defaut" and en_defaut is not None:
                nouvelles.append(_panne(session, pt, base, en_defaut, o.observe_le))
                en_defaut = None
        if en_defaut is not None:
            nouvelles.append(_panne(session, pt, base, en_defaut, None))
    return [a for a in nouvelles if a is not None]


def _figee(session, pt, base, a, b, n):
    return _alerte(session, type="valeur_figee", gravite="avertissement", debut=a.observe_le, fin=b.observe_le,
                   titre=f"Valeur figée — {pt.code}",
                   message=(f"{n} valeurs identiques ({a.valeur_normalisee} {pt.unite}) de {a.observe_le:%d/%m %H:%M} "
                            f"à {b.observe_le:%H:%M} UTC : capteur probablement bloqué."),
                   details={"valeur": a.valeur_normalisee, "nombre": n}, **base)


def _panne(session, pt, base, o, fin):
    duree = f" jusqu'à {fin:%d/%m %H:%M} UTC" if fin else " (toujours en cours)"
    return _alerte(session, type="panne_equipement", gravite="critique", debut=o.observe_le, fin=fin,
                   titre=f"Équipement en défaut — {pt.code.rsplit('-', 1)[0]}",
                   message=f"État « défaut » déclaré depuis {o.observe_le:%d/%m %H:%M} UTC{duree}.",
                   details={"observation_id": o.id}, **base)


def analyser_site(session: Session, site_id: int, debut: datetime, fin: datetime,
                  instant_reference: datetime | None = None) -> list[Alerte]:
    res = []
    pts = list(session.scalars(select(PointMesure).join(Actif, PointMesure.actif_id == Actif.id)
                               .where(Actif.site_id == site_id, PointMesure.actif_flag.is_(True))))
    for pt in pts:
        res.extend(analyser_point(session, pt, debut, fin, instant_reference, inclure_retard=False))
    rt = session.scalars(select(Observation).where(Observation.point_mesure_id.in_([p.id for p in pts]),
                                                   Observation.observe_le >= debut, Observation.observe_le <= fin)
                         .order_by(Observation.observe_le)).all()
    rt = [o for o in rt if "retard" in (o.qualite or [])]
    if rt:
        a = _alerte(session, type="retard", gravite="information", debut=rt[0].observe_le, fin=rt[-1].observe_le,
                    site_id=site_id, actif_id=None, point_mesure_id=None,
                    titre="Données reçues en retard",
                    message=(f"{len(rt)} observation(s) sur {len({o.point_mesure_id for o in rt})} point(s) ingérées plus "
                             f"de 15 min après observation (retard max "
                             f"{max((o.ingere_le - o.observe_le).total_seconds() for o in rt) / 60:.0f} min). "
                             "Valeurs conservées ; indicateurs temps réel de la période concernée tardifs."),
                    details={"lots": sorted({o.lot_id for o in rt})})
        if a:
            res.append(a)
    return res
