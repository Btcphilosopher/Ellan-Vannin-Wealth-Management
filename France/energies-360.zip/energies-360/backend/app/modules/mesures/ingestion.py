"""Ingestion des observations : contrôle d'unité, déduplication, retards,
bornes physiques, archivage brut du lot dans le stockage objet."""
from __future__ import annotations

import hashlib
from collections import defaultdict
from datetime import datetime, timedelta

from fastapi import HTTPException
from sqlalchemy import select
from sqlalchemy.orm import Session

from ...config import parametres
from ...core.services import json_stable, stockage
from ...db import maintenant
from ...unites.dimensions import ErreurDimensionnelle, Quantite, unite
from ..patrimoine.models import PointMesure
from .models import LotIngestion, Observation


def _empreinte(valeur, valeur_texte) -> str:
    base = f"{valeur!r}|{valeur_texte or ''}" if valeur is None else f"{round(float(valeur), 9)!r}|{valeur_texte or ''}"
    return hashlib.sha256(base.encode()).hexdigest()[:16]


def _horodatage(v) -> datetime:
    if isinstance(v, datetime):
        d = v
    else:
        d = datetime.fromisoformat(str(v).replace("Z", "+00:00"))
    if d.tzinfo is None:
        raise ValueError("horodatage sans fuseau horaire")
    return d


def ingerer(session: Session, mesures: list[dict], source: str, auteur: str, mode: str = "temps_reel",
            recu_le: datetime | None = None) -> LotIngestion:
    p = parametres()
    if len(mesures) > p.ingestion_lot_max:
        raise HTTPException(413, f"Lot trop volumineux ({len(mesures)} > {p.ingestion_lot_max} observations)")
    if mode == "rejeu_simulation" and recu_le is None:
        raise HTTPException(422, "Le rejeu simulé exige l'horodatage de réception simulé")
    ingere_le = recu_le if mode == "rejeu_simulation" else maintenant()

    brut = json_stable({"source": source, "mode": mode, "mesures": mesures}).encode()
    cle, h = stockage().deposer("ingestion", f"lot_{source}.json", brut)
    lot = LotIngestion(source=source, mode=mode, recu_le=ingere_le, depose_par=auteur, nb_recus=len(mesures),
                       cle_archive=cle, sha256_archive=h, rejets=[])
    session.add(lot)
    session.flush()

    points = {pt.code: pt for pt in session.scalars(select(PointMesure))}
    points_par_id = {pt.id: pt for pt in points.values()}
    # Pré-chargement des clés existantes par point sur la plage concernée
    par_point: dict[int, list[tuple[int, dict]]] = defaultdict(list)
    rejets = []
    for i, m in enumerate(mesures):
        pt = points.get(m.get("point")) or points_par_id.get(m.get("point_mesure_id"))
        if pt is None:
            rejets.append({"index": i, "motif": "point de mesure inconnu"})
            continue
        par_point[pt.id].append((i, m))

    seuil = timedelta(seconds=p.seuil_retard_s)
    for pid, items in par_point.items():
        pt = points_par_id[pid]
        try:
            u_point = unite(pt.unite)
        except ErreurDimensionnelle:
            u_point = None
        instants = []
        for i, m in items:
            try:
                instants.append(_horodatage(m["observe_le"]))
            except (KeyError, ValueError):
                pass
        existants: dict[tuple, Observation] = {}
        if instants:
            for o in session.scalars(select(Observation).where(
                    Observation.point_mesure_id == pid, Observation.observe_le >= min(instants),
                    Observation.observe_le <= max(instants))):
                existants.setdefault((o.observe_le, o.source), o)
                existants[(o.observe_le, o.source, o.empreinte_valeur)] = o
        for i, m in items:
            try:
                t = _horodatage(m["observe_le"])
            except (KeyError, ValueError) as e:
                rejets.append({"index": i, "motif": f"horodatage invalide : {e}"})
                continue
            if t > ingere_le + timedelta(minutes=5):
                rejets.append({"index": i, "motif": "observation datée dans le futur"})
                continue
            valeur, vtexte, u = m.get("valeur"), m.get("valeur_texte"), m.get("unite") or pt.unite
            norm = None
            if pt.type_signal != "etat":
                if valeur is None:
                    rejets.append({"index": i, "motif": "valeur absente (une absence n'est pas un zéro)"})
                    continue
                try:
                    q = Quantite(float(valeur), u, pt.nature_grandeur)
                    norm = q.vers(pt.unite).valeur if u_point else float(valeur)
                except (ErreurDimensionnelle, ValueError) as e:
                    rejets.append({"index": i, "motif": f"unité incompatible : {e}"})
                    continue
            src = m.get("source") or source
            emp = _empreinte(valeur, vtexte)
            if (t, src, emp) in existants:
                lot.nb_doublons_exacts += 1
                continue
            qualite = []
            conflit = existants.get((t, src))
            if conflit is not None:
                qualite.append("doublon_conflictuel")
                if "doublon_conflictuel" not in (conflit.qualite or []):
                    conflit.qualite = [*(conflit.qualite or []), "doublon_conflictuel"]
                lot.nb_doublons_conflictuels += 1
            if ingere_le - t > seuil:
                qualite.append("retard")
                lot.nb_retards += 1
            if norm is not None and ((pt.borne_min is not None and norm < pt.borne_min) or
                                     (pt.borne_max is not None and norm > pt.borne_max)):
                qualite.append("hors_bornes")
                lot.nb_hors_bornes += 1
            o = Observation(point_mesure_id=pid, actif_id=pt.actif_id, grandeur=pt.grandeur,
                            valeur=None if valeur is None else float(valeur), valeur_texte=vtexte, unite=u,
                            valeur_normalisee=norm, observe_le=t, ingere_le=ingere_le, source=src, lot_id=lot.id,
                            empreinte_valeur=emp, qualite=qualite)
            session.add(o)
            existants[(t, src, emp)] = o
            existants.setdefault((t, src), o)
            lot.nb_inseres += 1
    lot.nb_rejets = len(rejets)
    lot.rejets = rejets[:200]
    session.flush()
    return lot
