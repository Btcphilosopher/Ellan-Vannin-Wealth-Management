"""Calculs d'énergie, séries agrégées et bilans de site.

Règles :

* l'énergie d'un périmètre provient **uniquement** du compteur principal de ce
  périmètre sur le site ; les compteurs de contrôle (onduleurs) servent au
  recoupement et ne sont jamais additionnés ;
* une absence de données n'est jamais remplacée par zéro : la couverture est
  publiée et les intervalles manquants restent ``None`` ;
* une remise à zéro de compteur est détectée ; l'énergie non mesurée autour de
  la remise à zéro est publiée séparément comme estimation, jamais fusionnée.
"""
from __future__ import annotations

from collections import defaultdict
from datetime import datetime, timedelta

from sqlalchemy import select
from sqlalchemy.orm import Session

from ...unites.dimensions import Quantite
from ..patrimoine.models import Actif, PointMesure, Site
from .models import Observation

EXCLUS = {"hors_bornes"}  # observations exclues des agrégats (conservées en base)


def observations_valides(session: Session, point_id: int, debut: datetime, fin: datetime) -> list[Observation]:
    """Observations utilisables : hors bornes exclues ; en cas de doublon
    conflictuel, la première reçue est retenue (règle documentée)."""
    obs = session.scalars(select(Observation).where(
        Observation.point_mesure_id == point_id, Observation.observe_le >= debut,
        Observation.observe_le <= fin).order_by(Observation.observe_le, Observation.id)).all()
    res, vus = [], set()
    for o in obs:
        if set(o.qualite or []) & EXCLUS:
            continue
        if o.observe_le in vus:
            continue
        vus.add(o.observe_le)
        res.append(o)
    return res


def _grille(debut: datetime, fin: datetime, pas: int) -> list[datetime]:
    res, t = [], debut
    while t < fin:
        res.append(t)
        t += timedelta(seconds=pas)
    return res


def energie_compteur(session: Session, point: PointMesure, debut: datetime, fin: datetime) -> dict:
    """Énergie à partir d'un index cumulatif (kWh) entre ``debut`` et ``fin``."""
    obs = observations_valides(session, point.id, debut, fin)
    pas = timedelta(seconds=point.pas_attendu_s)
    if len(obs) < 2:
        return {"point": point.code, "valeur": None, "unite": "kWh", "statut": "indetermine",
                "methode": "différence d'index", "couverture_pct": 0.0,
                "avertissements": ["Moins de deux index valides : énergie indéterminée (≠ 0)"]}
    total, resets, trous, estim = 0.0, [], [], 0.0
    for a, b in zip(obs, obs[1:]):
        va, vb = a.valeur_normalisee, b.valeur_normalisee
        if vb >= va:
            total += vb - va
        else:
            # remise à zéro : l'index b mesure l'énergie depuis la remise à zéro
            total += vb
            resets.append({"avant": a.observe_le.isoformat(), "apres": b.observe_le.isoformat(),
                           "index_avant": va, "index_apres": vb, "observation_ids": [a.id, b.id]})
        if b.observe_le - a.observe_le > pas * 1.5:
            trous.append({"de": a.observe_le.isoformat(), "a": b.observe_le.isoformat()})
    attendus = len(_grille(debut, fin, point.pas_attendu_s)) + 1
    couverture = min(100.0, 100.0 * len(obs) / attendus)
    av, statut = [], "complet"
    if obs[0].observe_le - debut > pas or fin - obs[-1].observe_le > pas:
        statut = "incomplet"
        av.append("Index absents en début ou fin de période : énergie partielle sur la période mesurée")
    if trous:
        av.append(f"{len(trous)} interruption(s) de télémétrie : total connu par différence d'index, profil "
                  "intra-période inconnu")
    if resets:
        statut = "complet_avec_reserve" if statut == "complet" else statut
        av.append(f"{len(resets)} remise(s) à zéro détectée(s) : l'énergie entre le dernier index avant remise "
                  "à zéro et la remise à zéro n'est pas mesurée par ce compteur (voir estimation séparée)")
    return {"point": point.code, "point_id": point.id, "valeur": round(total, 3), "unite": "kWh",
            "nature": point.nature_grandeur, "statut": statut, "methode": "somme des différences d'index positives ; "
            "remise à zéro : index après remise à zéro compté depuis 0", "couverture_index_pct": round(couverture, 2),
            "remises_a_zero": resets, "interruptions": trous, "avertissements": av,
            "periode": {"debut": debut.isoformat(), "fin": fin.isoformat()},
            "observations_utilisees": len(obs), "premiere_observation_id": obs[0].id,
            "derniere_observation_id": obs[-1].id}


def energie_puissance(session: Session, point: PointMesure, debut: datetime, fin: datetime) -> dict:
    """Énergie par intégration d'une puissance moyenne par pas (rectangle à gauche)."""
    obs = {o.observe_le: o for o in observations_valides(session, point.id, debut, fin)}
    grille = _grille(debut, fin, point.pas_attendu_s)
    h = point.pas_attendu_s / 3600
    total, presents, manquants = 0.0, 0, []
    for t in grille:
        o = obs.get(t)
        if o is None:
            manquants.append(t)
            continue
        presents += 1
        total += Quantite(o.valeur_normalisee, point.unite, point.nature_grandeur or "electrique").vers("kW").valeur * h
    couverture = 100.0 * presents / len(grille) if grille else 0.0
    statut = "complet" if presents == len(grille) else ("indetermine" if presents == 0 else "incomplet")
    return {"point": point.code, "point_id": point.id, "valeur": round(total, 3) if presents else None,
            "unite": "kWh", "nature": point.nature_grandeur, "statut": statut, "couverture_pct": round(couverture, 2),
            "intervalles_manquants": len(manquants), "methode": f"Σ P(t) × {point.pas_attendu_s} s ; intervalles sans "
            "donnée exclus (non comptés comme zéro)", "avertissements":
            [] if statut == "complet" else [f"{len(manquants)} intervalle(s) sans donnée : valeur partielle"]}


def energie_point(session, point, debut, fin) -> dict:
    if point.type_signal == "cumul":
        return energie_compteur(session, point, debut, fin)
    return energie_puissance(session, point, debut, fin)


def serie(session: Session, point: PointMesure, debut: datetime, fin: datetime, pas_s: int) -> dict:
    """Série agrégée par pas ; ``None`` si aucune donnée (pas de zéro implicite)."""
    obs = observations_valides(session, point.id, debut, fin)
    seaux: dict[datetime, list[Observation]] = defaultdict(list)
    for o in obs:
        k = debut + timedelta(seconds=((o.observe_le - debut).total_seconds() // pas_s) * pas_s)
        seaux[k].append(o)
    attendus = max(1, pas_s // point.pas_attendu_s)
    points = []
    prec = None
    for t in _grille(debut, fin, pas_s):
        lot = seaux.get(t, [])
        if point.type_signal == "etat":
            v = lot[-1].valeur_texte if lot else None
        elif not lot:
            v = None
        elif point.type_signal == "cumul":
            dernier = lot[-1].valeur_normalisee
            v = None if prec is None else (dernier - prec if dernier >= prec else dernier)
            prec = dernier
        else:
            v = sum(o.valeur_normalisee for o in lot) / len(lot)
        if point.type_signal == "cumul" and not lot:
            prec = None
        points.append({"t": t.isoformat(), "v": None if v is None else (round(v, 4) if isinstance(v, float) else v),
                       "n": len(lot), "couverture_pct": round(min(100.0, 100 * len(lot) / attendus), 1),
                       "qualite": sorted({q for o in lot for q in (o.qualite or [])})})
    return {"point": point.code, "grandeur": point.grandeur,
            "unite": ("kWh / pas" if point.type_signal == "cumul" else point.unite),
            "agregation": {"cumul": "différence d'index par pas", "instantane": "moyenne des échantillons du pas",
                           "etat": "dernier état du pas"}[point.type_signal], "pas_s": pas_s, "points": points}


PERIMETRES_BILAN = ("production_pv", "decharge_batterie", "charge_batterie", "injection_reseau", "soutirage_reseau")


def points_principaux(session: Session, site_id: int) -> dict[str, PointMesure]:
    res = {}
    for pt in session.scalars(select(PointMesure).join(Actif, PointMesure.actif_id == Actif.id).where(
            Actif.site_id == site_id, PointMesure.role_comptage == "principal", PointMesure.grandeur == "energie")):
        res[pt.perimetre_comptage] = pt
    return res


def bilan_site(session: Session, site_id: int, debut: datetime, fin: datetime) -> dict:
    """Bilan électrique : production + décharge − charge − injection + soutirage
    = pertes et consommations auxiliaires non mesurées (écart publié tel quel)."""
    site = session.get(Site, site_id)
    pp = points_principaux(session, site_id)
    termes = {}
    for per in PERIMETRES_BILAN:
        if per in pp:
            termes[per] = energie_point(session, pp[per], debut, fin)
    if "production_pv" not in termes and "injection_reseau" not in termes:
        return {"site_id": site_id, "site": site.nom, "applicable": False,
                "message": "Aucun compteur principal électrique sur ce site"}
    v = {k: (t["valeur"] if t["valeur"] is not None else None) for k, t in termes.items()}
    indetermine = any(x is None for x in v.values())
    ecart = None
    if not indetermine:
        ecart = (v.get("production_pv", 0) + v.get("decharge_batterie", 0) - v.get("charge_batterie", 0)
                 - v.get("injection_reseau", 0) + v.get("soutirage_reseau", 0))
    prod = v.get("production_pv") or 0
    controle = []
    for pt in session.scalars(select(PointMesure).join(Actif, PointMesure.actif_id == Actif.id).where(
            Actif.site_id == site_id, PointMesure.role_comptage == "controle", PointMesure.grandeur == "energie")):
        e = energie_point(session, pt, debut, fin)
        controle.append({"point": pt.code, "perimetre": pt.perimetre_comptage, "valeur_kwh": e["valeur"],
                         "statut": e["statut"], "avertissements": e["avertissements"],
                         "remises_a_zero": e.get("remises_a_zero", [])})
    somme_ctrl = sum(c["valeur_kwh"] or 0 for c in controle if c["perimetre"] == "production_pv")
    statuts = {t["statut"] for t in termes.values()}
    return {
        "site_id": site_id, "site": site.nom, "applicable": True,
        "periode": {"debut": debut.isoformat(), "fin": fin.isoformat()},
        "termes": termes,
        "equation": "production_pv + decharge_batterie − charge_batterie − injection_reseau + soutirage_reseau "
                    "= pertes et auxiliaires non mesurés",
        "ecart_kwh": None if ecart is None else round(ecart, 3),
        "ecart_pct_production": None if ecart is None or not prod else round(100 * ecart / prod, 3),
        "interpretation_ecart": (
            "Indéterminé : un terme au moins est sans donnée." if ecart is None else
            "Écart négatif : incohérence de comptage à investiguer." if ecart < 0 else
            "Écart > 5 % de la production : à investiguer." if prod and ecart / prod > 0.05 else
            "Écart compatible avec pertes de transformation et auxiliaires (non mesurés, non ajustés)."),
        "statut": "indetermine" if indetermine else ("complet" if statuts == {"complet"} else "avec_reserves"),
        "controle": {"compteurs": controle, "somme_controle_production_kwh": round(somme_ctrl, 3),
                     "ecart_controle_vs_principal_pct": (round(100 * (somme_ctrl - prod) / prod, 3) if prod else None),
                     "note": "Compteurs de contrôle utilisés pour recoupement uniquement ; jamais additionnés."},
    }


def energie_portefeuille(session: Session, perimetre: str, debut: datetime, fin: datetime,
                         sites_autorises: set[int] | None) -> dict:
    lignes, exclus, total, indet = [], [], 0.0, False
    for pt, site_id in session.execute(select(PointMesure, Actif.site_id).join(Actif, PointMesure.actif_id == Actif.id)
                                       .where(PointMesure.grandeur == "energie",
                                              PointMesure.perimetre_comptage == perimetre)).all():
        if sites_autorises is not None and site_id not in sites_autorises:
            continue
        if pt.role_comptage != "principal":
            exclus.append({"point": pt.code, "role": pt.role_comptage,
                           "motif": "compteur de contrôle / sous-comptage : inclus dans le compteur principal"})
            continue
        e = energie_point(session, pt, debut, fin)
        lignes.append({"site_id": site_id, "point": pt.code, "valeur_kwh": e["valeur"], "statut": e["statut"],
                       "avertissements": e["avertissements"]})
        if e["valeur"] is None:
            indet = True
        else:
            total += e["valeur"]
    return {"perimetre": perimetre, "valeur": round(total, 3), "unite": "kWh",
            "statut": "partiel" if indet else "complet",
            "methode": "Σ des compteurs principaux (un par site et par périmètre, unicité contrôlée au référentiel)",
            "sites": lignes, "points_exclus": exclus}
