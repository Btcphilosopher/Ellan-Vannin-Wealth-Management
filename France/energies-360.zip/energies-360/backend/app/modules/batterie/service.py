"""État observé d'une batterie et simulation de charge / décharge sous contraintes.

Modèle de stock d'énergie (pas Δt en heures) :
    E[t+1] = E[t] + η_c · P_c · Δt − P_d · Δt / η_d
avec 0 ≤ P_c ≤ P_c,max, 0 ≤ P_d ≤ P_d,max, P_c · P_d = 0,
E_min = SoC_min · E_nom ≤ E ≤ SoC_max · E_nom = E_max.
"""
from __future__ import annotations

from datetime import datetime, timedelta

from fastapi import HTTPException
from sqlalchemy import select
from sqlalchemy.orm import Session

from ..mesures.energie import observations_valides
from ..patrimoine.models import PointMesure
from .models import ParametresBatterie, ScenarioSimulation

AVERTISSEMENT = ("Scénario simulé, isolé des opérations observées. Les revenus affichés sont des estimations "
                 "fondées sur des prix indicatifs simulés : ils ne constituent ni un résultat commercial ni une "
                 "garantie.")


def parametres_actifs(session: Session, actif_id: int, instant: datetime) -> ParametresBatterie:
    p = session.scalar(select(ParametresBatterie).where(ParametresBatterie.actif_id == actif_id,
                                                        ParametresBatterie.date_effet_debut <= instant)
                       .order_by(ParametresBatterie.date_effet_debut.desc()))
    if p is None:
        raise HTTPException(404, "Paramètres de batterie absents")
    return p


def etat_observe(session: Session, actif_id: int, instant: datetime) -> dict:
    p = parametres_actifs(session, actif_id, instant)
    pts = {pt.grandeur: pt for pt in session.scalars(select(PointMesure).where(PointMesure.actif_id == actif_id))}
    res = {"parametres": {"energie_nominale_kwh": p.energie_nominale_kwh, "p_charge_max_kw": p.puissance_charge_max_kw,
                          "p_decharge_max_kw": p.puissance_decharge_max_kw, "soc_min_pct": p.soc_min_pct,
                          "soc_max_pct": p.soc_max_pct, "rendement_charge": p.rendement_charge,
                          "rendement_decharge": p.rendement_decharge, "temperature_max_c": p.temperature_max_c,
                          "provenance": p.provenance}}
    for g in ("soc", "puissance", "temperature"):
        pt = pts.get(g)
        if not pt:
            continue
        obs = observations_valides(session, pt.id, instant - timedelta(hours=6), instant)
        if not obs:
            res[g] = {"valeur": None, "statut": "indetermine", "message": "aucune observation récente"}
            continue
        o = obs[-1]
        age = (instant - o.observe_le).total_seconds()
        res[g] = {"valeur": o.valeur_normalisee, "unite": pt.unite, "observe_le": o.observe_le.isoformat(),
                  "age_s": int(age), "qualite": o.qualite, "perime": age > pt.seuil_peremption_s}
    soc = res.get("soc", {}).get("valeur")
    if soc is not None and not res["soc"]["perime"]:
        res["energie_disponible_decharge_kwh"] = {
            "valeur": round(max(0.0, (soc - p.soc_min_pct) / 100 * p.energie_nominale_kwh * p.rendement_decharge), 1),
            "methode": "(SoC − SoC_min) × E_nom × η_décharge", "nature": "calculee"}
        res["capacite_de_charge_restante_kwh"] = {
            "valeur": round(max(0.0, (p.soc_max_pct - soc) / 100 * p.energie_nominale_kwh / p.rendement_charge), 1),
            "methode": "(SoC_max − SoC) × E_nom / η_charge (énergie à fournir côté réseau)", "nature": "calculee"}
    else:
        res["energie_disponible_decharge_kwh"] = {"valeur": None, "statut": "indetermine",
                                                  "message": "SoC absent ou périmé : énergie disponible non calculée"}
    t = res.get("temperature", {}).get("valeur")
    res["limites"] = {"temperature_depassee": bool(t is not None and t > p.temperature_max_c)}
    return res


def simuler(p: dict, prix: list[float], pas_h: float = 1.0, soc_initial_pct: float = 50.0,
            n_cycles_max_par_jour: float = 1.0) -> dict:
    """Arbitrage heuristique transparent : charge aux heures les moins chères,
    décharge aux plus chères, dans les limites physiques ; aucune optimisation
    opaque. Retourne la trajectoire et les vérifications d'invariants."""
    e_nom = p["energie_nominale_kwh"]
    e_min, e_max = p["soc_min_pct"] / 100 * e_nom, p["soc_max_pct"] / 100 * e_nom
    pc_max, pd_max = p["puissance_charge_max_kw"], p["puissance_decharge_max_kw"]
    eta_c, eta_d = p["rendement_charge"], p["rendement_decharge"]
    if not (0 < eta_c <= 1 and 0 < eta_d <= 1):
        raise HTTPException(422, "Rendements hors ]0 ; 1]")
    if not (0 <= p["soc_min_pct"] < p["soc_max_pct"] <= 100):
        raise HTTPException(422, "Bornes de SoC incohérentes")
    e = min(max(soc_initial_pct / 100 * e_nom, e_min), e_max)
    n = len(prix)
    pas_par_jour = int(round(24 / pas_h))
    plan = [0] * n  # +1 charge, -1 décharge
    heures_pleines = int(round((e_max - e_min) / min(pc_max * eta_c, pd_max) / pas_h * n_cycles_max_par_jour))
    for j0 in range(0, n, pas_par_jour):
        jour = list(range(j0, min(n, j0 + pas_par_jour)))
        tri = sorted(jour, key=lambda i: prix[i])
        k = min(heures_pleines, len(jour) // 2)
        if k == 0:
            continue
        # seuil de rentabilité : décharger seulement si prix × η_c × η_d > prix de charge le plus élevé retenu
        seuil = max(prix[x] for x in tri[:k]) / (eta_c * eta_d)
        if not any(prix[i] > seuil for i in tri[-k:]):
            continue
        for i in tri[:k]:
            plan[i] = 1
        for i in tri[-k:]:
            if prix[i] > seuil:
                plan[i] = -1
    traj, revenu, e_ch, e_dech = [], 0.0, 0.0, 0.0
    e0 = e
    for i in range(n):
        pc = pd = 0.0
        if plan[i] == 1:
            pc = max(0.0, min(pc_max, (e_max - e) / (eta_c * pas_h)))
        elif plan[i] == -1:
            pd = max(0.0, min(pd_max, (e - e_min) * eta_d / pas_h))
        e = e + eta_c * pc * pas_h - pd * pas_h / eta_d
        r = (pd - pc) * pas_h * prix[i] / 1000  # prix en EUR/MWh
        revenu += r
        e_ch += pc * pas_h
        e_dech += pd * pas_h
        traj.append({"pas": i, "prix_eur_mwh": prix[i], "p_charge_kw": round(pc, 3), "p_decharge_kw": round(pd, 3),
                     "energie_stockee_kwh": round(e, 3), "soc_pct": round(100 * e / e_nom, 3),
                     "revenu_estime_eur": round(r, 2)})
    tol = 1e-6
    verifs = {
        "soc_dans_bornes": all(e_min - tol <= t["energie_stockee_kwh"] <= e_max + tol for t in traj),
        "puissances_dans_limites": all(t["p_charge_kw"] <= pc_max + tol and t["p_decharge_kw"] <= pd_max + tol
                                       for t in traj),
        "pas_de_charge_decharge_simultanee": all(t["p_charge_kw"] == 0 or t["p_decharge_kw"] == 0 for t in traj),
        "bilan_energie_kwh": {
            "variation_stock": round(e - e0, 3), "eta_c_x_charge_moins_decharge_sur_eta_d":
                round(eta_c * e_ch - e_dech / eta_d, 3)},
        "pertes_kwh": round(e_ch - e_dech - (e - e0), 3),
    }
    verifs["bilan_conserve"] = abs(verifs["bilan_energie_kwh"]["variation_stock"]
                                   - verifs["bilan_energie_kwh"]["eta_c_x_charge_moins_decharge_sur_eta_d"]) < 1e-3
    return {"trajectoire": traj, "synthese": {"energie_chargee_kwh": round(e_ch, 1),
                                              "energie_dechargee_kwh": round(e_dech, 1),
                                              "cycles_equivalents": round(e_dech / (e_max - e_min) if e_max > e_min else 0, 3),
                                              "revenu_estime_eur": round(revenu, 2), "nature_revenu": "estimation"},
            "verifications": verifs, "avertissement": AVERTISSEMENT,
            "methode": "Arbitrage heuristique par classement journalier des prix ; contraintes appliquées à chaque pas."}


def creer_scenario(session: Session, actif_id: int, nom: str, prix: list[float], pas_h: float, soc_initial_pct: float,
                   auteur: str, surcharges: dict | None, instant: datetime) -> ScenarioSimulation:
    pb = parametres_actifs(session, actif_id, instant)
    p = {"energie_nominale_kwh": pb.energie_nominale_kwh, "puissance_charge_max_kw": pb.puissance_charge_max_kw,
         "puissance_decharge_max_kw": pb.puissance_decharge_max_kw, "soc_min_pct": pb.soc_min_pct,
         "soc_max_pct": pb.soc_max_pct, "rendement_charge": pb.rendement_charge,
         "rendement_decharge": pb.rendement_decharge}
    p.update(surcharges or {})
    res = simuler(p, prix, pas_h, soc_initial_pct)
    sc = ScenarioSimulation(type="batterie_arbitrage", nom=nom, actif_id=actif_id,
                            parametres={"batterie": p, "pas_h": pas_h, "soc_initial_pct": soc_initial_pct,
                                        "prix_source": "indice indicatif simulé", "n_pas": len(prix)},
                            resultats={"synthese": res["synthese"], "trajectoire": res["trajectoire"]},
                            verifications=res["verifications"], avertissement=AVERTISSEMENT, cree_par=auteur)
    session.add(sc)
    session.flush()
    return sc
