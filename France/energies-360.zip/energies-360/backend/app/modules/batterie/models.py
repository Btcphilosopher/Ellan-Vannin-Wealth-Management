"""Batteries : paramètres datés et scénarios isolés des opérations observées
(tables distinctes, jamais lues par les agrégats de mesures)."""
from __future__ import annotations

from sqlalchemy import Float, ForeignKey, Integer, String, Text
from sqlalchemy.orm import Mapped, mapped_column

from ...db import Base, HorodatageUTC, JSONType, maintenant


class ParametresBatterie(Base):
    __tablename__ = "parametres_batterie"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    actif_id: Mapped[int] = mapped_column(ForeignKey("actif.id"), index=True)
    energie_nominale_kwh: Mapped[float] = mapped_column(Float)
    puissance_charge_max_kw: Mapped[float] = mapped_column(Float)
    puissance_decharge_max_kw: Mapped[float] = mapped_column(Float)
    soc_min_pct: Mapped[float] = mapped_column(Float)
    soc_max_pct: Mapped[float] = mapped_column(Float)
    rendement_charge: Mapped[float] = mapped_column(Float)
    rendement_decharge: Mapped[float] = mapped_column(Float)
    temperature_max_c: Mapped[float] = mapped_column(Float)
    date_effet_debut = mapped_column(HorodatageUTC)
    provenance: Mapped[str] = mapped_column(String(200))


class ScenarioSimulation(Base):
    __tablename__ = "scenario_simulation"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    type: Mapped[str] = mapped_column(String(30))
    nom: Mapped[str] = mapped_column(String(200))
    actif_id: Mapped[int | None] = mapped_column(ForeignKey("actif.id"), nullable=True)
    parametres = mapped_column(JSONType)
    resultats = mapped_column(JSONType, nullable=True)
    verifications = mapped_column(JSONType, nullable=True)
    avertissement: Mapped[str] = mapped_column(Text)
    cree_par: Mapped[str] = mapped_column(String(80))
    cree_le = mapped_column(HorodatageUTC, default=maintenant)
