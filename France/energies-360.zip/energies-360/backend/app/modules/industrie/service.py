from __future__ import annotations

from datetime import datetime

from fastapi import HTTPException

from ...core.services import en_dict
from ...db import maintenant
from ...unites.dimensions import ErreurDimensionnelle, Quantite
from .models import BilanMatiere, TitreAmont


def evaluer_bilan(b: BilanMatiere) -> dict:
    """Bilan massique : Σ entrées − Σ sorties − pertes déclarées = écart non expliqué
    (publié, jamais réparti). Toute ligne hors masse est refusée."""

    def somme(lignes):
        total = Quantite(0.0, b.unite_bilan, "masse")
        for l in lignes:
            try:
                total = total + Quantite(float(l["quantite"]), l["unite"], "masse")
            except ErreurDimensionnelle as e:
                raise HTTPException(422, f"Ligne {l.get('produit')} : {e} (bilan exprimé en masse)")
        return total.valeur

    e, s, p = somme(b.entrees), somme(b.sorties), somme(b.pertes_declarees or [])
    ecart = e - s - p
    return {**en_dict(b), "total_entrees": round(e, 3), "total_sorties": round(s, 3), "pertes_declarees_total": round(p, 3),
            "ecart_non_explique": round(ecart, 3), "ecart_pct_entrees": round(100 * ecart / e, 3) if e else None,
            "unite": b.unite_bilan, "equation": "Σ entrées − Σ sorties − pertes déclarées = écart non expliqué",
            "note": "L'écart est publié tel quel ; aucune répartition automatique."}


def evaluer_titre(t: TitreAmont, instant: datetime | None = None) -> dict:
    instant = instant or maintenant()
    obligations = []
    for o in t.obligations or []:
        ech = datetime.fromisoformat(o["echeance"])
        jours = (ech - instant).days
        etat = o.get("statut", "a_faire")
        if etat != "realisee":
            etat = "en_retard" if jours < 0 else ("echeance_proche" if jours <= 60 else "a_faire")
        obligations.append({**o, "jours_restants": jours, "etat_calcule": etat})
    return {**en_dict(t), "obligations": obligations,
            "jours_avant_echeance_titre": (t.date_echeance - instant).days}
