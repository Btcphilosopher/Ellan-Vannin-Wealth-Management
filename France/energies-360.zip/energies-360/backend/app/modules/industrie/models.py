"""Sites industriels (bilans matière) et suivi administratif amont (titres,
obligations, déclarations) — suivis adaptés aux données disponibles."""
from __future__ import annotations

from sqlalchemy import Float, ForeignKey, Integer, String, Text
from sqlalchemy.orm import Mapped, mapped_column

from ...db import Base, HorodatageUTC, JSONType


class BilanMatiere(Base):
    __tablename__ = "bilan_matiere"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    site_id: Mapped[int] = mapped_column(ForeignKey("site.id"), index=True)
    periode_debut = mapped_column(HorodatageUTC)
    periode_fin = mapped_column(HorodatageUTC)
    entrees = mapped_column(JSONType)  # [{produit, quantite, unite, source}]
    sorties = mapped_column(JSONType)
    pertes_declarees = mapped_column(JSONType, default=list)
    unite_bilan: Mapped[str] = mapped_column(String(10), default="t")
    statut: Mapped[str] = mapped_column(String(20), default="brouillon")
    commentaire: Mapped[str | None] = mapped_column(Text, nullable=True)


class TitreAmont(Base):
    __tablename__ = "titre_amont"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    entite_id: Mapped[int] = mapped_column(ForeignKey("entite.id"))
    code: Mapped[str] = mapped_column(String(40), unique=True)
    nom: Mapped[str] = mapped_column(String(200))
    type: Mapped[str] = mapped_column(String(40))
    pays_fictif: Mapped[str] = mapped_column(String(80))
    operateur: Mapped[str] = mapped_column(String(120))
    participation_pct: Mapped[float] = mapped_column(Float)
    date_octroi = mapped_column(HorodatageUTC)
    date_echeance = mapped_column(HorodatageUTC)
    statut: Mapped[str] = mapped_column(String(30))
    obligations = mapped_column(JSONType, default=list)
    declarations = mapped_column(JSONType, default=list)
    mention: Mapped[str] = mapped_column(Text, default="Titre fictif — suivi administratif uniquement, "
                                                        "aucune donnée d'exploitation réelle")
