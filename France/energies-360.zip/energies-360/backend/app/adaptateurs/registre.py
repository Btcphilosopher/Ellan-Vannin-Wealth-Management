"""Adaptateurs vers les systèmes externes.

Principe : chaque intégration passe par un adaptateur qui déclare son mode
(simulation / lecture seule / non intégré) et ses capacités. La première
version fonctionne entièrement en simulation ; les intégrations futures sont
prévues en LECTURE SEULE, derrière une frontière contrôlée (DMZ industrielle,
diode ou passerelle de réplication) — aucune écriture vers les systèmes
industriels.

Les capacités annoncées pour les protocoles réels sont des hypothèses de
conception à VÉRIFIER dans les documentations officielles avant intégration
(voir docs/integrations.md).
"""
from __future__ import annotations

from dataclasses import asdict, dataclass, field

from fastapi import HTTPException


@dataclass
class Adaptateur:
    nom: str
    domaine: str
    mode: str  # simulation | lecture_seule_prevue | non_integre
    protocole_cible: str
    capacites: list[str]
    interdits: list[str] = field(default_factory=list)
    documentation_a_verifier: str = ""

    def decrire(self) -> dict:
        return asdict(self)


class MarcheSimule:
    """Place de marché simulée : aucun ordre réel ne peut être transmis."""

    nom = "marche_simule"

    def soumettre(self, ordre: dict) -> dict:
        if ordre.get("mode") != "simulation":
            raise HTTPException(403, "Passage d'ordre réel interdit : la plateforme ne transmet aucun ordre de marché")
        prix_ref = 82.0
        execute = (ordre["sens"] == "achat" and ordre["prix_limite"] >= prix_ref) or \
                  (ordre["sens"] == "vente" and ordre["prix_limite"] <= prix_ref)
        return {"statut": "execution_simulee" if execute else "non_execute_simule", "prix_reference_simule": prix_ref,
                "transmis": False, "mention": "Simulation pédagogique — aucun ordre transmis à une place de marché"}


MARCHE = MarcheSimule()

ADAPTATEURS = [
    Adaptateur("telemetrie_scada_simulee", "mesures", "simulation", "OPC UA / Modbus TCP / IEC 61850 (futur)",
               ["lecture de points de mesure", "rejeu d'historiques", "injection d'anomalies"],
               ["écriture de consignes", "commande d'équipements"],
               "OPC Foundation (OPC 10000), Modbus Organization, IEC 61850 — vérifier les profils de sécurité"),
    Adaptateur("ocpp_lecture_seule", "mobilite", "simulation", "OCPP 1.6J (sous-ensemble) ; 2.0.1 non implémenté",
               ["BootNotification", "Heartbeat", "StatusNotification", "StartTransaction", "MeterValues",
                "StopTransaction"],
               ["RemoteStartTransaction", "RemoteStopTransaction", "Reset", "ChangeAvailability", "UnlockConnector"],
               "Open Charge Alliance — spécifications OCPP 1.6 / 2.0.1, programme de certification"),
    Adaptateur("meteo_simulee", "production", "simulation", "API de prévision météo (à sélectionner)",
               ["éclairement plan des modules observé et prévu", "température ambiante"], [],
               "Conditions d'usage et licences du fournisseur retenu"),
    Adaptateur("erp_simule", "finance", "simulation", "ERP / comptabilité (à sélectionner)",
               ["lecture commandes, factures, paiements"], ["écriture comptable", "paiement"],
               "API officielle de l'ERP retenu"),
    Adaptateur("marche_simule", "contrats", "simulation", "Aucun (opérations de marché simulées)",
               ["ordres fictifs, exécution simulée"], ["tout ordre réel"], "—"),
    Adaptateur("annuaire_identites", "securite", "simulation", "OIDC / SAML (futur)",
               ["authentification locale fictive"], [], "Fournisseur d'identité retenu (découverte OIDC, JWKS)"),
    Adaptateur("mfa_totp", "securite", "integre", "TOTP RFC 6238", ["vérification de code à 6 chiffres"], [],
               "RFC 6238 / RFC 4226"),
    Adaptateur("stockage_objet", "socle", "integre", "Système de fichiers local ou S3 (MinIO)",
               ["dépôt adressé par contenu", "contrôle d'intégrité SHA-256"], [], "API S3 / documentation MinIO"),
    Adaptateur("llm", "ia", "non_integre", "Aucun modèle génératif activé",
               ["(désactivé) résumé / recherche augmentée sur documents autorisés"],
               ["autoriser une intervention", "piloter un procédé", "engager une dépense", "opérer sur un marché"],
               "Conditions du fournisseur et évaluation préalable"),
]


def description() -> dict:
    return {"principe": "Simulation intégrale en V1 ; futures intégrations en lecture seule, derrière une frontière "
                        "contrôlée entre informatique de gestion et systèmes industriels.",
            "adaptateurs": [a.decrire() for a in ADAPTATEURS]}


STATUT_FONCTIONNALITES = {
    "operationnel": [
        "Référentiel des actifs versionné (études approuvées figées)",
        "Ingestion de mesures avec déduplication, retards, bornes, archive brute",
        "Qualité des données : manquants, capteur périmé, valeur figée, remise à zéro, doublons, pannes",
        "Bilan énergétique sans double comptage, couverture publiée",
        "Maintenance : parcours complet, trois actes distincts",
        "Stocks : journal immuable, corrections liées, réservations atomiques, quarantaine, transferts",
        "Contrats : chaîne contrat → paiement, rapprochement, formules de prix sûres",
        "Validation dimensionnelle et conversions avec hypothèses",
        "Registre environnemental et contrôles de double comptage",
        "Finance : VAN/TRI explicites, coûts unitaires, marges définies, séparation estimé/facturé/encaissé",
        "Rapports traçables (manifeste, empreintes, signature HMAC)",
        "Authentification, MFA TOTP, permissions par rôle/entité/site, audit chaîné, journaux expurgés",
        "Sauvegarde / restauration logique testée",
    ],
    "simule": ["Télémétrie SCADA", "Bornes OCPP", "Météo et prévisions", "Indices de prix", "Paiements de recharge",
               "Opérations de marché", "Annuaire d'identités", "ERP"],
    "integre": ["PostgreSQL + PostGIS (requêtes spatiales)", "Stockage objet local / S3 (MinIO)", "TOTP RFC 6238",
                "WebSocket de diffusion d'événements"],
    "reporte": ["Connexion OIDC/SAML réelle", "OPC UA / Modbus / IEC 61850 en lecture seule", "OCPP 2.0.1",
                "Tables normalisées de correction de volume (ISO 91 / API MPMS 11.1)", "Modèles génératifs (LLM)",
                "Partitionnement temporel automatique / TimescaleDB", "Chiffrement des secrets par KMS",
                "Déclarations réglementaires et vérification tierce des émissions"],
}
