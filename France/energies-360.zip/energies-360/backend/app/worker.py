"""Processus de traitements en arrière-plan (``python -m app.worker``).

* exécute les tâches mises en file (analyse qualité, rapports, sauvegardes) ;
* en mode démonstration, joue un flux « temps réel » simulé : heartbeats OCPP
  des bornes et télémétrie batterie, diffusés ensuite par WebSocket.
"""
from __future__ import annotations

import logging
import time
from datetime import timedelta

from sqlalchemy import select

from . import modeles, taches  # noqa: F401
from .config import parametres
from .core.securite import configurer_journaux
from .core.services import executer_taches_en_attente, publier
from .db import configurer, maintenant, nouvelle_session

journal = logging.getLogger("e360.worker")


def flux_simule(dernier: dict):
    from .modules.mesures.ingestion import ingerer
    from .modules.mobilite.service import traiter_trame
    from .modules.patrimoine.models import Actif

    t = maintenant()
    with nouvelle_session() as s:
        if (t - dernier.get("heartbeat", t - timedelta(hours=1))).total_seconds() >= 60:
            for b in s.scalars(select(Actif).where(Actif.type_actif == "borne")):
                if b.code == "CP-PNF-02":
                    continue  # borne simulée hors communication
                traiter_trame(s, b.code, [2, f"hb-{int(t.timestamp())}", "Heartbeat", {}])
            dernier["heartbeat"] = t
        pas = t.replace(second=0, microsecond=0, minute=(t.minute // 10) * 10)
        if dernier.get("pas") != pas:
            soc = 50 + 30 * __import__("math").sin(pas.timestamp() / 7200)
            lot = ingerer(s, [{"point": "BESS-GAR-SOC", "observe_le": pas.isoformat(), "valeur": round(soc, 2)},
                              {"point": "BESS-GAR-TEMP", "observe_le": pas.isoformat(), "valeur": 25.0}],
                          "flux_temps_reel_simule", "worker")
            if lot.nb_inseres:
                publier(s, "telemetrie", f"Batterie : SoC {soc:.1f} % ({pas:%H:%M} UTC)", site_id=None,
                        point="BESS-GAR-SOC", valeur=round(soc, 2))
            dernier["pas"] = pas
        s.commit()


def boucle():
    configurer_journaux()
    configurer()
    if parametres().database_url.startswith("sqlite"):
        from .db import moteur

        modeles.metadata.create_all(moteur())
    journal.info("Worker démarré")
    dernier: dict = {}
    while True:
        try:
            with nouvelle_session() as s:
                faites = executer_taches_en_attente(s, 10)
                for t in faites:
                    journal.info("Tâche %s #%s : %s", t.type, t.id, t.statut)
            if parametres().mode_demo:
                flux_simule(dernier)
        except Exception as exc:  # noqa: BLE001
            journal.warning("Erreur worker : %s", exc)
        time.sleep(2)


if __name__ == "__main__":
    boucle()
