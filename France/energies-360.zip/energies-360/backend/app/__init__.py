"""Énergies 360 — prototype indépendant de plateforme multi-énergies (données synthétiques)."""
__version__ = "0.1.0"
