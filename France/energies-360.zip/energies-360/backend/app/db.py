"""Accès base de données (SQLAlchemy 2).

Cible : PostgreSQL 16 + PostGIS 3. SQLite est accepté pour les tests unitaires
et la démonstration autonome (les fonctions spatiales sont alors remplacées par
un calcul de distance haversine, signalé dans les réponses).
"""
from __future__ import annotations

from contextlib import contextmanager
from datetime import datetime, timezone
from typing import Iterator

from sqlalchemy import JSON, DateTime, MetaData, create_engine, event
from sqlalchemy.dialects.postgresql import JSONB
from sqlalchemy.orm import DeclarativeBase, Session, sessionmaker
from sqlalchemy.types import TypeDecorator

from .config import parametres

CONVENTION = {
    "ix": "ix_%(column_0_label)s",
    "uq": "uq_%(table_name)s_%(column_0_name)s",
    "ck": "ck_%(table_name)s_%(constraint_name)s",
    "fk": "fk_%(table_name)s_%(column_0_name)s_%(referred_table_name)s",
    "pk": "pk_%(table_name)s",
}


class Base(DeclarativeBase):
    metadata = MetaData(naming_convention=CONVENTION)


class HorodatageUTC(TypeDecorator):
    """Horodatage toujours stocké et restitué en UTC, avec fuseau explicite."""

    impl = DateTime(timezone=True)
    cache_ok = True

    def process_bind_param(self, value, dialect):
        if value is None:
            return None
        if value.tzinfo is None:
            raise ValueError("Horodatage sans fuseau horaire refusé (ambigu)")
        value = value.astimezone(timezone.utc)
        if dialect.name == "sqlite":
            return value.replace(tzinfo=None)
        return value

    def process_result_value(self, value, dialect):
        if value is None:
            return None
        if value.tzinfo is None:
            return value.replace(tzinfo=timezone.utc)
        return value.astimezone(timezone.utc)


JSONType = JSON().with_variant(JSONB(), "postgresql")


_DEMARRAGE = datetime.now(timezone.utc)


def maintenant() -> datetime:
    """Horloge *métier*.

    * ``E360_HORLOGE_FIGEE`` : instant fixe (tests reproductibles) ;
    * ``E360_HORLOGE_ORIGINE`` : horloge de démonstration qui démarre à l'instant
      indiqué et avance au rythme réel (jeu de données synthétique cohérent) ;
    * sinon : heure réelle UTC.
    L'audit et les jetons utilisent toujours l'heure réelle (``heure_reelle``).
    """
    p = parametres()
    if p.horloge_figee:
        return datetime.fromisoformat(p.horloge_figee).astimezone(timezone.utc)
    if p.horloge_origine:
        return datetime.fromisoformat(p.horloge_origine).astimezone(timezone.utc) + (datetime.now(timezone.utc) - _DEMARRAGE)
    return datetime.now(timezone.utc)


def heure_reelle() -> datetime:
    return datetime.now(timezone.utc)


_moteurs: dict[str, object] = {}


def creer_moteur(url: str):
    kwargs: dict = {"future": True}
    if url.startswith("sqlite"):
        kwargs["connect_args"] = {"check_same_thread": False, "timeout": 30}
    else:
        kwargs["pool_pre_ping"] = True
    moteur = create_engine(url, **kwargs)
    if url.startswith("sqlite"):

        @event.listens_for(moteur, "connect")
        def _pragma(conn, _):  # pragma: no cover - configuration
            cur = conn.cursor()
            cur.execute("PRAGMA foreign_keys=ON")
            cur.execute("PRAGMA journal_mode=WAL")
            cur.execute("PRAGMA busy_timeout=30000")
            cur.close()

    return moteur


class _Etat:
    moteur = None
    fabrique: sessionmaker | None = None


def configurer(url: str | None = None):
    url = url or parametres().url_base
    _Etat.moteur = creer_moteur(url)
    _Etat.fabrique = sessionmaker(bind=_Etat.moteur, expire_on_commit=False, future=True)
    return _Etat.moteur


def est_configure() -> bool:
    return _Etat.moteur is not None


def moteur():
    if _Etat.moteur is None:
        configurer()
    return _Etat.moteur


def nouvelle_session() -> Session:
    if _Etat.fabrique is None:
        configurer()
    return _Etat.fabrique()  # type: ignore[misc]


def obtenir_session() -> Iterator[Session]:
    session = nouvelle_session()
    try:
        yield session
        session.commit()
    except Exception:
        session.rollback()
        raise
    finally:
        session.close()


@contextmanager
def session_scope() -> Iterator[Session]:
    session = nouvelle_session()
    try:
        yield session
        session.commit()
    except Exception:
        session.rollback()
        raise
    finally:
        session.close()


def est_postgres() -> bool:
    return moteur().dialect.name == "postgresql"
