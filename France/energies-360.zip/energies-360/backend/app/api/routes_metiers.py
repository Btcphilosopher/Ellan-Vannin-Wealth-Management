"""Routes métiers : approvisionnements, logistique, contrats, distribution,
mobilité, batteries, environnement, finance, IA, industrie et amont."""
from __future__ import annotations

from datetime import datetime
from typing import Literal

from fastapi import APIRouter, Body, Depends, HTTPException, Query
from pydantic import BaseModel, Field
from sqlalchemy import select
from sqlalchemy.orm import Session

from ..adaptateurs.registre import MARCHE
from ..core import securite as sec
from ..core.securite import Principal, auditer, exiger, verifier_portee
from ..core.services import en_dict
from ..db import maintenant, obtenir_session
from ..modules.batterie import service as bat
from ..modules.batterie.models import ScenarioSimulation
from ..modules.contrats import service as ctr
from ..modules.contrats.models import (Contrat, EcheanceContrat, EngagementConfirme, Facture, Indice, LivraisonMesuree,
                                       OrdreMarcheSimule, Paiement, ValeurIndice)
from ..modules.distribution import service as dist
from ..modules.distribution.models import PrixAffiche
from ..modules.environnement import service as env
from ..modules.environnement.models import DonneeActivite, EmissionEvitee, FacteurEmission
from ..modules.finance import service as fin
from ..modules.finance.models import ScenarioInvestissement
from ..modules.ia import service as ia
from ..modules.industrie import service as ind
from ..modules.industrie.models import BilanMatiere, TitreAmont
from ..modules.mesures.models import Alerte
from ..modules.mobilite import service as mob
from ..modules.mobilite.models import SessionRecharge, Tarif
from ..modules.patrimoine.models import Actif, Entite, Produit, Site, Tiers
from ..modules.production.models import Incident
from ..modules.stocks import service as stk
from ..modules.stocks.models import (CommandeAchat, DocumentTransport, Ecart, Emplacement, LigneCommande, Livraison, Lot,
                                     MouvementStock, RegleCompatibilite, Reception, Reservation, SoldeStock, Transfert)
from .commun import dt, instant_ref, periode

r = APIRouter()


def _404():
    raise HTTPException(404, "Introuvable")


# ---------------------------------------------------------------------------
# Approvisionnements
# ---------------------------------------------------------------------------
@r.get("/approvisionnements/commandes", tags=["Approvisionnements"])
def commandes(p: Principal = Depends(exiger("approvisionnements:lire")), s: Session = Depends(obtenir_session)):
    autorises = p.sites_autorises(s, "approvisionnements:lire")
    res = []
    for c in s.scalars(select(CommandeAchat).order_by(CommandeAchat.id.desc())):
        if autorises is not None and c.site_id not in autorises:
            continue
        lignes = [en_dict(l) | {"produit": s.get(Produit, l.produit_id).code}
                  for l in s.scalars(select(LigneCommande).where(LigneCommande.commande_id == c.id))]
        livs = [en_dict(l) for l in s.scalars(select(Livraison).where(Livraison.commande_id == c.id))]
        res.append(en_dict(c) | {"fournisseur": s.get(Tiers, c.fournisseur_id).nom, "lignes": lignes, "livraisons": livs})
    return res


class LigneReception(BaseModel):
    ligne_commande_id: int
    quantite_recue: float = Field(ge=0)
    quantite_non_conforme: float = Field(0, ge=0)
    motif_non_conformite: str | None = None
    lot: str
    emplacement_id: int
    emplacement_quarantaine_id: int | None = None


class NouvelleReception(BaseModel):
    livraison_id: int
    lignes: list[LigneReception]


@r.post("/approvisionnements/receptions", tags=["Approvisionnements"], status_code=201)
def reception(n: NouvelleReception, p: Principal = Depends(exiger("approvisionnements:ecrire")),
              s: Session = Depends(obtenir_session)):
    l = s.get(Livraison, n.livraison_id) or _404()
    c = s.get(CommandeAchat, l.commande_id)
    verifier_portee(s, p, "approvisionnements:ecrire", site_id=c.site_id)
    if l.statut != "annoncee":
        raise HTTPException(409, "Livraison déjà réceptionnée")
    rec = stk.recevoir(s, l, [x.model_dump() for x in n.lignes], p.identifiant)
    auditer(s, p.identifiant, "reception", f"livraison:{l.id}", details={"statut": rec.statut})
    return en_dict(rec) | {"ecarts": [en_dict(e) for e in s.scalars(select(Ecart).where(
        Ecart.objet_type == "livraison", Ecart.objet_id == l.id))]}


# ---------------------------------------------------------------------------
# Logistique
# ---------------------------------------------------------------------------
@r.get("/logistique/stocks", tags=["Logistique"])
def stocks(p: Principal = Depends(exiger("stocks:lire")), s: Session = Depends(obtenir_session)):
    return {"soldes": stk.etat_stocks(s, p.sites_autorises(s, "stocks:lire")),
            "definitions": {"physique": "quantité présente (journal)", "reserve": "réservations actives",
                            "quarantaine": "lots bloqués ou en quarantaine", "disponible": "physique − réservé − quarantaine",
                            "en_transit_entrant": "transferts expédiés non reçus (hors physique)"}}


@r.get("/logistique/emplacements", tags=["Logistique"])
def emplacements(p: Principal = Depends(exiger("stocks:lire")), s: Session = Depends(obtenir_session)):
    autorises = p.sites_autorises(s, "stocks:lire")
    return [en_dict(e) for e in s.scalars(select(Emplacement)) if autorises is None or e.site_id in autorises]


@r.get("/logistique/mouvements", tags=["Logistique"])
def mouvements(p: Principal = Depends(exiger("stocks:lire")), s: Session = Depends(obtenir_session)):
    autorises = p.sites_autorises(s, "stocks:lire")
    res = []
    for m in s.scalars(select(MouvementStock).order_by(MouvementStock.id.desc()).limit(500)):
        e = s.get(Emplacement, m.emplacement_id)
        if autorises is None or e.site_id in autorises:
            res.append(en_dict(m) | {"emplacement": e.code, "produit": s.get(Produit, m.produit_id).code})
    return res


@r.get("/logistique/coherence", tags=["Logistique"])
def coherence(p: Principal = Depends(exiger("stocks:lire")), s: Session = Depends(obtenir_session)):
    return stk.coherence_journal(s)


class NouveauTransfert(BaseModel):
    produit_id: int
    lot_id: int | None = None
    source_id: int
    destination_id: int
    quantite: float = Field(gt=0)


def _site_empl(s, eid):
    e = s.get(Emplacement, eid) or _404()
    return e.site_id


@r.post("/logistique/transferts", tags=["Logistique"], status_code=201)
def transfert(t: NouveauTransfert, p: Principal = Depends(exiger("stocks:ecrire")), s: Session = Depends(obtenir_session)):
    verifier_portee(s, p, "stocks:ecrire", site_id=_site_empl(s, t.source_id))
    verifier_portee(s, p, "stocks:ecrire", site_id=_site_empl(s, t.destination_id))
    x = stk.creer_transfert(s, auteur=p.identifiant, **t.model_dump())
    auditer(s, p.identifiant, "transfert", f"transfert:{x.id}")
    return en_dict(x)


@r.post("/logistique/transferts/{tid}/reception", tags=["Logistique"])
def recevoir_transfert(tid: int, quantite_recue: float = Body(..., embed=True),
                       p: Principal = Depends(exiger("stocks:ecrire")), s: Session = Depends(obtenir_session)):
    t = s.get(Transfert, tid) or _404()
    verifier_portee(s, p, "stocks:ecrire", site_id=_site_empl(s, t.destination_id))
    return en_dict(stk.recevoir_transfert(s, t, quantite_recue, p.identifiant))


@r.get("/logistique/transferts", tags=["Logistique"])
def transferts(p: Principal = Depends(exiger("stocks:lire")), s: Session = Depends(obtenir_session)):
    return [en_dict(t) for t in s.scalars(select(Transfert).order_by(Transfert.id.desc()))]


class NouvelleReservation(BaseModel):
    solde_id: int
    quantite: float = Field(gt=0)
    reference: str


@r.post("/logistique/reservations", tags=["Logistique"], status_code=201)
def reserver(n: NouvelleReservation, p: Principal = Depends(exiger("stocks:ecrire")), s: Session = Depends(obtenir_session)):
    so = s.get(SoldeStock, n.solde_id) or _404()
    verifier_portee(s, p, "stocks:ecrire", site_id=_site_empl(s, so.emplacement_id))
    return en_dict(stk.reserver(s, n.solde_id, n.quantite, n.reference, p.identifiant))


@r.post("/logistique/reservations/{rid}/annuler", tags=["Logistique"])
def annuler(rid: int, p: Principal = Depends(exiger("stocks:ecrire")), s: Session = Depends(obtenir_session)):
    x = s.get(Reservation, rid) or _404()
    stk.annuler_reservation(s, x)
    return en_dict(x)


class NouvelleExpedition(BaseModel):
    reservation_id: int
    client_id: int
    transporteur_id: int | None = None


@r.post("/logistique/expeditions", tags=["Logistique"], status_code=201)
def expedier(n: NouvelleExpedition, p: Principal = Depends(exiger("stocks:ecrire")), s: Session = Depends(obtenir_session)):
    x = s.get(Reservation, n.reservation_id) or _404()
    so = s.get(SoldeStock, x.solde_id)
    verifier_portee(s, p, "stocks:ecrire", site_id=_site_empl(s, so.emplacement_id))
    e = stk.expedier(s, x, n.client_id, p.identifiant, n.transporteur_id)
    return en_dict(e) | {"document_transport": en_dict(s.get(DocumentTransport, e.document_transport_id))}


class Correction(BaseModel):
    quantite_correcte: float
    motif: str = Field(min_length=5)


@r.post("/logistique/mouvements/{mid}/corriger", tags=["Logistique"], status_code=201)
def corriger(mid: int, c: Correction, p: Principal = Depends(exiger("stocks:ecrire")), s: Session = Depends(obtenir_session)):
    m = s.get(MouvementStock, mid) or _404()
    verifier_portee(s, p, "stocks:ecrire", site_id=_site_empl(s, m.emplacement_id))
    x = stk.corriger_mouvement(s, mid, c.quantite_correcte, c.motif, p.identifiant)
    auditer(s, p.identifiant, "correction_mouvement", f"mouvement:{mid}")
    return en_dict(x)


class StatutLot(BaseModel):
    statut: Literal["libre", "quarantaine", "bloque"]
    motif: str


@r.post("/logistique/lots/{lot_id}/statut", tags=["Logistique"])
def statut_lot(lot_id: int, st: StatutLot, p: Principal = Depends(exiger("stocks:ecrire")), s: Session = Depends(obtenir_session)):
    lot = s.get(Lot, lot_id) or _404()
    stk.changer_statut_lot(s, lot, st.statut, st.motif, p.identifiant)
    auditer(s, p.identifiant, "statut_lot", f"lot:{lot_id}", details={"statut": st.statut})
    return en_dict(lot)


@r.get("/logistique/regles", tags=["Logistique"])
def regles(p: Principal = Depends(exiger("stocks:lire")), s: Session = Depends(obtenir_session)):
    return [en_dict(x) for x in s.scalars(select(RegleCompatibilite))]


@r.get("/logistique/ecarts", tags=["Logistique"])
def ecarts(p: Principal = Depends(exiger("stocks:lire")), s: Session = Depends(obtenir_session)):
    return [en_dict(x) for x in s.scalars(select(Ecart).order_by(Ecart.id.desc()))]


@r.get("/logistique/documents-transport", tags=["Logistique"])
def docs_transport(p: Principal = Depends(exiger("stocks:lire")), s: Session = Depends(obtenir_session)):
    return [en_dict(x) for x in s.scalars(select(DocumentTransport))]


# ---------------------------------------------------------------------------
# Contrats
# ---------------------------------------------------------------------------
@r.get("/contrats", tags=["Contrats"])
def contrats(p: Principal = Depends(exiger("contrats:lire")), s: Session = Depends(obtenir_session)):
    return [en_dict(c) | {"tiers": s.get(Tiers, c.tiers_id).nom, "produit": s.get(Produit, c.produit_id).nom}
            for c in s.scalars(select(Contrat))]


@r.get("/contrats/indices", tags=["Contrats"])
def indices(p: Principal = Depends(exiger("contrats:lire")), s: Session = Depends(obtenir_session)):
    return [en_dict(i) | {"valeurs": [en_dict(v) for v in s.scalars(select(ValeurIndice).where(
        ValeurIndice.indice_id == i.id).order_by(ValeurIndice.date_valeur))]} for i in s.scalars(select(Indice))]


@r.get("/contrats/{cid}/rapprochement", tags=["Contrats"])
def rapprochement(cid: int, p: Principal = Depends(exiger("contrats:lire")), s: Session = Depends(obtenir_session)):
    return ctr.rapprochement(s, s.get(Contrat, cid) or _404())


@r.get("/contrats/{cid}/cotation", tags=["Contrats"])
def cotation(cid: int, date: str | None = None, p: Principal = Depends(exiger("contrats:lire")),
             s: Session = Depends(obtenir_session)):
    return ctr.cotation(s, s.get(Contrat, cid) or _404(), dt(date, maintenant()))


class NouvelEngagement(BaseModel):
    echeance_id: int | None = None
    quantite: float = Field(gt=0)
    unite: str
    reference: str


@r.post("/contrats/{cid}/engagements", tags=["Contrats"], status_code=201)
def engagement(cid: int, n: NouvelEngagement, p: Principal = Depends(exiger("contrats:ecrire")),
               s: Session = Depends(obtenir_session)):
    c = s.get(Contrat, cid) or _404()
    if n.unite != c.unite:
        raise HTTPException(422, f"Unité contractuelle : {c.unite}")
    x = EngagementConfirme(contrat_id=c.id, confirme_par=p.identifiant, confirme_le=maintenant(), **n.model_dump())
    s.add(x)
    s.flush()
    return en_dict(x)


class NouvelleLivraisonMesuree(BaseModel):
    engagement_id: int | None = None
    quantite: float = Field(ge=0)
    unite: str
    nature_quantite: str | None = None
    source_type: Literal["reception", "compteur", "jaugeage"]
    source_id: int | None = None
    mesure_le: datetime


@r.post("/contrats/{cid}/livraisons-mesurees", tags=["Contrats"], status_code=201)
def livraison_mesuree(cid: int, n: NouvelleLivraisonMesuree, p: Principal = Depends(exiger("contrats:ecrire")),
                      s: Session = Depends(obtenir_session)):
    c = s.get(Contrat, cid) or _404()
    if n.unite != c.unite or (c.nature_quantite and n.nature_quantite != c.nature_quantite):
        raise HTTPException(422, f"Quantité attendue en {c.unite} ({c.nature_quantite})")
    x = LivraisonMesuree(contrat_id=c.id, **n.model_dump())
    s.add(x)
    s.flush()
    return en_dict(x)


class NouvelleFacture(BaseModel):
    contrat_id: int
    numero: str
    sens: Literal["recue", "emise"]
    date_facture: datetime
    date_echeance: datetime
    quantite_facturee: float
    unite: str
    prix_unitaire: float
    taux_tva_pct: float = 20


@r.post("/contrats/factures", tags=["Contrats"], status_code=201)
def facture(n: NouvelleFacture, p: Principal = Depends(exiger("contrats:ecrire")), s: Session = Depends(obtenir_session)):
    c = s.get(Contrat, n.contrat_id) or _404()
    if n.unite != c.unite:
        raise HTTPException(422, f"Unité de facturation ≠ unité contractuelle ({c.unite})")
    ht = round(n.quantite_facturee * n.prix_unitaire, 2)
    x = Facture(**n.model_dump(), montant_ht=ht, montant_ttc=round(ht * (1 + n.taux_tva_pct / 100), 2), devise=c.devise)
    s.add(x)
    s.flush()
    return en_dict(x)


class NouveauPaiement(BaseModel):
    facture_id: int
    date_paiement: datetime
    montant: float
    reference: str


@r.post("/contrats/paiements", tags=["Contrats"], status_code=201)
def paiement(n: NouveauPaiement, p: Principal = Depends(exiger("contrats:ecrire")), s: Session = Depends(obtenir_session)):
    f = s.get(Facture, n.facture_id) or _404()
    x = Paiement(**n.model_dump(), devise=f.devise)
    s.add(x)
    s.flush()
    return en_dict(x)


class OrdreMarche(BaseModel):
    produit: str
    sens: Literal["achat", "vente"]
    quantite: float = Field(gt=0)
    unite: str
    prix_limite: float
    devise: str = "EUR"
    mode: Literal["simulation", "reel"] = "simulation"


@r.post("/contrats/ordres-marche", tags=["Contrats"], status_code=201)
def ordre_marche(o: OrdreMarche, p: Principal = Depends(exiger("marche:simuler")), s: Session = Depends(obtenir_session)):
    res = MARCHE.soumettre(o.model_dump())  # lève 403 si mode réel
    x = OrdreMarcheSimule(**o.model_dump(exclude={"mode"}), cree_par=p.identifiant, resultat_simulation=res)
    s.add(x)
    s.flush()
    auditer(s, p.identifiant, "ordre_marche_simule", f"ordre:{x.id}")
    return en_dict(x)


# ---------------------------------------------------------------------------
# Distribution
# ---------------------------------------------------------------------------
@r.get("/distribution/stations", tags=["Distribution"])
def stations(p: Principal = Depends(exiger("distribution:lire")), s: Session = Depends(obtenir_session)):
    autorises = p.sites_autorises(s, "distribution:lire")
    return [en_dict(x) for x in s.scalars(select(Site).where(Site.domaine == "distribution"))
            if autorises is None or x.id in autorises]


@r.get("/distribution/stations/{site_id}/synthese", tags=["Distribution"])
def station(site_id: int, per=Depends(periode), p: Principal = Depends(exiger("distribution:lire")),
            s: Session = Depends(obtenir_session)):
    verifier_portee(s, p, "distribution:lire", site_id=site_id)
    return dist.synthese_station(s, site_id, per[0], per[1])


class NouveauPrix(BaseModel):
    site_id: int
    produit_id: int
    prix_ttc: float = Field(gt=0)
    valide_de: datetime
    source: str = "saisie gérant (simulée)"


@r.post("/distribution/prix", tags=["Distribution"], status_code=201)
def prix(n: NouveauPrix, p: Principal = Depends(exiger("distribution:ecrire")), s: Session = Depends(obtenir_session)):
    verifier_portee(s, p, "distribution:ecrire", site_id=n.site_id)
    prec = dist.prix_a_date(s, n.site_id, n.produit_id, n.valide_de)
    if prec:
        prec.valide_a = n.valide_de
    x = PrixAffiche(**n.model_dump())
    s.add(x)
    s.flush()
    return en_dict(x)


# ---------------------------------------------------------------------------
# Mobilité électrique
# ---------------------------------------------------------------------------
@r.post("/mobilite/ocpp/{identifiant}", tags=["Mobilité"])
def ocpp(identifiant: str, trame: list = Body(...), p: Principal = Depends(exiger("mobilite:ecrire")),
         s: Session = Depends(obtenir_session)):
    """Réception d'une trame OCPP-J (passerelle simulée, HTTP). Voir aussi le WebSocket /ws/ocpp/{identifiant}."""
    return mob.traiter_trame(s, identifiant, trame)


@r.get("/mobilite/bornes", tags=["Mobilité"])
def bornes(instant: datetime = Depends(instant_ref), p: Principal = Depends(exiger("mobilite:lire")),
           s: Session = Depends(obtenir_session)):
    res = []
    for b in s.scalars(select(Actif).where(Actif.type_actif == "borne").order_by(Actif.code)):
        cs = s.scalars(select(Actif).where(Actif.parent_id == b.id).order_by(Actif.code)).all()
        res.append(en_dict(b) | {"site": s.get(Site, b.site_id).nom,
                                 "connecteurs": [mob.evaluer_connecteur(s, c, instant) for c in cs]})
    return {"instant_reference": instant.isoformat(), "bornes": res,
            "commandes_non_implementees": mob.COMMANDES_NON_IMPLEMENTEES}


@r.get("/mobilite/sessions", tags=["Mobilité"])
def sessions(p: Principal = Depends(exiger("mobilite:lire")), s: Session = Depends(obtenir_session)):
    return [en_dict(x) | {"connecteur": s.get(Actif, x.connecteur_id).code}
            for x in s.scalars(select(SessionRecharge).order_by(SessionRecharge.debut.desc()))]


@r.get("/mobilite/sessions/{sid}", tags=["Mobilité"])
def session_detail(sid: int, p: Principal = Depends(exiger("mobilite:lire")), s: Session = Depends(obtenir_session)):
    return mob.detail_session(s, s.get(SessionRecharge, sid) or _404())


@r.get("/mobilite/tarifs", tags=["Mobilité"])
def tarifs(p: Principal = Depends(exiger("mobilite:lire")), s: Session = Depends(obtenir_session)):
    return [en_dict(t) for t in s.scalars(select(Tarif))]


# ---------------------------------------------------------------------------
# Batteries
# ---------------------------------------------------------------------------
@r.get("/batterie/{actif_id}/etat", tags=["Production"])
def etat_batterie(actif_id: int, instant: datetime = Depends(instant_ref), p: Principal = Depends(exiger("batterie:lire")),
                  s: Session = Depends(obtenir_session)):
    a = s.get(Actif, actif_id) or _404()
    verifier_portee(s, p, "batterie:lire", site_id=a.site_id)
    return bat.etat_observe(s, actif_id, instant)


class DemandeScenario(BaseModel):
    actif_id: int
    nom: str
    indice: str = "IDX_ELEC_SPOT_SIM"
    debut: str | None = None
    fin: str | None = None
    soc_initial_pct: float = Field(50, ge=0, le=100)
    surcharges: dict | None = Field(None, description="Paramètres modifiés pour le scénario (ex. rendement_charge)")


@r.post("/batterie/scenarios", tags=["Production"], status_code=201)
def scenario(d: DemandeScenario, p: Principal = Depends(exiger("batterie:simuler")), s: Session = Depends(obtenir_session)):
    a = s.get(Actif, d.actif_id) or _404()
    verifier_portee(s, p, "batterie:simuler", site_id=a.site_id)
    deb, fin_ = periode(d.debut, d.fin)
    ind = s.scalar(select(Indice).where(Indice.code == d.indice)) or _404()
    vals = s.scalars(select(ValeurIndice).where(ValeurIndice.indice_id == ind.id, ValeurIndice.date_valeur >= deb,
                                                ValeurIndice.date_valeur < fin_).order_by(ValeurIndice.date_valeur)).all()
    if not vals:
        raise HTTPException(422, "Aucune valeur d'indice sur la période")
    sc = bat.creer_scenario(s, d.actif_id, d.nom, [v.valeur for v in vals], 1.0, d.soc_initial_pct, p.identifiant,
                            d.surcharges, deb)
    sc.parametres = sc.parametres | {"indice": d.indice, "debut": deb.isoformat()}
    return en_dict(sc)


@r.get("/batterie/scenarios", tags=["Production"])
def scenarios(p: Principal = Depends(exiger("batterie:lire")), s: Session = Depends(obtenir_session)):
    return [en_dict(x, exclure=("resultats",)) | {"synthese": (x.resultats or {}).get("synthese")}
            for x in s.scalars(select(ScenarioSimulation).order_by(ScenarioSimulation.id.desc()))]


@r.get("/batterie/scenarios/{sid}", tags=["Production"])
def scenario_detail(sid: int, p: Principal = Depends(exiger("batterie:lire")), s: Session = Depends(obtenir_session)):
    return en_dict(s.get(ScenarioSimulation, sid) or _404())


# ---------------------------------------------------------------------------
# Environnement
# ---------------------------------------------------------------------------
@r.get("/environnement/facteurs", tags=["Environnement"])
def facteurs(p: Principal = Depends(exiger("environnement:lire")), s: Session = Depends(obtenir_session)):
    return [en_dict(f) for f in s.scalars(select(FacteurEmission))]


class NouvelleActivite(BaseModel):
    entite_id: int
    site_id: int | None = None
    actif_id: int | None = None
    categorie: str
    scope: Literal[1, 2, 3]
    categorie_scope3: int | None = None
    quantite: float = Field(ge=0)
    unite: str
    nature_quantite: str | None = None
    periode_debut: datetime
    periode_fin: datetime
    source_type: Literal["compteur", "facture", "releve", "estimation"]
    source_reference: str
    cle_origine: str
    nature: Literal["mesuree", "calculee", "estimee"]
    part_consolidee_pct: float = Field(100, ge=0, le=100)
    exclusions: list[dict] = []


@r.post("/environnement/activites", tags=["Environnement"], status_code=201)
def activite(n: NouvelleActivite, p: Principal = Depends(exiger("environnement:ecrire")), s: Session = Depends(obtenir_session)):
    if n.site_id:
        verifier_portee(s, p, "environnement:ecrire", site_id=n.site_id)
    a, ctrl = env.enregistrer_activite(s, n.model_dump(), p.identifiant)
    return en_dict(a) | {"controles_double_comptage": ctrl}


@r.get("/environnement/activites", tags=["Environnement"])
def activites(p: Principal = Depends(exiger("environnement:lire")), s: Session = Depends(obtenir_session)):
    return [en_dict(a) for a in s.scalars(select(DonneeActivite))]


class DemandeCalcul(BaseModel):
    donnee_activite_id: int
    facteur_code: str


@r.post("/environnement/calculs", tags=["Environnement"], status_code=201)
def calcul(d: DemandeCalcul, p: Principal = Depends(exiger("environnement:ecrire")), s: Session = Depends(obtenir_session)):
    a = s.get(DonneeActivite, d.donnee_activite_id) or _404()
    f = s.scalar(select(FacteurEmission).where(FacteurEmission.code == d.facteur_code)) or _404()
    return en_dict(env.calculer(s, a, f))


@r.post("/environnement/activites/{aid}/valider", tags=["Environnement"])
def valider(aid: int, p: Principal = Depends(exiger("environnement:valider")), s: Session = Depends(obtenir_session)):
    a = s.get(DonneeActivite, aid) or _404()
    if a.saisi_par == p.identifiant:
        raise HTTPException(409, "Séparation des tâches : la personne qui saisit ne peut pas valider")
    a.statut_validation, a.valide_par = "valide_interne", p.identifiant
    auditer(s, p.identifiant, "validation_environnement", f"activite:{aid}")
    return en_dict(a)


@r.get("/environnement/inventaire", tags=["Environnement"])
def inventaire(annee: int = 2026, p: Principal = Depends(exiger("environnement:lire")), s: Session = Depends(obtenir_session)):
    return env.inventaire(s, annee, p.sites_autorises(s, "environnement:lire"))


# ---------------------------------------------------------------------------
# Finance
# ---------------------------------------------------------------------------
@r.get("/finance/synthese", tags=["Finance"])
def synthese(annee: int = 2026, p: Principal = Depends(exiger("finance:lire")), s: Session = Depends(obtenir_session)):
    autorises = p.sites_autorises(s, "finance:lire")
    ents = None if autorises is None else {s.get(Site, x).entite_id for x in autorises}
    return fin.synthese(s, annee, ents)


@r.get("/finance/sites/{site_id}/cout-unitaire", tags=["Finance"])
def cout_unitaire(site_id: int, per=Depends(periode), p: Principal = Depends(exiger("finance:lire")),
                  s: Session = Depends(obtenir_session)):
    verifier_portee(s, p, "finance:lire", site_id=site_id)
    return fin.cout_unitaire_maintenance(s, site_id, per[0], per[1])


@r.get("/finance/sites/{site_id}/revenus", tags=["Finance"])
def revenus(site_id: int, per=Depends(periode), p: Principal = Depends(exiger("finance:lire")),
            s: Session = Depends(obtenir_session)):
    verifier_portee(s, p, "finance:lire", site_id=site_id)
    return fin.revenus_separes(s, site_id, per[0], per[1], "IDX_ELEC_SPOT_SIM")


@r.get("/finance/stations/{site_id}/marge", tags=["Finance"])
def marge(site_id: int, per=Depends(periode), p: Principal = Depends(exiger("finance:lire")),
          s: Session = Depends(obtenir_session)):
    verifier_portee(s, p, "finance:lire", site_id=site_id)
    return fin.marge_carburant(s, site_id, per[0], per[1])


@r.get("/finance/tresorerie", tags=["Finance"])
def tresorerie(debut: str | None = None, p: Principal = Depends(exiger("finance:lire")), s: Session = Depends(obtenir_session)):
    return fin.tresorerie_previsionnelle(s, dt(debut, datetime.fromisoformat("2026-06-15T00:00:00+00:00")))


class Flux(BaseModel):
    date: str
    montant: float
    libelle: str
    nature: str = "flux"


class NouvelInvestissement(BaseModel):
    nom: str
    site_id: int | None = None
    taux_actualisation_pct: float = Field(ge=-50, le=100)
    convention: Literal["dates_reelles_act365", "fin_de_periode_annuelle"] = "dates_reelles_act365"
    base: Literal["nominal", "reel"] = "nominal"
    date_reference: datetime
    flux: list[Flux]
    hypotheses: list[dict] = []
    limites: str = "Flux synthétiques ; fiscalité, financement et valeur terminale non modélisés."


@r.post("/finance/investissements", tags=["Finance"], status_code=201)
def investissement(n: NouvelInvestissement, p: Principal = Depends(exiger("finance:ecrire")),
                   s: Session = Depends(obtenir_session)):
    sc = ScenarioInvestissement(**n.model_dump(exclude={"flux"}), flux=[f.model_dump() for f in n.flux],
                                cree_par=p.identifiant)
    s.add(sc)
    s.flush()
    sc.resultats = fin.evaluer_investissement(sc)
    return en_dict(sc)


@r.get("/finance/investissements", tags=["Finance"])
def investissements(p: Principal = Depends(exiger("finance:lire")), s: Session = Depends(obtenir_session)):
    return [en_dict(x) for x in s.scalars(select(ScenarioInvestissement))]


# ---------------------------------------------------------------------------
# IA et automatisations (lecture seule)
# ---------------------------------------------------------------------------
@r.get("/ia/recherche", tags=["IA"])
def recherche(q: str = Query(..., min_length=2, max_length=200), p: Principal = Depends(exiger("ia:lire")),
              s: Session = Depends(obtenir_session)):
    return ia.rechercher_documents(s, q, p.sites_autorises(s, "documents:lire") if "documents:lire" in p.permissions()
                                   else set())


@r.get("/ia/incidents/{iid}/resume", tags=["IA"])
def resume(iid: int, p: Principal = Depends(exiger("ia:lire")), s: Session = Depends(obtenir_session)):
    i = s.get(Incident, iid) or _404()
    verifier_portee(s, p, "ia:lire", site_id=i.site_id)
    return ia.resumer_incident(s, i)


@r.get("/ia/alertes/{aid}/investigation", tags=["IA"])
def investigation(aid: int, p: Principal = Depends(exiger("ia:lire")), s: Session = Depends(obtenir_session)):
    a = s.get(Alerte, aid) or _404()
    verifier_portee(s, p, "ia:lire", site_id=a.site_id)
    return ia.proposer_investigation(s, a)


@r.get("/ia/sites/{site_id}/anomalies", tags=["IA"])
def anomalies(site_id: int, per=Depends(periode), p: Principal = Depends(exiger("ia:lire")),
              s: Session = Depends(obtenir_session)):
    verifier_portee(s, p, "ia:lire", site_id=site_id)
    return ia.detecter_anomalies(s, site_id, per[0], per[1])


@r.get("/ia/sites/{site_id}/evaluation-previsions", tags=["IA"])
def evaluation(site_id: int, p: Principal = Depends(exiger("ia:lire")), s: Session = Depends(obtenir_session)):
    verifier_portee(s, p, "ia:lire", site_id=site_id)
    d = datetime.fromisoformat
    return ia.evaluer_modeles(s, site_id, d("2026-06-15T00:00:00+00:00"), d("2026-06-19T00:00:00+00:00"),
                              d("2026-06-19T00:00:00+00:00"), d("2026-06-22T00:00:00+00:00"))


@r.get("/ia/sites/{site_id}/explication-ecart", tags=["IA"])
def explication(site_id: int, per=Depends(periode), p: Principal = Depends(exiger("ia:lire")),
                s: Session = Depends(obtenir_session)):
    verifier_portee(s, p, "ia:lire", site_id=site_id)
    return ia.expliquer_ecart(s, site_id, per[0], per[1])


# ---------------------------------------------------------------------------
# Sites industriels et amont (suivi administratif)
# ---------------------------------------------------------------------------
@r.get("/industrie/bilans", tags=["Actifs"])
def bilans(p: Principal = Depends(exiger("industrie:lire")), s: Session = Depends(obtenir_session)):
    return [ind.evaluer_bilan(b) for b in s.scalars(select(BilanMatiere))]


@r.get("/amont/titres", tags=["Contrats"])
def titres(instant: datetime = Depends(instant_ref), p: Principal = Depends(exiger("amont:lire")),
           s: Session = Depends(obtenir_session)):
    return [ind.evaluer_titre(t, instant) for t in s.scalars(select(TitreAmont))]
