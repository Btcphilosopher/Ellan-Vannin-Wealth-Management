"""Routes du socle : authentification, référentiel, mesures, production,
maintenance, documents, indicateurs, rapports, administration."""
from __future__ import annotations

import csv
import io
from datetime import datetime
from typing import Any, Literal

from fastapi import APIRouter, Depends, File, Form, HTTPException, Query, Request, UploadFile
from fastapi.responses import Response
from pydantic import BaseModel, Field
from sqlalchemy import func, select
from sqlalchemy.orm import Session

from ..config import parametres
from ..core import securite as sec
from ..core.models import JournalAudit, Tache, Utilisateur, Habilitation
from ..core.securite import Principal, auditer, exiger, verifier_portee
from ..core.services import en_dict, executer_taches_en_attente, mettre_en_file, stockage
from ..db import maintenant, obtenir_session
from ..modules.maintenance import service as mnt
from ..modules.maintenance.models import Defaut, Inspection, OrdreTravail, Piece
from ..modules.mesures import energie, ingestion, qualite
from ..modules.mesures.models import Alerte, Correction, LotIngestion, Observation
from ..modules.patrimoine import service as pat
from ..modules.patrimoine.models import (Actif, Capacite, ContratMaintenance, Document, Entite, Etude, Groupe,
                                         PointMesure, Responsable, Site, Tiers, VersionObjet)
from ..modules.production import service as prod
from ..modules.production.models import EvenementReduction, Incident, Prevision, ValeurPrevision
from ..modules.reporting import indicateurs, service as rapports
from ..modules.reporting.models import Rapport
from .commun import dt, instant_ref, periode

r = APIRouter()


# ---------------------------------------------------------------------------
# Authentification
# ---------------------------------------------------------------------------
class Connexion(BaseModel):
    identifiant: str = Field(max_length=80)
    mot_de_passe: str = Field(max_length=200)
    code_mfa: str | None = Field(None, max_length=10, description="Code TOTP si le MFA est exigé pour le compte")


@r.post("/auth/connexion", tags=["Authentification"])
def connexion(c: Connexion, request: Request, s: Session = Depends(obtenir_session)):
    sec.limiter_debit(f"connexion:{request.client.host if request.client else '?'}", 30)
    u = sec.FOURNISSEUR.authentifier(s, c.identifiant, c.mot_de_passe)
    if u is None:
        auditer(s, c.identifiant, "connexion", "auth", "echec", {"motif": "identifiants invalides"}, sec._ip(request))
        s.commit()
        raise HTTPException(401, "Identifiants invalides")
    if u.mfa_obligatoire:
        if not c.code_mfa:
            raise HTTPException(401, "Code MFA requis pour ce compte")
        if not sec.MFA.verifier(sec.dechiffrer_secret(u.secret_mfa_chiffre), c.code_mfa):
            auditer(s, u.identifiant, "connexion", "auth", "echec", {"motif": "MFA invalide"}, sec._ip(request))
            s.commit()
            raise HTTPException(401, "Code MFA invalide")
    auditer(s, u.identifiant, "connexion", "auth", "succes", {"mfa": u.mfa_obligatoire,
                                                               "fournisseur": sec.FOURNISSEUR.nom}, sec._ip(request))
    p = sec.charger_principal(s, u)
    return {"jeton": sec.emettre_jeton(u), "type": "Bearer", "utilisateur": _profil(s, p)}


def _profil(s: Session, p: Principal) -> dict:
    portees = []
    for x in p.portees:
        portees.append({"role": x.role, "entite": s.get(Entite, x.entite_id).nom if x.entite_id else None,
                        "site": s.get(Site, x.site_id).nom if x.site_id else None})
    return {"identifiant": p.identifiant, "nom": p.nom_affiche, "habilitations": portees,
            "permissions": sorted(p.permissions())}


@r.get("/auth/moi", tags=["Authentification"])
def moi(p: Principal = Depends(sec.principal_courant), s: Session = Depends(obtenir_session)):
    return _profil(s, p)


@r.get("/auth/demo/comptes", tags=["Authentification"])
def comptes_demo(s: Session = Depends(obtenir_session)):
    if not parametres().mode_demo:
        raise HTTPException(404)
    res = []
    for u in s.scalars(select(Utilisateur).where(Utilisateur.est_compte_service.is_(False))):
        roles = [h.role for h in s.scalars(select(Habilitation).where(Habilitation.utilisateur_id == u.id))]
        res.append({"identifiant": u.identifiant, "nom": u.nom_affiche, "roles": roles, "mfa": u.mfa_obligatoire})
    return {"mot_de_passe_demo": "Demo-E360!", "comptes": res,
            "avertissement": "Comptes fictifs de démonstration — à désactiver hors démonstration (E360_MODE_DEMO=false)"}


@r.get("/auth/demo/code-mfa/{identifiant}", tags=["Authentification"])
def code_mfa_demo(identifiant: str, s: Session = Depends(obtenir_session)):
    """Démonstration uniquement : affiche le code TOTP courant (remplace l'application d'authentification)."""
    if not parametres().mode_demo:
        raise HTTPException(404)
    u = s.scalar(select(Utilisateur).where(Utilisateur.identifiant == identifiant))
    if not u or not u.mfa_obligatoire:
        raise HTTPException(404, "Compte sans MFA")
    return {"code": sec.MFA.code(sec.dechiffrer_secret(u.secret_mfa_chiffre)), "validite_s": sec.MFA.pas}


# ---------------------------------------------------------------------------
# Référentiel des actifs
# ---------------------------------------------------------------------------
@r.get("/patrimoine/arbre", tags=["Actifs"])
def arbre(p: Principal = Depends(exiger("patrimoine:lire")), s: Session = Depends(obtenir_session)):
    autorises = p.sites_autorises(s, "patrimoine:lire")
    groupes = []
    for g in s.scalars(select(Groupe)):
        ents = []
        for e in s.scalars(select(Entite).where(Entite.groupe_id == g.id)):
            sites = [x for x in s.scalars(select(Site).where(Site.entite_id == e.id))
                     if autorises is None or x.id in autorises]
            ents.append({**en_dict(e), "sites": [{**en_dict(x), "nb_actifs": s.scalar(
                select(func.count(Actif.id)).where(Actif.site_id == x.id))} for x in sites]})
        groupes.append({**en_dict(g), "entites": ents})
    return groupes


@r.get("/patrimoine/sites", tags=["Actifs"])
def sites(p: Principal = Depends(exiger("patrimoine:lire")), s: Session = Depends(obtenir_session)):
    autorises = p.sites_autorises(s, "patrimoine:lire")
    return [en_dict(x) | {"entite": s.get(Entite, x.entite_id).nom}
            for x in s.scalars(select(Site)) if autorises is None or x.id in autorises]


@r.get("/patrimoine/carte", tags=["Actifs"])
def carte(p: Principal = Depends(exiger("patrimoine:lire")), s: Session = Depends(obtenir_session)):
    autorises = p.sites_autorises(s, "patrimoine:lire")
    feats = []
    for x in s.scalars(select(Site)):
        if autorises is not None and x.id not in autorises:
            continue
        alertes = s.scalar(select(func.count(Alerte.id)).where(Alerte.site_id == x.id, Alerte.statut != "close"))
        feats.append({"type": "Feature", "geometry": {"type": "Point", "coordinates": [x.longitude, x.latitude]},
                      "properties": {"id": x.id, "code": x.code, "nom": x.nom, "domaine": x.domaine,
                                     "commune": x.commune, "etat": x.etat, "alertes_ouvertes": alertes}})
    return {"type": "FeatureCollection", "crs": "EPSG:4326", "features": feats}


@r.get("/patrimoine/sites/proches", tags=["Actifs"])
def proches(lat: float = Query(..., ge=-90, le=90), lon: float = Query(..., ge=-180, le=180),
            rayon_km: float = Query(50, gt=0, le=2000), p: Principal = Depends(exiger("patrimoine:lire")),
            s: Session = Depends(obtenir_session)):
    return pat.sites_proches(s, lat, lon, rayon_km, p.sites_autorises(s, "patrimoine:lire"))


@r.get("/patrimoine/sites/{site_id}", tags=["Actifs"])
def site_detail(site_id: int, instant: datetime = Depends(instant_ref), p: Principal = Depends(exiger("patrimoine:lire")),
                s: Session = Depends(obtenir_session)):
    verifier_portee(s, p, "patrimoine:lire", site_id=site_id)
    x = s.get(Site, site_id) or _404()
    actifs = s.scalars(select(Actif).where(Actif.site_id == site_id).order_by(Actif.code)).all()
    res = []
    for a in actifs:
        caps = [en_dict(c) for c in pat.capacites_a_date(s, a.id, instant)]
        pts = [en_dict(pt) for pt in s.scalars(select(PointMesure).where(PointMesure.actif_id == a.id))]
        res.append({**en_dict(a), "capacites": caps, "points_mesure": pts})
    return {"site": en_dict(x), "entite": en_dict(s.get(Entite, x.entite_id)), "actifs": res,
            "responsables": [en_dict(rp) for rp in s.scalars(select(Responsable).where(Responsable.site_id == site_id))],
            "contrats_maintenance": [en_dict(c) | {"prestataire": s.get(Tiers, c.prestataire_id).nom}
                                     for c in s.scalars(select(ContratMaintenance)
                                                        .where(ContratMaintenance.site_id == site_id))],
            "documents": [en_dict(d, exclure=("texte_indexable", "cle_stockage"))
                          for d in s.scalars(select(Document).where(Document.site_id == site_id))]}


def _404():
    raise HTTPException(404, "Introuvable")


class NouvelActif(BaseModel):
    site_id: int
    parent_id: int | None = None
    code: str = Field(max_length=60)
    nom: str = Field(max_length=200)
    niveau: Literal["installation", "equipement"]
    type_actif: str
    etat: str = "en_service"
    fabricant: str | None = None
    modele: str | None = None
    date_effet_debut: datetime
    provenance: str = "saisie utilisateur (données synthétiques)"
    attributs: dict[str, Any] = {}


@r.post("/patrimoine/actifs", tags=["Actifs"], status_code=201)
def creer_actif(a: NouvelActif, p: Principal = Depends(exiger("patrimoine:ecrire")), s: Session = Depends(obtenir_session)):
    verifier_portee(s, p, "patrimoine:ecrire", site_id=a.site_id)
    if s.scalar(select(Actif).where(Actif.code == a.code)):
        raise HTTPException(409, "Code d'actif déjà utilisé")
    obj = pat.creer(s, Actif, p.identifiant, **a.model_dump())
    auditer(s, p.identifiant, "creation_actif", f"actif:{obj.id}")
    return en_dict(obj)


class ModifActif(BaseModel):
    motif: str = Field(min_length=3)
    champs: dict[str, Any]


@r.patch("/patrimoine/actifs/{actif_id}", tags=["Actifs"])
def modifier_actif(actif_id: int, m: ModifActif, p: Principal = Depends(exiger("patrimoine:ecrire")),
                   s: Session = Depends(obtenir_session)):
    a = s.get(Actif, actif_id) or _404()
    verifier_portee(s, p, "patrimoine:ecrire", site_id=a.site_id, ressource=f"actif:{actif_id}")
    if "site_id" in m.champs:
        verifier_portee(s, p, "patrimoine:ecrire", site_id=m.champs["site_id"])
    obj, v = pat.modifier(s, Actif, actif_id, p.identifiant, m.motif, **m.champs)
    auditer(s, p.identifiant, "modification_actif", f"actif:{actif_id}", details={"version": v.version})
    return {"actif": en_dict(obj), "version": v.version}


@r.get("/patrimoine/actifs/{actif_id}/historique", tags=["Actifs"])
def historique(actif_id: int, p: Principal = Depends(exiger("patrimoine:lire")), s: Session = Depends(obtenir_session)):
    a = s.get(Actif, actif_id) or _404()
    verifier_portee(s, p, "patrimoine:lire", site_id=a.site_id)
    return [en_dict(v) for v in s.scalars(select(VersionObjet).where(VersionObjet.objet_type == "actif",
                                                                     VersionObjet.objet_id == actif_id)
                                          .order_by(VersionObjet.version))]


class NouvelleCapacite(BaseModel):
    actif_id: int
    nature: Literal["installee", "disponible"]
    grandeur: str
    valeur: float
    unite: str
    date_effet_debut: datetime
    date_effet_fin: datetime | None = None
    provenance: str
    motif: str | None = None


@r.post("/patrimoine/capacites", tags=["Actifs"], status_code=201)
def creer_capacite(c: NouvelleCapacite, p: Principal = Depends(exiger("patrimoine:ecrire")),
                   s: Session = Depends(obtenir_session)):
    a = s.get(Actif, c.actif_id) or _404()
    verifier_portee(s, p, "patrimoine:ecrire", site_id=a.site_id)
    return en_dict(pat.creer(s, Capacite, p.identifiant, **c.model_dump()))


class NouveauPoint(BaseModel):
    actif_id: int
    code: str
    grandeur: str
    unite: str
    nature_grandeur: str | None = None
    type_signal: Literal["instantane", "cumul", "etat"]
    role_comptage: Literal["principal", "controle", "sous_comptage", "information"] = "information"
    perimetre_comptage: str | None = None
    pas_attendu_s: int = 600
    seuil_peremption_s: int = 1800
    borne_min: float | None = None
    borne_max: float | None = None


@r.post("/patrimoine/points-mesure", tags=["Actifs"], status_code=201)
def creer_point(pt: NouveauPoint, p: Principal = Depends(exiger("patrimoine:ecrire")), s: Session = Depends(obtenir_session)):
    a = s.get(Actif, pt.actif_id) or _404()
    verifier_portee(s, p, "patrimoine:ecrire", site_id=a.site_id)
    return en_dict(pat.creer(s, PointMesure, p.identifiant, **pt.model_dump()))


class NouvelleEtude(BaseModel):
    titre: str
    objet: str
    references: list[dict]


@r.post("/patrimoine/etudes", tags=["Actifs"], status_code=201)
def creer_etude(e: NouvelleEtude, p: Principal = Depends(exiger("patrimoine:ecrire")), s: Session = Depends(obtenir_session)):
    et = Etude(titre=e.titre, objet=e.objet, references=e.references, cree_par=p.identifiant)
    s.add(et)
    s.flush()
    return en_dict(et)


@r.post("/patrimoine/etudes/{etude_id}/approuver", tags=["Actifs"])
def approuver(etude_id: int, p: Principal = Depends(exiger("patrimoine:ecrire")), s: Session = Depends(obtenir_session)):
    et = s.get(Etude, etude_id) or _404()
    pat.approuver_etude(s, et, p.identifiant)
    auditer(s, p.identifiant, "approbation_etude", f"etude:{etude_id}", details={"empreinte": et.empreinte})
    return en_dict(et)


@r.get("/patrimoine/etudes/{etude_id}/comparer", tags=["Actifs"])
def comparer(etude_id: int, p: Principal = Depends(exiger("patrimoine:lire")), s: Session = Depends(obtenir_session)):
    return pat.comparer_etude(s, s.get(Etude, etude_id) or _404())


@r.get("/patrimoine/etudes", tags=["Actifs"])
def etudes(p: Principal = Depends(exiger("patrimoine:lire")), s: Session = Depends(obtenir_session)):
    return [en_dict(e, exclure=("instantane",)) for e in s.scalars(select(Etude))]


# ---------------------------------------------------------------------------
# Mesures et qualité
# ---------------------------------------------------------------------------
class MesureEntrante(BaseModel):
    point: str = Field(description="Code du point de mesure")
    observe_le: str = Field(description="ISO 8601 avec fuseau")
    valeur: float | None = None
    valeur_texte: str | None = Field(None, max_length=60)
    unite: str | None = None
    source: str | None = None


class LotEntrant(BaseModel):
    source: str = Field(max_length=60)
    mode: Literal["temps_reel", "rejeu_simulation"] = "temps_reel"
    recu_le: str | None = Field(None, description="Rejeu simulé uniquement : heure de réception simulée")
    mesures: list[MesureEntrante]


@r.post("/mesures/ingestion", tags=["Production"])
def ingerer(lot: LotEntrant, p: Principal = Depends(exiger("mesures:ecrire")), s: Session = Depends(obtenir_session)):
    sec.limiter_debit(f"ingestion:{p.identifiant}", 6000 if p.est_compte_service else None)
    if lot.mode == "rejeu_simulation" and not p.est_compte_service:
        raise HTTPException(403, "Le rejeu simulé est réservé au compte de service d'ingestion")
    l = ingestion.ingerer(s, [m.model_dump() for m in lot.mesures], lot.source, p.identifiant, lot.mode,
                          dt(lot.recu_le))
    return en_dict(l)


@r.post("/mesures/import-csv", tags=["Production"])
async def import_csv(fichier: UploadFile = File(...), source: str = Form("import_csv"),
                     p: Principal = Depends(exiger("mesures:ecrire")), s: Session = Depends(obtenir_session)):
    """Import CSV (colonnes : point, observe_le, valeur, unite) — taille et lignes limitées."""
    cfg = parametres()
    if fichier.content_type not in ("text/csv", "application/vnd.ms-excel", "text/plain"):
        raise HTTPException(415, "Type de fichier non accepté (CSV attendu)")
    contenu = await fichier.read(cfg.import_taille_max_octets + 1)
    if len(contenu) > cfg.import_taille_max_octets:
        raise HTTPException(413, f"Fichier > {cfg.import_taille_max_octets} octets")
    try:
        lignes = list(csv.DictReader(io.StringIO(contenu.decode("utf-8"))))
    except UnicodeDecodeError:
        raise HTTPException(422, "Encodage UTF-8 attendu")
    if len(lignes) > cfg.import_lignes_max:
        raise HTTPException(413, f"Plus de {cfg.import_lignes_max} lignes")
    mesures = [{"point": l.get("point"), "observe_le": l.get("observe_le"),
                "valeur": float(l["valeur"]) if l.get("valeur") not in (None, "") else None,
                "unite": l.get("unite") or None} for l in lignes]
    lot = ingestion.ingerer(s, mesures, source, p.identifiant, "temps_reel")
    lot.mode = "import_fichier"
    auditer(s, p.identifiant, "import_csv", f"lot:{lot.id}", details={"lignes": len(lignes)})
    return en_dict(lot)


@r.get("/mesures/lots", tags=["Production"])
def lots(p: Principal = Depends(exiger("mesures:lire")), s: Session = Depends(obtenir_session)):
    return [en_dict(l) for l in s.scalars(select(LotIngestion).order_by(LotIngestion.id.desc()).limit(100))]


@r.get("/mesures/points/{code}/observations", tags=["Production"])
def observations(code: str, per=Depends(periode), limite: int = Query(500, le=5000),
                 p: Principal = Depends(exiger("mesures:lire")), s: Session = Depends(obtenir_session)):
    pt = s.scalar(select(PointMesure).where(PointMesure.code == code)) or _404()
    verifier_portee(s, p, "mesures:lire", site_id=s.get(Actif, pt.actif_id).site_id)
    obs = s.scalars(select(Observation).where(Observation.point_mesure_id == pt.id, Observation.observe_le >= per[0],
                                              Observation.observe_le < per[1]).order_by(Observation.observe_le)
                    .limit(limite)).all()
    corr = s.scalars(select(Correction).where(Correction.point_mesure_id == pt.id)).all()
    return {"point": en_dict(pt), "observations_brutes": [en_dict(o) for o in obs],
            "corrections_et_estimations": [en_dict(c) for c in corr],
            "note": "Mesures brutes et corrections sont stockées séparément ; aucune valeur brute n'est modifiée."}


@r.get("/mesures/points/{code}/serie", tags=["Production"])
def serie(code: str, per=Depends(periode), pas_s: int = Query(3600, ge=600, le=86400),
          p: Principal = Depends(exiger("mesures:lire")), s: Session = Depends(obtenir_session)):
    pt = s.scalar(select(PointMesure).where(PointMesure.code == code)) or _404()
    verifier_portee(s, p, "mesures:lire", site_id=s.get(Actif, pt.actif_id).site_id)
    return energie.serie(s, pt, per[0], per[1], pas_s)


@r.get("/mesures/points/{code}/energie", tags=["Production"])
def energie_pt(code: str, per=Depends(periode), p: Principal = Depends(exiger("mesures:lire")),
               s: Session = Depends(obtenir_session)):
    pt = s.scalar(select(PointMesure).where(PointMesure.code == code)) or _404()
    verifier_portee(s, p, "mesures:lire", site_id=s.get(Actif, pt.actif_id).site_id)
    return energie.energie_point(s, pt, per[0], per[1])


@r.get("/mesures/sites/{site_id}/bilan", tags=["Production"])
def bilan(site_id: int, per=Depends(periode), p: Principal = Depends(exiger("mesures:lire")),
          s: Session = Depends(obtenir_session)):
    verifier_portee(s, p, "mesures:lire", site_id=site_id)
    return energie.bilan_site(s, site_id, per[0], per[1])


@r.get("/mesures/portefeuille/{perimetre}", tags=["Production"])
def portefeuille(perimetre: str, per=Depends(periode), p: Principal = Depends(exiger("mesures:lire")),
                 s: Session = Depends(obtenir_session)):
    return energie.energie_portefeuille(s, perimetre, per[0], per[1], p.sites_autorises(s, "mesures:lire"))


class DemandeAnalyse(BaseModel):
    site_id: int
    debut: str | None = None
    fin: str | None = None
    instant_reference: str | None = None
    en_arriere_plan: bool = False


@r.post("/mesures/qualite/analyser", tags=["Production"])
def analyser(d: DemandeAnalyse, p: Principal = Depends(exiger("mesures:lire")), s: Session = Depends(obtenir_session)):
    verifier_portee(s, p, "mesures:lire", site_id=d.site_id)
    deb, fin = periode(d.debut, d.fin)
    if d.en_arriere_plan:
        t = mettre_en_file(s, "analyse_qualite", d.model_dump(), p.identifiant)
        return {"tache_id": t.id, "statut": t.statut}
    al = qualite.analyser_site(s, d.site_id, deb, fin, dt(d.instant_reference, fin))
    return {"nouvelles_alertes": [en_dict(a) for a in al], "regles": qualite.REGLES}


@r.get("/mesures/alertes", tags=["Production"])
def alertes(statut: str | None = None, site_id: int | None = None, p: Principal = Depends(exiger("mesures:lire")),
            s: Session = Depends(obtenir_session)):
    autorises = p.sites_autorises(s, "mesures:lire")
    q = select(Alerte).order_by(Alerte.debut.desc())
    if statut:
        q = q.where(Alerte.statut == statut)
    if site_id:
        q = q.where(Alerte.site_id == site_id)
    return [en_dict(a) | {"site": s.get(Site, a.site_id).nom,
                          "actif": s.get(Actif, a.actif_id).code if a.actif_id else None}
            for a in s.scalars(q) if autorises is None or a.site_id in autorises]


@r.post("/mesures/alertes/{alerte_id}/acquitter", tags=["Production"])
def acquitter(alerte_id: int, p: Principal = Depends(exiger("mesures:ecrire")), s: Session = Depends(obtenir_session)):
    a = s.get(Alerte, alerte_id) or _404()
    verifier_portee(s, p, "mesures:ecrire", site_id=a.site_id)
    a.statut, a.acquittee_par = "acquittee", p.identifiant
    return en_dict(a)


class NouvelleCorrection(BaseModel):
    point: str
    debut: datetime
    fin: datetime
    valeur: float
    unite: str
    nature: Literal["correction", "estimation", "substitution"]
    methode: str = Field(min_length=5)
    justification: str = Field(min_length=5)
    observations_sources: list[int] = []


@r.post("/mesures/corrections", tags=["Production"], status_code=201)
def corriger(c: NouvelleCorrection, p: Principal = Depends(exiger("mesures:ecrire")), s: Session = Depends(obtenir_session)):
    pt = s.scalar(select(PointMesure).where(PointMesure.code == c.point)) or _404()
    verifier_portee(s, p, "mesures:ecrire", site_id=s.get(Actif, pt.actif_id).site_id)
    x = Correction(point_mesure_id=pt.id, **c.model_dump(exclude={"point"}), auteur=p.identifiant, cree_le=maintenant())
    s.add(x)
    s.flush()
    auditer(s, p.identifiant, "correction_mesure", f"point:{pt.code}", details={"nature": c.nature})
    return en_dict(x)


# ---------------------------------------------------------------------------
# Production
# ---------------------------------------------------------------------------
@r.get("/production/sites/{site_id}/synthese", tags=["Production"])
def synthese_production(site_id: int, per=Depends(periode), p: Principal = Depends(exiger("production:lire")),
                        s: Session = Depends(obtenir_session)):
    verifier_portee(s, p, "production:lire", site_id=site_id)
    return prod.synthese(s, site_id, per[0], per[1])


@r.get("/production/previsions", tags=["Production"])
def previsions(actif_id: int | None = None, p: Principal = Depends(exiger("production:lire")),
               s: Session = Depends(obtenir_session)):
    q = select(Prevision).where(Prevision.scenario.is_(False))
    if actif_id:
        q = q.where(Prevision.actif_id == actif_id)
    return [en_dict(x) for x in s.scalars(q.order_by(Prevision.emise_le))]


class NouvelleReduction(BaseModel):
    actif_id: int
    type: Literal["limitation_reseau", "ecretement_onduleur", "arret_volontaire"]
    debut: datetime
    fin: datetime
    puissance_limite_kw: float | None = None
    source: str
    reference_externe: str | None = None
    commentaire: str | None = None


@r.post("/production/reductions", tags=["Production"], status_code=201)
def reduction(n: NouvelleReduction, p: Principal = Depends(exiger("production:ecrire")), s: Session = Depends(obtenir_session)):
    a = s.get(Actif, n.actif_id) or _404()
    verifier_portee(s, p, "production:ecrire", site_id=a.site_id)
    x = EvenementReduction(**n.model_dump(), enregistre_par=p.identifiant)
    s.add(x)
    s.flush()
    return en_dict(x)


class NouvelIncident(BaseModel):
    site_id: int
    actif_id: int | None = None
    titre: str
    description: str
    gravite: Literal["mineure", "majeure", "critique"]
    debut: datetime
    fin: datetime | None = None
    alerte_ids: list[int] = []


@r.post("/production/incidents", tags=["Production"], status_code=201)
def incident(n: NouvelIncident, p: Principal = Depends(exiger("production:ecrire")), s: Session = Depends(obtenir_session)):
    verifier_portee(s, p, "production:ecrire", site_id=n.site_id)
    x = Incident(**n.model_dump(), cree_par=p.identifiant)
    s.add(x)
    s.flush()
    return en_dict(x)


@r.get("/production/incidents", tags=["Production"])
def incidents(p: Principal = Depends(exiger("production:lire")), s: Session = Depends(obtenir_session)):
    autorises = p.sites_autorises(s, "production:lire")
    return [en_dict(i) for i in s.scalars(select(Incident)) if autorises is None or i.site_id in autorises]


# ---------------------------------------------------------------------------
# Maintenance
# ---------------------------------------------------------------------------
class NouvelOrdre(BaseModel):
    actif_id: int
    titre: str = Field(max_length=240)
    description: str
    alerte_id: int | None = None
    defaut_id: int | None = None
    priorite: Literal["P1", "P2", "P3"] = "P2"
    type: Literal["correctif", "preventif"] = "correctif"


@r.post("/maintenance/ordres", tags=["Maintenance"], status_code=201)
def creer_ordre(o: NouvelOrdre, p: Principal = Depends(exiger("maintenance:ecrire")), s: Session = Depends(obtenir_session)):
    ot = mnt.creer_ordre(s, p, actif_id=o.actif_id, titre=o.titre, description=o.description, alerte_id=o.alerte_id,
                         defaut_id=o.defaut_id, priorite=o.priorite, type_=o.type)
    auditer(s, p.identifiant, "creation_ot", f"ot:{ot.id}")
    return mnt.detail_ordre(s, ot)


@r.get("/maintenance/ordres", tags=["Maintenance"])
def ordres(p: Principal = Depends(exiger("maintenance:lire")), s: Session = Depends(obtenir_session)):
    autorises = p.sites_autorises(s, "maintenance:lire")
    return [en_dict(o) | {"cout_total": mnt.cout_total(o), "actif": s.get(Actif, o.actif_id).code,
                          "site": s.get(Site, o.site_id).nom}
            for o in s.scalars(select(OrdreTravail).order_by(OrdreTravail.id.desc()))
            if autorises is None or o.site_id in autorises]


@r.get("/maintenance/ordres/{ordre_id}", tags=["Maintenance"])
def ordre(ordre_id: int, p: Principal = Depends(exiger("maintenance:lire")), s: Session = Depends(obtenir_session)):
    ot = s.get(OrdreTravail, ordre_id) or _404()
    verifier_portee(s, p, "maintenance:lire", site_id=ot.site_id)
    return mnt.detail_ordre(s, ot)


class Transition(BaseModel):
    vers: Literal["evalue", "planifie", "en_intervention", "controle", "cloture", "annule"]
    commentaire: str | None = None
    evaluation: str | None = None
    date_planifiee: datetime | None = None
    prestataire_id: int | None = None
    contrat_maintenance_id: int | None = None
    reference_permis_travail: str | None = None
    reference_consignation: str | None = None
    heures_main_oeuvre: float | None = None
    taux_horaire: float | None = None
    cout_externe: float | None = None


@r.post("/maintenance/ordres/{ordre_id}/transition", tags=["Maintenance"])
def transition(ordre_id: int, t: Transition, p: Principal = Depends(exiger("maintenance:ecrire")),
               s: Session = Depends(obtenir_session)):
    ot = s.get(OrdreTravail, ordre_id) or _404()
    champs = t.model_dump(exclude={"vers", "commentaire"}, exclude_none=True)
    mnt.transition(s, p, ot, t.vers, t.commentaire, **champs)
    auditer(s, p.identifiant, "transition_ot", f"ot:{ot.id}", details={"vers": t.vers})
    return mnt.detail_ordre(s, ot)


class Consommation(BaseModel):
    piece_id: int
    quantite: float = Field(gt=0)


@r.post("/maintenance/ordres/{ordre_id}/pieces", tags=["Maintenance"])
def pieces_ot(ordre_id: int, c: Consommation, p: Principal = Depends(exiger("maintenance:ecrire")),
              s: Session = Depends(obtenir_session)):
    ot = s.get(OrdreTravail, ordre_id) or _404()
    mnt.consommer_piece(s, p, ot, c.piece_id, c.quantite)
    return mnt.detail_ordre(s, ot)


class Controle(BaseModel):
    points: list[dict] = Field(description="[{libelle, resultat: conforme|non_conforme|sans_objet, commentaire}]")


@r.post("/maintenance/ordres/{ordre_id}/controle", tags=["Maintenance"])
def controle(ordre_id: int, c: Controle, p: Principal = Depends(exiger("maintenance:ecrire")),
             s: Session = Depends(obtenir_session)):
    ot = s.get(OrdreTravail, ordre_id) or _404()
    return en_dict(mnt.enregistrer_controle(s, p, ot, c.points))


@r.post("/maintenance/ordres/{ordre_id}/cloture-administrative", tags=["Maintenance"])
def cloture_adm(ordre_id: int, p: Principal = Depends(exiger("maintenance:ecrire")), s: Session = Depends(obtenir_session)):
    ot = s.get(OrdreTravail, ordre_id) or _404()
    res = mnt.cloture_administrative(s, p, ot)
    auditer(s, p.identifiant, "cloture_administrative", f"ot:{ot.id}")
    return res


class Decision(BaseModel):
    commentaire: str | None = None
    reference_procedure_externe: str | None = None
    declaration: str | None = None


@r.post("/maintenance/ordres/{ordre_id}/retour-disponibilite", tags=["Maintenance"])
def retour(ordre_id: int, d: Decision, p: Principal = Depends(exiger("maintenance:retour_disponibilite")),
           s: Session = Depends(obtenir_session)):
    ot = s.get(OrdreTravail, ordre_id) or _404()
    x = mnt.retour_disponibilite(s, p, ot, d.commentaire)
    auditer(s, p.identifiant, "retour_disponibilite", f"ot:{ot.id}")
    return en_dict(x)


@r.post("/maintenance/ordres/{ordre_id}/autorisation-operationnelle", tags=["Maintenance"])
def autorisation(ordre_id: int, d: Decision, p: Principal = Depends(exiger("maintenance:autorisation_operationnelle")),
                 s: Session = Depends(obtenir_session)):
    ot = s.get(OrdreTravail, ordre_id) or _404()
    x = mnt.autorisation_operationnelle(s, p, ot, d.reference_procedure_externe or "", d.declaration or "")
    auditer(s, p.identifiant, "autorisation_operationnelle", f"ot:{ot.id}",
            details={"reference": d.reference_procedure_externe})
    return en_dict(x)


@r.get("/maintenance/pieces", tags=["Maintenance"])
def pieces(p: Principal = Depends(exiger("maintenance:lire")), s: Session = Depends(obtenir_session)):
    return [en_dict(x) for x in s.scalars(select(Piece))]


@r.get("/maintenance/prestataires", tags=["Maintenance"])
def prestataires(p: Principal = Depends(exiger("maintenance:lire")), s: Session = Depends(obtenir_session)):
    return [en_dict(t) for t in s.scalars(select(Tiers)) if "prestataire" in (t.roles or [])]


@r.get("/maintenance/inspections", tags=["Maintenance"])
def inspections(p: Principal = Depends(exiger("maintenance:lire")), s: Session = Depends(obtenir_session)):
    return {"inspections": [en_dict(i) for i in s.scalars(select(Inspection))],
            "defauts": [en_dict(d) for d in s.scalars(select(Defaut))]}


# ---------------------------------------------------------------------------
# Documents (stockage objet protégé)
# ---------------------------------------------------------------------------
TYPES_DOCS = {"application/pdf", "text/plain", "text/csv", "image/png", "image/jpeg", "application/json"}


@r.post("/documents", tags=["Administration"], status_code=201)
async def deposer(fichier: UploadFile = File(...), titre: str = Form(...), type_document: str = Form(...),
                  site_id: int | None = Form(None), objet_type: str | None = Form(None),
                  objet_id: int | None = Form(None), p: Principal = Depends(exiger("documents:ecrire")),
                  s: Session = Depends(obtenir_session)):
    if site_id:
        verifier_portee(s, p, "documents:ecrire", site_id=site_id)
    if fichier.content_type not in TYPES_DOCS:
        raise HTTPException(415, "Type de document non autorisé")
    contenu = await fichier.read(parametres().import_taille_max_octets + 1)
    if len(contenu) > parametres().import_taille_max_octets:
        raise HTTPException(413, "Document trop volumineux")
    cle, h = stockage().deposer("documents", fichier.filename or "document", contenu)
    texte = contenu.decode("utf-8", "ignore")[:100_000] if fichier.content_type.startswith("text") else None
    d = Document(titre=titre, type_document=type_document, site_id=site_id, objet_type=objet_type, objet_id=objet_id,
                 cle_stockage=cle, sha256=h, taille_octets=len(contenu), type_mime=fichier.content_type,
                 texte_indexable=texte, depose_par=p.identifiant, depose_le=maintenant())
    s.add(d)
    s.flush()
    auditer(s, p.identifiant, "depot_document", f"document:{d.id}", details={"sha256": h})
    return en_dict(d, exclure=("texte_indexable", "cle_stockage"))


@r.get("/documents/{doc_id}/contenu", tags=["Administration"])
def lire_document(doc_id: int, p: Principal = Depends(exiger("documents:lire")), s: Session = Depends(obtenir_session)):
    d = s.get(Document, doc_id) or _404()
    if d.site_id:
        verifier_portee(s, p, "documents:lire", site_id=d.site_id)
    contenu = stockage().lire(d.cle_stockage, d.sha256)
    auditer(s, p.identifiant, "lecture_document", f"document:{d.id}")
    return Response(contenu, media_type=d.type_mime, headers={"X-Content-SHA256": d.sha256,
                                                             "Content-Disposition": "attachment"})


# ---------------------------------------------------------------------------
# Indicateurs et rapports
# ---------------------------------------------------------------------------
@r.get("/indicateurs", tags=["Vue d'ensemble"])
def vue_ensemble(per=Depends(periode), instant: datetime = Depends(instant_ref),
                 p: Principal = Depends(sec.principal_courant), s: Session = Depends(obtenir_session)):
    return {"periode": {"debut": per[0].isoformat(), "fin": per[1].isoformat()}, "instant_reference": instant.isoformat(),
            "indicateurs": indicateurs.vue_ensemble(s, p, per[0], per[1], instant)}


@r.get("/indicateurs/{code}", tags=["Vue d'ensemble"])
def indicateur(code: str, per=Depends(periode), instant: datetime = Depends(instant_ref),
               p: Principal = Depends(sec.principal_courant), s: Session = Depends(obtenir_session)):
    """Valeur, méthode de calcul et données sources de l'indicateur."""
    return indicateurs.calculer(s, p, code, per[0], per[1], instant)


class DemandeRapport(BaseModel):
    type: Literal["parcours_solaire"] = "parcours_solaire"
    site_id: int
    debut: str | None = None
    fin: str | None = None
    en_arriere_plan: bool = False


@r.post("/rapports", tags=["Administration"], status_code=201)
def creer_rapport(d: DemandeRapport, p: Principal = Depends(exiger("rapports:generer")), s: Session = Depends(obtenir_session)):
    verifier_portee(s, p, "rapports:generer", site_id=d.site_id)
    if d.en_arriere_plan:
        t = mettre_en_file(s, "rapport", d.model_dump() | {"auteur": p.identifiant}, p.identifiant)
        return {"tache_id": t.id, "statut": t.statut}
    deb, fin = periode(d.debut, d.fin)
    rp = rapports.generer(s, d.type, d.site_id, deb, fin, p.identifiant)
    auditer(s, p.identifiant, "generation_rapport", f"rapport:{rp.id}", details={"sha256": rp.sha256_json})
    return en_dict(rp)


@r.get("/rapports", tags=["Administration"])
def liste_rapports(p: Principal = Depends(sec.principal_courant), s: Session = Depends(obtenir_session)):
    return [en_dict(x, exclure=("manifeste",)) for x in s.scalars(select(Rapport).order_by(Rapport.id.desc()))
            if x.site_id is None or p.a("rapports:lire", site_id=x.site_id) or p.a("rapports:generer", site_id=x.site_id)]


@r.get("/rapports/{rapport_id}/telecharger", tags=["Administration"])
def telecharger(rapport_id: int, format: Literal["json", "html"] = "json", p: Principal = Depends(sec.principal_courant),
                s: Session = Depends(obtenir_session)):
    x = s.get(Rapport, rapport_id) or _404()
    if not (p.a("rapports:lire", site_id=x.site_id) or p.a("rapports:generer", site_id=x.site_id)):
        raise HTTPException(403, "Accès au rapport non autorisé")
    cle, h, mt = (x.cle_json, x.sha256_json, "application/json") if format == "json" else \
        (x.cle_html, x.sha256_html, "text/html; charset=utf-8")
    auditer(s, p.identifiant, "telechargement_rapport", f"rapport:{x.id}", details={"format": format})
    return Response(stockage().lire(cle, h), media_type=mt,
                    headers={"X-Content-SHA256": h, "Content-Disposition": f'attachment; filename="rapport_{x.id}.{format}"'})


@r.get("/rapports/{rapport_id}/verifier", tags=["Administration"])
def verifier_rapport(rapport_id: int, p: Principal = Depends(sec.principal_courant), s: Session = Depends(obtenir_session)):
    return rapports.verifier(s, s.get(Rapport, rapport_id) or _404())


# ---------------------------------------------------------------------------
# Administration
# ---------------------------------------------------------------------------
@r.get("/admin/utilisateurs", tags=["Administration"])
def utilisateurs(p: Principal = Depends(exiger("administration:gerer")), s: Session = Depends(obtenir_session)):
    res = []
    for u in s.scalars(select(Utilisateur)):
        habs = [en_dict(h) for h in s.scalars(select(Habilitation).where(Habilitation.utilisateur_id == u.id))]
        res.append(en_dict(u, exclure=("hash_mot_de_passe", "secret_mfa_chiffre")) | {"habilitations": habs})
    return res


@r.get("/admin/audit", tags=["Administration"])
def audit(limite: int = Query(200, le=2000), resultat: str | None = None,
          p: Principal = Depends(exiger("administration:audit")), s: Session = Depends(obtenir_session)):
    q = select(JournalAudit).order_by(JournalAudit.id.desc()).limit(limite)
    if resultat:
        q = q.where(JournalAudit.resultat == resultat)
    return [en_dict(e) for e in s.scalars(q)]


@r.get("/admin/audit/verifier", tags=["Administration"])
def verifier_audit(p: Principal = Depends(exiger("administration:audit")), s: Session = Depends(obtenir_session)):
    return sec.verifier_chaine_audit(s)


@r.get("/admin/taches", tags=["Administration"])
def taches(p: Principal = Depends(exiger("administration:gerer")), s: Session = Depends(obtenir_session)):
    return [en_dict(t) for t in s.scalars(select(Tache).order_by(Tache.id.desc()).limit(100))]


@r.post("/admin/taches/executer", tags=["Administration"])
def executer(p: Principal = Depends(exiger("administration:gerer")), s: Session = Depends(obtenir_session)):
    """Exécute les tâches en attente dans le processus API (le worker le fait en continu)."""
    return [en_dict(t) for t in executer_taches_en_attente(s, 20)]


@r.post("/admin/sauvegardes", tags=["Administration"])
def sauvegarde(p: Principal = Depends(exiger("administration:sauvegarde")), s: Session = Depends(obtenir_session)):
    t = mettre_en_file(s, "sauvegarde", {}, p.identifiant)
    auditer(s, p.identifiant, "demande_sauvegarde", f"tache:{t.id}")
    return {"tache_id": t.id, "statut": t.statut}


@r.get("/admin/adaptateurs", tags=["Administration"])
def adaptateurs(p: Principal = Depends(sec.principal_courant)):
    from ..adaptateurs import registre

    return registre.description()


@r.get("/admin/statut-fonctionnalites", tags=["Administration"])
def statut_fonctionnalites():
    from ..adaptateurs import registre

    return registre.STATUT_FONCTIONNALITES
