from __future__ import annotations

from datetime import datetime

from fastapi import HTTPException, Query

from ..config import parametres
from ..db import maintenant


def dt(v: str | None, defaut: datetime | None = None) -> datetime | None:
    if v is None:
        return defaut
    try:
        d = datetime.fromisoformat(v.replace("Z", "+00:00").replace(" ", "+"))
    except ValueError:
        raise HTTPException(422, f"Horodatage invalide : {v}")
    if d.tzinfo is None:
        raise HTTPException(422, "Horodatage sans fuseau horaire : préciser Z ou ±hh:mm")
    return d


def periode(debut: str | None = Query(None, description="ISO 8601 avec fuseau ; défaut : période de démonstration"),
            fin: str | None = Query(None, description="ISO 8601 avec fuseau")) -> tuple[datetime, datetime]:
    p = parametres()
    d = dt(debut, datetime.fromisoformat(p.demo_debut))
    f = dt(fin, datetime.fromisoformat(p.demo_fin))
    if f <= d:
        raise HTTPException(422, "La fin doit être postérieure au début")
    if (f - d).days > 400:
        raise HTTPException(422, "Période limitée à 400 jours")
    return d, f


def instant_ref(instant: str | None = Query(None, description="Instant de référence (défaut : horloge métier)")) -> datetime:
    return dt(instant, maintenant())
