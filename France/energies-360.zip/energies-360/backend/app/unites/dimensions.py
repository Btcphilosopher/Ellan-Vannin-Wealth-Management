"""Validation dimensionnelle et conversions explicites.

Principes appliqués :

* chaque grandeur porte une **dimension** (vecteur d'exposants) et une **nature**
  (ex. énergie électrique vs énergie contenue dans un combustible, volume
  observé vs volume corrigé à 15 °C) ;
* une conversion automatique n'est permise qu'entre unités de même dimension
  **et** de même nature (kWh → MWh, L → m³ observé) ;
* toute conversion qui dépend d'une propriété physique (densité, température,
  pouvoir calorifique, rendement, taux de change…) passe par une fonction
  dédiée qui exige une :class:`Hypothese` et la conserve dans le résultat ;
* il n'existe **aucun** coefficient universel m³ ↔ t ↔ MWh.
"""
from __future__ import annotations

import math
from dataclasses import dataclass, field, replace
from typing import Iterable

# Dimensions de base : masse, longueur, temps, température, quantité d'unités
# discrètes (colis, fûts…), et une dimension par devise (pas de conversion
# implicite entre devises).
BASES = ("M", "L", "T", "THETA", "N", "EUR", "USD")


def _dim(**exp: int) -> tuple[int, ...]:
    return tuple(exp.get(b, 0) for b in BASES)


SANS_DIM = _dim()
DIM_PUISSANCE = _dim(M=1, L=2, T=-3)
DIM_ENERGIE = _dim(M=1, L=2, T=-2)
DIM_VOLUME = _dim(L=3)
DIM_MASSE = _dim(M=1)
DIM_TEMPS = _dim(T=1)
DIM_TEMP = _dim(THETA=1)
DIM_PRESSION = _dim(M=1, L=-1, T=-2)
DIM_DEBIT_VOL = _dim(L=3, T=-1)
DIM_DEBIT_MASSE = _dim(M=1, T=-1)
DIM_IRRADIANCE = _dim(M=1, T=-3)  # W/m²
DIM_UNITES = _dim(N=1)


class ErreurDimensionnelle(ValueError):
    """Opération entre grandeurs incompatibles."""


class ConversionInterdite(ValueError):
    """Conversion qui exigerait une hypothèse physique non fournie."""


@dataclass(frozen=True)
class Unite:
    symbole: str
    facteur: float  # vers l'unité SI cohérente de la dimension
    dimension: tuple[int, ...]
    decalage: float = 0.0  # unités affines (°C)
    natures: tuple[str, ...] = ()  # natures admises ; vide = toute nature
    libelle: str = ""


_REGISTRE: dict[str, Unite] = {}


def _reg(symbole, facteur, dimension, natures=(), libelle="", decalage=0.0, alias=()):
    u = Unite(symbole, facteur, dimension, decalage, tuple(natures), libelle)
    _REGISTRE[symbole] = u
    for a in alias:
        _REGISTRE[a] = u


NAT_ENERGIE = ("electrique", "combustible_pci", "combustible_pcs", "thermique")
NAT_VOLUME = ("observe", "corrige_15c", "normal_0c_101325", "standard_15c_101325")
NAT_MASSE = ("masse", "co2e")
NAT_PRESSION = ("absolue", "relative")

_reg("sans_dimension", 1, SANS_DIM, libelle="sans dimension", alias=("1",))
_reg("%", 0.01, SANS_DIM, libelle="pour cent")
for s, f in (("W", 1), ("kW", 1e3), ("MW", 1e6), ("GW", 1e9)):
    _reg(s, f, DIM_PUISSANCE, ("electrique", "thermique"), "puissance")
for s, f in (("J", 1), ("kJ", 1e3), ("MJ", 1e6), ("GJ", 1e9), ("Wh", 3600), ("kWh", 3.6e6),
             ("MWh", 3.6e9), ("GWh", 3.6e12), ("TWh", 3.6e15)):
    _reg(s, f, DIM_ENERGIE, NAT_ENERGIE, "énergie")
for s, f in (("m3", 1), ("L", 1e-3), ("hL", 0.1), ("kL", 1.0)):
    _reg(s, f, DIM_VOLUME, NAT_VOLUME, "volume", alias=(s.replace("3", "³"),) if "3" in s else ())
_reg("Nm3", 1, DIM_VOLUME, ("normal_0c_101325",), "volume normal (0 °C, 101,325 kPa)")
_reg("Sm3", 1, DIM_VOLUME, ("standard_15c_101325",), "volume standard (15 °C, 101,325 kPa)")
for s, f in (("g", 1e-3), ("kg", 1), ("t", 1e3), ("kt", 1e6)):
    _reg(s, f, DIM_MASSE, NAT_MASSE, "masse")
for s, f in (("kgCO2e", 1), ("tCO2e", 1e3), ("gCO2e", 1e-3)):
    _reg(s, f, DIM_MASSE, ("co2e",), "masse équivalent CO2")
for s, f in (("s", 1), ("min", 60), ("h", 3600), ("j", 86400)):
    _reg(s, f, DIM_TEMPS, (), "durée")
_reg("K", 1, DIM_TEMP, (), "température")
_reg("degC", 1, DIM_TEMP, (), "température", decalage=273.15, alias=("°C",))
for s, f in (("Pa", 1), ("kPa", 1e3), ("bar", 1e5), ("mbar", 1e2)):
    _reg(s, f, DIM_PRESSION, NAT_PRESSION, "pression")
for s, f in (("m3/h", 1 / 3600), ("L/min", 1e-3 / 60), ("L/h", 1e-3 / 3600)):
    _reg(s, f, DIM_DEBIT_VOL, NAT_VOLUME, "débit volumique")
for s, f in (("kg/h", 1 / 3600), ("t/h", 1 / 3.6)):
    _reg(s, f, DIM_DEBIT_MASSE, ("masse",), "débit massique")
_reg("W/m2", 1, DIM_IRRADIANCE, (), "éclairement", alias=("W/m²",))
for s in ("unite", "fut", "bidon", "bouteille", "palette", "ibc", "session"):
    _reg(s, 1, DIM_UNITES, (), "quantité dénombrée")
_reg("EUR", 1, _dim(EUR=1), (), "euro")
_reg("USD", 1, _dim(USD=1), (), "dollar US")


def unite(symbole: str) -> Unite:
    """Résout un symbole, y compris un quotient simple ``a/b``."""
    if symbole in _REGISTRE:
        return _REGISTRE[symbole]
    if "/" in symbole:
        num, den = symbole.split("/", 1)
        un, ud = unite(num), unite(den)
        if un.decalage or ud.decalage:
            raise ErreurDimensionnelle("Unité affine dans un quotient")
        dim = tuple(a - b for a, b in zip(un.dimension, ud.dimension))
        return Unite(symbole, un.facteur / ud.facteur, dim, 0.0, (), f"{un.libelle} par {ud.libelle}")
    raise ErreurDimensionnelle(f"Unité inconnue : {symbole!r}")


def dimension_de(symbole: str) -> tuple[int, ...]:
    return unite(symbole).dimension


@dataclass(frozen=True)
class Hypothese:
    """Hypothèse physique ou économique explicite attachée à un résultat."""

    nom: str
    valeur: float
    unite: str
    source: str
    condition: str | None = None  # ex. "15 °C", "PCI", "observe"
    validite: str | None = None

    def en_dict(self) -> dict:
        return {k: v for k, v in self.__dict__.items() if v is not None}


@dataclass(frozen=True)
class Quantite:
    valeur: float
    unite: str
    nature: str | None = None
    hypotheses: tuple[Hypothese, ...] = field(default_factory=tuple)

    def __post_init__(self):
        u = unite(self.unite)
        if self.nature and u.natures and self.nature not in u.natures:
            raise ErreurDimensionnelle(
                f"Nature {self.nature!r} incompatible avec l'unité {self.unite} (admises : {u.natures})")
        if u.dimension == DIM_ENERGIE and not self.nature:
            raise ErreurDimensionnelle(
                "Une énergie doit préciser sa nature (electrique, combustible_pci, combustible_pcs, thermique)")
        if u.dimension == DIM_VOLUME and not self.nature:
            raise ErreurDimensionnelle(
                "Un volume doit préciser s'il est observé ou corrigé à des conditions de référence")
        if not math.isfinite(self.valeur):
            raise ErreurDimensionnelle("Valeur non finie")

    @property
    def dimension(self):
        return unite(self.unite).dimension

    def vers(self, cible: str) -> "Quantite":
        """Conversion d'échelle uniquement (même dimension, même nature)."""
        us, uc = unite(self.unite), unite(cible)
        if us.dimension != uc.dimension:
            raise ConversionInterdite(
                f"{self.unite} → {cible} : dimensions différentes ; une hypothèse physique explicite est nécessaire")
        if self.nature and uc.natures and self.nature not in uc.natures:
            raise ConversionInterdite(f"{cible} n'admet pas la nature {self.nature!r}")
        si = self.valeur * us.facteur + us.decalage
        return replace(self, valeur=(si - uc.decalage) / uc.facteur, unite=cible)

    def _compatible(self, autre: "Quantite"):
        if self.dimension != autre.dimension:
            raise ErreurDimensionnelle(f"Addition impossible : {self.unite} et {autre.unite}")
        if (self.nature or None) != (autre.nature or None):
            raise ErreurDimensionnelle(
                f"Addition impossible : natures {self.nature!r} et {autre.nature!r} différentes")
        if unite(self.unite).decalage or unite(autre.unite).decalage:
            raise ErreurDimensionnelle("Addition de températures affines non définie ; utiliser des écarts en K")

    def __add__(self, autre: "Quantite") -> "Quantite":
        self._compatible(autre)
        return replace(self, valeur=self.valeur + autre.vers(self.unite).valeur,
                       hypotheses=_fusion(self.hypotheses, autre.hypotheses))

    def __sub__(self, autre: "Quantite") -> "Quantite":
        self._compatible(autre)
        return replace(self, valeur=self.valeur - autre.vers(self.unite).valeur,
                       hypotheses=_fusion(self.hypotheses, autre.hypotheses))

    def en_dict(self) -> dict:
        d = {"valeur": self.valeur, "unite": self.unite}
        if self.nature:
            d["nature"] = self.nature
        if self.hypotheses:
            d["hypotheses"] = [h.en_dict() for h in self.hypotheses]
        return d


def _fusion(a: Iterable[Hypothese], b: Iterable[Hypothese]) -> tuple[Hypothese, ...]:
    vues, res = set(), []
    for h in (*a, *b):
        if h not in vues:
            vues.add(h)
            res.append(h)
    return tuple(res)


def verifier_unite(symbole: str, dimension_attendue: tuple[int, ...], contexte: str = "") -> None:
    if dimension_de(symbole) != dimension_attendue:
        raise ErreurDimensionnelle(f"{contexte} : unité {symbole} de dimension inattendue")


# ---------------------------------------------------------------------------
# Conversions dépendant d'hypothèses
# ---------------------------------------------------------------------------

def energie_depuis_puissance(puissance: Quantite, duree_h: float) -> Quantite:
    """Énergie = puissance moyenne × durée (la nature est conservée)."""
    if puissance.dimension != DIM_PUISSANCE:
        raise ErreurDimensionnelle("Une puissance est attendue")
    kw = puissance.vers("kW").valeur
    return Quantite(kw * duree_h, "kWh", puissance.nature or "electrique", puissance.hypotheses)


def corriger_volume_15c(volume: Quantite, temperature_c: float, coefficient: Hypothese) -> Quantite:
    """Volume observé → volume corrigé à 15 °C (méthode linéaire simplifiée).

    V15 = Vt × (1 − α × (t − 15)). Cette approximation est documentée comme
    telle : un usage métrologique ou fiscal impose les tables normalisées
    (ex. ISO 91 / API MPMS 11.1), non implémentées dans le prototype.
    """
    if volume.nature != "observe":
        raise ConversionInterdite("La correction à 15 °C s'applique à un volume observé")
    if coefficient.unite not in ("1/K", "/K", "1/degC"):
        raise ErreurDimensionnelle("Coefficient de dilatation attendu en 1/K")
    facteur = 1 - coefficient.valeur * (temperature_c - 15.0)
    hyp_t = Hypothese("temperature_produit", temperature_c, "degC", "mesure associée au volume", "observation")
    meth = Hypothese("methode_correction", 1.0, "sans_dimension",
                     "linéaire simplifiée — ne remplace pas les tables normalisées", "prototype")
    return Quantite(volume.valeur * facteur, volume.unite, "corrige_15c",
                    _fusion(volume.hypotheses, (coefficient, hyp_t, meth)))


def volume_vers_masse(volume: Quantite, densite: Hypothese) -> Quantite:
    """Masse = volume × densité, à condition que la densité corresponde aux
    conditions du volume (densité à 15 °C ↔ volume corrigé à 15 °C)."""
    if volume.dimension != DIM_VOLUME:
        raise ErreurDimensionnelle("Un volume est attendu")
    if densite.unite != "kg/m3":
        raise ErreurDimensionnelle("Densité attendue en kg/m3")
    if densite.condition != volume.nature:
        raise ConversionInterdite(
            f"Densité donnée pour {densite.condition!r} mais volume {volume.nature!r} : "
            "corriger d'abord le volume ou fournir la densité aux conditions observées")
    m3 = volume.vers("m3").valeur
    return Quantite(m3 * densite.valeur, "kg", "masse", _fusion(volume.hypotheses, (densite,)))


def masse_vers_energie(masse: Quantite, pouvoir_calorifique: Hypothese) -> Quantite:
    """Énergie contenue = masse × PCI ou PCS (condition ``PCI`` ou ``PCS``)."""
    if masse.nature != "masse":
        raise ConversionInterdite("Une masse physique est attendue")
    if pouvoir_calorifique.condition not in ("PCI", "PCS"):
        raise ConversionInterdite("Préciser si le pouvoir calorifique est PCI ou PCS")
    u = unite(pouvoir_calorifique.unite)
    if u.dimension != tuple(a - b for a, b in zip(DIM_ENERGIE, DIM_MASSE)):
        raise ErreurDimensionnelle("Pouvoir calorifique attendu en énergie/masse (ex. MJ/kg)")
    joules = masse.vers("kg").valeur * pouvoir_calorifique.valeur * u.facteur
    nature = "combustible_pci" if pouvoir_calorifique.condition == "PCI" else "combustible_pcs"
    return Quantite(joules / 3.6e6, "kWh", nature, _fusion(masse.hypotheses, (pouvoir_calorifique,)))


def pcs_vers_pci(energie: Quantite, ratio_pci_pcs: Hypothese) -> Quantite:
    if energie.nature != "combustible_pcs":
        raise ConversionInterdite("Énergie exprimée en PCS attendue")
    if not 0.8 <= ratio_pci_pcs.valeur <= 1.0:
        raise ConversionInterdite("Ratio PCI/PCS hors plage plausible [0,8 ; 1,0]")
    return Quantite(energie.valeur * ratio_pci_pcs.valeur, energie.unite, "combustible_pci",
                    _fusion(energie.hypotheses, (ratio_pci_pcs,)))


def combustible_vers_electrique(energie: Quantite, rendement: Hypothese) -> Quantite:
    """Estimation d'énergie électrique produite à partir d'un combustible."""
    if energie.nature != "combustible_pci":
        raise ConversionInterdite("Convertir d'abord en PCI ; le rendement s'exprime sur PCI")
    if not 0 < rendement.valeur < 1:
        raise ConversionInterdite("Rendement hors ]0 ; 1[")
    return Quantite(energie.valeur * rendement.valeur, energie.unite, "electrique",
                    _fusion(energie.hypotheses, (rendement,)))


def convertir_devise(montant: Quantite, cible: str, taux: Hypothese) -> Quantite:
    if unite(montant.unite).dimension == unite(cible).dimension:
        return montant
    if taux.unite != f"{cible}/{montant.unite}":
        raise ErreurDimensionnelle(f"Taux attendu en {cible}/{montant.unite}")
    return Quantite(montant.valeur * taux.valeur, cible, None, _fusion(montant.hypotheses, (taux,)))
