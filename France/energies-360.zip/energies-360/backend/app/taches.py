"""Gestionnaires des traitements en arrière-plan."""
from __future__ import annotations

from datetime import datetime
from pathlib import Path

from .config import parametres
from .core.services import en_dict, publier, tache
from .db import heure_reelle, moteur


@tache("analyse_qualite")
def _analyse(session, p: dict):
    from .api.commun import dt
    from .modules.mesures.qualite import analyser_site

    deb = dt(p.get("debut"), datetime.fromisoformat(parametres().demo_debut))
    fin = dt(p.get("fin"), datetime.fromisoformat(parametres().demo_fin))
    al = analyser_site(session, p["site_id"], deb, fin, dt(p.get("instant_reference"), fin))
    session.commit()
    return {"nouvelles_alertes": len(al), "types": sorted({a.type for a in al})}


@tache("rapport")
def _rapport(session, p: dict):
    from .api.commun import dt
    from .modules.reporting.service import generer

    deb = dt(p.get("debut"), datetime.fromisoformat(parametres().demo_debut))
    fin = dt(p.get("fin"), datetime.fromisoformat(parametres().demo_fin))
    r = generer(session, p.get("type", "parcours_solaire"), p["site_id"], deb, fin, p.get("auteur", "worker"))
    publier(session, "rapport", f"Rapport #{r.id} généré", site_id=p["site_id"], rapport_id=r.id)
    session.commit()
    return {"rapport_id": r.id, "sha256": r.sha256_json}


@tache("sauvegarde")
def _sauvegarde(session, p: dict):
    from .sauvegarde import sauvegarder

    dest = Path(parametres().stockage_repertoire) / "sauvegardes" / f"e360_{heure_reelle():%Y%m%dT%H%M%S}.tar.gz"
    m = sauvegarder(moteur(), dest)
    return {"fichier": str(dest), "sha256": m["sha256_archive"], "tables": len(m["tables"])}
