"""Application FastAPI — monolithe modulaire Énergies 360."""
from __future__ import annotations

import asyncio
import json
import logging
import time
from contextlib import asynccontextmanager

from fastapi import FastAPI, Request, WebSocket, WebSocketDisconnect
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from sqlalchemy import select

from . import __version__, modeles, taches  # noqa: F401  (enregistre les tâches)
from .api import routes_metiers, routes_socle
from .config import parametres
from .core import securite as sec
from .core.models import Evenement
from .core.services import en_dict
from .db import configurer, est_configure, moteur, nouvelle_session

journal = logging.getLogger("e360")

DESCRIPTION = """
**Énergies 360** — prototype indépendant de plateforme intégrée pour un groupe multi-énergies.

> Concept indépendant, **sans affiliation** avec un quelconque groupe énergétique et **sans accès** à ses systèmes.
> Toutes les données sont **synthétiques**. Aucune commande de procédé, aucun ordre de marché réel.

Authentification : `POST /api/auth/connexion` puis en-tête `Authorization: Bearer <jeton>`.
Chaque indicateur (`GET /api/indicateurs/{code}`) publie sa méthode et ses données sources.
"""

TAGS = [{"name": n} for n in ("Authentification", "Vue d'ensemble", "Actifs", "Production", "Maintenance",
                               "Approvisionnements", "Logistique", "Contrats", "Distribution", "Mobilité",
                               "Environnement", "Finance", "IA", "Administration")]


@asynccontextmanager
async def cycle_de_vie(app: FastAPI):
    sec.configurer_journaux()
    if not est_configure():
        configurer()
    if moteur().dialect.name == "sqlite":
        modeles.metadata.create_all(moteur())  # PostgreSQL : schéma géré par Alembic
    yield


def creer_application() -> FastAPI:
    p = parametres()
    app = FastAPI(title="Énergies 360 — API (prototype indépendant)", version=__version__, description=DESCRIPTION,
                  openapi_tags=TAGS, lifespan=cycle_de_vie)
    app.add_middleware(CORSMiddleware, allow_origins=[o.strip() for o in p.cors_origines.split(",")],
                       allow_methods=["GET", "POST", "PATCH"], allow_headers=["Authorization", "Content-Type"])

    @app.middleware("http")
    async def entetes_securite(request: Request, call_next):
        debut = time.perf_counter()
        longueur = int(request.headers.get("content-length") or 0)
        if longueur > p.import_taille_max_octets * 2:
            return JSONResponse({"detail": "Requête trop volumineuse"}, status_code=413)
        reponse = await call_next(request)
        reponse.headers["X-Content-Type-Options"] = "nosniff"
        reponse.headers["X-Frame-Options"] = "DENY"
        reponse.headers["Referrer-Policy"] = "no-referrer"
        reponse.headers["Cache-Control"] = "no-store"
        reponse.headers["X-Donnees"] = "synthetiques"
        journal.info("%s %s %s %.0fms", request.method, request.url.path, reponse.status_code,
                     (time.perf_counter() - debut) * 1000)
        return reponse

    app.include_router(routes_socle.r, prefix="/api")
    app.include_router(routes_metiers.r, prefix="/api")

    @app.get("/api/sante", tags=["Administration"])
    def sante():
        return {"statut": "ok", "version": __version__, "base": moteur().dialect.name,
                "donnees": "synthétiques", "mode_demo": p.mode_demo}

    @app.get("/api/contexte", tags=["Vue d'ensemble"])
    def contexte():
        from .db import maintenant

        return {"periode_demo": {"debut": p.demo_debut, "fin": p.demo_fin}, "horloge_metier": maintenant().isoformat(),
                "avertissement": "Prototype indépendant — données synthétiques — sans affiliation."}

    @app.websocket("/ws/evenements")
    async def ws_evenements(ws: WebSocket):
        """Diffusion des événements (alertes, maintenance, logistique, mobilité).

        Le jeton est transmis dans le premier message ``{"jeton": "..."}`` (jamais
        dans l'URL, pour ne pas apparaître dans les journaux)."""
        await ws.accept()
        try:
            premier = json.loads(await asyncio.wait_for(ws.receive_text(), timeout=10))
            with nouvelle_session() as s:
                principal = sec.principal_depuis_jeton(s, premier.get("jeton", ""))
                sites = principal.sites_autorises(s, "mesures:lire") if "mesures:lire" in principal.permissions() \
                    else principal.sites_autorises(s, "patrimoine:lire")
                dernier = s.scalar(select(Evenement.id).order_by(Evenement.id.desc()).limit(1)) or 0
            await ws.send_json({"type": "connexion", "message": f"Connecté : {principal.identifiant}"})
            while True:
                await asyncio.sleep(1.0)
                with nouvelle_session() as s:
                    evts = s.scalars(select(Evenement).where(Evenement.id > dernier).order_by(Evenement.id).limit(50)).all()
                for e in evts:
                    dernier = e.id
                    if e.site_id is not None and sites is not None and e.site_id not in sites:
                        continue
                    await ws.send_json(en_dict(e))
        except (WebSocketDisconnect, asyncio.TimeoutError):
            return
        except Exception as exc:  # jeton invalide, etc.
            try:
                await ws.send_json({"type": "erreur", "message": getattr(exc, "detail", "erreur")})
                await ws.close(code=4401)
            except Exception:
                pass

    @app.websocket("/ws/ocpp/{identifiant}")
    async def ws_ocpp(ws: WebSocket, identifiant: str):
        """Point d'entrée OCPP-J (sous-protocole ``ocpp1.6``), simulé et en lecture seule.

        Prototype : l'authentification de la borne (profil de sécurité OCPP) n'est
        pas implémentée ; ce point d'entrée n'est actif qu'en mode démonstration."""
        if not p.mode_demo:
            await ws.close(code=4403)
            return
        await ws.accept(subprotocol="ocpp1.6")
        from .modules.mobilite.service import traiter_trame

        try:
            while True:
                trame = json.loads(await ws.receive_text())
                with nouvelle_session() as s:
                    rep = traiter_trame(s, identifiant, trame)
                    s.commit()
                await ws.send_text(json.dumps(rep))
        except WebSocketDisconnect:
            return

    return app


app = creer_application()
