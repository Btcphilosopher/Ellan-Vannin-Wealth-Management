"""Import de tous les modèles (métadonnées complètes pour Alembic et create_all)."""
from .core import models as _core  # noqa: F401
from .modules.batterie import models as _bat  # noqa: F401
from .modules.contrats import models as _ctr  # noqa: F401
from .modules.distribution import models as _dist  # noqa: F401
from .modules.environnement import models as _env  # noqa: F401
from .modules.finance import models as _fin  # noqa: F401
from .modules.industrie import models as _ind  # noqa: F401
from .modules.maintenance import models as _mnt  # noqa: F401
from .modules.mesures import models as _mes  # noqa: F401
from .modules.mobilite import models as _mob  # noqa: F401
from .modules.patrimoine import models as _pat  # noqa: F401
from .modules.production import models as _prod  # noqa: F401
from .modules.reporting import models as _rep  # noqa: F401
from .modules.stocks import models as _stk  # noqa: F401
from .db import Base

metadata = Base.metadata
