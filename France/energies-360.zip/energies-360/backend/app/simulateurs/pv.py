"""Simulateur de centrale PV + batterie + poste de livraison (données synthétiques
déterministes), avec injection d'anomalies documentées."""
from __future__ import annotations

import math
import random
from dataclasses import dataclass, field
from datetime import datetime, timedelta, timezone

LAT = 43.62  # site fictif « Les Garrigues » (Occitanie)
PAS = timedelta(minutes=10)


def eclairement_ciel_clair(t: datetime) -> float:
    """Éclairement plan des modules (W/m²) — modèle géométrique simplifié."""
    j = t.timetuple().tm_yday
    decl = math.radians(23.44) * math.sin(2 * math.pi * (284 + j) / 365)
    h_solaire = (t.hour + t.minute / 60 + 0.25) - 12  # UTC ≈ heure solaire + 0,25 h (longitude ~3,9° E)
    w = math.radians(15 * h_solaire)
    lat = math.radians(LAT)
    sin_h = math.sin(lat) * math.sin(decl) + math.cos(lat) * math.cos(decl) * math.cos(w)
    if sin_h <= 0:
        return 0.0
    # plan incliné 25° plein sud : gain approximatif
    return 1080 * sin_h ** 1.15 * (1 + 0.18 * math.cos(w))


def nebulosite(t: datetime) -> float:
    """Facteur nuageux déterministe par jour (0,35 – 1)."""
    jour = (t.date() - datetime(2026, 6, 15).date()).days
    base = [1.0, 0.97, 0.62, 0.95, 0.99, 0.80, 0.98, 1.0, 0.9][jour % 9]
    return base * (0.92 + 0.08 * math.sin(t.hour * 1.7 + jour))


def prevision_eclairement(t: datetime) -> float:
    """Prévision d'éclairement simulée (fournisseur météo fictif) : erreur
    déterministe de ±12 % autour de l'observé sans bruit."""
    return eclairement_ciel_clair(t) * nebulosite(t) * (1 + 0.12 * math.sin(t.toordinal() * 3.1 + t.hour))


@dataclass
class ConfigScenario:
    debut: datetime = datetime(2026, 6, 15, tzinfo=timezone.utc)
    jours: int = 7
    onduleurs: int = 4
    pac_onduleur_kw: float = 2500.0
    pdc_onduleur_kw: float = 3000.0
    graine: int = 360
    anomalies: dict = field(default_factory=lambda: {
        "reset_compteur": ("PV-GAR-OND3-E", datetime(2026, 6, 17, 13, 20, tzinfo=timezone.utc)),
        "panne_onduleur": ("OND2", datetime(2026, 6, 18, 10, 0, tzinfo=timezone.utc),
                           datetime(2026, 6, 18, 15, 30, tzinfo=timezone.utc)),
        "limitation_reseau": (datetime(2026, 6, 16, 12, 0, tzinfo=timezone.utc),
                              datetime(2026, 6, 16, 14, 0, tzinfo=timezone.utc), 6000.0),
        "pyranometre_fige": (datetime(2026, 6, 21, 10, 20, tzinfo=timezone.utc),
                             datetime(2026, 6, 21, 11, 0, tzinfo=timezone.utc)),
        "trou_telemetrie_pdl": (datetime(2026, 6, 20, 9, 0, tzinfo=timezone.utc),
                                datetime(2026, 6, 20, 11, 0, tzinfo=timezone.utc)),
        "pic_incoherent": ("PV-GAR-OND1-P", datetime(2026, 6, 19, 12, 0, tzinfo=timezone.utc), 9999.0),
        "lot_retarde": datetime(2026, 6, 19, 8, 0, tzinfo=timezone.utc),
    })


def _iso(t: datetime) -> str:
    return t.isoformat()


def generer(cfg: ConfigScenario | None = None) -> dict:
    """Retourne {"lots": [ {recu_le, mesures:[...]} ], "verite": {...}}.

    Les lots sont transmis toutes les 10 minutes par une passerelle simulée. Les anomalies sont injectées et la « vérité terrain » est
    renvoyée pour les tests."""
    cfg = cfg or ConfigScenario()
    rnd = random.Random(cfg.graine)
    an = cfg.anomalies
    n = int(cfg.jours * 24 * 6)
    idx = {f"PV-GAR-OND{i}-E": 0.0 for i in range(1, cfg.onduleurs + 1)}
    idx.update({"PV-GAR-CPT-PROD-E": 1_250_000.0, "GAR-PDL-EI": 3_400_000.0, "GAR-PDL-ES": 41_000.0,
                "BESS-GAR-CPT-EC": 520_000.0, "BESS-GAR-CPT-ED": 455_000.0})
    for i in range(1, cfg.onduleurs + 1):
        idx[f"PV-GAR-OND{i}-E"] = 300_000.0 + 1000 * i
    soc = 50.0
    e_nom, pmax_bess = 10_000.0, 5_000.0
    eta_c = eta_d = 0.95
    par_heure: dict[datetime, list[dict]] = {}
    verite = {"production_pv_kwh": 0.0, "injection_kwh": 0.0, "soutirage_kwh": 0.0, "charge_kwh": 0.0,
              "decharge_kwh": 0.0, "auxiliaires_kwh": 0.0, "pertes_transfo_kwh": 0.0,
              "energie_ond3_avant_reset_non_comptee_kwh": 0.0}
    lim_deb, lim_fin, lim_kw = an["limitation_reseau"]
    reset_pt, reset_t = an["reset_compteur"]
    _, panne_deb, panne_fin = an["panne_onduleur"]
    fige_deb, fige_fin = an["pyranometre_fige"]
    trou_deb, trou_fin = an["trou_telemetrie_pdl"]
    valeur_figee = None
    for k in range(n):
        t = cfg.debut + k * PAS
        g = eclairement_ciel_clair(t) * nebulosite(t)
        g_mes = max(0.0, g * (1 + rnd.gauss(0, 0.01))) if g > 0 else 0.0
        t_amb = 19 + 9 * math.sin(math.pi * ((t.hour + t.minute / 60) - 9) / 12) + rnd.gauss(0, 0.3)
        t_mod = t_amb + g / 40
        mes: list[dict] = []

        def m(point, valeur=None, texte=None):
            mes.append({"point": point, "observe_le": _iso(t), "valeur": valeur, "valeur_texte": texte})

        p_total = 0.0
        for i in range(1, cfg.onduleurs + 1):
            pot = max(0.0, g / 1000 * cfg.pdc_onduleur_kw * 0.86 * (1 - 0.0037 * (t_mod - 25)))
            p = min(cfg.pac_onduleur_kw, pot) * (1 + rnd.gauss(0, 0.004)) if pot > 0 else 0.0
            p = min(p, cfg.pac_onduleur_kw)
            etat = "marche" if g > 5 else "veille"
            if lim_deb <= t < lim_fin:
                p = min(p, lim_kw / cfg.onduleurs)
                etat = "limitation" if g > 5 else etat
            if i == 2 and panne_deb <= t < panne_fin:
                p, etat = 0.0, "defaut"
            e = p * PAS.total_seconds() / 3600
            p_total += p
            pt_e = f"PV-GAR-OND{i}-E"
            if pt_e == reset_pt and t == reset_t:
                verite["energie_ond3_avant_reset_non_comptee_kwh"] = round(e * 0.4, 3)
                idx[pt_e] = e * 0.6  # remise à zéro au cours du pas
            else:
                idx[pt_e] += e
            m(f"PV-GAR-OND{i}-P", round(p, 2))
            m(pt_e, round(idx[pt_e], 3))
            m(f"PV-GAR-OND{i}-ETAT", texte=etat)
        e_pv = p_total * PAS.total_seconds() / 3600
        verite["production_pv_kwh"] += e_pv
        idx["PV-GAR-CPT-PROD-E"] += e_pv
        m("PV-GAR-CPT-PROD-E", round(idx["PV-GAR-CPT-PROD-E"], 3))
        m("PV-GAR-CPT-PROD-P", round(p_total, 2))
        # Météo (pyranomètre figé puis muet)
        if fige_deb <= t < fige_fin:
            valeur_figee = valeur_figee if valeur_figee is not None else round(g_mes, 1)
            m("PV-GAR-METEO-GPOA", valeur_figee)
        elif t >= fige_fin and t.date() == fige_fin.date():
            pass  # capteur muet jusqu'à la fin de la journée → capteur périmé
        elif t > fige_fin:
            pass
        else:
            m("PV-GAR-METEO-GPOA", round(g_mes, 1))
        m("PV-GAR-METEO-TAMB", round(t_amb, 2))
        m("PV-GAR-METEO-TMOD", round(t_mod, 2))
        # Batterie : charge le midi sur excédent, décharge le soir
        h = t.hour + t.minute / 60
        p_bess = 0.0  # >0 décharge, <0 charge (côté AC)
        if 10 <= h < 14 and soc < 90:
            p_bess = -min(pmax_bess * 0.6, (90 - soc) / 100 * e_nom / eta_c / (1 / 6))
        elif 17 <= h < 21 and soc > 10:
            p_bess = min(pmax_bess * 0.6, (soc - 10) / 100 * e_nom * eta_d / (1 / 6))
        e_bess = abs(p_bess) / 6
        if p_bess < 0:
            soc += e_bess * eta_c / e_nom * 100
            idx["BESS-GAR-CPT-EC"] += e_bess
            verite["charge_kwh"] += e_bess
        elif p_bess > 0:
            soc -= e_bess / eta_d / e_nom * 100
            idx["BESS-GAR-CPT-ED"] += e_bess
            verite["decharge_kwh"] += e_bess
        mes.append({"point": "BESS-GAR-SOC", "observe_le": _iso(t), "valeur": round(soc, 3)})
        mes.append({"point": "BESS-GAR-P", "observe_le": _iso(t), "valeur": round(p_bess, 2)})
        mes.append({"point": "BESS-GAR-TEMP", "observe_le": _iso(t), "valeur": round(24 + abs(p_bess) / 800 + rnd.gauss(0, .2), 2)})
        m("BESS-GAR-CPT-EC", round(idx["BESS-GAR-CPT-EC"], 3))
        m("BESS-GAR-CPT-ED", round(idx["BESS-GAR-CPT-ED"], 3))
        # Poste de livraison : auxiliaires 25 kW + pertes transfo 1,2 %
        aux = 25.0 / 6
        net = e_pv + (e_bess if p_bess > 0 else -e_bess) - aux
        pertes = max(0.0, net) * 0.012
        net -= pertes
        verite["auxiliaires_kwh"] += aux
        verite["pertes_transfo_kwh"] += pertes
        if net >= 0:
            idx["GAR-PDL-EI"] += net
            verite["injection_kwh"] += net
        else:
            idx["GAR-PDL-ES"] += -net
            verite["soutirage_kwh"] += -net
        if not (trou_deb <= t < trou_fin):
            m("GAR-PDL-EI", round(idx["GAR-PDL-EI"], 3))
            m("GAR-PDL-ES", round(idx["GAR-PDL-ES"], 3))
            m("GAR-PDL-P", round(net * 6, 2))
        # Pic incohérent
        pic_pt, pic_t, pic_v = an["pic_incoherent"]
        if t == pic_t:
            for x in mes:
                if x["point"] == pic_pt:
                    x["valeur"] = pic_v
        # la passerelle transmet chaque pas de 10 min, 2 min après sa fin
        par_heure.setdefault(t + PAS, []).extend(mes)

    lots = []
    for recu, mes in sorted(par_heure.items()):
        recu_le = recu + timedelta(minutes=2)
        if an["lot_retarde"] <= recu < an["lot_retarde"] + timedelta(hours=1):
            recu_le = an["lot_retarde"] + timedelta(hours=3)  # passerelle coupée 1 h, rattrapage 3 h plus tard
        lots.append({"recu_le": _iso(recu_le), "mesures": mes})
    # Doublons : retransmission exacte d'un lot + 2 doublons conflictuels
    retrans = lots[180]
    lots.append({"recu_le": _iso(datetime.fromisoformat(retrans["recu_le"]) + timedelta(minutes=20)),
                 "mesures": [dict(x) for x in retrans["mesures"]], "note": "retransmission exacte"})
    conflits = [dict(x) for x in lots[240]["mesures"] if x["point"] in ("PV-GAR-OND4-P", "PV-GAR-METEO-TAMB")][:2]
    for c in conflits:
        c["valeur"] = round((c["valeur"] or 0) + 7.5, 2)
    lots.append({"recu_le": _iso(datetime.fromisoformat(lots[240]["recu_le"]) + timedelta(minutes=5)),
                 "mesures": conflits, "note": "doublons conflictuels"})
    verite = {k: round(v, 3) for k, v in verite.items()}
    verite["soc_final_pct"] = round(soc, 3)
    verite["doublons_exacts"] = len(retrans["mesures"])
    verite["doublons_conflictuels"] = len(conflits)
    return {"lots": lots, "verite": verite, "config": cfg}


def prix_spot_simule(debut: datetime, heures: int) -> list[tuple[datetime, float]]:
    """Indice horaire d'électricité SIMULÉ (EUR/MWh) : creux solaire, pointe du soir."""
    res = []
    for k in range(heures):
        t = debut + timedelta(hours=k)
        h = t.hour + 2  # heure locale été approx.
        base = 78 + 22 * math.sin(math.pi * (h - 6) / 12) if 6 <= h <= 18 else 70
        creux = -38 * math.exp(-((h - 13.5) ** 2) / 6)
        pointe = 45 * math.exp(-((h - 20) ** 2) / 3)
        res.append((t, round(base + creux + pointe + 6 * math.sin(k / 7), 2)))
    return res
