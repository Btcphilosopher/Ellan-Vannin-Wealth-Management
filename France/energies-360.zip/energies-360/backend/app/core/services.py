"""Services transverses : stockage objet protégé, événements, tâches, utilitaires."""
from __future__ import annotations

import hashlib
import hmac
import json
import time
from datetime import date, datetime
from decimal import Decimal
from pathlib import Path
from typing import Any, Callable

from sqlalchemy import inspect, select, update
from sqlalchemy.orm import Session

from ..config import parametres
from ..db import maintenant
from .models import Evenement, Tache


# ---------------------------------------------------------------------------
# Sérialisation
# ---------------------------------------------------------------------------

def en_dict(obj, exclure: tuple[str, ...] = ()) -> dict:
    if obj is None:
        return None  # type: ignore[return-value]
    res = {}
    for col in inspect(obj).mapper.column_attrs:
        if col.key in exclure:
            continue
        v = getattr(obj, col.key)
        res[col.key] = serialiser(v)
    return res


def serialiser(v):
    if isinstance(v, datetime):
        return v.isoformat()
    if isinstance(v, date):
        return v.isoformat()
    if isinstance(v, Decimal):
        return float(v)
    return v


def json_stable(obj) -> str:
    return json.dumps(obj, sort_keys=True, ensure_ascii=False, default=serialiser, separators=(",", ":"))


def sha256(donnees: bytes | str) -> str:
    if isinstance(donnees, str):
        donnees = donnees.encode()
    return hashlib.sha256(donnees).hexdigest()


# ---------------------------------------------------------------------------
# Stockage objet protégé
# ---------------------------------------------------------------------------

class StockageObjet:
    """Interface de stockage objet : écriture adressée par contenu, intégrité
    vérifiée à la lecture, accès uniquement via l'API (contrôle de permission)."""

    def deposer(self, espace: str, nom: str, contenu: bytes) -> tuple[str, str]:
        raise NotImplementedError  # pragma: no cover

    def lire(self, cle: str, empreinte_attendue: str | None = None) -> bytes:
        raise NotImplementedError  # pragma: no cover


class StockageLocal(StockageObjet):
    """Système de fichiers local (volume Docker non exposé)."""

    def __init__(self, racine: str):
        self.racine = Path(racine)
        self.racine.mkdir(parents=True, exist_ok=True)

    def deposer(self, espace, nom, contenu):
        h = sha256(contenu)
        sur = "".join(c for c in nom if c.isalnum() or c in "._-")[:80] or "objet"
        cle = f"{espace}/{h[:2]}/{h}_{sur}"
        chemin = self.racine / cle
        chemin.parent.mkdir(parents=True, exist_ok=True)
        if not chemin.exists():
            chemin.write_bytes(contenu)
        return cle, h

    def lire(self, cle, empreinte_attendue=None):
        chemin = (self.racine / cle).resolve()
        if self.racine.resolve() not in chemin.parents:
            raise PermissionError("Clé de stockage hors espace autorisé")
        contenu = chemin.read_bytes()
        if empreinte_attendue and sha256(contenu) != empreinte_attendue:
            raise ValueError("Intégrité de l'objet compromise (empreinte différente)")
        return contenu


class StockageS3(StockageObjet):  # pragma: no cover - dépend d'un service externe
    """Stockage compatible S3 (MinIO dans Docker Compose). Nécessite ``boto3``."""

    def __init__(self):
        import boto3  # noqa: import optionnel

        p = parametres()
        self.bucket = p.s3_bucket
        self.client = boto3.client("s3", endpoint_url=p.s3_endpoint, aws_access_key_id=p.s3_access_key,
                                   aws_secret_access_key=p.s3_secret_key)
        try:
            self.client.head_bucket(Bucket=self.bucket)
        except Exception:
            self.client.create_bucket(Bucket=self.bucket)

    def deposer(self, espace, nom, contenu):
        h = sha256(contenu)
        cle = f"{espace}/{h[:2]}/{h}_{nom[:80]}"
        self.client.put_object(Bucket=self.bucket, Key=cle, Body=contenu, Metadata={"sha256": h},
                               ServerSideEncryption="AES256")
        return cle, h

    def lire(self, cle, empreinte_attendue=None):
        contenu = self.client.get_object(Bucket=self.bucket, Key=cle)["Body"].read()
        if empreinte_attendue and sha256(contenu) != empreinte_attendue:
            raise ValueError("Intégrité de l'objet compromise")
        return contenu


_stockage: StockageObjet | None = None


def stockage() -> StockageObjet:
    global _stockage
    if _stockage is None:
        p = parametres()
        _stockage = StockageS3() if p.stockage_backend == "s3" else StockageLocal(p.stockage_repertoire)
    return _stockage


def reinitialiser_stockage(racine: str | None = None):
    global _stockage
    _stockage = StockageLocal(racine) if racine else None


def url_signee(cle: str, duree_s: int = 300) -> str:
    exp = int(time.time()) + duree_s
    sig = hmac.new(parametres().jwt_secret.encode(), f"{cle}:{exp}".encode(), hashlib.sha256).hexdigest()
    return f"?cle={cle}&exp={exp}&sig={sig}"


# ---------------------------------------------------------------------------
# Événements (diffusion WebSocket)
# ---------------------------------------------------------------------------

def publier(session: Session, type_: str, message: str, site_id: int | None = None, **donnees) -> Evenement:
    e = Evenement(type=type_, message=message, site_id=site_id, donnees=json.loads(json_stable(donnees)),
                  cree_le=maintenant())
    session.add(e)
    session.flush()
    return e


# ---------------------------------------------------------------------------
# Tâches en arrière-plan
# ---------------------------------------------------------------------------
GESTIONNAIRES: dict[str, Callable[[Session, dict], Any]] = {}


def tache(nom: str):
    def deco(fn):
        GESTIONNAIRES[nom] = fn
        return fn

    return deco


def mettre_en_file(session: Session, type_: str, parametres_: dict, demandeur: str) -> Tache:
    if type_ not in GESTIONNAIRES:
        raise ValueError(f"Type de tâche inconnu : {type_}")
    t = Tache(type=type_, parametres=parametres_, demandee_par=demandeur, cree_le=maintenant())
    session.add(t)
    session.flush()
    return t


def prendre_tache(session: Session) -> Tache | None:
    """Réservation atomique d'une tâche (``FOR UPDATE SKIP LOCKED`` sous PostgreSQL)."""
    q = select(Tache).where(Tache.statut == "en_attente").order_by(Tache.id).limit(1)
    if session.bind.dialect.name == "postgresql":
        q = q.with_for_update(skip_locked=True)
    t = session.scalar(q)
    if t is None:
        return None
    n = session.execute(update(Tache).where(Tache.id == t.id, Tache.statut == "en_attente")
                        .values(statut="en_cours", debut=maintenant(), tentatives=Tache.tentatives + 1)).rowcount
    if n != 1:
        return None
    session.flush()
    session.refresh(t)
    return t


def executer_tache(session: Session, t: Tache) -> Tache:
    try:
        res = GESTIONNAIRES[t.type](session, t.parametres or {})
        t.resultat = json.loads(json_stable(res)) if res is not None else None
        t.statut = "terminee"
    except Exception as exc:  # noqa: BLE001 - la tâche capture l'erreur
        session.rollback()
        t = session.get(Tache, t.id)
        t.statut = "echec"
        t.erreur = str(exc)[:2000]
    t.fin = maintenant()
    session.commit()
    return t


def executer_taches_en_attente(session: Session, maximum: int = 100) -> list[Tache]:
    faites = []
    for _ in range(maximum):
        t = prendre_tache(session)
        if t is None:
            break
        session.commit()
        faites.append(executer_tache(session, t))
    return faites
