"""Authentification, MFA, permissions par rôle / entité / site, audit, expurgation.

* L'authentification organisationnelle passe par un adaptateur de fournisseur
  d'identité (annuaire local simulé ; un adaptateur OIDC est prévu).
* Le MFA passe par un adaptateur ; l'implémentation fournie est TOTP (RFC 6238).
* Les permissions combinent un rôle et une portée (globale, entité ou site).
"""
from __future__ import annotations

import base64
import hashlib
import hmac
import json
import logging
import re
import struct
import time
from collections import defaultdict, deque
from dataclasses import dataclass, field
from datetime import timedelta
from typing import Iterable

import jwt
from argon2 import PasswordHasher
from argon2.exceptions import VerifyMismatchError
from fastapi import Depends, HTTPException, Request, status
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer
from sqlalchemy import select
from sqlalchemy.orm import Session

from ..config import parametres
from ..db import heure_reelle, maintenant, obtenir_session
from .models import Habilitation, JournalAudit, Utilisateur

journal = logging.getLogger("e360.securite")
_hasher = PasswordHasher()

# ---------------------------------------------------------------------------
# Rôles et permissions
# ---------------------------------------------------------------------------
DOMAINES = ("patrimoine", "mesures", "production", "maintenance", "approvisionnements", "stocks",
            "contrats", "distribution", "mobilite", "batterie", "environnement", "finance",
            "rapports", "ia", "documents", "industrie", "amont")
LECTURE_TOUT = {f"{d}:lire" for d in DOMAINES}

ROLES: dict[str, set[str]] = {
    "admin_plateforme": {"administration:gerer", "administration:audit", "administration:sauvegarde",
                         "patrimoine:lire", "mesures:lire"},
    "direction": LECTURE_TOUT | {"rapports:generer"},
    "auditeur": LECTURE_TOUT | {"administration:audit"},
    "responsable_site": {"patrimoine:lire", "patrimoine:ecrire", "mesures:lire", "mesures:ecrire",
                         "production:lire", "production:ecrire", "maintenance:lire", "maintenance:ecrire",
                         "maintenance:retour_disponibilite", "stocks:lire", "batterie:lire", "batterie:simuler",
                         "finance:lire", "environnement:lire", "rapports:lire", "rapports:generer", "ia:lire",
                         "documents:lire", "documents:ecrire"},
    "technicien_maintenance": {"patrimoine:lire", "mesures:lire", "production:lire", "maintenance:lire",
                               "maintenance:ecrire", "documents:lire", "documents:ecrire", "ia:lire"},
    "exploitant_habilite": {"patrimoine:lire", "mesures:lire", "production:lire", "maintenance:lire",
                            "maintenance:autorisation_operationnelle", "documents:lire"},
    "logisticien": {"patrimoine:lire", "stocks:lire", "stocks:ecrire", "approvisionnements:lire",
                    "approvisionnements:ecrire", "distribution:lire", "distribution:ecrire", "documents:lire",
                    "documents:ecrire", "contrats:lire"},
    "gestionnaire_contrats": {"contrats:lire", "contrats:ecrire", "marche:simuler", "approvisionnements:lire",
                              "distribution:lire", "stocks:lire", "finance:lire", "patrimoine:lire",
                              "mesures:lire", "rapports:generer", "documents:lire"},
    "analyste_finance": {"finance:lire", "finance:ecrire", "contrats:lire", "maintenance:lire",
                         "production:lire", "mesures:lire", "patrimoine:lire", "distribution:lire",
                         "mobilite:lire", "batterie:lire", "batterie:simuler", "rapports:lire",
                         "rapports:generer", "stocks:lire"},
    "analyste_environnement": {"environnement:lire", "environnement:ecrire", "mesures:lire", "patrimoine:lire",
                               "distribution:lire", "production:lire", "rapports:generer", "rapports:lire"},
    "validateur_environnement": {"environnement:lire", "environnement:valider", "patrimoine:lire"},
    "operateur_mobilite": {"mobilite:lire", "mobilite:ecrire", "patrimoine:lire", "maintenance:lire",
                           "maintenance:ecrire", "mesures:lire"},
    "service_ia": LECTURE_TOUT - {"finance:lire"},  # lecture seule, aucune écriture
    "service_ingestion": {"mesures:ecrire", "mobilite:ecrire", "patrimoine:lire"},
}

PERMISSIONS_INTERDITES_IA = {"maintenance:ecrire", "maintenance:autorisation_operationnelle",
                             "maintenance:retour_disponibilite", "finance:ecrire", "marche:simuler",
                             "stocks:ecrire", "contrats:ecrire"}
assert not (ROLES["service_ia"] & PERMISSIONS_INTERDITES_IA)


@dataclass
class Portee:
    role: str
    entite_id: int | None
    site_id: int | None


@dataclass
class Principal:
    id: int
    identifiant: str
    nom_affiche: str
    portees: list[Portee] = field(default_factory=list)
    est_compte_service: bool = False

    def roles(self) -> set[str]:
        return {p.role for p in self.portees}

    def permissions(self) -> set[str]:
        res: set[str] = set()
        for p in self.portees:
            res |= ROLES.get(p.role, set())
        return res

    def a(self, permission: str, site_id: int | None = None, entite_id: int | None = None) -> bool:
        from ..modules.patrimoine.models import Site  # import tardif (cycle)

        for p in self.portees:
            if permission not in ROLES.get(p.role, set()):
                continue
            if p.entite_id is None and p.site_id is None:
                return True
            if site_id is not None:
                if p.site_id == site_id:
                    return True
                if p.entite_id is not None and p.entite_id == _entite_du_site(site_id):
                    return True
            elif entite_id is not None and p.site_id is None and p.entite_id == entite_id:
                return True
        return False

    def sites_autorises(self, session: Session, permission: str) -> set[int] | None:
        """Ensemble des sites autorisés ; ``None`` signifie « tous »."""
        from ..modules.patrimoine.models import Site

        res: set[int] = set()
        for p in self.portees:
            if permission not in ROLES.get(p.role, set()):
                continue
            if p.entite_id is None and p.site_id is None:
                return None
            if p.site_id is not None:
                res.add(p.site_id)
            elif p.entite_id is not None:
                res |= set(session.scalars(select(Site.id).where(Site.entite_id == p.entite_id)))
        return res


_cache_entites: dict[int, int] = {}


def _entite_du_site(site_id: int) -> int | None:
    if site_id in _cache_entites:
        return _cache_entites[site_id]
    from ..db import session_scope
    from ..modules.patrimoine.models import Site

    with session_scope() as s:
        site = s.get(Site, site_id)
        if site is None:
            return None
        _cache_entites[site_id] = site.entite_id
        return site.entite_id


def vider_cache_portees():
    _cache_entites.clear()


# ---------------------------------------------------------------------------
# Mots de passe et MFA (adaptateur TOTP RFC 6238)
# ---------------------------------------------------------------------------

def hacher_mot_de_passe(mdp: str) -> str:
    return _hasher.hash(mdp)


def verifier_mot_de_passe(hash_: str, mdp: str) -> bool:
    try:
        return _hasher.verify(hash_, mdp)
    except VerifyMismatchError:
        return False
    except Exception:
        return False


class AdaptateurMFA:
    """Interface : un fournisseur MFA vérifie un facteur pour un utilisateur."""

    nom = "abstrait"

    def verifier(self, secret: str, code: str) -> bool:  # pragma: no cover - interface
        raise NotImplementedError


class MFATotp(AdaptateurMFA):
    nom = "totp_rfc6238"
    pas = 30
    chiffres = 6

    def code(self, secret_b32: str, instant: float | None = None) -> str:
        cle = base64.b32decode(secret_b32.upper() + "=" * (-len(secret_b32) % 8))
        compteur = int((instant if instant is not None else time.time()) // self.pas)
        mac = hmac.new(cle, struct.pack(">Q", compteur), hashlib.sha1).digest()
        o = mac[-1] & 0x0F
        val = (struct.unpack(">I", mac[o:o + 4])[0] & 0x7FFFFFFF) % (10 ** self.chiffres)
        return str(val).zfill(self.chiffres)

    def verifier(self, secret: str, code: str) -> bool:
        t = time.time()
        return any(hmac.compare_digest(self.code(secret, t + d * self.pas), code or "") for d in (-1, 0, 1))


MFA = MFATotp()


def _cle_chiffrement() -> bytes:
    return hashlib.sha256(("mfa:" + parametres().cle_chiffrement).encode()).digest()


def chiffrer_secret(secret: str) -> str:
    """Protection simple du secret MFA au repos (XOR avec une clé dérivée).

    Prototype : en production, utiliser un KMS / coffre de secrets.
    """
    cle = _cle_chiffrement()
    b = secret.encode()
    return base64.b64encode(bytes(x ^ cle[i % len(cle)] for i, x in enumerate(b))).decode()


def dechiffrer_secret(valeur: str) -> str:
    cle = _cle_chiffrement()
    b = base64.b64decode(valeur)
    return bytes(x ^ cle[i % len(cle)] for i, x in enumerate(b)).decode()


# ---------------------------------------------------------------------------
# Adaptateurs de fournisseur d'identité
# ---------------------------------------------------------------------------

class FournisseurIdentite:
    nom = "abstrait"

    def authentifier(self, session: Session, identifiant: str, secret: str) -> Utilisateur | None:
        raise NotImplementedError  # pragma: no cover


class AnnuaireLocalSimule(FournisseurIdentite):
    """Annuaire organisationnel simulé (comptes fictifs en base)."""

    nom = "annuaire_local_simule"

    def authentifier(self, session, identifiant, secret):
        u = session.scalar(select(Utilisateur).where(Utilisateur.identifiant == identifiant))
        if u and u.actif and verifier_mot_de_passe(u.hash_mot_de_passe, secret):
            return u
        return None


class FournisseurOIDC(FournisseurIdentite):
    """Point d'extension OIDC (non intégré). Vérifier la configuration auprès de
    la documentation officielle du fournisseur retenu (découverte, JWKS, PKCE)."""

    nom = "oidc_non_integre"

    def authentifier(self, session, identifiant, secret):
        raise HTTPException(501, "Fournisseur OIDC non intégré dans ce prototype")


FOURNISSEUR = AnnuaireLocalSimule()


# ---------------------------------------------------------------------------
# Jetons
# ---------------------------------------------------------------------------

def emettre_jeton(u: Utilisateur) -> str:
    p = parametres()
    now = heure_reelle()
    charge = {"sub": str(u.id), "idt": u.identifiant, "iat": int(now.timestamp()),
              "exp": int((now + timedelta(minutes=p.jwt_duree_minutes)).timestamp()), "iss": "energies360"}
    return jwt.encode(charge, p.jwt_secret, algorithm=p.jwt_algorithme)


def charger_principal(session: Session, u: Utilisateur) -> Principal:
    now = maintenant()
    habs = session.scalars(select(Habilitation).where(Habilitation.utilisateur_id == u.id)).all()
    portees = [Portee(h.role, h.entite_id, h.site_id) for h in habs
               if (h.valide_a is None or h.valide_a > now)]
    return Principal(u.id, u.identifiant, u.nom_affiche, portees, u.est_compte_service)


_bearer = HTTPBearer(auto_error=False)


def principal_courant(request: Request, cred: HTTPAuthorizationCredentials | None = Depends(_bearer),
                      session: Session = Depends(obtenir_session)) -> Principal:
    if cred is None:
        raise HTTPException(status.HTTP_401_UNAUTHORIZED, "Authentification requise")
    return principal_depuis_jeton(session, cred.credentials)


def principal_depuis_jeton(session: Session, jeton: str) -> Principal:
    p = parametres()
    try:
        charge = jwt.decode(jeton, p.jwt_secret, algorithms=[p.jwt_algorithme], issuer="energies360",
                            options={"verify_iat": False})
    except jwt.PyJWTError:
        raise HTTPException(status.HTTP_401_UNAUTHORIZED, "Jeton invalide ou expiré")
    u = session.get(Utilisateur, int(charge["sub"]))
    if not u or not u.actif:
        raise HTTPException(status.HTTP_401_UNAUTHORIZED, "Compte inactif")
    return charger_principal(session, u)


def exiger(permission: str):
    """Dépendance FastAPI : la permission doit exister sur au moins une portée."""

    def _dep(request: Request, principal: Principal = Depends(principal_courant),
             session: Session = Depends(obtenir_session)) -> Principal:
        if permission not in principal.permissions():
            auditer(session, principal.identifiant, "acces_refuse", request.url.path, "refus",
                    {"permission": permission}, _ip(request))
            session.commit()
            raise HTTPException(status.HTTP_403_FORBIDDEN,
                                f"Permission « {permission} » absente de vos habilitations")
        return principal

    return _dep


def verifier_portee(session: Session, principal: Principal, permission: str, *, site_id: int | None = None,
                    entite_id: int | None = None, ressource: str = "") -> None:
    if not principal.a(permission, site_id=site_id, entite_id=entite_id):
        auditer(session, principal.identifiant, "acces_refuse", ressource or f"site:{site_id}", "refus",
                {"permission": permission, "site_id": site_id, "entite_id": entite_id})
        session.commit()
        raise HTTPException(status.HTTP_403_FORBIDDEN,
                            f"Permission « {permission} » non accordée sur ce périmètre")


def _ip(request: Request | None) -> str | None:
    if request is None or request.client is None:
        return None
    return request.client.host


# ---------------------------------------------------------------------------
# Audit chaîné
# ---------------------------------------------------------------------------
_GENESE = "0" * 64


def _empreinte(prec: str, horodatage: str, acteur: str, action: str, ressource: str, resultat: str,
               details: dict) -> str:
    contenu = json.dumps([prec, horodatage, acteur, action, ressource, resultat, details],
                         sort_keys=True, ensure_ascii=False, default=str)
    return hashlib.sha256(contenu.encode()).hexdigest()


def auditer(session: Session, acteur: str, action: str, ressource: str, resultat: str = "succes",
            details: dict | None = None, adresse: str | None = None) -> JournalAudit:
    details = expurger_dict(details or {})
    dernier = session.scalar(select(JournalAudit).order_by(JournalAudit.id.desc()).limit(1))
    prec = dernier.empreinte if dernier else _GENESE
    h = heure_reelle().replace(microsecond=0)
    e = JournalAudit(horodatage=h, acteur=acteur, action=action, ressource=ressource, resultat=resultat,
                     details=details, adresse=adresse, empreinte_precedente=prec,
                     empreinte=_empreinte(prec, h.isoformat(), acteur, action, ressource, resultat, details))
    session.add(e)
    session.flush()
    return e


def verifier_chaine_audit(session: Session) -> dict:
    prec = _GENESE
    n = 0
    for e in session.scalars(select(JournalAudit).order_by(JournalAudit.id)):
        attendu = _empreinte(prec, e.horodatage.replace(microsecond=0).isoformat(), e.acteur, e.action,
                             e.ressource, e.resultat, e.details or {})
        if e.empreinte_precedente != prec or e.empreinte != attendu:
            return {"integre": False, "premiere_rupture": e.id, "entrees_verifiees": n}
        prec = e.empreinte
        n += 1
    return {"integre": True, "entrees_verifiees": n, "derniere_empreinte": prec}


# ---------------------------------------------------------------------------
# Expurgation des journaux
# ---------------------------------------------------------------------------
_MOTIFS = [
    (re.compile(r"(?i)(bearer\s+)[A-Za-z0-9\-_\.=]+"), r"\1[EXPURGÉ]"),
    (re.compile(r"(?i)(\"?(mot_de_passe|password|secret|code_mfa|token|jeton|api[_-]?key)\"?\s*[:=]\s*\"?)[^\s\",}]+"),
     r"\1[EXPURGÉ]"),
    (re.compile(r"[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}"), "[COURRIEL EXPURGÉ]"),
    (re.compile(r"eyJ[A-Za-z0-9_\-]+\.[A-Za-z0-9_\-]+\.[A-Za-z0-9_\-]+"), "[JWT EXPURGÉ]"),
]
_CLES_SENSIBLES = {"mot_de_passe", "password", "secret", "code_mfa", "jeton", "token", "id_tag", "idTag"}


def expurger(texte: str) -> str:
    for motif, remplacement in _MOTIFS:
        texte = motif.sub(remplacement, texte)
    return texte


def expurger_dict(d):
    if isinstance(d, dict):
        return {k: ("[EXPURGÉ]" if k in _CLES_SENSIBLES else expurger_dict(v)) for k, v in d.items()}
    if isinstance(d, list):
        return [expurger_dict(x) for x in d]
    if isinstance(d, str):
        return expurger(d)
    return d


class FiltreExpurgation(logging.Filter):
    def filter(self, record: logging.LogRecord) -> bool:
        try:
            msg = record.getMessage()
        except Exception:  # pragma: no cover
            return True
        record.msg = expurger(msg)
        record.args = ()
        return True


def configurer_journaux():
    racine = logging.getLogger()
    if not any(isinstance(f, FiltreExpurgation) for h in racine.handlers for f in h.filters):
        logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s %(message)s")
        for h in logging.getLogger().handlers:
            h.addFilter(FiltreExpurgation())


# ---------------------------------------------------------------------------
# Limitation de débit (mémoire, par identifiant) — prototype mono-instance
# ---------------------------------------------------------------------------
_fenetres: dict[str, deque] = defaultdict(deque)


def limiter_debit(cle: str, max_par_minute: int | None = None) -> None:
    max_par_minute = max_par_minute or parametres().limite_requetes_par_minute
    t = time.monotonic()
    f = _fenetres[cle]
    while f and t - f[0] > 60:
        f.popleft()
    if len(f) >= max_par_minute:
        raise HTTPException(status.HTTP_429_TOO_MANY_REQUESTS, "Trop de requêtes ; réessayer plus tard")
    f.append(t)


def roles_connus() -> Iterable[str]:
    return ROLES.keys()
