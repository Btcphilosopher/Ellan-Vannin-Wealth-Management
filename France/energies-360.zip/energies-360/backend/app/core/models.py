"""Modèles transverses : identités, habilitations, audit, événements, tâches."""
from __future__ import annotations

from sqlalchemy import BigInteger, Boolean, ForeignKey, Integer, String, Text
from sqlalchemy.orm import Mapped, mapped_column

from ..db import Base, HorodatageUTC, JSONType, maintenant


class Utilisateur(Base):
    __tablename__ = "utilisateur"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    identifiant: Mapped[str] = mapped_column(String(80), unique=True)
    nom_affiche: Mapped[str] = mapped_column(String(160))
    organisation: Mapped[str] = mapped_column(String(160), default="Groupe Énergies 360 (fictif)")
    hash_mot_de_passe: Mapped[str] = mapped_column(String(255))
    mfa_obligatoire: Mapped[bool] = mapped_column(Boolean, default=False)
    secret_mfa_chiffre: Mapped[str | None] = mapped_column(String(255), nullable=True)
    est_compte_service: Mapped[bool] = mapped_column(Boolean, default=False)
    actif: Mapped[bool] = mapped_column(Boolean, default=True)
    echecs_connexion: Mapped[int] = mapped_column(Integer, default=0)
    cree_le = mapped_column(HorodatageUTC, default=maintenant)


class Habilitation(Base):
    """Rôle accordé à un utilisateur, global ou limité à une entité / un site."""

    __tablename__ = "habilitation"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    utilisateur_id: Mapped[int] = mapped_column(ForeignKey("utilisateur.id"))
    role: Mapped[str] = mapped_column(String(60))
    entite_id: Mapped[int | None] = mapped_column(ForeignKey("entite.id"), nullable=True)
    site_id: Mapped[int | None] = mapped_column(ForeignKey("site.id"), nullable=True)
    accorde_par: Mapped[str] = mapped_column(String(80), default="initialisation")
    valide_de = mapped_column(HorodatageUTC, default=maintenant)
    valide_a = mapped_column(HorodatageUTC, nullable=True)


class JournalAudit(Base):
    """Journal d'audit chaîné (chaque entrée contient l'empreinte de la précédente)."""

    __tablename__ = "journal_audit"
    id: Mapped[int] = mapped_column(BigInteger().with_variant(Integer, "sqlite"), primary_key=True)
    horodatage = mapped_column(HorodatageUTC, default=maintenant, index=True)
    acteur: Mapped[str] = mapped_column(String(80))
    action: Mapped[str] = mapped_column(String(80), index=True)
    ressource: Mapped[str] = mapped_column(String(160))
    resultat: Mapped[str] = mapped_column(String(20))  # succes | refus | echec
    details = mapped_column(JSONType, default=dict)
    adresse: Mapped[str | None] = mapped_column(String(64), nullable=True)
    empreinte_precedente: Mapped[str] = mapped_column(String(64))
    empreinte: Mapped[str] = mapped_column(String(64))


class Evenement(Base):
    """File d'événements diffusés en WebSocket (multi-processus via la base)."""

    __tablename__ = "evenement"
    id: Mapped[int] = mapped_column(BigInteger().with_variant(Integer, "sqlite"), primary_key=True)
    cree_le = mapped_column(HorodatageUTC, default=maintenant, index=True)
    type: Mapped[str] = mapped_column(String(60))
    site_id: Mapped[int | None] = mapped_column(Integer, nullable=True)
    message: Mapped[str] = mapped_column(Text)
    donnees = mapped_column(JSONType, default=dict)


class Tache(Base):
    """Traitement en arrière-plan exécuté par le processus ``worker``."""

    __tablename__ = "tache"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    type: Mapped[str] = mapped_column(String(60))
    parametres = mapped_column(JSONType, default=dict)
    statut: Mapped[str] = mapped_column(String(20), default="en_attente", index=True)
    demandee_par: Mapped[str] = mapped_column(String(80))
    cree_le = mapped_column(HorodatageUTC, default=maintenant)
    debut = mapped_column(HorodatageUTC, nullable=True)
    fin = mapped_column(HorodatageUTC, nullable=True)
    resultat = mapped_column(JSONType, nullable=True)
    erreur: Mapped[str | None] = mapped_column(Text, nullable=True)
    tentatives: Mapped[int] = mapped_column(Integer, default=0)
