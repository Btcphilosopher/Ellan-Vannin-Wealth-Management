"""Démonstration reproductible de bout en bout, exclusivement via l'API HTTP.

Usage :
    python -m app.demo.scenario                    # en processus (base locale, initialisée si vide)
    python -m app.demo.scenario --url http://localhost:8000   # contre la pile Docker Compose

Étapes : 1 actifs · 2 ingestion · 3 énergie sans double comptage · 4 capteur périmé ·
5 maintenance · 6 réception et transfert · 7 rapprochement de livraison · 8 session de
recharge · 9 simulation batterie · 10 calcul environnemental · 11 analyse économique ·
12 rapport traçable — avec doublons, compteur réinitialisé, livraison partielle, panne
et tentative d'accès non autorisée.
"""
from __future__ import annotations

import argparse
import json
import sys
import threading
from datetime import datetime, timedelta, timezone
from pathlib import Path

from ..simulateurs.pv import ConfigScenario, generer

UTC = timezone.utc
D0, D1 = "2026-06-15T00:00:00+00:00", "2026-06-22T00:00:00+00:00"
MDP = "Demo-E360!"


class Client:
    def __init__(self, url: str | None):
        if url:
            import httpx

            self.c = httpx.Client(base_url=url, timeout=120)
        else:
            from fastapi.testclient import TestClient

            from ..main import app

            self.c = TestClient(app)
            self.c.__enter__()
        self.jetons: dict[str, str] = {}

    def connecter(self, idt: str) -> str:
        corps = {"identifiant": idt, "mot_de_passe": MDP}
        r = self.c.post("/api/auth/connexion", json=corps)
        if r.status_code == 401 and "MFA" in r.text:
            code = self.c.get(f"/api/auth/demo/code-mfa/{idt}").json()["code"]
            r = self.c.post("/api/auth/connexion", json=corps | {"code_mfa": code})
        r.raise_for_status()
        self.jetons[idt] = r.json()["jeton"]
        return self.jetons[idt]

    def req(self, qui: str, methode: str, chemin: str, attendu: int | tuple = (200, 201), **kw):
        if qui not in self.jetons:
            self.connecter(qui)
        r = self.c.request(methode, chemin, headers={"Authorization": f"Bearer {self.jetons[qui]}"}, **kw)
        att = attendu if isinstance(attendu, tuple) else (attendu,)
        if r.status_code not in att:
            raise AssertionError(f"{methode} {chemin} par {qui} : {r.status_code} (attendu {att}) — {r.text[:500]}")
        try:
            return r.json()
        except Exception:
            return r.content


def executer(url: str | None = None, sortie: str = "demo_sortie", initialiser_local: bool = True) -> dict:
    if url is None and initialiser_local:
        from .. import modeles
        from ..db import configurer, moteur, session_scope
        from .seed import initialiser

        configurer()
        modeles.metadata.create_all(moteur())
        with session_scope() as s:
            initialiser(s)
    c = Client(url)
    out = Path(sortie)
    out.mkdir(parents=True, exist_ok=True)
    R: dict = {"etapes": {}}

    def etape(n, titre, donnees):
        R["etapes"][f"{n:02d}"] = {"titre": titre, **donnees}
        print(f"\n=== Étape {n} — {titre}")
        for k, v in donnees.items():
            print(f"  · {k} : {json.dumps(v, ensure_ascii=False, default=str)[:240]}")

    if url and c.req("direction", "GET", "/api/mesures/lots"):
        print("Démonstration déjà exécutée sur cette base (lots présents) : rien à faire.")
        return {"deja_executee": True}
    sites = {s["code"]: s for s in c.req("direction", "GET", "/api/patrimoine/sites")}
    pv = sites["SITE-PV-GAR"]["id"]
    detail = c.req("c.durand", "GET", f"/api/patrimoine/sites/{pv}")
    actifs = {a["code"]: a for a in detail["actifs"]}

    # 1. Enregistrement des actifs ------------------------------------------------
    nouveau = c.req("c.durand", "POST", "/api/patrimoine/actifs", json={
        "site_id": pv, "parent_id": actifs["PV-GAR"]["id"], "code": "PV-GAR-METEO2", "nom": "Pyranomètre de secours",
        "niveau": "equipement", "type_actif": "capteur", "date_effet_debut": "2026-06-21T12:00:00+00:00"})
    refus_double = c.req("c.durand", "POST", "/api/patrimoine/points-mesure", attendu=409, json={
        "actif_id": actifs["GAR-PDL"]["id"], "code": "GAR-PDL-EI-BIS", "grandeur": "energie", "unite": "kWh",
        "nature_grandeur": "electrique", "type_signal": "cumul", "role_comptage": "principal",
        "perimetre_comptage": "injection_reseau"})
    etude = c.req("c.durand", "POST", "/api/patrimoine/etudes", json={
        "titre": "Étude de productible 2026 (fictive)", "objet": "Base de calcul du budget",
        "references": [{"objet_type": "actif", "objet_id": actifs["PV-GAR-OND2"]["id"]}]})
    c.req("c.durand", "POST", f"/api/patrimoine/etudes/{etude['id']}/approuver")
    c.req("c.durand", "PATCH", f"/api/patrimoine/actifs/{actifs['PV-GAR-OND2']['id']}", json={
        "motif": "Remplacement du module de puissance (modèle révisé)", "champs": {"modele": "OND-2500 rév. B (fictif)"}})
    cmp_ = c.req("c.durand", "GET", f"/api/patrimoine/etudes/{etude['id']}/comparer")
    proches = c.req("direction", "GET", "/api/patrimoine/sites/proches", params={"lat": 45.7, "lon": 4.9, "rayon_km": 40})
    etape(1, "Enregistrement des actifs", {
        "actif_cree": nouveau["code"], "second_compteur_principal_refuse": refus_double["detail"][:120],
        "etude_figee": {"instantane_integre": cmp_["instantane_integre"],
                        "ecarts_detectes": len(cmp_["ecarts_avec_referentiel_courant"])},
        "requete_spatiale": {"methode": proches["methode"], "sites": [x["code"] for x in proches["sites"]]}})

    # 2. Ingestion de mesures simulées --------------------------------------------
    sim = generer(ConfigScenario())
    cumul = {"lots": 0, "recus": 0, "inseres": 0, "doublons_exacts": 0, "doublons_conflictuels": 0, "retards": 0,
             "hors_bornes": 0, "rejets": 0}
    for lot in sim["lots"]:
        r = c.req("svc.ingestion", "POST", "/api/mesures/ingestion", json={
            "source": "passerelle_scada_simulee", "mode": "rejeu_simulation", "recu_le": lot["recu_le"],
            "mesures": lot["mesures"]})
        cumul["lots"] += 1
        for k_api, k in (("nb_recus", "recus"), ("nb_inseres", "inseres"), ("nb_doublons_exacts", "doublons_exacts"),
                         ("nb_doublons_conflictuels", "doublons_conflictuels"), ("nb_retards", "retards"),
                         ("nb_hors_bornes", "hors_bornes"), ("nb_rejets", "rejets")):
            cumul[k] += r[k_api]
    c.req("c.durand", "POST", "/api/production/reductions", json={
        "actif_id": actifs["PV-GAR"]["id"], "type": "limitation_reseau", "debut": "2026-06-16T12:00:00+00:00",
        "fin": "2026-06-16T14:00:00+00:00", "puissance_limite_kw": 6000,
        "source": "ordre de limitation du gestionnaire de réseau (simulé)", "reference_externe": "LIM-SIM-0616"})
    etape(2, "Ingestion de mesures simulées", cumul)

    # 3. Énergie sans double comptage -------------------------------------------------
    bilan = c.req("c.durand", "GET", f"/api/mesures/sites/{pv}/bilan", params={"debut": D0, "fin": D1})
    inj = c.req("direction", "GET", "/api/mesures/portefeuille/injection_reseau", params={"debut": D0, "fin": D1})
    ppv = c.req("direction", "GET", "/api/mesures/portefeuille/production_pv", params={"debut": D0, "fin": D1})
    naif = sum(t["valeur"] for t in bilan["termes"].values()) + bilan["controle"]["somme_controle_production_kwh"]
    v = sim["verite"]
    etape(3, "Calcul d'énergie sans double comptage", {
        "production_pv_kwh": bilan["termes"]["production_pv"]["valeur"], "verite_simulateur_kwh": v["production_pv_kwh"],
        "injection_reseau_kwh": bilan["termes"]["injection_reseau"]["valeur"], "verite_injection_kwh": v["injection_kwh"],
        "ecart_bilan_kwh": bilan["ecart_kwh"], "verite_aux_plus_pertes_kwh": round(v["auxiliaires_kwh"] + v["pertes_transfo_kwh"], 1),
        "interpretation": bilan["interpretation_ecart"],
        "controle_onduleurs_kwh": bilan["controle"]["somme_controle_production_kwh"],
        "remise_a_zero_detectee": [x["point"] for x in bilan["controle"]["compteurs"] if x["remises_a_zero"]],
        "somme_naive_incorrecte_kwh": round(naif, 1), "portefeuille_injection_kwh": inj["valeur"],
        "portefeuille_production_pv_kwh": ppv["valeur"],
        "compteurs_exclus_du_portefeuille": [x["point"] for x in ppv["points_exclus"]]})

    # 4. Détection d'un capteur périmé -----------------------------------------------
    c.req("c.durand", "POST", "/api/mesures/qualite/analyser", json={"site_id": pv, "debut": D0, "fin": D1,
                                                                    "instant_reference": D1})
    alertes = c.req("c.durand", "GET", "/api/mesures/alertes", params={"site_id": pv})
    perime = next(a for a in alertes if a["type"] == "capteur_perime")
    par_type: dict = {}
    for a in alertes:
        par_type[a["type"]] = par_type.get(a["type"], 0) + 1
    piste = c.req("svc.ia", "GET", f"/api/ia/alertes/{perime['id']}/investigation")
    etape(4, "Détection d'un capteur périmé", {"alerte": perime["titre"], "message": perime["message"],
                                                "regle": perime["regle"], "alertes_par_type": par_type,
                                                "investigation_proposee_ia": piste["etapes_proposees"],
                                                "garde_fous": piste["garde_fous"]})

    # 5. Ordre de maintenance (panne onduleur 2) --------------------------------------
    panne = next(a for a in alertes if a["type"] == "panne_equipement")
    refus_portee = c.req("l.martin", "POST", "/api/maintenance/ordres", attendu=403, json={
        "actif_id": c.req("direction", "GET", f"/api/patrimoine/sites/{sites['SITE-STA-TIL']['id']}")["actifs"][0]["id"],
        "titre": "Test hors périmètre", "description": "doit être refusé"})
    ot = c.req("l.martin", "POST", "/api/maintenance/ordres", json={
        "actif_id": panne["actif_id"], "alerte_id": panne["id"], "priorite": "P1",
        "titre": "Onduleur 2 en défaut — module de puissance", "description": panne["message"]})
    oid = ot["id"]
    pieces = {p["code"]: p for p in c.req("l.martin", "GET", "/api/maintenance/pieces")}
    prest = c.req("l.martin", "GET", "/api/maintenance/prestataires")[0]
    c.req("l.martin", "POST", f"/api/maintenance/ordres/{oid}/transition", json={
        "vers": "evalue", "evaluation": "Code F-217 (surchauffe IGBT) — remplacement du module de puissance"})
    c.req("l.martin", "POST", f"/api/maintenance/ordres/{oid}/transition", json={
        "vers": "planifie", "date_planifiee": "2026-06-19T07:00:00+00:00", "prestataire_id": prest["id"]})
    sans_permis = c.req("l.martin", "POST", f"/api/maintenance/ordres/{oid}/transition", attendu=422,
                        json={"vers": "en_intervention"})
    c.req("l.martin", "POST", f"/api/maintenance/ordres/{oid}/pieces", json={"piece_id": pieces["PCE-IGBT-2500"]["id"],
                                                                              "quantite": 1})
    c.req("l.martin", "POST", f"/api/maintenance/ordres/{oid}/transition", json={
        "vers": "en_intervention", "reference_permis_travail": "PT-GAR-2026-0412 (procédure site)",
        "reference_consignation": "CONS-GAR-0412"})
    c.req("l.martin", "POST", f"/api/maintenance/ordres/{oid}/transition", json={
        "vers": "controle", "heures_main_oeuvre": 6.5, "taux_horaire": 95.0, "cout_externe": 450.0})
    c.req("l.martin", "POST", f"/api/maintenance/ordres/{oid}/controle", json={"points": [
        {"libelle": "Serrage des connexions", "resultat": "conforme"},
        {"libelle": "Essai de fonctionnement à vide", "resultat": "conforme"},
        {"libelle": "Absence de code défaut", "resultat": "conforme"}]})
    c.req("l.martin", "POST", f"/api/maintenance/ordres/{oid}/transition", json={"vers": "cloture"})
    c.req("l.martin", "POST", f"/api/maintenance/ordres/{oid}/cloture-administrative")
    tech_refuse = c.req("l.martin", "POST", f"/api/maintenance/ordres/{oid}/retour-disponibilite", attendu=403, json={})
    c.req("c.durand", "POST", f"/api/maintenance/ordres/{oid}/retour-disponibilite",
          json={"commentaire": "Contrôle conforme ; remise à disposition technique"})
    ia_refuse = c.req("svc.ia", "POST", f"/api/maintenance/ordres/{oid}/autorisation-operationnelle", attendu=403, json={})
    c.req("s.bernard", "POST", f"/api/maintenance/ordres/{oid}/autorisation-operationnelle", json={
        "reference_procedure_externe": "DECONS-GAR-0412", "declaration": "Déconsignation réalisée selon procédure site"})
    inc = c.req("c.durand", "POST", "/api/production/incidents", json={
        "site_id": pv, "actif_id": panne["actif_id"], "titre": "Arrêt de l'onduleur 2 (défaut F-217)",
        "description": "Onduleur 2 en défaut, production réduite d'environ 25 %", "gravite": "majeure",
        "debut": panne["debut"], "fin": panne["fin"], "alerte_ids": [panne["id"]]})
    resume = c.req("svc.ia", "GET", f"/api/ia/incidents/{inc['id']}/resume")
    det = c.req("c.durand", "GET", f"/api/maintenance/ordres/{oid}")
    etape(5, "Création et suivi d'un ordre de maintenance", {
        "ordre": det["numero"], "etat": det["etat"], "parcours": [t["vers"] for t in det["transitions"]],
        "cout_total_eur": det["cout_total"], "trois_actes": det["trois_actes_distincts"],
        "refus_hors_perimetre": refus_portee["detail"], "refus_sans_permis": sans_permis["detail"][:90],
        "technicien_ne_peut_remettre_en_disponibilite": tech_refuse["detail"],
        "ia_ne_peut_autoriser": ia_refuse["detail"], "resume_incident_ia": resume["resume"]})

    # 6. Réception et transfert de stock ------------------------------------------------
    cmds = c.req("n.petit", "GET", "/api/approvisionnements/commandes")
    cmd = cmds[0]
    empl = {e["code"]: e for e in c.req("n.petit", "GET", "/api/logistique/emplacements")}
    lc = {l["produit"]: l for l in cmd["lignes"]}
    refus_compat = c.req("n.petit", "POST", "/api/approvisionnements/receptions", attendu=409, json={
        "livraison_id": cmd["livraisons"][0]["id"], "lignes": [
            {"ligne_commande_id": lc["GAZ-BUT-13"]["id"], "quantite_recue": 120, "lot": "LOT-BUT-26-061",
             "emplacement_id": empl["DEP-Z-A"]["id"]}]})
    rec = c.req("n.petit", "POST", "/api/approvisionnements/receptions", json={
        "livraison_id": cmd["livraisons"][0]["id"], "lignes": [
            {"ligne_commande_id": lc["LUB-5W30-208"]["id"], "quantite_recue": 36, "quantite_non_conforme": 2,
             "motif_non_conformite": "fûts cabossés, joint de bonde douteux", "lot": "LOT-LUB-26-118",
             "emplacement_id": empl["DEP-Z-A"]["id"], "emplacement_quarantaine_id": empl["DEP-Q"]["id"]},
            {"ligne_commande_id": lc["LUB-5W30-5L"]["id"], "quantite_recue": 600, "lot": "LOT-LUB5-26-044",
             "emplacement_id": empl["DEP-Z-B"]["id"]},
            {"ligne_commande_id": lc["GAZ-BUT-13"]["id"], "quantite_recue": 120, "lot": "LOT-BUT-26-061",
             "emplacement_id": empl["DEP-Z-C"]["id"]}]})
    stocks = c.req("n.petit", "GET", "/api/logistique/stocks")["soldes"]
    bidons = next(x for x in stocks if x["produit"] == "LUB-5W30-5L" and x["emplacement"] == "DEP-Z-B")
    tr = c.req("n.petit", "POST", "/api/logistique/transferts", json={
        "produit_id": bidons["produit_id"], "lot_id": bidons["lot_id"], "source_id": empl["DEP-Z-B"]["id"],
        "destination_id": empl["STA-TIL-BOUT"]["id"], "quantite": 120})
    en_transit = next(x for x in c.req("n.petit", "GET", "/api/logistique/stocks")["soldes"]
                      if x["emplacement"] == "DEP-Z-B" and x["produit"] == "LUB-5W30-5L")
    c.req("n.petit", "POST", f"/api/logistique/transferts/{tr['id']}/reception", json={"quantite_recue": 118})
    # Réservations concurrentes sur les 36−2… fûts disponibles
    futs = next(x for x in c.req("n.petit", "GET", "/api/logistique/stocks")["soldes"]
                if x["emplacement"] == "DEP-Z-A" and x["produit"] == "LUB-5W30-208")
    resultats = []

    def reserver(i):
        r = c.c.post("/api/logistique/reservations", json={"solde_id": futs["solde_id"], "quantite": 20,
                                                           "reference": f"CMD-CLIENT-{i}"},
                     headers={"Authorization": f"Bearer {c.jetons['n.petit']}"})
        resultats.append(r.status_code)

    fils = [threading.Thread(target=reserver, args=(i,)) for i in range(3)]
    [f.start() for f in fils]
    [f.join() for f in fils]
    coh = c.req("n.petit", "GET", "/api/logistique/coherence")
    ecarts = c.req("n.petit", "GET", "/api/logistique/ecarts")
    etape(6, "Réception et transfert de stock", {
        "refus_compatibilite": refus_compat["detail"][:120], "reception": rec["statut"],
        "ecarts": [e["description"] for e in ecarts], "transfert": tr["numero"],
        "en_transit_pendant_transfert": tr["quantite"], "physique_source_apres_expedition": en_transit["physique"],
        "reservations_concurrentes_20_sur_34": sorted(resultats), "journal_coherent": coh["coherent"]})

    # 7. Rapprochement d'une livraison (contrat carburant) -----------------------------
    contrats = {x["numero"]: x for x in c.req("a.moreau", "GET", "/api/contrats")}
    cg = contrats["CTR-GO-TIL-2026"]
    synth_til = c.req("a.moreau", "GET", f"/api/distribution/stations/{sites['SITE-STA-TIL']['id']}/synthese",
                      params={"debut": D0, "fin": D1})
    liv = synth_til["livraisons"][0]
    eng = c.req("a.moreau", "POST", f"/api/contrats/{cg['id']}/engagements", json={
        "quantite": 30000, "unite": "L", "reference": "NOM-GO-TIL-0617"})
    c.req("a.moreau", "POST", f"/api/contrats/{cg['id']}/livraisons-mesurees", json={
        "engagement_id": eng["id"], "quantite": liv["volume_15c_bl_l"], "unite": "L", "nature_quantite": "corrige_15c",
        "source_type": "jaugeage", "source_id": liv["id"], "mesure_le": liv["horodatage"]})
    cot = c.req("a.moreau", "GET", f"/api/contrats/{cg['id']}/cotation", params={"date": "2026-06-17T06:30:00+00:00"})
    fac = c.req("a.moreau", "POST", "/api/contrats/factures", json={
        "contrat_id": cg["id"], "numero": "FA-CSE-2026-3381", "sens": "recue", "date_facture": "2026-06-18T00:00:00+00:00",
        "date_echeance": "2026-07-18T00:00:00+00:00", "quantite_facturee": liv["volume_15c_bl_l"], "unite": "L",
        "prix_unitaire": cot["prix"]})
    c.req("a.moreau", "POST", "/api/contrats/paiements", json={"facture_id": fac["id"],
                                                               "date_paiement": "2026-06-20T00:00:00+00:00",
                                                               "montant": round(fac["montant_ttc"] / 2, 2),
                                                               "reference": "VIR-SIM-0620 (acompte)"})
    rap = c.req("a.moreau", "GET", f"/api/contrats/{cg['id']}/rapprochement")
    marche_reel = c.req("a.moreau", "POST", "/api/contrats/ordres-marche", attendu=403, json={
        "produit": "électricité J+1", "sens": "vente", "quantite": 5, "unite": "MWh", "prix_limite": 80, "mode": "reel"})
    etape(7, "Rapprochement d'une livraison", {
        "quantites_L15": rap["quantites"], "montants_eur": rap["montants"], "ecarts": [e["message"] for e in rap["ecarts"]],
        "prix": f"{cot['prix']} {cot['unite']} — {cot['nature']}", "ordre_marche_reel_refuse": marche_reel["detail"],
        "cuves": [{"cuve": x["cuve"], "ecart_l15": x.get("ecart_l15"), "interpretation": x.get("interpretation")}
                  for x in synth_til["cuves"]]})

    # 8. Suivi d'une session de recharge (OCPP simulé) -----------------------------------
    def ocpp(borne, action, charge):
        return c.req("svc.ingestion", "POST", f"/api/mobilite/ocpp/{borne}", json=[2, f"{action}-{borne}", action, charge])

    # CP-PNF-02 reste muette (communication perdue) : ses connecteurs sont « indéterminés », pas disponibles
    for borne in ("CP-TIL-01", "CP-TIL-02", "CP-PNF-01"):
        ocpp(borne, "BootNotification", {"chargePointVendor": "Fictif", "chargePointModel": "AC/DC-150",
                                         "firmwareVersion": "1.4.2"})
        for k in (1, 2):
            statut = "Faulted" if (borne, k) == ("CP-PNF-01", 2) else "Available"
            ocpp(borne, "StatusNotification", {"connectorId": k, "status": statut,
                                               "errorCode": "GroundFailure" if statut == "Faulted" else "NoError",
                                               "timestamp": "2026-06-21T23:50:00+00:00"})
    debut = ocpp("CP-TIL-01", "StartTransaction", {"connectorId": 2, "idTag": "BADGE-FICTIF-0042", "meterStart": 1_204_000,
                                                   "timestamp": "2026-06-21T17:05:00+00:00"})
    tid = debut[2]["transactionId"]
    ocpp("CP-TIL-01", "StatusNotification", {"connectorId": 2, "status": "Charging", "errorCode": "NoError",
                                             "timestamp": "2026-06-21T17:05:10+00:00"})
    ocpp("CP-TIL-01", "MeterValues", {"connectorId": 2, "transactionId": tid, "meterValue": [
        {"timestamp": "2026-06-21T17:20:00+00:00", "sampledValue": [
            {"value": "1228500", "measurand": "Energy.Active.Import.Register", "unit": "Wh"},
            {"value": "98.4", "measurand": "Power.Active.Import", "unit": "kW"}]}]})
    ocpp("CP-TIL-01", "StopTransaction", {"transactionId": tid, "meterStop": 1_243_600, "reason": "EVDisconnected",
                                          "timestamp": "2026-06-21T17:38:00+00:00"})
    ocpp("CP-TIL-01", "StatusNotification", {"connectorId": 2, "status": "Available", "errorCode": "NoError",
                                             "timestamp": "2026-06-21T23:55:00+00:00"})
    non_supporte = ocpp("CP-TIL-01", "DataTransfer", {"vendorId": "X"})
    sess = c.req("m.fontaine", "GET", "/api/mobilite/sessions")[0]
    sd = c.req("m.fontaine", "GET", f"/api/mobilite/sessions/{sess['id']}")
    bornes = c.req("m.fontaine", "GET", "/api/mobilite/bornes")
    evals = [{"connecteur": x["connecteur"], "joignable": x["joignable"], "declare": x["statut_declare"],
              "evalue": x["disponibilite_evaluee"]} for b in bornes["bornes"] for x in b["connecteurs"]]
    etape(8, "Suivi d'une session de recharge", {
        "session": {"transaction": sd["transaction_id"], "energie_kwh": sd["energie_kwh"], "montant_ttc": sd["montant_ttc"],
                    "statut": sd["statut"], "badge": sd["badge_pseudonyme"], "tarification": sd["detail_tarification"]},
        "paiement": sd["paiements"][0]["statut"] if sd["paiements"] else None,
        "action_non_supportee": non_supporte[2], "evaluation_connecteurs": evals})

    # 9. Simulation de batterie ---------------------------------------------------------
    etat = c.req("c.durand", "GET", f"/api/batterie/{actifs['BESS-GAR']['id']}/etat", params={"instant": D1})
    sc = c.req("c.durand", "POST", "/api/batterie/scenarios", json={
        "actif_id": actifs["BESS-GAR"]["id"], "nom": "Arbitrage semaine 25 (scénario)", "debut": D0, "fin": D1,
        "soc_initial_pct": 50})
    etape(9, "Simulation de batterie", {"etat_observe_soc": etat["soc"], "energie_disponible": etat["energie_disponible_decharge_kwh"],
                                        "synthese_scenario": sc["resultats"]["synthese"],
                                        "verifications": sc["verifications"], "avertissement": sc["avertissement"]})

    # 10. Calcul environnemental sourcé -----------------------------------------------------
    ent = {e["code"]: e for g in c.req("direction", "GET", "/api/patrimoine/arbre") for e in g["entites"]}
    a1 = c.req("e.garnier", "POST", "/api/environnement/activites", json={
        "entite_id": ent["ENT-REN"]["id"], "site_id": pv, "categorie": "electricite_soutiree", "scope": 2,
        "quantite": bilan["termes"]["soutirage_reseau"]["valeur"], "unite": "kWh", "nature_quantite": "electrique",
        "periode_debut": D0, "periode_fin": D1, "source_type": "compteur", "source_reference": "GAR-PDL-ES",
        "cle_origine": "GAR-PDL-ES:2026-06-15/2026-06-22", "nature": "mesuree"})
    c.req("e.garnier", "POST", "/api/environnement/calculs", json={"donnee_activite_id": a1["id"],
                                                                    "facteur_code": "FE-ELEC-RES-SIM"})
    doublon = c.req("e.garnier", "POST", "/api/environnement/activites", attendu=409, json={
        "entite_id": ent["ENT-REN"]["id"], "site_id": pv, "actif_id": actifs["GAR-PDL"]["id"],
        "categorie": "electricite_soutiree", "scope": 2, "quantite": 120.0, "unite": "kWh", "nature_quantite": "electrique",
        "periode_debut": "2026-06-18T00:00:00+00:00", "periode_fin": "2026-06-19T00:00:00+00:00",
        "source_type": "compteur", "source_reference": "sous-comptage auxiliaires",
        "cle_origine": "AUX-GAR:2026-06-18", "nature": "mesuree"})
    til = sites["SITE-STA-TIL"]["id"]
    vente_go = sum(x["volume_observe_l"] for x in synth_til["ventes"] if x["produit"] == "GO-B7")
    flotte = {"entite_id": ent["ENT-LOG"]["id"], "site_id": til, "categorie": "combustion_flotte_propre", "scope": 1,
              "quantite": 640, "unite": "L", "nature_quantite": "corrige_15c", "periode_debut": D0, "periode_fin": D1,
              "source_type": "releve", "source_reference": "pleins des véhicules de service pris à la station",
              "cle_origine": "FLOTTE-TIL:2026-W25", "nature": "mesuree"}
    a3 = c.req("e.garnier", "POST", "/api/environnement/activites", json=flotte)
    c.req("e.garnier", "POST", "/api/environnement/calculs", json={"donnee_activite_id": a3["id"],
                                                                    "facteur_code": "FE-GO-COMB-SIM"})
    vendu = {"entite_id": ent["ENT-LOG"]["id"], "site_id": til, "categorie": "carburant_vendu", "scope": 3,
             "categorie_scope3": 11, "quantite": round(vente_go * (1 - 0.00083 * 1.5), 1), "unite": "L",
             "nature_quantite": "corrige_15c", "periode_debut": D0, "periode_fin": D1, "source_type": "releve",
             "source_reference": "ventes pompes corrigées à 15 °C (hypothèse : T moyenne cuve 16,5 °C)",
             "cle_origine": "VENTES-GO-TIL:2026-W25", "nature": "calculee"}
    s3s1 = c.req("e.garnier", "POST", "/api/environnement/activites", attendu=409, json=vendu)
    a2 = c.req("e.garnier", "POST", "/api/environnement/activites", json=vendu | {"exclusions": [
        {"cle_origine": "FLOTTE-TIL:2026-W25", "quantite": 640, "motif": "volume auto-consommé déjà en scope 1"}]})
    c.req("e.garnier", "POST", "/api/environnement/calculs", json={"donnee_activite_id": a2["id"],
                                                                    "facteur_code": "FE-GO-COMB-SIM"})
    nature_refusee = c.req("e.garnier", "POST", "/api/environnement/activites", json={
        **vendu, "categorie": "test_nature", "cle_origine": "TEST-NATURE", "nature_quantite": "observe", "scope": 3,
        "exclusions": []})
    refus_nature = c.req("e.garnier", "POST", "/api/environnement/calculs", attendu=422, json={
        "donnee_activite_id": nature_refusee["id"], "facteur_code": "FE-GO-COMB-SIM"})
    auto_validation = c.req("v.roux", "POST", f"/api/environnement/activites/{a1['id']}/valider")
    inv = c.req("e.garnier", "GET", "/api/environnement/inventaire", params={"annee": 2026})
    etape(10, "Calcul environnemental sourcé", {
        "totaux_tco2e": inv["totaux_par_scope"], "incertitudes": inv["incertitude_par_scope_tco2e"],
        "par_nature": inv["par_nature"], "doublon_site_equipement_refuse": doublon["detail"][:110],
        "doublon_scope1_scope3_refuse": s3s1["detail"][:110], "volume_observe_vs_facteur_15c_refuse":
            refus_nature["detail"][:110], "validation": auto_validation["statut_validation"],
        "mention": inv["mention"]})

    # 11. Analyse économique ---------------------------------------------------------------
    cu = c.req("j.lefevre", "GET", f"/api/finance/sites/{pv}/cout-unitaire", params={"debut": D0, "fin": D1})
    rev = c.req("j.lefevre", "GET", f"/api/finance/sites/{pv}/revenus", params={"debut": D0, "fin": D1})
    marge = c.req("j.lefevre", "GET", f"/api/finance/stations/{til}/marge", params={"debut": D0, "fin": D1})
    flux = [{"date": "2026-09-01", "montant": -420000, "libelle": "Remplacement anticipé des 4 onduleurs"}]
    flux += [{"date": f"{2027 + k}-09-01", "montant": 61000 - 1000 * k, "libelle": "gain de disponibilité + maintenance évitée"}
             for k in range(10)]
    inv_sc = c.req("j.lefevre", "POST", "/api/finance/investissements", json={
        "nom": "Renouvellement anticipé des onduleurs (fictif)", "site_id": pv, "taux_actualisation_pct": 7.0,
        "convention": "dates_reelles_act365", "base": "nominal", "date_reference": "2026-09-01T00:00:00+00:00",
        "flux": flux, "hypotheses": [{"nom": "gain_disponibilite", "valeur": "0,6 point", "source": "hypothèse fictive"},
                                     {"nom": "prix_moyen", "valeur": "70 EUR/MWh", "source": "indice simulé"}]})
    expl = c.req("svc.ia", "GET", f"/api/ia/sites/{pv}/explication-ecart", params={"debut": D0, "fin": D1})
    evalm = c.req("svc.ia", "GET", f"/api/ia/sites/{pv}/evaluation-previsions")
    acces_refuse = c.req("m.fontaine", "GET", "/api/finance/synthese", attendu=403)
    modif_refusee = c.req("m.fontaine", "PATCH", f"/api/patrimoine/actifs/{actifs['PV-GAR']['id']}", attendu=403,
                          json={"motif": "tentative", "champs": {"etat": "hors_service"}})
    c.c.post("/api/auth/connexion", json={"identifiant": "direction", "mot_de_passe": MDP, "code_mfa": "000000"})
    audit = c.req("r.audit", "GET", "/api/admin/audit", params={"resultat": "refus"})
    chaine = c.req("r.audit", "GET", "/api/admin/audit/verifier")
    etape(11, "Analyse économique", {
        "cout_maintenance_eur_par_mwh": cu["valeur"], "numerateur": cu["numerateur"]["cout_maintenance_eur"],
        "denominateur_mwh": cu["denominateur"]["production_mwh"], "revenus_separes": rev,
        "marge_carburant": marge["lignes"],
        "explication_ecart_prevision": {k: expl[k] for k in ("prevu_p50_kwh", "realise_kwh", "contributions",
                                                            "residu_non_explique_kwh")},
        "evaluation_modeles_prevision_test_disjoint": {k: v["mae_kwh"] for k, v in evalm["resultats"].items()}, "van_tri": {k: inv_sc["resultats"][k] for k in ("van", "tri_pct", "note_tri")},
        "tentatives_non_autorisees": {"finance": acces_refuse["detail"], "modification_actif": modif_refusee["detail"],
                                      "refus_journalises": len(audit), "chaine_audit": chaine}})

    # 12. Export d'un rapport traçable --------------------------------------------------------
    rp = c.req("c.durand", "POST", "/api/rapports", json={"type": "parcours_solaire", "site_id": pv,
                                                           "debut": D0, "fin": D1})
    js = c.req("c.durand", "GET", f"/api/rapports/{rp['id']}/telecharger", params={"format": "json"})
    ht = c.req("c.durand", "GET", f"/api/rapports/{rp['id']}/telecharger", params={"format": "html"})
    (out / "rapport_parcours_solaire.json").write_text(json.dumps(js, ensure_ascii=False, indent=1, default=str))
    (out / "rapport_parcours_solaire.html").write_bytes(ht if isinstance(ht, bytes) else str(ht).encode())
    ver = c.req("c.durand", "GET", f"/api/rapports/{rp['id']}/verifier")
    ind = c.req("direction", "GET", "/api/indicateurs", params={"debut": D0, "fin": D1, "instant": D1})
    etape(12, "Export d'un rapport traçable", {
        "rapport": rp["titre"], "sha256_json": rp["sha256_json"], "verification": ver,
        "manifeste_sections": list(js["manifeste"]["empreintes_sections_sha256"].keys()),
        "indicateurs_vue_ensemble": {i["code"]: f"{i['valeur']} {i.get('unite', '')}" for i in ind["indicateurs"]}})
    R["verite_simulateur"] = sim["verite"]
    (out / "resultats_demo.json").write_text(json.dumps(R, ensure_ascii=False, indent=1, default=str))
    print(f"\nRésultats : {out / 'resultats_demo.json'}")
    return R


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--url", default=None)
    ap.add_argument("--sortie", default="demo_sortie")
    a = ap.parse_args()
    executer(a.url, a.sortie)
    sys.exit(0)
