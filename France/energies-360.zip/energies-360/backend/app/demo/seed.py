"""Initialisation du portefeuille FICTIF de démonstration (données synthétiques).

Toutes les entités, personnes, sites, contrats, facteurs et prix sont inventés.
"""
from __future__ import annotations

import base64
import math
import random
from datetime import datetime, timedelta, timezone

from sqlalchemy import select
from sqlalchemy.orm import Session

from ..core import securite as sec
from ..core.models import Habilitation, Utilisateur
from ..core.services import stockage
from ..modules.batterie.models import ParametresBatterie
from ..modules.contrats.models import Contrat, EcheanceContrat, Indice, ValeurIndice
from ..modules.distribution.models import Jaugeage, LivraisonCarburant, PrixAffiche, VenteCarburant
from ..modules.environnement.models import FacteurEmission
from ..modules.finance.models import LigneBudget
from ..modules.industrie.models import BilanMatiere, TitreAmont
from ..modules.maintenance.models import Piece
from ..modules.mobilite.models import Tarif
from ..modules.patrimoine import service as pat
from ..modules.patrimoine.models import (Actif, Capacite, ContratMaintenance, Document, Entite, Groupe, PointMesure,
                                         Produit, Responsable, Site, Tiers)
from ..modules.production.models import Prevision, ValeurPrevision
from ..modules.production.service import puissance_potentielle_kw
from ..modules.stocks.models import CommandeAchat, DocumentTransport, Emplacement, LigneCommande, Livraison, RegleCompatibilite
from ..simulateurs.pv import ConfigScenario, prevision_eclairement, prix_spot_simule

UTC = timezone.utc
D0 = datetime(2026, 6, 15, tzinfo=UTC)
D1 = datetime(2026, 6, 22, tzinfo=UTC)
ORIGINE = datetime(2026, 1, 1, tzinfo=UTC)
MDP_DEMO = "Demo-E360!"
AUTEUR = "initialisation_demo"


def _secret_totp(identifiant: str) -> str:
    """Secret TOTP déterministe de démonstration (dérivé de l'identifiant)."""
    return base64.b32encode(("E360" + identifiant).ljust(20, "0")[:20].encode()).decode().rstrip("=")


def initialiser(s: Session, avec_donnees_stations: bool = True) -> dict:
    if s.scalar(select(Groupe)):
        return {"deja_initialise": True}
    ids: dict[str, int] = {}
    g = Groupe(code="GRP-E360", nom="Groupe Énergies 360 (fictif)")
    s.add(g)
    s.flush()
    entites = [
        ("ENT-REN", "Énergies 360 Renouvelables (fictive)", "renouvelable",
         "Production d'électricité renouvelable et stockage par batteries ; unités : kW, kWh, W/m², %"),
        ("ENT-LOG", "Énergies 360 Logistique & Distribution (fictive)", "distribution",
         "Approvisionnement, dépôt de produits conditionnés, stations-service ; unités : L (observé / 15 °C), fûts, t"),
        ("ENT-MOB", "Énergies 360 Mobilité (fictive)", "mobilite",
         "Exploitation des bornes de recharge ; unités : kWh délivrés, sessions, EUR TTC"),
        ("ENT-IND", "Énergies 360 Industrie (fictive)", "industrie", "Transformation ; bilans matière en t"),
        ("ENT-AMO", "Énergies 360 Amont — suivi administratif (fictive)", "amont",
         "Suivi administratif de titres pétroliers et gaziers fictifs ; aucune donnée d'exploitation"),
    ]
    for code, nom, dom, resp in entites:
        e = Entite(groupe_id=g.id, code=code, nom=nom, domaine=dom, responsabilites=resp)
        s.add(e)
        s.flush()
        ids[code] = e.id

    def site(code, nom, ent, dom, lat, lon, commune):
        x = pat.creer(s, Site, AUTEUR, entite_id=ids[ent], code=code, nom=nom, domaine=dom, latitude=lat, longitude=lon,
                      commune=commune, date_effet_debut=ORIGINE, provenance="portefeuille fictif de démonstration")
        ids[code] = x.id
        return x

    site("SITE-PV-GAR", "Parc solaire et stockage des Garrigues (fictif)", "ENT-REN", "renouvelable", 43.62, 3.87,
         "Les Garrigues-sur-Lez (commune fictive)")
    site("SITE-DEP-SAU", "Dépôt de produits conditionnés de Saint-Aurel (fictif)", "ENT-LOG", "depot", 45.72, 4.95,
         "Saint-Aurel-en-Velin (commune fictive)")
    site("SITE-STA-TIL", "Relais des Tilleuls (station fictive)", "ENT-LOG", "distribution", 45.60, 4.80,
         "Les Tilleuls-sur-Gier (commune fictive)")
    site("SITE-STA-PNF", "Relais du Pont-Neuf (station fictive)", "ENT-LOG", "distribution", 44.93, 4.89,
         "Pont-Neuf-sur-Rhône (commune fictive)")
    site("SITE-IND-LYM", "Unité de mélange de lubrifiants (fictive)", "ENT-IND", "industrie", 45.68, 4.88,
         "Vallon-de-l'Ozon (commune fictive)")

    def actif(code, nom, site_code, niveau, type_, parent=None, **attrs):
        a = pat.creer(s, Actif, AUTEUR, site_id=ids[site_code], parent_id=ids.get(parent) if parent else None, code=code,
                      nom=nom, niveau=niveau, type_actif=type_, date_effet_debut=ORIGINE,
                      fabricant=attrs.pop("fabricant", "Constructeur fictif"), modele=attrs.pop("modele", None),
                      mise_en_service=attrs.pop("mise_en_service", datetime(2022, 4, 1, tzinfo=UTC)), attributs=attrs)
        ids[code] = a.id
        return a

    def cap(code, nature, grandeur, valeur, unite, debut=ORIGINE, fin=None, provenance="plaque constructeur fictive",
            motif=None):
        pat.creer(s, Capacite, AUTEUR, actif_id=ids[code], nature=nature, grandeur=grandeur, valeur=valeur, unite=unite,
                  date_effet_debut=debut, date_effet_fin=fin, provenance=provenance, motif=motif)

    def pt(code, actif_code, grandeur, unite, type_, role="information", perimetre=None, nature=None, bmin=None,
           bmax=None, pas=600, peremption=1800):
        pat.creer(s, PointMesure, AUTEUR, actif_id=ids[actif_code], code=code, grandeur=grandeur, unite=unite,
                  nature_grandeur=nature, type_signal=type_, role_comptage=role, perimetre_comptage=perimetre,
                  borne_min=bmin, borne_max=bmax, pas_attendu_s=pas, seuil_peremption_s=peremption)

    # --- Centrale PV ---------------------------------------------------------
    cfg = ConfigScenario()
    actif("PV-GAR", "Centrale photovoltaïque des Garrigues", "SITE-PV-GAR", "installation", "centrale_pv")
    cap("PV-GAR", "installee", "puissance_ac", 10_000, "kW")
    cap("PV-GAR", "installee", "puissance_dc", 12_000, "kW", provenance="somme des puissances crête modules (fictif)")
    cap("PV-GAR", "disponible", "puissance_ac", 9_500, "kW", provenance="convention de raccordement fictive",
        motif="Restriction temporaire de raccordement à 9,5 MW (fictive)")
    for i in range(1, cfg.onduleurs + 1):
        c = f"PV-GAR-OND{i}"
        actif(c, f"Onduleur central {i}", "SITE-PV-GAR", "equipement", "onduleur", "PV-GAR", modele="OND-2500 (fictif)",
              puissance_dc_kw=cfg.pdc_onduleur_kw)
        cap(c, "installee", "puissance_ac", cfg.pac_onduleur_kw, "kW")
        pt(f"{c}-P", c, "puissance", "kW", "instantane", nature="electrique", bmin=-50, bmax=cfg.pac_onduleur_kw * 1.1)
        pt(f"{c}-E", c, "energie", "kWh", "cumul", "controle", "production_pv", "electrique", bmin=0)
        pt(f"{c}-ETAT", c, "etat", "sans_dimension", "etat")
    actif("PV-GAR-CPT-PROD", "Compteur de production PV (sortie onduleurs, HTA)", "SITE-PV-GAR", "equipement",
          "compteur", "PV-GAR", classe_precision="0,5S (fictive)")
    pt("PV-GAR-CPT-PROD-E", "PV-GAR-CPT-PROD", "energie", "kWh", "cumul", "principal", "production_pv", "electrique", bmin=0)
    pt("PV-GAR-CPT-PROD-P", "PV-GAR-CPT-PROD", "puissance", "kW", "instantane", nature="electrique", bmin=-100, bmax=11_000)
    actif("PV-GAR-METEO", "Station météo de la centrale", "SITE-PV-GAR", "equipement", "station_meteo", "PV-GAR")
    pt("PV-GAR-METEO-GPOA", "PV-GAR-METEO", "irradiance", "W/m2", "instantane", bmin=0, bmax=1500)
    pt("PV-GAR-METEO-TAMB", "PV-GAR-METEO", "temperature", "degC", "instantane", bmin=-30, bmax=55)
    pt("PV-GAR-METEO-TMOD", "PV-GAR-METEO", "temperature", "degC", "instantane", bmin=-30, bmax=95)
    # --- Batterie ------------------------------------------------------------
    actif("BESS-GAR", "Système de stockage par batteries des Garrigues", "SITE-PV-GAR", "installation", "batterie",
          chimie="LFP (fictive)")
    cap("BESS-GAR", "installee", "energie", 10_000, "kWh", provenance="fiche technique fictive")
    cap("BESS-GAR", "installee", "puissance_ac", 5_000, "kW")
    pt("BESS-GAR-SOC", "BESS-GAR", "soc", "%", "instantane", bmin=0, bmax=100)
    pt("BESS-GAR-P", "BESS-GAR", "puissance", "kW", "instantane", nature="electrique", bmin=-5_500, bmax=5_500)
    pt("BESS-GAR-TEMP", "BESS-GAR", "temperature", "degC", "instantane", bmin=-20, bmax=60)
    actif("BESS-GAR-CPT", "Compteur bidirectionnel batterie", "SITE-PV-GAR", "equipement", "compteur", "BESS-GAR")
    pt("BESS-GAR-CPT-EC", "BESS-GAR-CPT", "energie", "kWh", "cumul", "principal", "charge_batterie", "electrique", bmin=0)
    pt("BESS-GAR-CPT-ED", "BESS-GAR-CPT", "energie", "kWh", "cumul", "principal", "decharge_batterie", "electrique", bmin=0)
    s.add(ParametresBatterie(actif_id=ids["BESS-GAR"], energie_nominale_kwh=10_000, puissance_charge_max_kw=5_000,
                             puissance_decharge_max_kw=5_000, soc_min_pct=10, soc_max_pct=90, rendement_charge=0.95,
                             rendement_decharge=0.95, temperature_max_c=45, date_effet_debut=ORIGINE,
                             provenance="fiche technique fictive"))
    # --- Poste de livraison --------------------------------------------------
    actif("GAR-PDL", "Poste de livraison HTA (point d'injection)", "SITE-PV-GAR", "installation", "poste_livraison")
    pt("GAR-PDL-EI", "GAR-PDL", "energie", "kWh", "cumul", "principal", "injection_reseau", "electrique", bmin=0)
    pt("GAR-PDL-ES", "GAR-PDL", "energie", "kWh", "cumul", "principal", "soutirage_reseau", "electrique", bmin=0)
    pt("GAR-PDL-P", "GAR-PDL", "puissance", "kW", "instantane", nature="electrique", bmin=-6000, bmax=16000)

    # --- Tiers, produits ------------------------------------------------------
    for code, nom, roles in [("FOUR-LUB", "Lubrifiants Rhône-Alpes (fournisseur fictif)", ["fournisseur"]),
                             ("FOUR-CARB", "Carburants du Sud-Est (fournisseur fictif)", ["fournisseur"]),
                             ("PREST-SOL", "Solaire Maintenance Services (prestataire fictif)", ["prestataire"]),
                             ("TRANS-VAL", "Transports Valmont (transporteur fictif)", ["transporteur"]),
                             ("CLI-AGR", "Agrégateur Énergie Horizon (acheteur fictif)", ["client"]),
                             ("CLI-GAR", "Garage du Centre (client fictif)", ["client"])]:
        t = Tiers(code=code, nom=nom, roles=roles)
        s.add(t)
        s.flush()
        ids[code] = t.id
    src_alpha = "valeur indicative de démonstration — à remplacer par des tables normalisées"
    produits = [
        ("LUB-5W30-208", "Huile moteur 5W-30 — fût 208 L (fictive)", "lubrifiant", "fut", "fût 208 L", "lubrifiant", {}),
        ("LUB-5W30-5L", "Huile moteur 5W-30 — bidon 5 L (fictive)", "lubrifiant", "bidon", "bidon 5 L", "lubrifiant", {}),
        ("GAZ-BUT-13", "Butane — bouteille 13 kg (fictive)", "gaz_conditionne", "bouteille", "bouteille 13 kg",
         "gaz_inflammable", {}),
        ("ADB-IBC", "AdBlue — IBC 1 000 L (fictif)", "adblue", "ibc", "IBC 1 000 L", "adblue", {}),
        ("GO-B7", "Gazole B7", "carburant", "L", "vrac", "carburant",
         {"coefficient_dilatation_1_K": {"valeur": 0.00083, "source": src_alpha},
          "densite_15c": {"valeur": 835.0, "unite": "kg/m3", "source": src_alpha},
          "pci": {"valeur": 42.6, "unite": "MJ/kg", "source": src_alpha}}),
        ("SP95-E10", "Sans plomb 95-E10", "carburant", "L", "vrac", "carburant",
         {"coefficient_dilatation_1_K": {"valeur": 0.00120, "source": src_alpha},
          "densite_15c": {"valeur": 745.0, "unite": "kg/m3", "source": src_alpha}}),
        ("ELEC", "Électricité (énergie active)", "electricite", "MWh", None, "energie", {}),
    ]
    for code, nom, cat, u, cond, grp, props in produits:
        p = Produit(code=code, nom=nom, categorie=cat, unite_gestion=u, conditionnement=cond, groupe_compatibilite=grp,
                    proprietes=props, nature_unite="observe" if u == "L" else None)
        s.add(p)
        s.flush()
        ids[code] = p.id

    # --- Dépôt ----------------------------------------------------------------
    for code, nom, cap_, u, grps, q in [
        ("DEP-Z-A", "Zone A — lubrifiants en fûts", 400, "fut", ["lubrifiant", "adblue"], False),
        ("DEP-Z-B", "Zone B — lubrifiants en bidons", 3000, "bidon", ["lubrifiant"], False),
        ("DEP-Z-C", "Zone C — gaz conditionné (bouteilles)", 600, "bouteille", ["gaz_inflammable"], False),
        ("DEP-Z-D", "Zone D — AdBlue (IBC)", 40, "ibc", ["adblue"], False),
        ("DEP-Q", "Zone de quarantaine (fûts)", 60, "fut", ["lubrifiant"], True),
    ]:
        actif(code, nom, "SITE-DEP-SAU", "installation", "zone_stockage")
        e = Emplacement(site_id=ids["SITE-DEP-SAU"], actif_id=ids[code], code=code, nom=nom,
                        type="quarantaine" if q else "zone", capacite=cap_, unite_capacite=u, groupes_autorises=grps,
                        est_quarantaine=q)
        s.add(e)
        s.flush()
        ids["E:" + code] = e.id
    for a, b, ok, just, st in [
        ("gaz_inflammable", "lubrifiant", False, "Séparation des gaz inflammables et des huiles (règle fictive de démo)",
         "validee"),
        ("adblue", "lubrifiant", True, "Cohabitation admise en zone ventilée (règle fictive de démo)", "validee"),
        ("adblue", "gaz_inflammable", False, "Règle proposée, en attente de validation HSE", "proposee"),
    ]:
        x, y = sorted((a, b))
        s.add(RegleCompatibilite(groupe_a=x, groupe_b=y, autorise=ok, justification=just,
                                 reference_documentaire="Référentiel de stockage interne fictif RS-07",
                                 statut=st, valide_par="hse.referent (fictif)" if st == "validee" else None,
                                 valide_le=ORIGINE if st == "validee" else None))

    # --- Stations et bornes -----------------------------------------------------
    for sc, lib in (("SITE-STA-TIL", "TIL"), ("SITE-STA-PNF", "PNF")):
        for prod, vol in (("GO-B7", 40_000), ("SP95-E10", 30_000)):
            code = f"STA-{lib}-CUVE-{prod.split('-')[0]}"
            actif(code, f"Cuve {prod} {vol:,} L".replace(",", " "), sc, "equipement", "cuve", produit=prod)
            e = Emplacement(site_id=ids[sc], actif_id=ids[code], code=code, nom=f"Cuve {prod}", type="cuve",
                            capacite=vol, unite_capacite="L", groupes_autorises=["carburant"])
            s.add(e)
            s.flush()
            ids["E:" + code] = e.id
        for k in (1, 2):
            actif(f"STA-{lib}-PMP{k}", f"Distributeur multi-produits {k}", sc, "equipement", "pompe")
        bout = f"STA-{lib}-BOUT"
        actif(bout, "Boutique — rayon lubrifiants", sc, "installation", "zone_stockage")
        e = Emplacement(site_id=ids[sc], actif_id=ids[bout], code=bout, nom="Boutique — rayon lubrifiants", type="zone",
                        capacite=300, unite_capacite="bidon", groupes_autorises=["lubrifiant"])
        s.add(e)
        s.flush()
        ids["E:" + bout] = e.id
        for k in (1, 2):
            b = f"CP-{lib}-0{k}"
            actif(b, f"Borne de recharge {lib}-{k}", sc, "equipement", "borne", protocole="OCPP 1.6J (simulé)",
                  exploitant="ENT-MOB")
            for c, (typ, kw) in enumerate((("Type 2", 22), ("CCS2", 150)), start=1):
                actif(f"{b}-C{c}", f"Connecteur {c} ({typ})", sc, "equipement", "connecteur", b, type=typ,
                      puissance_max_kw=kw)
    s.add(Tarif(code="TARIF-STD-2026", libelle="Tarif public de recharge (fictif)", prix_kwh_ttc=0.49,
                prix_minute_ttc=0.01, frais_session_ttc=0.50, valide_de=ORIGINE))

    # --- Site industriel et amont ------------------------------------------------
    actif("IND-LYM-MEL", "Ligne de mélange", "SITE-IND-LYM", "installation", "ligne_production")
    s.add(BilanMatiere(site_id=ids["SITE-IND-LYM"], periode_debut=datetime(2026, 6, 1, tzinfo=UTC),
                       periode_fin=datetime(2026, 7, 1, tzinfo=UTC),
                       entrees=[{"produit": "Huiles de base (fictives)", "quantite": 412.0, "unite": "t",
                                 "source": "pesées réception (simulées)"},
                                {"produit": "Additifs (fictifs)", "quantite": 38500.0, "unite": "kg",
                                 "source": "bons de réception (simulés)"}],
                       sorties=[{"produit": "Lubrifiants finis (fictifs)", "quantite": 446.2, "unite": "t",
                                 "source": "pesées expédition (simulées)"}],
                       pertes_declarees=[{"produit": "Purges et rinçages", "quantite": 2.1, "unite": "t",
                                          "source": "déclaration exploitation (simulée)"}],
                       statut="brouillon", commentaire="Bilan mensuel fictif"))
    s.add(TitreAmont(entite_id=ids["ENT-AMO"], code="PX-07", nom="Permis exclusif de recherche fictif « Iroise-Sud »",
                     type="permis_exploration", pays_fictif="Territoire fictif d'Armorique", operateur="Opérateur fictif A",
                     participation_pct=35.0, date_octroi=datetime(2023, 3, 1, tzinfo=UTC),
                     date_echeance=datetime(2028, 3, 1, tzinfo=UTC), statut="en_vigueur",
                     obligations=[{"libelle": "Rapport annuel d'activité", "echeance": "2026-07-31T00:00:00+00:00",
                                   "statut": "a_faire"},
                                  {"libelle": "Engagement de travaux minimal (étude sismique)",
                                   "echeance": "2026-06-30T00:00:00+00:00", "statut": "a_faire"},
                                  {"libelle": "Garantie financière renouvelée", "echeance": "2026-03-31T00:00:00+00:00",
                                   "statut": "realisee"}],
                     declarations=[{"periode": "2025", "objet": "aucune production (phase exploration)",
                                    "volume": 0, "unite": "Sm3", "conditions_reference": "15 °C, 101,325 kPa",
                                    "source": "déclaration administrative fictive"}]))

    # --- Contrats, indices -------------------------------------------------------
    i_e = Indice(code="IDX_ELEC_SPOT_SIM", libelle="Indice horaire d'électricité SIMULÉ", unite="EUR/MWh", devise="EUR",
                 source="simulateur interne Énergies 360 (aucune source de marché réelle)", nature="indicatif_simule")
    i_g = Indice(code="IDX_GAZOLE_SIM", libelle="Indice gazole SIMULÉ", unite="EUR/m3", devise="EUR",
                 source="simulateur interne Énergies 360", nature="publication_simulee")
    s.add_all([i_e, i_g])
    s.flush()
    for t, v in prix_spot_simule(D0 - timedelta(days=1), 24 * 9):
        jour = t.replace(hour=0, minute=0)
        s.add(ValeurIndice(indice_id=i_e.id, date_valeur=t, valeur=v, publie_le=jour - timedelta(hours=11)))
    for k in range(12):
        d = D0 - timedelta(days=2) + timedelta(days=k)
        s.add(ValeurIndice(indice_id=i_g.id, date_valeur=d, valeur=round(718 + 6 * math.sin(k), 2),
                           publie_le=d + timedelta(hours=17)))
    c_e = Contrat(numero="CTR-ELEC-GAR-2026", type="vente", tiers_id=ids["CLI-AGR"], entite_id=ids["ENT-REN"],
                  site_id=ids["SITE-PV-GAR"], produit_id=ids["ELEC"], quantite_contractuelle=15_000, unite="MWh",
                  tolerance_pct=10, date_debut=ORIGINE, date_fin=datetime(2027, 1, 1, tzinfo=UTC),
                  formule_prix="IDX_ELEC_SPOT_SIM * 0.97 - 1.5", unite_prix="EUR/MWh",
                  conditions_livraison="Point de livraison GAR-PDL, comptage du gestionnaire de réseau (simulé)")
    c_g = Contrat(numero="CTR-GO-TIL-2026", type="achat", tiers_id=ids["FOUR-CARB"], entite_id=ids["ENT-LOG"],
                  site_id=ids["SITE-STA-TIL"], produit_id=ids["GO-B7"], quantite_contractuelle=360_000, unite="L",
                  nature_quantite="corrige_15c", tolerance_pct=3, date_debut=ORIGINE,
                  date_fin=datetime(2027, 1, 1, tzinfo=UTC), formule_prix="IDX_GAZOLE_SIM / 1000 + 0.62",
                  unite_prix="EUR/L", conditions_livraison="Rendu cuve, volumes facturés à 15 °C (bon de livraison)")
    s.add_all([c_e, c_g])
    s.flush()
    ids["CTR-ELEC"], ids["CTR-GO"] = c_e.id, c_g.id
    s.add(EcheanceContrat(contrat_id=c_g.id, periode_debut=datetime(2026, 6, 1, tzinfo=UTC),
                          periode_fin=datetime(2026, 7, 1, tzinfo=UTC), quantite_prevue=30_000, unite="L"))
    s.add(EcheanceContrat(contrat_id=c_e.id, periode_debut=datetime(2026, 6, 1, tzinfo=UTC),
                          periode_fin=datetime(2026, 7, 1, tzinfo=UTC), quantite_prevue=1_550, unite="MWh"))

    # --- Approvisionnement du dépôt (commande + livraison annoncée) -------------
    cmd = CommandeAchat(numero="CA-2026-0142", fournisseur_id=ids["FOUR-LUB"], site_id=ids["SITE-DEP-SAU"],
                        emise_le=datetime(2026, 6, 10, tzinfo=UTC), cree_par="n.petit")
    s.add(cmd)
    s.flush()
    l1 = LigneCommande(commande_id=cmd.id, produit_id=ids["LUB-5W30-208"], quantite=40, unite="fut", prix_unitaire=610.0)
    l2 = LigneCommande(commande_id=cmd.id, produit_id=ids["LUB-5W30-5L"], quantite=600, unite="bidon", prix_unitaire=21.5)
    l3 = LigneCommande(commande_id=cmd.id, produit_id=ids["GAZ-BUT-13"], quantite=120, unite="bouteille",
                       prix_unitaire=31.0)
    s.add_all([l1, l2, l3])
    s.flush()
    ids.update({"LC-FUT": l1.id, "LC-BIDON": l2.id, "LC-BUT": l3.id, "CMD": cmd.id})
    bl = DocumentTransport(type="bon_livraison", numero="BL-LRA-778812", transporteur_id=ids["TRANS-VAL"],
                           contenu={"lignes": [{"produit": "LUB-5W30-208", "quantite": 40, "unite": "fut"},
                                               {"produit": "LUB-5W30-5L", "quantite": 600, "unite": "bidon"},
                                               {"produit": "GAZ-BUT-13", "quantite": 120, "unite": "bouteille"}],
                                    "mention": "document fictif de démonstration"}, emis_le=datetime(2026, 6, 16, tzinfo=UTC))
    s.add(bl)
    s.flush()
    liv = Livraison(commande_id=cmd.id, document_transport_id=bl.id, date_prevue=datetime(2026, 6, 16, 8, tzinfo=UTC),
                    lignes_annoncees=[{"ligne_commande_id": l1.id, "quantite": 40},
                                      {"ligne_commande_id": l2.id, "quantite": 600},
                                      {"ligne_commande_id": l3.id, "quantite": 120}])
    s.add(liv)
    s.flush()
    ids["LIVRAISON"] = liv.id

    # --- Maintenance, finance, environnement -------------------------------------
    s.add(ContratMaintenance(numero="CM-PV-GAR-2026", prestataire_id=ids["PREST-SOL"], site_id=ids["SITE-PV-GAR"],
                             perimetre="Maintenance corrective et préventive des onduleurs et du poste HTA (fictif)",
                             delai_intervention_h=24, taux_horaire=95.0, date_debut=ORIGINE,
                             date_fin=datetime(2027, 1, 1, tzinfo=UTC)))
    for code, lib, q, cu in [("PCE-IGBT-2500", "Module de puissance IGBT pour OND-2500 (fictif)", 2, 1850.0),
                             ("PCE-FUS-DC1500", "Fusible DC 1 500 V (fictif)", 20, 35.0),
                             ("PCE-VENT-OND", "Ventilateur d'onduleur (fictif)", 4, 220.0)]:
        s.add(Piece(code=code, libelle=lib, quantite_stock=q, cout_unitaire=cu))
    for ent, site_c, poste, m in [("ENT-REN", "SITE-PV-GAR", "maintenance", 180_000), ("ENT-REN", "SITE-PV-GAR",
                                                                                         "exploitation", 95_000),
                                  ("ENT-LOG", "SITE-DEP-SAU", "maintenance", 60_000),
                                  ("ENT-MOB", None, "maintenance", 40_000)]:
        s.add(LigneBudget(entite_id=ids[ent], site_id=ids.get(site_c) if site_c else None, annee=2026, poste=poste,
                          montant=m))
    for code, lib, v, u, nat, src, inc, per in [
        ("FE-ELEC-RES-SIM", "Électricité soutirée au réseau — mix moyen (FICTIF)", 0.052, "kgCO2e/kWh", "electrique",
         "Facteur FICTIF de démonstration — à remplacer par une base officielle (ex. base nationale de facteurs)", 10,
         "émissions directes de production, hors amont"),
        ("FE-GO-COMB-SIM", "Gazole — combustion (FICTIF)", 2.65, "kgCO2e/L", "corrige_15c",
         "Facteur FICTIF de démonstration — à remplacer par une base officielle", 5, "combustion seule"),
        ("FE-SP95-COMB-SIM", "Essence SP95-E10 — combustion (FICTIF)", 2.28, "kgCO2e/L", "corrige_15c",
         "Facteur FICTIF de démonstration — à remplacer par une base officielle", 5, "combustion seule"),
        ("FE-ELEC-MARGINAL-REF-SIM", "Référence pour émissions évitées — mix marginal (FICTIF)", 0.30, "kgCO2e/kWh",
         "electrique", "Scénario de référence FICTIF ; méthode d'émissions évitées non normalisée", 40,
         "référence contrefactuelle"),
    ]:
        s.add(FacteurEmission(code=code, libelle=lib, valeur=v, unite=u, nature_denominateur=nat, source=src,
                              annee_reference=2025, geographie="France (fictif)", incertitude_pct=inc, perimetre=per))

    # --- Responsables et utilisateurs ---------------------------------------------
    comptes = [
        ("admin.plateforme", "Alex Admin (fictif)", True, [("admin_plateforme", None, None)]),
        ("direction", "Dominique Direction (fictif)", True, [("direction", None, None)]),
        ("c.durand", "Camille Durand (fictive) — responsable du site des Garrigues", False,
         [("responsable_site", None, "SITE-PV-GAR")]),
        ("l.martin", "Lou Martin (fictif) — technicien maintenance", False,
         [("technicien_maintenance", "ENT-REN", None)]),
        ("s.bernard", "Sacha Bernard (fictif) — exploitant habilité", True, [("exploitant_habilite", None, "SITE-PV-GAR")]),
        ("n.petit", "Noa Petit (fictif) — logisticien", False, [("logisticien", "ENT-LOG", None)]),
        ("a.moreau", "Andréa Moreau (fictive) — gestion des contrats", False, [("gestionnaire_contrats", None, None)]),
        ("j.lefevre", "Jules Lefèvre (fictif) — analyste financier", False, [("analyste_finance", None, None)]),
        ("e.garnier", "Eden Garnier (fictif) — analyste environnement", False, [("analyste_environnement", None, None)]),
        ("v.roux", "Vic Roux (fictif) — validation environnement", False, [("validateur_environnement", None, None)]),
        ("m.fontaine", "Maé Fontaine (fictif) — opérateur mobilité", False, [("operateur_mobilite", None, None)]),
        ("r.audit", "Robin Audit (fictif) — auditeur interne", False, [("auditeur", None, None)]),
        ("svc.ingestion", "Compte de service — ingestion télémétrie simulée", False, [("service_ingestion", None, None)]),
        ("svc.ia", "Compte de service — assistance analytique (lecture seule)", False, [("service_ia", None, None)]),
    ]
    h = sec.hacher_mot_de_passe(MDP_DEMO)
    for idt, nom, mfa, habs in comptes:
        u = Utilisateur(identifiant=idt, nom_affiche=nom, hash_mot_de_passe=h, mfa_obligatoire=mfa,
                        secret_mfa_chiffre=sec.chiffrer_secret(_secret_totp(idt)) if mfa else None,
                        est_compte_service=idt.startswith("svc."))
        s.add(u)
        s.flush()
        ids["U:" + idt] = u.id
        for role, ent, site_c in habs:
            s.add(Habilitation(utilisateur_id=u.id, role=role, entite_id=ids.get(ent) if ent else None,
                               site_id=ids.get(site_c) if site_c else None))
    for nom, fct, resp, idt, site_c in [
        ("Camille Durand (fictive)", "Responsable de site", "exploitation", "c.durand", "SITE-PV-GAR"),
        ("Lou Martin (fictif)", "Technicien de maintenance", "maintenance", "l.martin", "SITE-PV-GAR"),
        ("Sacha Bernard (fictif)", "Chargé d'exploitation habilité", "hse", "s.bernard", "SITE-PV-GAR"),
        ("Noa Petit (fictif)", "Chef de dépôt", "exploitation", "n.petit", "SITE-DEP-SAU"),
        ("Eden Garnier (fictif)", "Référent données environnementales", "donnees", "e.garnier", None)]:
        s.add(Responsable(nom=nom, fonction=fct, responsabilite=resp, utilisateur_id=ids["U:" + idt],
                          site_id=ids.get(site_c) if site_c else None, date_debut=ORIGINE))

    # --- Documents (texte indexable) ---------------------------------------------
    docs = [
        ("Procédure de consignation d'un onduleur central (fictive)", "procedure", "SITE-PV-GAR", "interne",
         "Avant toute intervention sur un onduleur, la consignation est réalisée par une personne habilitée selon la "
         "procédure du site. Ouvrir le sectionneur AC puis DC, vérifier l'absence de tension, poser les cadenas. Le "
         "permis de travail est délivré par le chargé d'exploitation. Énergies 360 enregistre la référence du permis "
         "mais ne délivre aucun permis."),
        ("Notice technique onduleur OND-2500 (fictive)", "notice", "SITE-PV-GAR", "interne",
         "Code défaut F-217 : surchauffe du module de puissance IGBT. Vérifier les ventilateurs et le filtre. "
         "Remplacement du module de puissance par un technicien qualifié. Puissance nominale 2 500 kW AC."),
        ("Plan de prévention prestataire maintenance (fictif)", "hse", "SITE-PV-GAR", "interne",
         "Le prestataire Solaire Maintenance Services intervient sous plan de prévention. Délai d'intervention 24 h."),
        ("Fiche de données de sécurité butane (fictive)", "fds", "SITE-DEP-SAU", "interne",
         "Gaz extrêmement inflammable. Stocker à l'écart des huiles et des sources de chaleur, en zone ventilée."),
        ("Note restreinte — négociation tarifaire (fictive)", "note", "SITE-STA-TIL", "restreint",
         "Document restreint : non indexé par l'assistance."),
    ]
    for titre, type_, site_c, conf, texte in docs:
        cle, hh = stockage().deposer("documents", f"{type_}.txt", texte.encode())
        s.add(Document(titre=titre, type_document=type_, site_id=ids[site_c], cle_stockage=cle, sha256=hh,
                       taille_octets=len(texte.encode()), type_mime="text/plain", confidentialite=conf,
                       texte_indexable=texte, depose_par=AUTEUR))

    # --- Prévisions de production --------------------------------------------------
    for j in range(7):
        jour = D0 + timedelta(days=j)
        pv = Prevision(actif_id=ids["PV-GAR"], modele="physique_simplifie+meteo_simulee", version_modele="1.0",
                       emise_le=jour - timedelta(hours=12), horizon_h=36, debut=jour, fin=jour + timedelta(days=1),
                       methode_incertitude="bande empirique ±18 % (P10/P90) issue d'erreurs historiques simulées",
                       donnees_entree={"meteo": "prévision d'éclairement simulée", "pdc_kw": 12_000, "pac_kw": 10_000})
        s.add(pv)
        s.flush()
        for hh_ in range(24):
            t = jour + timedelta(hours=hh_)
            e = sum(puissance_potentielle_kw(prevision_eclairement(t + timedelta(minutes=10 * k)),
                                             25 + prevision_eclairement(t + timedelta(minutes=10 * k)) / 40,
                                             12_000, 10_000) / 6 for k in range(6))
            s.add(ValeurPrevision(prevision_id=pv.id, debut=t, p10=round(e * 0.82, 1), p50=round(e, 1),
                                  p90=round(min(e * 1.18, 10_000), 1)))
    if avec_donnees_stations:
        simuler_stations(s, ids)
    s.flush()
    sec.vider_cache_portees()
    return {"deja_initialise": False, "ids": {k: v for k, v in ids.items()}}


def simuler_stations(s: Session, ids: dict):
    """Ventes horaires, prix datés, jaugeages quotidiens et livraisons (synthétiques)."""
    rnd = random.Random(42)
    alpha = {"GO-B7": 0.00083, "SP95-E10": 0.00120}
    for sc, lib, fuite in (("SITE-STA-TIL", "TIL", 0.0), ("SITE-STA-PNF", "PNF", 0.008)):
        for prod, v15_init, prix in (("GO-B7", 14_000.0 if lib == "TIL" else 30_000.0, 1.739),
                                     ("SP95-E10", 18_000.0, 1.859)):
            pid = ids[prod]
            cuve = ids[f"E:STA-{lib}-CUVE-{prod.split('-')[0]}"]
            s.add(PrixAffiche(site_id=ids[sc], produit_id=pid, prix_ttc=prix, valide_de=ORIGINE,
                              valide_a=datetime(2026, 6, 18, 5, tzinfo=UTC), source="affichage gérant (simulé)"))
            s.add(PrixAffiche(site_id=ids[sc], produit_id=pid, prix_ttc=round(prix - 0.024, 3),
                              valide_de=datetime(2026, 6, 18, 5, tzinfo=UTC), source="affichage gérant (simulé)"))
            v15 = v15_init
            for j in range(8):
                jour = D0 + timedelta(days=j)
                t_cuve = 16.5 + 1.2 * math.sin(j)
                s.add(Jaugeage(cuve_id=cuve, horodatage=jour, volume_observe_l=round(v15 * (1 + alpha[prod] * (t_cuve - 15)), 1),
                               temperature_c=round(t_cuve, 2)))
                if j == 7:
                    break
                if lib == "TIL" and prod == "GO-B7" and j == 2:
                    v15_bl = 22_000.0
                    t_liv = 19.0
                    s.add(LivraisonCarburant(site_id=ids[sc], cuve_id=cuve, produit_id=pid,
                                             horodatage=jour + timedelta(hours=6, minutes=30),
                                             volume_observe_l=round(v15_bl * (1 + alpha[prod] * (t_liv - 15)), 1),
                                             temperature_c=t_liv, volume_15c_bl_l=v15_bl, contrat_id=ids["CTR-GO"],
                                             hypotheses=[{"source": "bon de livraison fictif BL-CSE-55120",
                                                          "note": "commande 30 000 L15, livraison partielle"}]))
                    v15 += v15_bl
                for hh in range(5, 23):
                    t = jour + timedelta(hours=hh, minutes=rnd.randint(0, 59))
                    n = rnd.randint(2, 5) if prod == "GO-B7" else rnd.randint(1, 3)
                    for _ in range(n):
                        vol = round(rnd.uniform(18, 62), 2)
                        p_aff = prix if t < datetime(2026, 6, 18, 5, tzinfo=UTC) else round(prix - 0.024, 3)
                        s.add(VenteCarburant(site_id=ids[sc], produit_id=pid, pompe_id=ids[f"STA-{lib}-PMP{rnd.randint(1, 2)}"],
                                             cuve_id=cuve, horodatage=t, volume_observe_l=vol, prix_applique_ttc=p_aff,
                                             montant_ttc=round(vol * p_aff, 2)))
                        v15 -= vol * (1 - alpha[prod] * (t_cuve - 15))
                if fuite and prod == "SP95-E10":
                    v15 -= 35.0  # écart physique inexpliqué simulé à PNF (≈ 35 L15/jour)
