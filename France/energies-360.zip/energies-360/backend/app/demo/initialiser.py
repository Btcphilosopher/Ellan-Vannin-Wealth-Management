"""Initialisation idempotente : schéma (Alembic sous PostgreSQL) + portefeuille fictif.

    python -m app.demo.initialiser
"""
from __future__ import annotations

from .. import modeles
from ..db import configurer, moteur, session_scope
from .seed import initialiser


def main():
    configurer()
    if moteur().dialect.name == "sqlite":
        modeles.metadata.create_all(moteur())
    else:
        from alembic import command
        from alembic.config import Config

        command.upgrade(Config("alembic.ini"), "head")
    with session_scope() as s:
        r = initialiser(s)
    print("Portefeuille fictif déjà présent" if r.get("deja_initialise") else "Portefeuille fictif initialisé")


if __name__ == "__main__":
    main()
