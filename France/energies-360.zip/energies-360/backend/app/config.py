"""Configuration de la plateforme Énergies 360.

Les secrets ne sont jamais codés en dur pour un déploiement : ils sont lus depuis
une variable d'environnement ou, de préférence, depuis un fichier monté
(convention ``*_FILE`` compatible Docker secrets).
"""
from __future__ import annotations

import os
import secrets
from functools import lru_cache
from pathlib import Path

from pydantic_settings import BaseSettings, SettingsConfigDict


def _lire_secret(nom: str, defaut: str | None = None) -> str | None:
    chemin = os.environ.get(f"{nom}_FILE")
    if chemin and Path(chemin).exists():
        return Path(chemin).read_text(encoding="utf-8").strip()
    return os.environ.get(nom, defaut)


class Parametres(BaseSettings):
    model_config = SettingsConfigDict(env_prefix="E360_", extra="ignore")

    nom_application: str = "Énergies 360 — prototype indépendant"
    environnement: str = "developpement"
    mode_demo: bool = True
    database_url: str = "sqlite:///./energies360.db"
    cors_origines: str = "http://localhost:3000"

    jwt_algorithme: str = "HS256"
    jwt_duree_minutes: int = 120

    stockage_backend: str = "local"  # local | s3
    stockage_repertoire: str = "./stockage_objets"
    s3_endpoint: str | None = None
    s3_bucket: str = "energies360"

    # Limitation des imports
    import_taille_max_octets: int = 5 * 1024 * 1024
    import_lignes_max: int = 50_000
    ingestion_lot_max: int = 20_000
    limite_requetes_par_minute: int = 600

    # Qualité des données
    seuil_retard_s: int = 900  # 15 min entre observation et ingestion
    # Horloge de référence : en démonstration, la "date courante" est figée pour
    # rendre le parcours reproductible.
    horloge_figee: str | None = None
    horloge_origine: str | None = None
    # Période du jeu de démonstration (données synthétiques)
    demo_debut: str = "2026-06-15T00:00:00+00:00"
    demo_fin: str = "2026-06-22T00:00:00+00:00"

    def _secret(self, nom: str) -> str:
        valeur = _lire_secret(nom)
        if valeur:
            return valeur
        if self.environnement == "production":
            raise RuntimeError(f"{nom}(_FILE) obligatoire en production")
        # Développement / démonstration : secret local généré une fois, persisté hors dépôt (0600)
        chemin = Path(self.stockage_repertoire) / ".secrets_locaux" / nom.lower()
        if not chemin.exists():
            chemin.parent.mkdir(parents=True, exist_ok=True)
            chemin.write_text(secrets.token_urlsafe(48), encoding="utf-8")
            chemin.chmod(0o600)
        return chemin.read_text(encoding="utf-8").strip()

    @property
    def url_base(self) -> str:
        """URL de connexion ; le mot de passe peut venir d'un secret monté
        (E360_DATABASE_PASSWORD_FILE) pour ne pas figurer dans l'environnement."""
        mdp = _lire_secret("E360_DATABASE_PASSWORD")
        if not mdp or self.database_url.startswith("sqlite"):
            return self.database_url
        from sqlalchemy.engine import make_url

        u = make_url(self.database_url)
        return u.set(password=mdp).render_as_string(hide_password=False) if u.password is None else self.database_url

    @property
    def jwt_secret(self) -> str:
        return self._secret("E360_JWT_SECRET")

    @property
    def cle_chiffrement(self) -> str:
        """Clé de protection des secrets MFA au repos (distincte du secret JWT)."""
        return self._secret("E360_CLE_CHIFFREMENT")

    @property
    def s3_access_key(self) -> str | None:
        return _lire_secret("E360_S3_ACCESS_KEY")

    @property
    def s3_secret_key(self) -> str | None:
        return _lire_secret("E360_S3_SECRET_KEY")




@lru_cache
def parametres() -> Parametres:
    return Parametres()
