# TOTALENERGIES — ÉNERGIES 360 · prototype de plateforme intégrée multi-énergies

> **Concept indépendant.** Ce prototype n'est ni affilié à TotalEnergies ni approuvé par
> TotalEnergies, et n'a aucun accès à ses systèmes. Le nom n'est utilisé que pour désigner le type
> d'organisation visé. Toutes les entités, personnes, sites, contrats, prix, facteurs d'émission et
> mesures sont **synthétiques**. Aucune commande de procédé industriel, aucun ordre de marché réel.

Énergies 360 relie **actifs, flux physiques, interventions, engagements commerciaux et impacts
environnementaux** à des données vérifiables et à des responsabilités explicites : chaque
indicateur ouvre ses données sources et sa méthode de calcul.

## Contenu de l'archive

| Chemin | Contenu |
|---|---|
| `backend/` | API Python FastAPI (monolithe modulaire), modèles SQLAlchemy, migrations Alembic, simulateurs, démonstration, tests |
| `frontend/` | Application web Next.js 14 / React 18 / TypeScript (12 espaces de navigation) |
| `docker-compose.yml` | PostgreSQL + PostGIS, init, API, worker, démonstration, frontend ; profils `s3` (MinIO) et `tls` (Caddy) |
| `docs/` | architecture, séries temporelles, méthodes de calcul, sécurité, intégrations, IA, API (OpenAPI), démonstration, résultats de tests, statut des fonctionnalités, captures |
| `scripts/` | génération des secrets, sauvegarde / restauration PostgreSQL et test de restauration |
| `exemples/` | sorties réelles du parcours de démonstration (résultats JSON, rapport traçable JSON + HTML) |

## Démarrage rapide (Docker Compose)

```bash
./scripts/generer_secrets.sh
```

```bash
docker compose up --build
```

* Application : <http://localhost:3000> — API : <http://localhost:8000/docs>
* Le service `demo` rejoue automatiquement le parcours complet (télémétrie d'une semaine,
  maintenance, stocks, contrats, recharge, batterie, environnement, finance, rapport).
* HTTPS local optionnel : `docker compose --profile tls up --build` puis <https://localhost:8443>.

## Démarrage sans Docker (développement)

Prérequis : Python ≥ 3.11, Node.js 20. SQLite est utilisé par défaut (PostGIS → repli haversine).

```bash
cd backend && pip install -r requirements-dev.txt
```

```bash
cd backend && E360_HORLOGE_ORIGINE=2026-06-22T00:00:00+00:00 python -m app.demo.scenario
```

```bash
cd backend && E360_HORLOGE_ORIGINE=2026-06-22T00:00:00+00:00 uvicorn app.main:app --port 8000
```

```bash
cd frontend && npm ci && npm run build && npm start
```

Avec PostgreSQL + PostGIS : `E360_DATABASE_URL=postgresql+psycopg://user@hôte:5432/base`, puis
`alembic upgrade head` (ou `python -m app.demo.initialiser`).

## Comptes fictifs de démonstration

Mot de passe commun : `Demo-E360!` (démonstration uniquement ; `E360_MODE_DEMO=false` désactive
les points d'entrée de démonstration). Les comptes marqués MFA exigent un code TOTP ; en mode
démonstration la page de connexion l'obtient via `GET /api/auth/demo/code-mfa/{id}`.

| Identifiant | Rôle | Portée | MFA |
|---|---|---|---|
| `direction` | direction (lecture de tout) | groupe | oui |
| `admin.plateforme` | administration, audit, sauvegardes | groupe | oui |
| `c.durand` | responsable de site | parc des Garrigues | non |
| `l.martin` | technicien de maintenance | entité Renouvelables | non |
| `s.bernard` | exploitant habilité (autorisation opérationnelle) | parc des Garrigues | oui |
| `n.petit` | logisticien | entité Logistique & Distribution | non |
| `a.moreau` | gestion des contrats | groupe | non |
| `j.lefevre` | analyste financier | groupe | non |
| `e.garnier` / `v.roux` | analyste / validateur environnement | groupe | non |
| `m.fontaine` | opérateur mobilité (sert aux tentatives non autorisées) | groupe | non |
| `r.audit` | auditeur interne | groupe | non |

## Portefeuille fictif et parcours démontré

Centrale solaire 12 MWc / 10 MWac (4 onduleurs) et batterie 5 MW / 10 MWh sur le parc des
Garrigues, dépôt de produits conditionnés de Saint-Aurel, stations « Relais des Tilleuls » et
« Relais du Pont-Neuf », 4 bornes / 8 connecteurs, une unité de mélange (bilan matière) et un
titre amont fictif (suivi administratif).

Parcours (`python -m app.demo.scenario`, détaillé dans [docs/demonstration.md](docs/demonstration.md)) :
1 enregistrement des actifs · 2 ingestion simulée · 3 énergie sans double comptage ·
4 capteur périmé · 5 ordre de maintenance · 6 réception et transfert de stock ·
7 rapprochement d'une livraison · 8 session de recharge · 9 simulation de batterie ·
10 calcul environnemental sourcé · 11 analyse économique · 12 rapport traçable —
avec doublons, compteur réinitialisé, livraison partielle, panne et tentatives d'accès non
autorisées.

## Tests

```bash
cd backend && python -m pytest
```

```bash
cd backend && E360_TEST_PG_URL="postgresql+psycopg://postgres@hôte:5432/postgres" E360_TESTS_SUR_PG=1 python -m pytest
```

Résultats réels d'exécution : [docs/resultats-tests.md](docs/resultats-tests.md).
Statut opérationnel / simulé / intégré / reporté : [docs/statut-fonctionnalites.md](docs/statut-fonctionnalites.md).

## Documentation

[Architecture](docs/architecture.md) · [Séries temporelles](docs/series-temporelles.md) ·
[Unités, bilans et méthodes](docs/methodes-calcul.md) · [Sécurité](docs/securite.md) ·
[Intégrations](docs/integrations.md) · [IA](docs/ia-gouvernance.md) · [API](docs/api.md) ·
[Captures d'écran](docs/captures/)

## Limites

Prototype de démonstration : pas de déclaration réglementaire, pas d'audit environnemental, pas
de certification de cybersécurité ou de conformité industrielle ; l'application ne déclare jamais
une installation sûre et ne remplace ni la consignation ni le permis de travail.
