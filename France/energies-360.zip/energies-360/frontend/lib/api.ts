"use client";
import { useCallback, useEffect, useMemo, useState } from "react";

export const API_URL = (process.env.NEXT_PUBLIC_API_URL || "http://localhost:8000").replace(/\/$/, "");
export const WS_URL = API_URL.replace(/^http/, "ws");

const CLE_JETON = "e360_jeton";
const CLE_PROFIL = "e360_profil";

export type Profil = {
  identifiant: string;
  nom: string;
  habilitations: { role: string; entite: string | null; site: string | null }[];
  permissions: string[];
};

function stockageSession(): Storage | null {
  try {
    return typeof window !== "undefined" ? window.sessionStorage : null;
  } catch {
    return null;
  }
}

export function jeton(): string | null {
  return stockageSession()?.getItem(CLE_JETON) ?? null;
}

export function profil(): Profil | null {
  const brut = stockageSession()?.getItem(CLE_PROFIL);
  if (!brut) return null;
  try {
    return JSON.parse(brut) as Profil;
  } catch {
    return null;
  }
}

export function enregistrerSession(j: string, p: Profil) {
  const s = stockageSession();
  s?.setItem(CLE_JETON, j);
  s?.setItem(CLE_PROFIL, JSON.stringify(p));
}

export function deconnecter() {
  const s = stockageSession();
  s?.removeItem(CLE_JETON);
  s?.removeItem(CLE_PROFIL);
}

export class ErreurApi extends Error {
  statut: number;
  constructor(statut: number, message: string) {
    super(message);
    this.statut = statut;
  }
}

function detail(corps: unknown, statut: number): string {
  if (corps && typeof corps === "object" && "detail" in corps) {
    const d = (corps as { detail: unknown }).detail;
    if (typeof d === "string") return d;
    if (Array.isArray(d))
      return d.map((x) => (x && typeof x === "object" && "msg" in x ? String((x as { msg: string }).msg) : JSON.stringify(x))).join(" ; ");
    return JSON.stringify(d);
  }
  return `Erreur HTTP ${statut}`;
}

export async function api<T = any>(chemin: string, options: RequestInit & { params?: Record<string, string | number | undefined | null> } = {}): Promise<T> {
  const { params, ...init } = options;
  let url = `${API_URL}${chemin}`;
  if (params) {
    const q = new URLSearchParams();
    Object.entries(params).forEach(([k, v]) => {
      if (v !== undefined && v !== null && v !== "") q.set(k, String(v));
    });
    const s = q.toString();
    if (s) url += (url.includes("?") ? "&" : "?") + s;
  }
  const entetes: Record<string, string> = { ...(init.headers as Record<string, string> | undefined) };
  const j = jeton();
  if (j) entetes["Authorization"] = `Bearer ${j}`;
  if (init.body && typeof init.body === "string") entetes["Content-Type"] = "application/json";
  const rep = await fetch(url, { ...init, headers: entetes });
  const texte = await rep.text();
  let corps: unknown = null;
  try {
    corps = texte ? JSON.parse(texte) : null;
  } catch {
    corps = texte;
  }
  if (rep.status === 401 && !chemin.startsWith("/api/auth/")) {
    deconnecter();
    if (typeof window !== "undefined" && !window.location.pathname.startsWith("/connexion")) {
      window.location.href = "/connexion";
    }
  }
  if (!rep.ok) throw new ErreurApi(rep.status, detail(corps, rep.status));
  return corps as T;
}

export function post<T = any>(chemin: string, corps: unknown): Promise<T> {
  return api<T>(chemin, { method: "POST", body: JSON.stringify(corps ?? {}) });
}

export type Etat<T> = { donnees: T | null; erreur: ErreurApi | null; chargement: boolean; recharger: () => void };

export function useApi<T = any>(chemin: string | null, params?: Record<string, string | number | undefined | null>): Etat<T> {
  const [donnees, setDonnees] = useState<T | null>(null);
  const [erreur, setErreur] = useState<ErreurApi | null>(null);
  const [chargement, setChargement] = useState<boolean>(!!chemin);
  const [compteur, setCompteur] = useState(0);
  const cle = JSON.stringify(params ?? {});
  useEffect(() => {
    if (!chemin) return;
    let actif = true;
    setChargement(true);
    api<T>(chemin, { params: JSON.parse(cle) })
      .then((d) => {
        if (actif) {
          setDonnees(d);
          setErreur(null);
        }
      })
      .catch((e) => {
        if (actif) setErreur(e instanceof ErreurApi ? e : new ErreurApi(0, String(e)));
      })
      .finally(() => actif && setChargement(false));
    return () => {
      actif = false;
    };
  }, [chemin, cle, compteur]);
  const recharger = useCallback(() => setCompteur((c) => c + 1), []);
  return { donnees, erreur, chargement, recharger };
}

export type Contexte = { debut: string; fin: string; horloge: string };

let contexteCache: Contexte | null = null;

export function useContexte(): Contexte | null {
  const [c, setC] = useState<Contexte | null>(contexteCache);
  useEffect(() => {
    if (contexteCache) return;
    api<{ periode_demo: { debut: string; fin: string }; horloge_metier: string }>("/api/contexte")
      .then((r) => {
        contexteCache = { debut: r.periode_demo.debut, fin: r.periode_demo.fin, horloge: r.horloge_metier };
        setC(contexteCache);
      })
      .catch(() => {
        contexteCache = { debut: "2026-06-15T00:00:00+00:00", fin: "2026-06-22T00:00:00+00:00", horloge: "" };
        setC(contexteCache);
      });
  }, []);
  return c;
}

export function aPermission(p: string): boolean {
  return profil()?.permissions.includes(p) ?? false;
}


/** Paramètres de période de démonstration (mémorisés) : debut, fin et instant = fin. */
export function usePeriode(): Record<string, string> | null {
  const c = useContexte();
  return useMemo(() => (c ? { debut: c.debut, fin: c.fin, instant: c.fin } : null), [c]);
}

export function useSites(): { id: number; code: string; nom: string; domaine: string }[] {
  const e = useApi<{ id: number; code: string; nom: string; domaine: string }[]>("/api/patrimoine/sites");
  return e.donnees ?? [];
}
