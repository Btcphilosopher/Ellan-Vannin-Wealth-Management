export function nombre(v: unknown, decimales = 1): string {
  if (v === null || v === undefined || v === "") return "—";
  const n = typeof v === "number" ? v : Number(v);
  if (!Number.isFinite(n)) return String(v);
  return n.toLocaleString("fr-FR", { maximumFractionDigits: decimales, minimumFractionDigits: 0 });
}

export function date(v: unknown, avecHeure = true): string {
  if (!v || typeof v !== "string") return "—";
  const d = new Date(v);
  if (Number.isNaN(d.getTime())) return v;
  return d.toLocaleString("fr-FR", {
    timeZone: "UTC",
    day: "2-digit",
    month: "2-digit",
    year: "numeric",
    ...(avecHeure ? { hour: "2-digit", minute: "2-digit" } : {}),
  }) + (avecHeure ? " UTC" : "");
}

export function heure(v: string): string {
  const d = new Date(v);
  return d.toLocaleString("fr-FR", { timeZone: "UTC", day: "2-digit", month: "2-digit", hour: "2-digit" });
}

export function kwhEnMwh(v: number | null | undefined): string {
  if (v === null || v === undefined) return "indéterminé";
  return `${nombre(v / 1000, 2)} MWh`;
}

export const LIBELLES_ETAT: Record<string, string> = {
  signale: "Signalé",
  evalue: "Évalué",
  planifie: "Planifié",
  en_intervention: "En intervention",
  controle: "Contrôle",
  cloture: "Clôturé",
  annule: "Annulé",
};
