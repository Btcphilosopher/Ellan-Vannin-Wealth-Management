"use client";
import { useState } from "react";

type Site = {
  type: string;
  geometry: { type: string; coordinates: [number, number] };
  properties: { id: number; code: string; nom: string; domaine: string; commune: string | null; etat: string; alertes_ouvertes: number };
};

// Contour approximatif de la France métropolitaine (lon, lat) — tracé simplifié, sans valeur cartographique.
const FRANCE: [number, number][] = [
  [2.55, 51.09], [3.2, 50.75], [4.15, 50.25], [4.85, 50.15], [5.8, 49.55], [6.4, 49.47], [7.0, 49.15], [8.2, 48.97],
  [7.8, 48.5], [7.6, 47.6], [6.85, 47.4], [6.1, 46.6], [6.2, 46.2], [6.8, 45.9], [7.0, 45.3], [6.6, 45.1], [7.0, 44.2],
  [7.5, 43.8], [6.6, 43.15], [5.4, 43.2], [4.6, 43.4], [3.3, 43.2], [3.05, 42.5], [1.7, 42.5], [0.7, 42.8], [-0.3, 42.8],
  [-1.8, 43.35], [-1.45, 43.6], [-1.2, 44.6], [-1.15, 45.5], [-1.6, 46.2], [-2.2, 47.1], [-3.0, 47.5], [-4.4, 47.8],
  [-4.75, 48.35], [-4.0, 48.7], [-3.0, 48.8], [-1.9, 48.65], [-1.6, 48.7], [-1.9, 49.7], [-1.25, 49.7], [-1.1, 49.35],
  [0.1, 49.45], [1.1, 49.95], [1.6, 50.25], [1.6, 50.85],
];
const CORSE: [number, number][] = [[9.4, 43.0], [9.55, 42.6], [9.4, 41.4], [9.1, 41.4], [8.6, 41.9], [8.6, 42.4], [9.3, 42.8]];

const COULEURS: Record<string, [string, string]> = {
  renouvelable: ["#00a3a6", "Renouvelable et stockage"],
  depot: ["#f39200", "Dépôt / terminal"],
  distribution: ["#e4002b", "Station-service et recharge"],
  industrie: ["#6b4fbb", "Site industriel"],
  mobilite: ["#2e8540", "Mobilité"],
};

const LARG = 560;
const HAUT = 560;
const LON0 = -5.3;
const LON1 = 9.8;
const LAT0 = 41.2;
const LAT1 = 51.3;
const K = Math.cos((46 * Math.PI) / 180);

function proj([lon, lat]: [number, number]): [number, number] {
  const largeurDeg = (LON1 - LON0) * K;
  const hauteurDeg = LAT1 - LAT0;
  const e = Math.min(LARG / largeurDeg, HAUT / hauteurDeg);
  return [((lon - LON0) * K) * e + 10, (LAT1 - lat) * e + 10];
}

const poly = (pts: [number, number][]) => pts.map((p) => proj(p).map((v) => v.toFixed(1)).join(",")).join(" ");

export default function Carte({ sites, surSelection }: { sites: Site[]; surSelection?: (id: number) => void }) {
  const [survol, setSurvol] = useState<number | null>(null);
  return (
    <figure style={{ margin: 0 }}>
      <svg viewBox={`0 0 ${LARG + 20} ${HAUT}`} role="img" aria-label="Carte schématique des sites du portefeuille fictif" style={{ width: "100%", height: "auto", background: "#eaf3fb", borderRadius: 8 }}>
        <polygon points={poly(FRANCE)} fill="#ffffff" stroke="#9aa8c4" strokeWidth={1.2} />
        <polygon points={poly(CORSE)} fill="#ffffff" stroke="#9aa8c4" strokeWidth={1.2} />
        {[...sites].sort((a, b) => b.geometry.coordinates[1] - a.geometry.coordinates[1]).map((s, i, tous) => {
          const [x, y] = proj(s.geometry.coordinates);
          // décalage vertical des étiquettes des sites voisins pour éviter les chevauchements
          const voisins = tous.slice(0, i).filter((o) => {
            const [ox, oy] = proj(o.geometry.coordinates);
            return Math.abs(ox - x) < 120 && Math.abs(oy - y) < 16;
          }).length;
          const decal = voisins * 14;
          const [c] = COULEURS[s.properties.domaine] ?? ["#0b1b3f"];
          const actif = survol === s.properties.id;
          const etiquette = s.properties.nom.replace(/ \(.*\)$/, "");
          const aDroite = x < 250;
          return (
            <g
              key={s.properties.id}
              onMouseEnter={() => setSurvol(s.properties.id)}
              onMouseLeave={() => setSurvol(null)}
              onClick={() => surSelection?.(s.properties.id)}
              style={{ cursor: surSelection ? "pointer" : "default" }}
              tabIndex={0}
              role="button"
              aria-label={`${s.properties.nom}, ${s.properties.alertes_ouvertes} alerte(s) ouverte(s)`}
            >
              <circle cx={x} cy={y} r={actif ? 9 : 7} fill={c} stroke="#0b1b3f" strokeWidth={1.5} />
              {s.properties.alertes_ouvertes > 0 && (
                <g>
                  <circle cx={x + 8} cy={y - 8} r={8} fill="#e4002b" stroke="#fff" strokeWidth={1.5} />
                  <text x={x + 8} y={y - 4.5} fontSize="9" fill="#fff" textAnchor="middle" fontWeight="700">
                    {s.properties.alertes_ouvertes}
                  </text>
                </g>
              )}
              <text x={aDroite ? x + 18 : x - 12} y={y + 4 + decal} fontSize="11" textAnchor={aDroite ? "start" : "end"} fill="#0b1b3f" fontWeight={actif ? 700 : 500}
                style={{ paintOrder: "stroke", stroke: "#fff", strokeWidth: 3 }}>
                {etiquette}
              </text>
            </g>
          );
        })}
      </svg>
      <figcaption className="legende">
        {Object.entries(COULEURS).map(([k, [c, l]]) => (
          <span key={k}>
            <span className="pastille" style={{ background: c, height: 10, width: 10, borderRadius: 5 }} />
            {l}
          </span>
        ))}
        <span>
          <span className="pastille" style={{ background: "#e4002b", height: 10, width: 10, borderRadius: 5 }} />
          nombre d&apos;alertes ouvertes
        </span>
        <span>Fond schématique (WGS 84, projection équirectangulaire), sites et communes fictifs.</span>
      </figcaption>
    </figure>
  );
}
