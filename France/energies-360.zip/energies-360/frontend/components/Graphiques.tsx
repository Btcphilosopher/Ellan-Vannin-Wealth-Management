"use client";
import { heure, nombre } from "@/lib/format";

export type Serie = { nom: string; couleur: string; valeurs: (number | null)[]; pointille?: boolean; zone?: boolean };
export type Bande = { nom: string; couleur: string; bas: (number | null)[]; haut: (number | null)[] };

const L = 760;
const H = 260;
const M = { g: 64, d: 16, h: 14, b: 42 };

function echelle(min: number, max: number) {
  if (min === max) {
    max = min + 1;
  }
  const etendue = max - min;
  const pas = Math.pow(10, Math.floor(Math.log10(etendue / 4)));
  const mult = [1, 2, 2.5, 5, 10].find((m) => etendue / (pas * m) <= 6) ?? 10;
  const p = pas * mult;
  const bas = Math.floor(min / p) * p;
  const haut = Math.ceil(max / p) * p;
  const graduations: number[] = [];
  for (let v = bas; v <= haut + p / 2; v += p) graduations.push(Number(v.toFixed(10)));
  return { bas, haut, graduations };
}

function segments(vals: (number | null)[], x: (i: number) => number, y: (v: number) => number): [number, number][][] {
  const res: [number, number][][] = [];
  let cur: [number, number][] = [];
  vals.forEach((v, i) => {
    if (v === null || v === undefined || !Number.isFinite(v)) {
      if (cur.length) res.push(cur);
      cur = [];
    } else cur.push([x(i), y(v)]);
  });
  if (cur.length) res.push(cur);
  return res;
}

const chemin = (pts: [number, number][]) => pts.map(([a, b], k) => `${k ? "L" : "M"}${a.toFixed(1)},${b.toFixed(1)}`).join("");

export function GraphiqueLignes({ titre, uniteY, temps, series, bandes = [], hauteur = H, zeroInclus = true }: {
  titre: string;
  uniteY: string;
  temps: string[];
  series: Serie[];
  bandes?: Bande[];
  hauteur?: number;
  zeroInclus?: boolean;
}) {
  const toutes = [...series.flatMap((s) => s.valeurs), ...bandes.flatMap((b) => [...b.bas, ...b.haut])].filter(
    (v): v is number => v !== null && v !== undefined && Number.isFinite(v),
  );
  const manquants = series.some((s) => s.valeurs.some((v) => v === null || v === undefined));
  const n = temps.length;
  if (!n || !toutes.length) return <div className="petit">{titre} : aucune donnée sur la période (≠ zéro).</div>;
  const { bas, haut, graduations } = echelle(zeroInclus ? Math.min(0, ...toutes) : Math.min(...toutes), Math.max(...toutes));
  const lx = L - M.g - M.d;
  const ly = hauteur - M.h - M.b;
  const x = (i: number) => M.g + (n <= 1 ? 0 : (i / (n - 1)) * lx);
  const y = (v: number) => M.h + ly - ((v - bas) / (haut - bas)) * ly;
  const pasEtiquette = Math.max(1, Math.ceil(n / 8));
  return (
    <figure className="graphique" style={{ margin: 0 }}>
      <figcaption className="titre-g">{titre}</figcaption>
      <svg viewBox={`0 0 ${L} ${hauteur}`} role="img" aria-label={`${titre} — unité ${uniteY}`}>
        <rect x={M.g} y={M.h} width={lx} height={ly} fill="#fbfcfe" stroke="#d9dfeb" />
        {graduations.map((g) => (
          <g key={g}>
            <line x1={M.g} x2={M.g + lx} y1={y(g)} y2={y(g)} stroke="#e7ebf3" />
            <text x={M.g - 6} y={y(g) + 4} fontSize="11" textAnchor="end" fill="#4a5673">
              {nombre(g, 2)}
            </text>
          </g>
        ))}
        <text x={14} y={M.h + ly / 2} fontSize="11" fill="#0b1b3f" transform={`rotate(-90 14 ${M.h + ly / 2})`} textAnchor="middle">
          {uniteY}
        </text>
        {temps.map((t, i) =>
          i % pasEtiquette === 0 ? (
            <g key={t + i}>
              <line x1={x(i)} x2={x(i)} y1={M.h + ly} y2={M.h + ly + 4} stroke="#4a5673" />
              <text x={x(i)} y={M.h + ly + 16} fontSize="10" textAnchor="middle" fill="#4a5673">
                {heure(t)}
              </text>
            </g>
          ) : null,
        )}
        <text x={M.g + lx / 2} y={hauteur - 6} fontSize="11" textAnchor="middle" fill="#0b1b3f">
          temps (jour/mois heure, UTC)
        </text>
        {bandes.map((b) => {
          const pts: string[] = [];
          const retour: string[] = [];
          b.haut.forEach((v, i) => {
            const bv = b.bas[i];
            if (v !== null && bv !== null && v !== undefined && bv !== undefined) {
              pts.push(`${x(i).toFixed(1)},${y(v).toFixed(1)}`);
              retour.unshift(`${x(i).toFixed(1)},${y(bv).toFixed(1)}`);
            }
          });
          return pts.length ? <polygon key={b.nom} points={[...pts, ...retour].join(" ")} fill={b.couleur} opacity={0.18} /> : null;
        })}
        {series.map((s) =>
          segments(s.valeurs, x, y).map((pts, k) => (
            <g key={s.nom + k}>
              {s.zone && (
                <path d={`${chemin(pts)}L${pts[pts.length - 1][0].toFixed(1)},${y(Math.max(bas, 0)).toFixed(1)}L${pts[0][0].toFixed(1)},${y(Math.max(bas, 0)).toFixed(1)}Z`} fill={s.couleur} opacity={0.1} />
              )}
              {pts.length === 1 ? (
                <circle cx={pts[0][0]} cy={pts[0][1]} r={2} fill={s.couleur} />
              ) : (
                <path d={chemin(pts)} fill="none" stroke={s.couleur} strokeWidth={1.8} strokeDasharray={s.pointille ? "5 4" : undefined} />
              )}
            </g>
          )),
        )}
      </svg>
      <div className="legende">
        {series.map((s) => (
          <span key={s.nom}>
            <span className="pastille" style={{ background: s.couleur }} />
            {s.nom}
          </span>
        ))}
        {bandes.map((b) => (
          <span key={b.nom}>
            <span className="pastille" style={{ background: b.couleur, opacity: 0.35, height: 10 }} />
            {b.nom}
          </span>
        ))}
        <span>Unité : {uniteY}</span>
        {manquants && <span><b>Trous de courbe : donnée absente ≠ zéro</b></span>}
      </div>
    </figure>
  );
}

export function GraphiqueBarres({ titre, unite, barres }: { titre: string; unite: string; barres: { libelle: string; valeur: number | null; couleur?: string }[] }) {
  const vals = barres.map((b) => b.valeur).filter((v): v is number => v !== null);
  if (!vals.length) return <div className="petit">{titre} : aucune donnée.</div>;
  const max = Math.max(...vals, 0) || 1;
  const hb = 26;
  const hauteur = barres.length * hb + 30;
  const lg = 210;
  const lb = L - lg - 110;
  return (
    <figure className="graphique" style={{ margin: 0 }}>
      <figcaption className="titre-g">{titre}</figcaption>
      <svg viewBox={`0 0 ${L} ${hauteur}`} role="img" aria-label={`${titre} — unité ${unite}`}>
        {barres.map((b, i) => (
          <g key={b.libelle}>
            <text x={lg - 8} y={i * hb + 18} fontSize="12" textAnchor="end" fill="#0b1b3f">
              {b.libelle}
            </text>
            {b.valeur === null ? (
              <text x={lg + 4} y={i * hb + 18} fontSize="12" fill="#9b001d">
                indéterminé (≠ 0)
              </text>
            ) : (
              <>
                <rect x={lg} y={i * hb + 5} width={Math.max(1, (Math.max(0, b.valeur) / max) * lb)} height={hb - 10} fill={b.couleur ?? "#00a3a6"} rx={3} />
                <text x={lg + Math.max(1, (Math.max(0, b.valeur) / max) * lb) + 6} y={i * hb + 18} fontSize="12" fill="#0b1b3f">
                  {nombre(b.valeur, 2)} {unite}
                </text>
              </>
            )}
          </g>
        ))}
        <text x={lg} y={hauteur - 6} fontSize="11" fill="#4a5673">
          Unité : {unite}
        </text>
      </svg>
    </figure>
  );
}
