"use client";
import { nombre } from "@/lib/format";

type Terme = { valeur: number | null; statut: string };
export type Bilan = {
  applicable: boolean;
  termes: Record<string, Terme>;
  ecart_kwh: number | null;
  ecart_pct_production: number | null;
  interpretation_ecart: string;
  equation: string;
  statut: string;
};

function mwh(v: number | null | undefined) {
  return v === null || v === undefined ? "indéterminé" : `${nombre(v / 1000, 2)} MWh`;
}

function Fleche({ x1, y1, x2, y2, v, max, couleur, libelle, dy = -8 }: { x1: number; y1: number; x2: number; y2: number; v: number | null; max: number; couleur: string; libelle: string; dy?: number }) {
  const ep = v === null ? 2 : Math.max(2, Math.min(28, (Math.abs(v) / (max || 1)) * 28));
  const mx = (x1 + x2) / 2;
  const my = (y1 + y2) / 2;
  return (
    <g>
      <path d={`M${x1},${y1} C${mx},${y1} ${mx},${y2} ${x2},${y2}`} fill="none" stroke={couleur} strokeWidth={ep} opacity={v === null ? 0.35 : 0.7} strokeDasharray={v === null ? "6 4" : undefined} markerEnd="url(#pointe)" />
      <text x={mx} y={my + dy} fontSize="12" textAnchor="middle" fill="#0b1b3f" style={{ paintOrder: "stroke", stroke: "#fff", strokeWidth: 4 }}>
        {libelle} : {mwh(v)}
      </text>
    </g>
  );
}

function Noeud({ x, y, l, h = 56, titre, sous, couleur }: { x: number; y: number; l: number; h?: number; titre: string; sous: string; couleur: string }) {
  return (
    <g>
      <rect x={x} y={y} width={l} height={h} rx={8} fill="#fff" stroke={couleur} strokeWidth={2.5} />
      <text x={x + l / 2} y={y + 22} fontSize="13" fontWeight="700" textAnchor="middle" fill="#0b1b3f">
        {titre}
      </text>
      <text x={x + l / 2} y={y + 40} fontSize="11" textAnchor="middle" fill="#4a5673">
        {sous}
      </text>
    </g>
  );
}

export default function SchemaFlux({ bilan }: { bilan: Bilan }) {
  if (!bilan.applicable) return <div className="petit">Aucun bilan électrique pour ce site.</div>;
  const t = bilan.termes;
  const v = (k: string) => (t[k] ? t[k].valeur : null);
  const max = Math.max(...["production_pv", "injection_reseau", "charge_batterie", "decharge_batterie", "soutirage_reseau"].map((k) => Math.abs(v(k) ?? 0)), 1);
  return (
    <figure style={{ margin: 0 }}>
      <svg viewBox="0 0 820 360" role="img" aria-label="Schéma des flux d'énergie du site" style={{ width: "100%", height: "auto" }}>
        <defs>
          <marker id="pointe" markerWidth="12" markerHeight="12" refX="10" refY="6" orient="auto" markerUnits="userSpaceOnUse">
            <path d="M0,0 L12,6 L0,12 Z" fill="#0b1b3f" />
          </marker>
        </defs>
        <Noeud x={20} y={60} l={170} titre="Production PV" sous="compteur principal" couleur="#00a3a6" />
        <Noeud x={325} y={130} l={170} titre="Poste de livraison" sous="nœud de bilan (HTA)" couleur="#0b1b3f" />
        <Noeud x={630} y={60} l={170} titre="Réseau public" sous="injection / soutirage" couleur="#e4002b" />
        <Noeud x={20} y={250} l={170} titre="Batterie" sous="compteur bidirectionnel" couleur="#f39200" />
        <Noeud x={630} y={250} l={170} titre="Pertes et auxiliaires" sous="écart de bilan, non mesuré" couleur="#9aa8c4" />
        <Fleche x1={190} y1={88} x2={325} y2={150} v={v("production_pv")} max={max} couleur="#00a3a6" libelle="Production" />
        <Fleche x1={495} y1={150} x2={630} y2={88} v={v("injection_reseau")} max={max} couleur="#e4002b" libelle="Injection" />
        <Fleche x1={630} y1={110} x2={495} y2={170} v={v("soutirage_reseau")} max={max} couleur="#7a8fb8" libelle="Soutirage" dy={24} />
        <Fleche x1={325} y1={175} x2={190} y2={265} v={v("charge_batterie")} max={max} couleur="#f39200" libelle="Charge" dy={-12} />
        <Fleche x1={190} y1={290} x2={325} y2={180} v={v("decharge_batterie")} max={max} couleur="#c77700" libelle="Décharge" dy={30} />
        <Fleche x1={495} y1={180} x2={630} y2={278} v={bilan.ecart_kwh} max={max} couleur="#9aa8c4" libelle="Écart" dy={20} />
      </svg>
      <figcaption className="petit">
        {bilan.equation}. Écart publié tel quel : <b>{mwh(bilan.ecart_kwh)}</b>
        {bilan.ecart_pct_production !== null ? ` (${nombre(bilan.ecart_pct_production, 2)} % de la production)` : ""} — {bilan.interpretation_ecart} Épaisseur
        des flèches proportionnelle à l&apos;énergie ; pointillés = indéterminé.
      </figcaption>
    </figure>
  );
}
