"use client";
import { ReactNode, useState } from "react";
import { ErreurApi } from "@/lib/api";
import { date, nombre } from "@/lib/format";

export function Erreur({ e }: { e: ErreurApi | null | undefined }) {
  if (!e) return null;
  const refus = e.statut === 403;
  return (
    <div className="message erreur" role="alert">
      <b>{refus ? "Accès refusé (403)" : `Erreur${e.statut ? ` ${e.statut}` : ""}`} :</b> {e.message}
      {refus && <div className="petit">Le refus est journalisé dans l&apos;audit. Les permissions dépendent du rôle et du périmètre (entité / site).</div>}
    </div>
  );
}

export function Chargement({ actif }: { actif: boolean }) {
  return actif ? <div className="petit" aria-live="polite">Chargement…</div> : null;
}

export function Bloc<T>({ etat, children }: { etat: { donnees: T | null; erreur: ErreurApi | null; chargement: boolean }; children: (d: T) => ReactNode }) {
  if (etat.erreur) return <Erreur e={etat.erreur} />;
  if (etat.chargement && !etat.donnees) return <Chargement actif />;
  if (!etat.donnees) return null;
  return <>{children(etat.donnees)}</>;
}

export function Json({ titre = "Données sources (JSON)", valeur, ouvert = false }: { titre?: string; valeur: unknown; ouvert?: boolean }) {
  return (
    <details className="json" open={ouvert}>
      <summary>{titre}</summary>
      <pre>{JSON.stringify(valeur, null, 2)}</pre>
    </details>
  );
}

const GRAV: Record<string, [string, string]> = {
  critique: ["b-critique", "CRITIQUE"],
  avertissement: ["b-avertissement", "AVERTISSEMENT"],
  information: ["b-information", "INFORMATION"],
};

export function Gravite({ g }: { g: string }) {
  const [c, l] = GRAV[g] ?? ["b-neutre", g.toUpperCase()];
  return <span className={`badge ${c}`}>{l}</span>;
}

export function Statut({ s, libelle }: { s: string | null | undefined; libelle?: string }) {
  if (!s) return <span className="badge b-neutre">—</span>;
  const ok = ["complet", "conforme", "disponible", "terminee", "cloture", "recu", "valide_interne", "capture", "integre", "succes"];
  const av = ["incomplet", "avec_reserves", "partielle", "avec_ecart", "a_confirmer", "complet_avec_reserve", "estimation", "partiel", "occupe", "en_transit", "brouillon"];
  const ko = ["indetermine", "indeterminee", "indisponible", "refus", "echec", "incomplete", "en_retard"];
  const c = ok.includes(s) ? "b-ok" : av.includes(s) ? "b-avertissement" : ko.includes(s) ? "b-critique" : "b-neutre";
  return <span className={`badge ${c}`}>{libelle ?? s.replace(/_/g, " ")}</span>;
}

export type AlerteT = {
  id: number;
  type: string;
  gravite: string;
  titre: string;
  message: string;
  regle: string;
  debut: string;
  statut: string;
  site?: string;
  actif?: string | null;
  actif_id?: number | null;
  ordre_travail_id?: number | null;
};

export function Alerte({ a, action }: { a: AlerteT; action?: ReactNode }) {
  return (
    <div className={`alerte ${a.gravite}`}>
      <div className="ligne" style={{ justifyContent: "space-between" }}>
        <span className="t">
          <Gravite g={a.gravite} /> {a.titre}
        </span>
        <span className="petit">
          {date(a.debut)} · statut : {a.statut.replace(/_/g, " ")}
          {a.site ? ` · ${a.site}` : ""}
        </span>
      </div>
      <div className="m">{a.message}</div>
      <div className="r">
        Règle appliquée : {a.regle} <span className="badge b-neutre">{a.type}</span>
      </div>
      {action}
    </div>
  );
}

export type Colonne<T> = { cle: string; titre: string; num?: boolean; rendu?: (l: T) => ReactNode };

export function Tableau<T extends Record<string, any>>({ lignes, colonnes, vide = "Aucune donnée.", surClic, selection }: {
  lignes: T[];
  colonnes: Colonne<T>[];
  vide?: string;
  surClic?: (l: T) => void;
  selection?: (l: T) => boolean;
}) {
  if (!lignes.length) return <div className="petit">{vide}</div>;
  return (
    <div className="defilement">
      <table className="tab">
        <thead>
          <tr>
            {colonnes.map((c) => (
              <th key={c.cle} className={c.num ? "num" : ""} scope="col">
                {c.titre}
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          {lignes.map((l, i) => (
            <tr
              key={(l.id as string | number | undefined) ?? i}
              onClick={surClic ? () => surClic(l) : undefined}
              style={surClic ? { cursor: "pointer" } : undefined}
              className={selection?.(l) ? "selection" : ""}
            >
              {colonnes.map((c) => (
                <td key={c.cle} className={c.num ? "num" : ""}>
                  {c.rendu ? c.rendu(l) : c.num ? nombre(l[c.cle], 3) : formaterValeur(l[c.cle])}
                </td>
              ))}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

function formaterValeur(v: unknown): ReactNode {
  if (v === null || v === undefined) return "—";
  if (typeof v === "boolean") return v ? "oui" : "non";
  if (typeof v === "string" && /^\d{4}-\d{2}-\d{2}T/.test(v)) return date(v);
  if (typeof v === "object") return <code>{JSON.stringify(v)}</code>;
  return String(v);
}

export function Onglets({ onglets, children }: { onglets: string[]; children: (actif: string) => ReactNode }) {
  const [actif, setActif] = useState(onglets[0]);
  return (
    <>
      <div className="onglets" role="tablist">
        {onglets.map((o) => (
          <button key={o} role="tab" aria-selected={actif === o} className={actif === o ? "actif" : ""} onClick={() => setActif(o)}>
            {o}
          </button>
        ))}
      </div>
      {children(actif)}
    </>
  );
}

export function EntetePage({ titre, sousTitre, droite }: { titre: string; sousTitre?: string; droite?: ReactNode }) {
  return (
    <div className="entete-page">
      <div>
        <h1>{titre}</h1>
        {sousTitre && <p>{sousTitre}</p>}
      </div>
      {droite}
    </div>
  );
}

export function Valeur({ v, unite, decimales = 1 }: { v: number | null | undefined; unite: string; decimales?: number }) {
  if (v === null || v === undefined) return <span title="donnée absente ou indéterminée (≠ 0)">indéterminé</span>;
  return (
    <span>
      {nombre(v, decimales)} <span className="petit">{unite}</span>
    </span>
  );
}
