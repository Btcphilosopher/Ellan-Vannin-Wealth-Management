"use client";
import { useEffect, useState } from "react";
import { api, ErreurApi } from "@/lib/api";
import { date, nombre } from "@/lib/format";
import { Erreur, Json, Statut } from "./ui";

export type Indicateur = {
  code: string;
  libelle: string;
  domaine: string;
  valeur: number | null;
  unite?: string;
  nature?: string;
  statut?: string;
  methode?: string;
  avertissements?: string[];
  periode?: { debut: string; fin: string };
  instant_reference?: string;
  sources?: unknown;
};

const NATURES: Record<string, string> = {
  mesure: "Mesure",
  calcul: "Calcul",
  estimation: "Estimation",
  comptage: "Comptage",
  evaluation: "Évaluation par règles",
};

export function CarteKpi({ i, params }: { i: Indicateur; params: Record<string, string> }) {
  const [ouvert, setOuvert] = useState(false);
  const classe = i.nature === "estimation" ? " estimation" : i.statut === "indisponible" ? " indisponible" : "";
  return (
    <>
      <button className={`kpi${classe}`} onClick={() => setOuvert(true)} aria-haspopup="dialog" title="Ouvrir la méthode de calcul et les données sources">
        <div className="libelle">{i.libelle}</div>
        <div className="valeur">
          {i.valeur === null || i.valeur === undefined ? <span title="indéterminé (≠ 0)">—</span> : nombre(i.valeur, 2)}
          <span className="unite">{i.unite}</span>
        </div>
        <div className="pied">
          <span>{NATURES[i.nature ?? ""] ?? i.nature ?? ""}</span>
          <Statut s={i.statut} />
        </div>
        {i.avertissements && i.avertissements.length > 0 && i.statut === "indisponible" && (
          <div className="petit" style={{ marginTop: 4 }}>{i.avertissements[0]}</div>
        )}
      </button>
      {ouvert && <TiroirIndicateur code={i.code} params={params} fermer={() => setOuvert(false)} />}
    </>
  );
}

export function TiroirIndicateur({ code, params, fermer }: { code: string; params: Record<string, string>; fermer: () => void }) {
  const [d, setD] = useState<Indicateur | null>(null);
  const [e, setE] = useState<ErreurApi | null>(null);
  useEffect(() => {
    api<Indicateur>(`/api/indicateurs/${code}`, { params })
      .then(setD)
      .catch((x) => setE(x));
  }, [code, params]);
  useEffect(() => {
    const k = (ev: KeyboardEvent) => ev.key === "Escape" && fermer();
    window.addEventListener("keydown", k);
    return () => window.removeEventListener("keydown", k);
  }, [fermer]);
  return (
    <>
      <div className="tiroir-fond" onClick={fermer} />
      <div className="tiroir" role="dialog" aria-modal="true" aria-label="Détail de l'indicateur">
        <button className="fermer secondaire" onClick={fermer}>
          Fermer ✕
        </button>
        <Erreur e={e} />
        {!d && !e && <div>Chargement…</div>}
        {d && (
          <>
            <h2 style={{ marginTop: 0 }}>{d.libelle}</h2>
            <div style={{ fontSize: "1.8rem", fontWeight: 700 }}>
              {d.valeur === null ? "indéterminé" : nombre(d.valeur, 3)} <span className="petit">{d.unite}</span>
            </div>
            <dl className="def">
              <dt>Code</dt>
              <dd>
                <code>{d.code}</code>
              </dd>
              <dt>Nature</dt>
              <dd>{NATURES[d.nature ?? ""] ?? d.nature}</dd>
              <dt>Statut</dt>
              <dd>
                <Statut s={d.statut} />
              </dd>
              <dt>Méthode de calcul</dt>
              <dd>{d.methode}</dd>
              <dt>Période</dt>
              <dd>
                {date(d.periode?.debut)} → {date(d.periode?.fin)}
              </dd>
              <dt>Instant de référence</dt>
              <dd>{date(d.instant_reference)}</dd>
              <dt>Domaine</dt>
              <dd>{d.domaine}</dd>
            </dl>
            {d.avertissements && d.avertissements.length > 0 && (
              <div className="message avert">
                <b>Avertissements :</b>
                <ul style={{ margin: "4px 0 0 18px", padding: 0 }}>
                  {d.avertissements.map((a, k) => (
                    <li key={k}>{a}</li>
                  ))}
                </ul>
              </div>
            )}
            <h3>Données sources</h3>
            <SourcesLisibles sources={d.sources} />
            <Json valeur={d.sources} titre="Données sources complètes (JSON brut)" />
          </>
        )}
      </div>
    </>
  );
}

function TableObjets({ titre, lignes }: { titre: string; lignes: Record<string, unknown>[] }) {
  const cols = Array.from(new Set(lignes.flatMap((l) => Object.keys(l)))).slice(0, 8);
  return (
    <div style={{ marginBottom: 10 }}>
      <div style={{ fontWeight: 600 }}>
        {titre} ({lignes.length})
      </div>
      <div className="defilement">
        <table className="tab">
          <thead>
            <tr>
              {cols.map((c) => (
                <th key={c}>{c.replace(/_/g, " ")}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {lignes.slice(0, 30).map((l, i) => (
              <tr key={i}>
                {cols.map((c) => {
                  const x = l[c];
                  return <td key={c}>{x !== null && typeof x === "object" ? JSON.stringify(x).slice(0, 120) : String(x ?? "—")}</td>;
                })}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      {lignes.length > 30 && <div className="petit">… {lignes.length - 30} lignes supplémentaires dans le JSON brut.</div>}
    </div>
  );
}

function SourcesLisibles({ sources, profondeur = 0, titre }: { sources: unknown; profondeur?: number; titre?: string }) {
  if (!sources || typeof sources !== "object") return profondeur ? null : <div className="petit">Aucune source détaillée.</div>;
  const entrees = Object.entries(sources as Record<string, unknown>);
  const scalaires = entrees.filter(([, v]) => v === null || typeof v !== "object");
  const tableaux = entrees.filter(([, v]) => Array.isArray(v) && v.length > 0 && typeof v[0] === "object" && v[0] !== null);
  const listes = entrees.filter(([, v]) => Array.isArray(v) && v.length > 0 && typeof v[0] !== "object");
  const objets = entrees.filter(([, v]) => v !== null && typeof v === "object" && !Array.isArray(v));
  return (
    <div style={profondeur ? { borderLeft: "3px solid #d9dfeb", paddingLeft: 10, marginBottom: 10 } : undefined}>
      {titre && <div style={{ fontWeight: 700, marginBottom: 4 }}>{titre.replace(/_/g, " ")}</div>}
      {scalaires.length > 0 && (
        <dl className="def">
          {scalaires.map(([k, v]) => (
            <div key={k} style={{ display: "contents" }}>
              <dt>{k.replace(/_/g, " ")}</dt>
              <dd>{typeof v === "number" ? nombre(v, 3) : String(v ?? "—")}</dd>
            </div>
          ))}
        </dl>
      )}
      {listes.map(([k, v]) => (
        <div key={k} className="petit">
          <b>{k.replace(/_/g, " ")} :</b> {(v as unknown[]).join(" ; ")}
        </div>
      ))}
      {tableaux.map(([k, v]) => (
        <TableObjets key={k} titre={k.replace(/_/g, " ")} lignes={v as Record<string, unknown>[]} />
      ))}
      {profondeur < 2 && objets.map(([k, v]) => <SourcesLisibles key={k} sources={v} profondeur={profondeur + 1} titre={k} />)}
    </div>
  );
}
