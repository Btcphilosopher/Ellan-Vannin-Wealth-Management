"use client";
import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { useEffect, useRef, useState } from "react";
import { deconnecter, jeton, profil, Profil, WS_URL } from "@/lib/api";

const NAV: [string, string][] = [
  ["/", "Vue d'ensemble"],
  ["/actifs", "Actifs"],
  ["/production", "Production"],
  ["/maintenance", "Maintenance"],
  ["/approvisionnements", "Approvisionnements"],
  ["/logistique", "Logistique"],
  ["/contrats", "Contrats"],
  ["/distribution", "Distribution"],
  ["/mobilite", "Mobilité"],
  ["/environnement", "Environnement"],
  ["/finance", "Finance"],
  ["/administration", "Administration"],
];

type Evt = { id?: number; type: string; message: string; cree_le?: string };

function Evenements() {
  const [evts, setEvts] = useState<Evt[]>([]);
  const [etat, setEtat] = useState("connexion…");
  const [replie, setReplie] = useState(false);
  const ws = useRef<WebSocket | null>(null);
  useEffect(() => {
    const j = jeton();
    if (!j) return;
    let ferme = false;
    let essai: ReturnType<typeof setTimeout> | null = null;
    const ouvrir = () => {
      const s = new WebSocket(`${WS_URL}/ws/evenements`);
      ws.current = s;
      s.onopen = () => s.send(JSON.stringify({ jeton: j }));
      s.onmessage = (m) => {
        try {
          const e = JSON.parse(m.data) as Evt;
          if (e.type === "connexion") setEtat("en direct");
          else if (e.type === "erreur") setEtat("refusé");
          else setEvts((l) => [e, ...l].slice(0, 40));
        } catch {
          /* message non JSON ignoré */
        }
      };
      s.onclose = () => {
        setEtat("déconnecté");
        if (!ferme) essai = setTimeout(ouvrir, 5000);
      };
      s.onerror = () => setEtat("erreur de connexion");
    };
    ouvrir();
    return () => {
      ferme = true;
      if (essai) clearTimeout(essai);
      ws.current?.close();
    };
  }, []);
  return (
    <aside className={`evenements${replie ? " replie" : ""}`} aria-label="Événements en direct">
      <div className="en-tete">
        <span>
          Événements (WebSocket) — <b>{etat}</b>
        </span>
        <button onClick={() => setReplie(!replie)} aria-expanded={!replie}>
          {replie ? "Ouvrir" : "Réduire"}
        </button>
      </div>
      {!replie && (
        <ul>
          {evts.length === 0 && <li className="petit">Aucun événement reçu depuis l&apos;ouverture de la page.</li>}
          {evts.map((e, i) => (
            <li key={e.id ?? i}>
              <span className="badge b-neutre">{e.type}</span> {e.message}
            </li>
          ))}
        </ul>
      )}
    </aside>
  );
}

export default function Shell({ children }: { children: React.ReactNode }) {
  const chemin = usePathname();
  const routeur = useRouter();
  const [p, setP] = useState<Profil | null>(null);
  const [pret, setPret] = useState(false);
  const [ouvert, setOuvert] = useState(false);
  const estConnexion = chemin?.startsWith("/connexion");

  useEffect(() => {
    const pr = profil();
    setP(pr);
    setPret(true);
    if (!jeton() && !estConnexion) routeur.replace("/connexion");
    setOuvert(false);
  }, [chemin, estConnexion, routeur]);

  if (estConnexion) return <main className="contenu">{children}</main>;
  if (!pret || !p) return <main className="contenu">Chargement…</main>;

  return (
    <div className="cadre">
      <nav className={`nav${ouvert ? " ouvert" : ""}`} aria-label="Navigation principale">
        <div className="marque">
          <div className="titre">TOTALENERGIES — ÉNERGIES 360</div>
          <div className="sous">concept indépendant · sans affiliation</div>
          <div className="trait" />
        </div>
        <button className="menu-bouton secondaire" onClick={() => setOuvert(!ouvert)} aria-expanded={ouvert}>
          Menu
        </button>
        <div className="liens">
          {NAV.map(([href, lib]) => (
            <Link key={href} href={href} className={chemin === href ? "actif" : ""} aria-current={chemin === href ? "page" : undefined}>
              {lib}
            </Link>
          ))}
          <div className="utilisateur">
            <div>
              <b>{p.nom}</b>
            </div>
            <div>{p.habilitations.map((h) => `${h.role}${h.site ? " · " + h.site : h.entite ? " · " + h.entite : " · global"}`).join(", ")}</div>
            <button
              className="secondaire"
              onClick={() => {
                deconnecter();
                routeur.replace("/connexion");
              }}
            >
              Se déconnecter
            </button>
          </div>
        </div>
      </nav>
      <main className="contenu">{children}</main>
      <Evenements />
    </div>
  );
}
