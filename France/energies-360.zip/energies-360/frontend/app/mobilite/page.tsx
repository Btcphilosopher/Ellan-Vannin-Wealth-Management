"use client";
import { useState } from "react";
import { useApi, usePeriode } from "@/lib/api";
import { date, nombre } from "@/lib/format";
import { Bloc, EntetePage, Json, Statut, Tableau } from "@/components/ui";

const LIB_DISPO: Record<string, string> = {
  disponible: "disponible",
  indisponible: "indisponible",
  indeterminee: "indeterminee",
  a_confirmer: "a_confirmer",
  occupe: "occupe",
};

function DetailSession({ id }: { id: number }) {
  const s = useApi<any>(`/api/mobilite/sessions/${id}`);
  return (
    <Bloc etat={s}>
      {(d) => (
        <div className="carte-bloc" style={{ marginTop: 14 }}>
          <h3>Session — transaction {d.transaction_id}</h3>
          <div className="grille g3">
            <div>
              <h3>Énergie délivrée</h3>
              <dl className="def">
                <dt>Index début</dt>
                <dd>{nombre(d.index_debut_wh, 0)} Wh</dd>
                <dt>Index fin</dt>
                <dd>{nombre(d.index_fin_wh, 0)} Wh</dd>
                <dt>Énergie</dt>
                <dd>
                  <b>{nombre(d.energie_kwh, 3)} kWh</b>
                </dd>
                <dt>Puissance max</dt>
                <dd>{nombre(d.puissance_max_kw)} kW</dd>
                <dt>Durée</dt>
                <dd>
                  {date(d.debut)} → {date(d.fin)}
                </dd>
              </dl>
            </div>
            <div>
              <h3>Tarif appliqué</h3>
              <dl className="def">
                {Object.entries(d.detail_tarification ?? {}).map(([k, v]) => (
                  <div key={k} style={{ display: "contents" }}>
                    <dt>{k.replace(/_/g, " ")}</dt>
                    <dd>{String(v)}</dd>
                  </div>
                ))}
                <dt>Montant TTC</dt>
                <dd>
                  <b>
                    {nombre(d.montant_ttc, 2)} {d.devise}
                  </b>
                </dd>
              </dl>
            </div>
            <div>
              <h3>Paiement (simulé, distinct)</h3>
              <Tableau lignes={d.paiements} vide="Aucun paiement." colonnes={[{ cle: "reference", titre: "Réf." }, { cle: "statut", titre: "Statut", rendu: (p: any) => <Statut s={p.statut} /> }, { cle: "montant_ttc", titre: "TTC", num: true }, { cle: "prestataire", titre: "Prestataire" }]} />
              <p className="petit">Badge pseudonymisé : {d.badge_pseudonyme} (l&apos;identifiant du badge n&apos;est jamais stocké en clair).</p>
            </div>
          </div>
          <h3>Messages OCPP de la session</h3>
          <Tableau
            lignes={d.messages_ocpp}
            colonnes={[
              { cle: "recu_le", titre: "Reçu le" },
              { cle: "action", titre: "Action" },
              { cle: "traitement", titre: "Traitement" },
              { cle: "charge_utile", titre: "Charge utile", rendu: (m: any) => <code>{JSON.stringify(m.charge_utile).slice(0, 140)}</code> },
            ]}
          />
        </div>
      )}
    </Bloc>
  );
}

export default function Mobilite() {
  const per = usePeriode();
  const bornes = useApi<any>(per ? "/api/mobilite/bornes" : null, per ? { instant: per.fin } : undefined);
  const sessions = useApi<any[]>("/api/mobilite/sessions");
  const tarifs = useApi<any[]>("/api/mobilite/tarifs");
  const [sel, setSel] = useState<number | null>(null);
  return (
    <>
      <EntetePage titre="Mobilité — recharge électrique" sousTitre="Borne · connecteur · session · énergie délivrée · tarif · paiement · état de communication, suivis séparément (adaptateur OCPP 1.6J simulé, lecture seule)." />
      <div className="message info">Un connecteur joignable n&apos;est pas automatiquement disponible : la disponibilité est évaluée par règle (joignable, état déclaré récent, absence de défaut et d&apos;OT ouvert).</div>
      <Bloc etat={bornes}>
        {(d) => (
          <>
            {d.bornes.map((b: any) => (
              <div className="carte-bloc" key={b.id} style={{ marginBottom: 12 }}>
                <h3>
                  {b.code} — {b.nom} · {b.site} <span className="badge b-neutre">{b.attributs?.protocole}</span>
                </h3>
                <Tableau
                  lignes={b.connecteurs.map((c: any) => ({ id: c.connecteur, ...c }))}
                  colonnes={[
                    { cle: "connecteur", titre: "Connecteur" },
                    { cle: "type", titre: "Type" },
                    { cle: "puissance_max_kw", titre: "P max (kW)", num: true },
                    { cle: "joignable", titre: "Communication", rendu: (c: any) => <Statut s={c.joignable ? "conforme" : "indetermine"} libelle={c.joignable ? "joignable" : "non joignable"} /> },
                    { cle: "derniere_communication", titre: "Dernière communication" },
                    { cle: "statut_declare", titre: "État déclaré (borne)", rendu: (c: any) => c.statut_declare ?? "—" },
                    { cle: "code_erreur", titre: "Code erreur" },
                    { cle: "disponibilite_evaluee", titre: "Disponibilité évaluée", rendu: (c: any) => <Statut s={LIB_DISPO[c.disponibilite_evaluee] ?? c.disponibilite_evaluee} libelle={c.disponibilite_evaluee.replace("_", " ")} /> },
                    { cle: "raisons", titre: "Raisons", rendu: (c: any) => c.raisons.join(" ; ") || "—" },
                  ]}
                />
              </div>
            ))}
            <p className="petit">Règle : {d.bornes[0]?.connecteurs[0]?.regle}. Commandes non implémentées (lecture seule) : {d.commandes_non_implementees.join(", ")}.</p>
          </>
        )}
      </Bloc>
      <div className="grille g2">
        <div className="carte-bloc">
          <h3>Sessions de recharge</h3>
          <Bloc etat={sessions}>
            {(l) => (
              <Tableau
                lignes={l}
                vide="Aucune session."
                surClic={(s: any) => setSel(s.id)}
                selection={(s: any) => s.id === sel}
                colonnes={[
                  { cle: "transaction_id", titre: "Transaction" },
                  { cle: "connecteur", titre: "Connecteur" },
                  { cle: "debut", titre: "Début" },
                  { cle: "energie_kwh", titre: "Énergie (kWh)", num: true },
                  { cle: "montant_ttc", titre: "TTC (EUR)", num: true },
                  { cle: "statut", titre: "Statut", rendu: (s: any) => <Statut s={s.statut} /> },
                ]}
              />
            )}
          </Bloc>
        </div>
        <div className="carte-bloc">
          <h3>Tarifs datés</h3>
          <Bloc etat={tarifs}>{(l) => <><Tableau lignes={l} colonnes={[{ cle: "code", titre: "Code" }, { cle: "libelle", titre: "Libellé" }, { cle: "prix_kwh_ttc", titre: "EUR/kWh TTC", num: true }, { cle: "prix_minute_ttc", titre: "EUR/min TTC", num: true }, { cle: "frais_session_ttc", titre: "Frais/session", num: true }, { cle: "valide_de", titre: "Valide de" }]} /><Json valeur={l} titre="Tarifs (JSON)" /></>}</Bloc>
        </div>
      </div>
      {sel && <DetailSession key={sel} id={sel} />}
    </>
  );
}
