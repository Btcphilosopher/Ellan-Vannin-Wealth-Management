"use client";
import { useMemo, useState } from "react";
import { ErreurApi, post, useApi, usePeriode, useSites } from "@/lib/api";
import { date, nombre } from "@/lib/format";
import SchemaFlux, { Bilan } from "@/components/Flux";
import { GraphiqueBarres, GraphiqueLignes } from "@/components/Graphiques";
import { Alerte, AlerteT, Bloc, EntetePage, Erreur, Json, Onglets, Statut, Tableau, Valeur } from "@/components/ui";

function CreerOT({ a, surCree }: { a: AlerteT; surCree: () => void }) {
  const [msg, setMsg] = useState<string | null>(null);
  const [err, setErr] = useState<ErreurApi | null>(null);
  if (a.ordre_travail_id) return <div className="petit">Prise en charge par l&apos;ordre de travail #{a.ordre_travail_id}.</div>;
  if (!a.actif_id || !["panne_equipement", "capteur_perime", "valeur_figee", "compteur_reinitialise"].includes(a.type)) return null;
  return (
    <div style={{ marginTop: 6 }}>
      <button
        className="secondaire"
        onClick={async () => {
          setErr(null);
          try {
            const ot = await post("/api/maintenance/ordres", {
              actif_id: a.actif_id,
              alerte_id: a.id,
              titre: a.titre,
              description: a.message,
              priorite: a.gravite === "critique" ? "P1" : "P2",
            });
            setMsg(`Ordre ${ot.numero} créé (état : signalé).`);
            surCree();
          } catch (e) {
            setErr(e as ErreurApi);
          }
        }}
      >
        Créer un ordre de travail
      </button>
      {msg && <span className="petit"> {msg}</span>}
      <Erreur e={err} />
    </div>
  );
}

function Batterie({ actifId, per }: { actifId: number; per: Record<string, string> }) {
  const etat = useApi<any>(`/api/batterie/${actifId}/etat`, { instant: per.fin });
  const liste = useApi<any[]>("/api/batterie/scenarios");
  const [sc, setSc] = useState<any>(null);
  const [err, setErr] = useState<ErreurApi | null>(null);
  const [rend, setRend] = useState("0.95");
  const [soc, setSoc] = useState("50");
  async function lancer() {
    setErr(null);
    try {
      const r = await post("/api/batterie/scenarios", {
        actif_id: actifId,
        nom: `Scénario interface (η charge ${rend})`,
        debut: per.debut,
        fin: per.fin,
        soc_initial_pct: Number(soc),
        surcharges: { rendement_charge: Number(rend) },
      });
      setSc(r);
      liste.recharger();
    } catch (e) {
      setErr(e as ErreurApi);
    }
  }
  return (
    <>
      <div className="grille g2">
        <div className="carte-bloc">
          <h3>État observé (instant de référence {date(per.fin)})</h3>
          <Bloc etat={etat}>
            {(d) => (
              <dl className="def">
                <dt>État de charge</dt>
                <dd>
                  <Valeur v={d.soc?.valeur} unite="%" /> {d.soc?.perime && <span className="badge b-critique">PÉRIMÉ</span>}{" "}
                  <span className="petit">observé {date(d.soc?.observe_le)}</span>
                </dd>
                <dt>Puissance</dt>
                <dd>
                  <Valeur v={d.puissance?.valeur} unite="kW (+ décharge / − charge)" />
                </dd>
                <dt>Température</dt>
                <dd>
                  <Valeur v={d.temperature?.valeur} unite="°C" /> {d.limites?.temperature_depassee && <span className="badge b-critique">LIMITE DÉPASSÉE</span>}
                </dd>
                <dt>Énergie disponible</dt>
                <dd>
                  <Valeur v={d.energie_disponible_decharge_kwh?.valeur} unite="kWh" /> <span className="petit">{d.energie_disponible_decharge_kwh?.methode ?? d.energie_disponible_decharge_kwh?.message}</span>
                </dd>
                <dt>Capacité de charge restante</dt>
                <dd>
                  <Valeur v={d.capacite_de_charge_restante_kwh?.valeur} unite="kWh" />
                </dd>
                <dt>Limites</dt>
                <dd className="petit">
                  E nominale {nombre(d.parametres.energie_nominale_kwh)} kWh · P max {nombre(d.parametres.p_charge_max_kw)} / {nombre(d.parametres.p_decharge_max_kw)} kW · SoC [
                  {d.parametres.soc_min_pct} ; {d.parametres.soc_max_pct}] % · η {d.parametres.rendement_charge} / {d.parametres.rendement_decharge} · T max {d.parametres.temperature_max_c} °C ·{" "}
                  {d.parametres.provenance}
                </dd>
              </dl>
            )}
          </Bloc>
        </div>
        <div className="carte-bloc">
          <h3>Simulation de charge / décharge (scénario isolé)</h3>
          <div className="message avert">Les scénarios sont stockés à part des opérations observées. Revenu affiché = estimation sur indice simulé, non garantie.</div>
          <div className="ligne">
            <label>
              SoC initial (%)
              <input type="number" min={0} max={100} value={soc} onChange={(e) => setSoc(e.target.value)} />
            </label>
            <label>
              Rendement de charge
              <input type="number" step="0.01" min={0.5} max={1} value={rend} onChange={(e) => setRend(e.target.value)} />
            </label>
            <button onClick={lancer}>Simuler la période</button>
          </div>
          <Erreur e={err} />
          <Bloc etat={liste}>
            {(l) => (
              <Tableau
                lignes={l}
                vide="Aucun scénario."
                colonnes={[
                  { cle: "nom", titre: "Scénario" },
                  { cle: "cree_par", titre: "Par" },
                  { cle: "c", titre: "Énergie déchargée (kWh)", num: true, rendu: (x: any) => nombre(x.synthese?.energie_dechargee_kwh) },
                  { cle: "r", titre: "Revenu estimé (EUR)", num: true, rendu: (x: any) => nombre(x.synthese?.revenu_estime_eur, 2) },
                  { cle: "v", titre: "Contraintes respectées", rendu: (x: any) => <Statut s={x.verifications?.soc_dans_bornes && x.verifications?.bilan_conserve ? "conforme" : "echec"} libelle={x.verifications?.soc_dans_bornes && x.verifications?.bilan_conserve ? "oui" : "non"} /> },
                ]}
              />
            )}
          </Bloc>
        </div>
      </div>
      {sc && (
        <div className="carte-bloc" style={{ marginTop: 14 }}>
          <GraphiqueLignes
            titre={`${sc.nom} — état de charge simulé`}
            uniteY="SoC (%)"
            temps={sc.resultats.trajectoire.map((_: any, i: number) => new Date(new Date(per.debut).getTime() + i * 3600e3).toISOString())}
            series={[{ nom: "SoC simulé", couleur: "#f39200", valeurs: sc.resultats.trajectoire.map((t: any) => t.soc_pct), zone: true }]}
          />
          <GraphiqueLignes
            titre="Prix indicatif simulé utilisé"
            uniteY="EUR/MWh"
            hauteur={180}
            zeroInclus={false}
            temps={sc.resultats.trajectoire.map((_: any, i: number) => new Date(new Date(per.debut).getTime() + i * 3600e3).toISOString())}
            series={[{ nom: "IDX_ELEC_SPOT_SIM (simulé)", couleur: "#0b1b3f", valeurs: sc.resultats.trajectoire.map((t: any) => t.prix_eur_mwh) }]}
          />
          <dl className="def">
            <dt>Énergie chargée</dt>
            <dd>{nombre(sc.resultats.synthese.energie_chargee_kwh)} kWh</dd>
            <dt>Énergie déchargée</dt>
            <dd>{nombre(sc.resultats.synthese.energie_dechargee_kwh)} kWh</dd>
            <dt>Cycles équivalents</dt>
            <dd>{nombre(sc.resultats.synthese.cycles_equivalents, 2)}</dd>
            <dt>Revenu estimé</dt>
            <dd>
              {nombre(sc.resultats.synthese.revenu_estime_eur, 2)} EUR <span className="badge b-avertissement">ESTIMATION NON GARANTIE</span>
            </dd>
          </dl>
          <div className="petit">{sc.avertissement}</div>
          <Json valeur={sc.verifications} titre="Vérifications des contraintes physiques" ouvert />
        </div>
      )}
    </>
  );
}

function Analyses({ siteId, per }: { siteId: number; per: Record<string, string> }) {
  const anomalies = useApi<any>(`/api/ia/sites/${siteId}/anomalies`, per);
  const evalP = useApi<any>(`/api/ia/sites/${siteId}/evaluation-previsions`);
  const expl = useApi<any>(`/api/ia/sites/${siteId}/explication-ecart`, per);
  return (
    <>
      <div className="message info">
        Assistance analytique par règles transparentes et modèles simples. Chaque résultat est une suggestion à vérifier : l&apos;IA n&apos;autorise aucune intervention, ne pilote
        aucun procédé, n&apos;engage aucune dépense et n&apos;opère sur aucun marché.
      </div>
      <div className="grille g2">
        <div className="carte-bloc">
          <h3>Évaluation des modèles de prévision (période de test distincte)</h3>
          <Bloc etat={evalP}>
            {(d) => (
              <>
                <Tableau
                  lignes={Object.entries(d.resultats).map(([k, v]: [string, any]) => ({ id: k, modele: k, ...v }))}
                  colonnes={[
                    { cle: "modele", titre: "Modèle" },
                    { cle: "n", titre: "Heures", num: true },
                    { cle: "mae_kwh", titre: "MAE (kWh)", num: true },
                    { cle: "rmse_kwh", titre: "RMSE (kWh)", num: true },
                    { cle: "biais_kwh", titre: "Biais (kWh)", num: true },
                    { cle: "nmae_pct_pac", titre: "nMAE (% Pac)", num: true },
                  ]}
                />
                <p className="petit">
                  Apprentissage {date(d.periode_apprentissage[0], false)} → {date(d.periode_apprentissage[1], false)} ; test {date(d.periode_test[0], false)} →{" "}
                  {date(d.periode_test[1], false)}. Meilleur MAE : <b>{d.meilleur_mae}</b>. Références simples : {d.references_simples.join(", ")}.
                </p>
              </>
            )}
          </Bloc>
        </div>
        <div className="carte-bloc">
          <h3>Explication de l&apos;écart prévision – réalisation</h3>
          <Bloc etat={expl}>
            {(d) => (
              <>
                <GraphiqueBarres
                  titre="Décomposition de l'écart (estimations)"
                  unite="kWh"
                  barres={[
                    { libelle: "Écart total P50 − réalisé", valeur: d.ecart_kwh, couleur: "#0b1b3f" },
                    { libelle: "Indisponibilité", valeur: d.contributions.indisponibilite_estimee_kwh, couleur: "#e4002b" },
                    { libelle: "Limitation réseau", valeur: d.contributions.limitation_reseau_estimee_kwh, couleur: "#f39200" },
                    { libelle: "Écrêtement onduleur", valeur: d.contributions.ecretement_onduleur_estime_kwh, couleur: "#00a3a6" },
                    { libelle: "Résidu non expliqué", valeur: d.residu_non_explique_kwh, couleur: "#9aa8c4" },
                  ]}
                />
                <p className="petit">{d.lecture}</p>
              </>
            )}
          </Bloc>
        </div>
      </div>
      <div className="carte-bloc" style={{ marginTop: 14 }}>
        <h3>Détection d&apos;anomalies de performance</h3>
        <Bloc etat={anomalies}>
          {(d) =>
            d.applicable ? (
              <>
                <p className="petit">
                  {d.methode} — PR médian {nombre(d.pr_median, 3)} sur {d.heures_analysees} h.
                </p>
                <Tableau lignes={d.anomalies} vide="Aucune anomalie au-delà du seuil." colonnes={[{ cle: "t", titre: "Heure" }, { cle: "pr", titre: "PR", num: true }, { cle: "z_robuste", titre: "z robuste", num: true }]} />
              </>
            ) : (
              <div className="petit">Non applicable.</div>
            )
          }
        </Bloc>
      </div>
    </>
  );
}

export default function Production() {
  const per = usePeriode();
  const sites = useSites();
  const pv = sites.find((s) => s.code === "SITE-PV-GAR");
  const synth = useApi<any>(pv && per ? `/api/production/sites/${pv.id}/synthese` : null, per ?? undefined);
  const bilan = useApi<Bilan>(pv && per ? `/api/mesures/sites/${pv.id}/bilan` : null, per ?? undefined);
  const alertes = useApi<AlerteT[]>(pv ? "/api/mesures/alertes" : null, pv ? { site_id: pv.id } : undefined);
  const detail = useApi<any>(pv && per ? `/api/patrimoine/sites/${pv.id}` : null, per ? { instant: per.fin } : undefined);
  const bessId = useMemo(() => detail.donnees?.actifs?.find((a: any) => a.code === "BESS-GAR")?.id as number | undefined, [detail.donnees]);

  return (
    <>
      <EntetePage
        titre="Production et performance"
        sousTitre={pv ? `${pv.nom} — parcours solaire : production, qualité des données, maintenance, économie` : "Chargement du site…"}
      />
      {synth.erreur && <Erreur e={synth.erreur} />}
      {pv && per && (
        <Onglets onglets={["Production", "Bilan et flux", "Qualité et alertes", "Batterie", "Analyses (IA)"]}>
          {(o) => (
            <>
              {o === "Production" && (
                <Bloc etat={synth}>
                  {(d) => {
                    const lignes = d.prevision_vs_realise.lignes as any[];
                    const temps = lignes.map((l) => l.t);
                    const g = d.meteo.GPOA?.points ?? [];
                    return (
                      <>
                        <div className="grille g4">
                          <div className="carte-bloc">
                            <div className="petit">Production mesurée (compteur principal)</div>
                            <div style={{ fontSize: "1.4rem", fontWeight: 700 }}>
                              <Valeur v={d.production_mesuree?.valeur != null ? d.production_mesuree.valeur / 1000 : null} unite="MWh" decimales={2} />
                            </div>
                            <Statut s={d.production_mesuree?.statut} />
                          </div>
                          <div className="carte-bloc">
                            <div className="petit">Disponibilité technique</div>
                            <div style={{ fontSize: "1.4rem", fontWeight: 700 }}>
                              <Valeur v={d.disponibilite.valeur_pct} unite="%" decimales={2} />
                            </div>
                            <div className="petit">part indéterminée : {nombre(d.disponibilite.part_indeterminee_pct, 2)} %</div>
                          </div>
                          <div className="carte-bloc">
                            <div className="petit">Capacité installée / disponible (AC)</div>
                            <div style={{ fontSize: "1.2rem", fontWeight: 700 }}>
                              {nombre(d.capacites.installee_puissance_ac?.valeur)} / {nombre(d.capacites.disponible_puissance_ac?.valeur)} kW
                            </div>
                            <div className="petit">{d.capacites.disponible_puissance_ac?.motif}</div>
                          </div>
                          <div className="carte-bloc">
                            <div className="petit">Écart prévision (MAE horaire)</div>
                            <div style={{ fontSize: "1.4rem", fontWeight: 700 }}>
                              <Valeur v={d.prevision_vs_realise.indicateurs.mae_kwh} unite="kWh" />
                            </div>
                            <div className="petit">
                              biais {nombre(d.prevision_vs_realise.indicateurs.biais_kwh)} kWh · nMAE {nombre(d.prevision_vs_realise.indicateurs.nmae_pct_capacite, 2)} % ·{" "}
                              {d.prevision_vs_realise.indicateurs.heures_comparees} h comparées
                            </div>
                          </div>
                        </div>
                        <div className="carte-bloc" style={{ marginTop: 14 }}>
                          <GraphiqueLignes
                            titre="Production horaire mesurée vs prévision P50 (bande P10–P90)"
                            uniteY="énergie (kWh / h)"
                            temps={temps}
                            series={[
                              { nom: "Réalisé (compteur principal)", couleur: "#00a3a6", valeurs: lignes.map((l) => l.realise_kwh), zone: true },
                              { nom: "Prévision P50", couleur: "#0b1b3f", valeurs: lignes.map((l) => l.p50_kwh), pointille: true },
                            ]}
                            bandes={[{ nom: "Incertitude P10–P90", couleur: "#f39200", bas: lignes.map((l) => l.p10_kwh), haut: lignes.map((l) => l.p90_kwh) }]}
                          />
                          <p className="petit">
                            Prévisions :{" "}
                            {d.prevision_vs_realise.previsions.slice(0, 2).map((p: any) => `${p.modele} v${p.version}, émise ${date(p.emise_le)}, horizon ${p.horizon_h} h, ${p.incertitude}`).join(" ; ")}
                            {d.prevision_vs_realise.previsions.length > 2 ? ` … (${d.prevision_vs_realise.previsions.length} prévisions)` : ""}
                          </p>
                        </div>
                        <div className="grille g2" style={{ marginTop: 14 }}>
                          <div className="carte-bloc">
                            <GraphiqueLignes
                              titre="Éclairement dans le plan des modules (moyenne horaire)"
                              uniteY="W/m²"
                              temps={g.map((p: any) => p.t)}
                              series={[{ nom: "G_POA (pyranomètre)", couleur: "#f39200", valeurs: g.map((p: any) => p.v) }]}
                            />
                            <p className="petit">Le pyranomètre se fige puis cesse d&apos;émettre le 21/06 : la courbe s&apos;interrompt (capteur périmé), elle ne tombe pas à zéro.</p>
                          </div>
                          <div className="carte-bloc">
                            <h3>Pertes estimées (modèle, distinctes des mesures)</h3>
                            <GraphiqueBarres
                              titre="Énergie non produite estimée"
                              unite="kWh"
                              barres={[
                                { libelle: "Indisponibilité (panne)", valeur: d.pertes_estimees.indisponibilite_kwh, couleur: "#e4002b" },
                                { libelle: "Limitation réseau enregistrée", valeur: d.pertes_estimees.limitation_reseau_kwh, couleur: "#f39200" },
                                { libelle: "Écrêtement onduleur", valeur: d.pertes_estimees.ecretement_onduleur_kwh, couleur: "#00a3a6" },
                              ]}
                            />
                            <p className="petit">
                              {d.pertes_estimees.methode} {d.pertes_estimees.avertissement} Pas non estimés faute d&apos;éclairement : {d.pertes_estimees.pas_sans_eclairement}.
                            </p>
                          </div>
                        </div>
                        <div className="grille g2" style={{ marginTop: 14 }}>
                          <div className="carte-bloc">
                            <h3>Disponibilité par onduleur</h3>
                            <Tableau
                              lignes={d.disponibilite.onduleurs}
                              colonnes={[
                                { cle: "onduleur", titre: "Onduleur" },
                                { cle: "puissance_ac_kw", titre: "P AC (kW)", num: true },
                                { cle: "heures_disponibles", titre: "Disponible (h)", num: true },
                                { cle: "heures_indisponibles", titre: "Indisponible (h)", num: true },
                                { cle: "heures_indeterminees", titre: "Indéterminé (h)", num: true },
                              ]}
                            />
                            <p className="petit">{d.disponibilite.methode}</p>
                          </div>
                          <div className="carte-bloc">
                            <h3>Réductions de production enregistrées</h3>
                            <Tableau
                              lignes={d.pertes_estimees.reductions_enregistrees}
                              vide="Aucune réduction enregistrée."
                              colonnes={[
                                { cle: "type", titre: "Type" },
                                { cle: "debut", titre: "Début" },
                                { cle: "fin", titre: "Fin" },
                                { cle: "puissance_limite_kw", titre: "Limite (kW)", num: true },
                                { cle: "source", titre: "Source" },
                                { cle: "reference_externe", titre: "Référence" },
                              ]}
                            />
                            <h3>Incidents</h3>
                            <Tableau lignes={d.incidents} vide="Aucun incident déclaré." colonnes={[{ cle: "titre", titre: "Titre" }, { cle: "gravite", titre: "Gravité" }, { cle: "debut", titre: "Début" }, { cle: "statut", titre: "Statut" }]} />
                          </div>
                        </div>
                      </>
                    );
                  }}
                </Bloc>
              )}
              {o === "Bilan et flux" && (
                <Bloc etat={bilan}>
                  {(b: any) => (
                    <>
                      <div className="carte-bloc">
                        <h3>Schéma des flux d&apos;énergie — {date(per.debut, false)} au {date(per.fin, false)}</h3>
                        <SchemaFlux bilan={b} />
                      </div>
                      <div className="grille g2" style={{ marginTop: 14 }}>
                        <div className="carte-bloc">
                          <h3>Termes du bilan (compteurs principaux uniquement)</h3>
                          <Tableau
                            lignes={Object.entries(b.termes).map(([k, t]: [string, any]) => ({ id: k, perimetre: k, ...t }))}
                            colonnes={[
                              { cle: "perimetre", titre: "Périmètre" },
                              { cle: "point", titre: "Compteur" },
                              { cle: "valeur", titre: "Énergie (kWh)", num: true },
                              { cle: "statut", titre: "Statut", rendu: (t: any) => <Statut s={t.statut} /> },
                              { cle: "avertissements", titre: "Avertissements", rendu: (t: any) => t.avertissements.join(" ") || "—" },
                            ]}
                          />
                        </div>
                        <div className="carte-bloc">
                          <h3>Recoupement par compteurs de contrôle (jamais additionnés)</h3>
                          <Tableau
                            lignes={b.controle.compteurs}
                            colonnes={[
                              { cle: "point", titre: "Compteur" },
                              { cle: "valeur_kwh", titre: "Énergie (kWh)", num: true },
                              { cle: "statut", titre: "Statut", rendu: (t: any) => <Statut s={t.statut} /> },
                              { cle: "r", titre: "Remises à zéro", rendu: (t: any) => (t.remises_a_zero.length ? `${t.remises_a_zero.length} détectée(s)` : "—") },
                            ]}
                          />
                          <p className="petit">
                            Somme de contrôle : {nombre(b.controle.somme_controle_production_kwh)} kWh · écart vs principal {nombre(b.controle.ecart_controle_vs_principal_pct, 3)} %. {b.controle.note}
                          </p>
                        </div>
                      </div>
                    </>
                  )}
                </Bloc>
              )}
              {o === "Qualité et alertes" && (
                <Bloc etat={alertes}>
                  {(l) => (
                    <>
                      <p className="petit">{l.length} alerte(s) sur le site. Les mesures brutes sont conservées ; les corrections et estimations sont stockées à part.</p>
                      {l.map((a) => (
                        <Alerte key={a.id} a={a} action={<CreerOT a={a} surCree={alertes.recharger} />} />
                      ))}
                    </>
                  )}
                </Bloc>
              )}
              {o === "Batterie" && (bessId ? <Batterie actifId={bessId} per={per} /> : <Bloc etat={detail}>{() => <div className="petit">Batterie introuvable.</div>}</Bloc>)}
              {o === "Analyses (IA)" && <Analyses siteId={pv.id} per={per} />}
            </>
          )}
        </Onglets>
      )}
    </>
  );
}
