"use client";
import Link from "next/link";
import { useApi, usePeriode } from "@/lib/api";
import { date } from "@/lib/format";
import { CarteKpi, Indicateur } from "@/components/Kpi";
import Carte from "@/components/Carte";
import { Alerte, AlerteT, Bloc, EntetePage } from "@/components/ui";

const ESPACES: { domaine: string; titre: string; lien: string; unites: string }[] = [
  { domaine: "renouvelable", titre: "Production d'électricité renouvelable", lien: "/production", unites: "kW, kWh, MWh, W/m², %" },
  { domaine: "stockage", titre: "Stockage par batteries", lien: "/production", unites: "kW, kWh, % SoC, °C" },
  { domaine: "approvisionnement", titre: "Approvisionnement et distribution d'énergie", lien: "/approvisionnements", unites: "L (observé / 15 °C), MWh, EUR" },
  { domaine: "terminal", titre: "Terminaux et stockage de produits", lien: "/logistique", unites: "fûts, bidons, bouteilles, IBC" },
  { domaine: "distribution", titre: "Réseau de stations-service", lien: "/distribution", unites: "L observés, L15, EUR/L TTC" },
  { domaine: "mobilite", titre: "Recharge de véhicules électriques", lien: "/mobilite", unites: "kWh délivrés, sessions, EUR TTC" },
  { domaine: "industrie", titre: "Sites industriels et transformation", lien: "/actifs", unites: "t (bilan matière)" },
  { domaine: "amont", titre: "Suivi administratif pétrole et gaz", lien: "/contrats", unites: "obligations, échéances, Sm³ (déclaratif)" },
];

export default function VueEnsemble() {
  const per = usePeriode();
  const ind = useApi<{ indicateurs: Indicateur[]; periode: { debut: string; fin: string } }>(per ? "/api/indicateurs" : null, per ?? undefined);
  const carte = useApi("/api/patrimoine/carte");
  const alertes = useApi<AlerteT[]>("/api/mesures/alertes", { statut: "ouverte" });
  return (
    <>
      <EntetePage
        titre="Vue d'ensemble"
        sousTitre={per ? `Période de démonstration : ${date(per.debut)} → ${date(per.fin)} · cliquer sur un indicateur pour sa méthode et ses données sources` : ""}
      />
      <Bloc etat={ind}>
        {(d) => (
          <div className="grille g4">
            {d.indicateurs.map((i) => (
              <CarteKpi key={i.code} i={i} params={per!} />
            ))}
          </div>
        )}
      </Bloc>
      <div className="grille g2" style={{ marginTop: 16 }}>
        <div className="carte-bloc">
          <h3>Carte du portefeuille fictif</h3>
          <Bloc etat={carte}>{(d: any) => <Carte sites={d.features} />}</Bloc>
        </div>
        <div className="carte-bloc">
          <h3>Espaces métiers</h3>
          <p className="petit">Données communes partagées (référentiel, mesures, tiers, produits) ; unités, contraintes et responsabilités propres à chaque domaine.</p>
          <table className="tab">
            <thead>
              <tr>
                <th>Espace</th>
                <th>Unités de référence</th>
              </tr>
            </thead>
            <tbody>
              {ESPACES.map((e) => (
                <tr key={e.domaine}>
                  <td>
                    <Link href={e.lien}>{e.titre}</Link>
                  </td>
                  <td className="petit">{e.unites}</td>
                </tr>
              ))}
            </tbody>
          </table>
          <div className="message info" style={{ marginTop: 10 }}>
            Parcours prioritaire : <Link href="/production">production solaire</Link> → <Link href="/maintenance">maintenance</Link> →{" "}
            <Link href="/finance">analyse économique</Link> → <Link href="/administration">rapport traçable</Link>.
          </div>
        </div>
      </div>
      <h2>Alertes ouvertes</h2>
      <Bloc etat={alertes}>
        {(l) => (
          <>
            {l.length === 0 && <div className="petit">Aucune alerte ouverte (ou analyse de qualité non lancée).</div>}
            {l.slice(0, 12).map((a) => (
              <Alerte key={a.id} a={a} />
            ))}
            {l.length > 12 && <Link href="/production">… {l.length - 12} autres alertes</Link>}
          </>
        )}
      </Bloc>
    </>
  );
}
