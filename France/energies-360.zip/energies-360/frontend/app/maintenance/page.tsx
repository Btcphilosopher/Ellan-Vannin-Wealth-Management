"use client";
import { useState } from "react";
import { ErreurApi, post, useApi } from "@/lib/api";
import { date, LIBELLES_ETAT, nombre } from "@/lib/format";
import { Bloc, EntetePage, Erreur, Statut, Tableau } from "@/components/ui";

const ORDRE = ["signale", "evalue", "planifie", "en_intervention", "controle", "cloture"];
const SUIVANT: Record<string, string> = { signale: "evalue", evalue: "planifie", planifie: "en_intervention", en_intervention: "controle", controle: "cloture" };

function Actions({ ot, recharger }: { ot: any; recharger: () => void }) {
  const [err, setErr] = useState<ErreurApi | null>(null);
  const [ok, setOk] = useState<string | null>(null);
  const [champ, setChamp] = useState<Record<string, string>>({
    evaluation: "",
    date_planifiee: "2026-06-23T07:00",
    reference_permis_travail: "",
    heures_main_oeuvre: "4",
    taux_horaire: "95",
    reference_procedure_externe: "",
  });
  const maj = (k: string) => (e: React.ChangeEvent<HTMLInputElement>) => setChamp({ ...champ, [k]: e.target.value });
  async function faire(chemin: string, corps: unknown, msg: string) {
    setErr(null);
    setOk(null);
    try {
      await post(`/api/maintenance/ordres/${ot.id}${chemin}`, corps);
      setOk(msg);
      recharger();
    } catch (e) {
      setErr(e as ErreurApi);
    }
  }
  const vers = SUIVANT[ot.etat];
  return (
    <div className="carte-bloc" style={{ marginTop: 10 }}>
      <h3>Actions (soumises aux permissions et aux règles du parcours)</h3>
      {vers && (
        <div className="ligne">
          {vers === "evalue" && <label style={{ flex: 1 }}>Évaluation<input value={champ.evaluation} onChange={maj("evaluation")} /></label>}
          {vers === "planifie" && <label>Date planifiée (UTC)<input type="datetime-local" value={champ.date_planifiee} onChange={maj("date_planifiee")} /></label>}
          {vers === "en_intervention" && (
            <label style={{ flex: 1 }}>
              Référence du permis de travail (procédure externe)
              <input value={champ.reference_permis_travail} onChange={maj("reference_permis_travail")} placeholder="ex. PT-GAR-2026-0500" />
            </label>
          )}
          {vers === "controle" && (
            <>
              <label>Heures de main-d&apos;œuvre<input type="number" value={champ.heures_main_oeuvre} onChange={maj("heures_main_oeuvre")} /></label>
              <label>Taux horaire (EUR/h)<input type="number" value={champ.taux_horaire} onChange={maj("taux_horaire")} /></label>
            </>
          )}
          <button
            onClick={() =>
              faire(
                "/transition",
                {
                  vers,
                  evaluation: champ.evaluation || undefined,
                  date_planifiee: vers === "planifie" ? `${champ.date_planifiee}:00+00:00` : undefined,
                  reference_permis_travail: champ.reference_permis_travail || undefined,
                  heures_main_oeuvre: vers === "controle" ? Number(champ.heures_main_oeuvre) : undefined,
                  taux_horaire: vers === "controle" ? Number(champ.taux_horaire) : undefined,
                },
                `Passage à « ${LIBELLES_ETAT[vers]} » enregistré.`,
              )
            }
          >
            Passer à : {LIBELLES_ETAT[vers]}
          </button>
        </div>
      )}
      {ot.etat === "controle" && (
        <button
          className="secondaire"
          onClick={() =>
            faire(
              "/controle",
              {
                points: [
                  { libelle: "Serrage des connexions", resultat: "conforme" },
                  { libelle: "Essai de fonctionnement", resultat: "conforme" },
                  { libelle: "Absence de code défaut", resultat: "conforme" },
                ],
              },
              "Contrôle de fin d'intervention enregistré.",
            )
          }
        >
          Saisir un contrôle conforme (3 points)
        </button>
      )}
      {ot.etat === "cloture" && (
        <div className="ligne">
          {!ot.trois_actes_distincts.cloture_administrative && (
            <button className="secondaire" onClick={() => faire("/cloture-administrative", {}, "Clôture administrative enregistrée.")}>
              Clôture administrative
            </button>
          )}
          {!ot.trois_actes_distincts.retour_disponibilite && (
            <button className="secondaire" onClick={() => faire("/retour-disponibilite", { commentaire: "Remise à disposition (interface)" }, "Retour en disponibilité enregistré.")}>
              Retour en disponibilité
            </button>
          )}
          {!ot.trois_actes_distincts.autorisation_operationnelle && (
            <>
              <label>
                Réf. procédure externe
                <input value={champ.reference_procedure_externe} onChange={maj("reference_procedure_externe")} placeholder="ex. DECONS-0500" />
              </label>
              <button
                className="secondaire"
                onClick={() =>
                  faire(
                    "/autorisation-operationnelle",
                    { reference_procedure_externe: champ.reference_procedure_externe, declaration: "Autorisation donnée selon procédure du site" },
                    "Autorisation opérationnelle enregistrée.",
                  )
                }
              >
                Enregistrer l&apos;autorisation opérationnelle
              </button>
            </>
          )}
        </div>
      )}
      {ok && <div className="message ok">{ok}</div>}
      <Erreur e={err} />
    </div>
  );
}

function Detail({ id }: { id: number }) {
  const d = useApi<any>(`/api/maintenance/ordres/${id}`);
  return (
    <Bloc etat={d}>
      {(ot) => {
        const idx = ORDRE.indexOf(ot.etat);
        return (
          <div className="carte-bloc" style={{ marginTop: 14 }}>
            <h2 style={{ marginTop: 0 }}>
              {ot.numero} — {ot.titre}
            </h2>
            <div className="etapes" aria-label="Parcours de l'ordre de travail">
              {ORDRE.map((e, i) => (
                <span key={e} className={i < idx ? "fait" : i === idx ? "courant" : ""}>
                  {i + 1}. {LIBELLES_ETAT[e]}
                </span>
              ))}
            </div>
            <div className="message avert">{ot.avertissement}</div>
            <div className="grille g2">
              <div>
                <dl className="def">
                  <dt>Priorité / type</dt>
                  <dd>
                    {ot.priorite} · {ot.type}
                  </dd>
                  <dt>Description</dt>
                  <dd>{ot.description}</dd>
                  <dt>Évaluation</dt>
                  <dd>{ot.evaluation ?? "—"}</dd>
                  <dt>Planification</dt>
                  <dd>{date(ot.date_planifiee)}</dd>
                  <dt>Intervention</dt>
                  <dd>
                    {date(ot.debut_intervention)} → {date(ot.fin_intervention)}
                  </dd>
                  <dt>Permis de travail</dt>
                  <dd>{ot.reference_permis_travail ?? "—"} (référence d&apos;une procédure externe)</dd>
                  <dt>Consignation</dt>
                  <dd>{ot.reference_consignation ?? "—"}</dd>
                </dl>
              </div>
              <div>
                <h3>Coûts ({ot.cout_detail.devise})</h3>
                <dl className="def">
                  <dt>Main-d&apos;œuvre</dt>
                  <dd>{nombre(ot.cout_detail.main_oeuvre, 2)}</dd>
                  <dt>Pièces</dt>
                  <dd>{nombre(ot.cout_detail.pieces, 2)}</dd>
                  <dt>Prestations externes</dt>
                  <dd>{nombre(ot.cout_detail.externe, 2)}</dd>
                  <dt>Total</dt>
                  <dd>
                    <b>{nombre(ot.cout_total, 2)} EUR</b>
                  </dd>
                </dl>
                <h3>Trois actes distincts</h3>
                <Tableau
                  lignes={[
                    { id: 1, acte: "Clôture administrative", fait: ot.trois_actes_distincts.cloture_administrative, par: ot.cloture_administrative_par },
                    { id: 2, acte: "Retour en disponibilité", fait: ot.trois_actes_distincts.retour_disponibilite, par: ot.retour_disponibilite[0]?.decide_par },
                    {
                      id: 3,
                      acte: "Autorisation opérationnelle",
                      fait: ot.trois_actes_distincts.autorisation_operationnelle,
                      par: ot.autorisations_operationnelles[0] ? `${ot.autorisations_operationnelles[0].accordee_par} (réf. ${ot.autorisations_operationnelles[0].reference_procedure_externe})` : null,
                    },
                  ]}
                  colonnes={[
                    { cle: "acte", titre: "Acte" },
                    { cle: "fait", titre: "État", rendu: (l: any) => <Statut s={l.fait ? "conforme" : "brouillon"} libelle={l.fait ? "enregistré" : "non réalisé"} /> },
                    { cle: "par", titre: "Par" },
                  ]}
                />
              </div>
            </div>
            <h3>Transitions</h3>
            <Tableau lignes={ot.transitions} colonnes={[{ cle: "de", titre: "De" }, { cle: "vers", titre: "Vers" }, { cle: "par", titre: "Par" }, { cle: "le", titre: "Le" }, { cle: "commentaire", titre: "Commentaire" }]} />
            <h3>Pièces consommées</h3>
            <Tableau lignes={ot.pieces} vide="Aucune pièce." colonnes={[{ cle: "piece_id", titre: "Pièce #" }, { cle: "quantite", titre: "Quantité", num: true }, { cle: "cout_unitaire", titre: "Coût unitaire (EUR)", num: true }]} />
            <h3>Contrôles de fin d&apos;intervention</h3>
            {ot.controles.length === 0 && <div className="petit">Aucun contrôle saisi.</div>}
            {ot.controles.map((c: any) => (
              <div key={c.id}>
                <Statut s={c.conforme ? "conforme" : "echec"} /> par {c.realise_par} le {date(c.le)} : {c.points_controle.map((p: any) => `${p.libelle} (${p.resultat})`).join(" · ")}
              </div>
            ))}
            <Actions ot={ot} recharger={d.recharger} />
          </div>
        );
      }}
    </Bloc>
  );
}

export default function Maintenance() {
  const ots = useApi<any[]>("/api/maintenance/ordres");
  const pieces = useApi<any[]>("/api/maintenance/pieces");
  const [sel, setSel] = useState<number | null>(null);
  const [cle, setCle] = useState(0);
  return (
    <>
      <EntetePage titre="Maintenance et interventions" sousTitre="Signalement → évaluation → planification → intervention → contrôle → clôture. Les ordres se créent depuis les alertes (Production › Qualité et alertes)." />
      <div className="carte-bloc">
        <h3>Ordres de travail</h3>
        <Bloc etat={ots}>
          {(l) => (
            <Tableau
              lignes={l}
              vide="Aucun ordre de travail. Créez-en un depuis une alerte de panne."
              surClic={(o: any) => {
                setSel(o.id);
                setCle((k) => k + 1);
              }}
              selection={(o: any) => o.id === sel}
              colonnes={[
                { cle: "numero", titre: "N°" },
                { cle: "titre", titre: "Titre" },
                { cle: "site", titre: "Site" },
                { cle: "actif", titre: "Actif" },
                { cle: "priorite", titre: "Priorité" },
                { cle: "etat", titre: "État", rendu: (o: any) => <Statut s={o.etat} /> },
                { cle: "cout_total", titre: "Coût (EUR)", num: true },
                { cle: "cree_le", titre: "Créé le" },
              ]}
            />
          )}
        </Bloc>
      </div>
      {sel && <Detail key={`${sel}-${cle}`} id={sel} />}
      <div className="carte-bloc" style={{ marginTop: 14 }}>
        <h3>Pièces de rechange</h3>
        <Bloc etat={pieces}>
          {(l) => <Tableau lignes={l} colonnes={[{ cle: "code", titre: "Code" }, { cle: "libelle", titre: "Libellé" }, { cle: "quantite_stock", titre: "Stock", num: true }, { cle: "unite", titre: "Unité" }, { cle: "cout_unitaire", titre: "Coût unitaire (EUR)", num: true }]} />}
        </Bloc>
      </div>
    </>
  );
}
