"use client";
import { useState } from "react";
import { ErreurApi, post, useApi, usePeriode, useSites } from "@/lib/api";
import { nombre } from "@/lib/format";
import { GraphiqueBarres } from "@/components/Graphiques";
import { Bloc, EntetePage, Erreur, Json, Tableau } from "@/components/ui";

function Investissement({ siteId }: { siteId?: number }) {
  const liste = useApi<any[]>("/api/finance/investissements");
  const [taux, setTaux] = useState("7");
  const [capex, setCapex] = useState("420000");
  const [gain, setGain] = useState("61000");
  const [annees, setAnnees] = useState("10");
  const [convention, setConvention] = useState("dates_reelles_act365");
  const [res, setRes] = useState<any>(null);
  const [err, setErr] = useState<ErreurApi | null>(null);
  async function calculer() {
    setErr(null);
    const n = Number(annees);
    const flux = [{ date: "2026-09-01", montant: -Number(capex), libelle: "Investissement initial" }];
    for (let k = 0; k < n; k++) flux.push({ date: `${2027 + k}-09-01`, montant: Number(gain), libelle: `Flux net année ${k + 1}` });
    try {
      const r = await post("/api/finance/investissements", {
        nom: `Scénario interface (${capex} EUR, ${taux} %)`,
        site_id: siteId,
        taux_actualisation_pct: Number(taux),
        convention,
        base: "nominal",
        date_reference: "2026-09-01T00:00:00+00:00",
        flux,
        hypotheses: [{ nom: "flux annuels constants", source: "saisie utilisateur (synthétique)" }],
      });
      setRes(r);
      liste.recharger();
    } catch (e) {
      setErr(e as ErreurApi);
    }
  }
  return (
    <div className="carte-bloc">
      <h3>Scénario d&apos;investissement — VAN / TRI explicites</h3>
      <div className="ligne">
        <label>Investissement (EUR)<input type="number" value={capex} onChange={(e) => setCapex(e.target.value)} /></label>
        <label>Flux annuel (EUR)<input type="number" value={gain} onChange={(e) => setGain(e.target.value)} /></label>
        <label>Durée (ans)<input type="number" min={1} max={30} value={annees} onChange={(e) => setAnnees(e.target.value)} /></label>
        <label>Taux d&apos;actualisation (%)<input type="number" step="0.1" value={taux} onChange={(e) => setTaux(e.target.value)} /></label>
        <label>
          Convention
          <select value={convention} onChange={(e) => setConvention(e.target.value)}>
            <option value="dates_reelles_act365">Dates réelles, base 365</option>
            <option value="fin_de_periode_annuelle">Fin de période annuelle</option>
          </select>
        </label>
        <button onClick={calculer}>Calculer</button>
      </div>
      <Erreur e={err} />
      {res && (
        <>
          <dl className="def">
            <dt>VAN</dt>
            <dd>
              <b>{nombre(res.resultats.van, 2)} {res.resultats.devise}</b>
            </dd>
            <dt>TRI</dt>
            <dd>
              {res.resultats.tri_pct === null ? "indéfini" : `${nombre(res.resultats.tri_pct, 3)} %`} — {res.resultats.note_tri}
            </dd>
            <dt>Formule</dt>
            <dd>
              <code>{res.resultats.conventions.formule}</code>
            </dd>
            <dt>Conventions</dt>
            <dd>
              taux {res.resultats.conventions.taux_actualisation_pct} % · {res.resultats.conventions.convention} · {res.resultats.conventions.base} · date de référence{" "}
              {res.resultats.conventions.date_reference}
            </dd>
            <dt>Limites</dt>
            <dd>{res.resultats.limites}</dd>
          </dl>
          <div className="message avert">{res.resultats.avertissement}</div>
          <Tableau
            lignes={res.resultats.flux_actualises.map((f: any, i: number) => ({ id: i, ...f }))}
            colonnes={[
              { cle: "date", titre: "Date" },
              { cle: "montant", titre: "Flux (EUR)", num: true },
              { cle: "facteur_actualisation", titre: "Facteur", num: true },
              { cle: "valeur_actualisee", titre: "Valeur actualisée (EUR)", num: true },
            ]}
          />
        </>
      )}
      <h3>Scénarios enregistrés</h3>
      <Bloc etat={liste}>
        {(l) => (
          <Tableau
            lignes={l}
            vide="Aucun scénario."
            colonnes={[
              { cle: "nom", titre: "Nom" },
              { cle: "taux_actualisation_pct", titre: "Taux (%)", num: true },
              { cle: "van", titre: "VAN (EUR)", num: true, rendu: (s: any) => nombre(s.resultats?.van, 2) },
              { cle: "tri", titre: "TRI (%)", num: true, rendu: (s: any) => nombre(s.resultats?.tri_pct, 3) },
              { cle: "cree_par", titre: "Par" },
            ]}
          />
        )}
      </Bloc>
    </div>
  );
}

export default function Finance() {
  const per = usePeriode();
  const sites = useSites();
  const pv = sites.find((s) => s.code === "SITE-PV-GAR");
  const til = sites.find((s) => s.code === "SITE-STA-TIL");
  const synth = useApi<any>("/api/finance/synthese", { annee: 2026 });
  const cu = useApi<any>(pv && per ? `/api/finance/sites/${pv.id}/cout-unitaire` : null, per ? { debut: per.debut, fin: per.fin } : undefined);
  const rev = useApi<any>(pv && per ? `/api/finance/sites/${pv.id}/revenus` : null, per ? { debut: per.debut, fin: per.fin } : undefined);
  const marge = useApi<any>(til && per ? `/api/finance/stations/${til.id}/marge` : null, per ? { debut: per.debut, fin: per.fin } : undefined);
  const treso = useApi<any>(per ? "/api/finance/tresorerie" : null, per ? { debut: per.debut } : undefined);
  return (
    <>
      <EntetePage titre="Finance et analyses" sousTitre="Revenus estimés, facturation, encaissements et résultat sont distincts. Aucune rentabilité globale n'est déduite d'un indicateur opérationnel isolé." />
      {synth.erreur && <Erreur e={synth.erreur} />}
      <div className="grille g2">
        <div className="carte-bloc">
          <h3>Revenus du site solaire — quatre notions séparées</h3>
          <Bloc etat={rev}>
            {(r) => (
              <>
                <GraphiqueBarres
                  titre="Électricité injectée — période de démonstration"
                  unite="EUR"
                  barres={[
                    { libelle: "Revenu estimé", valeur: r.revenu_estime.valeur, couleur: "#f39200" },
                    { libelle: "Facturé (HT)", valeur: r.facture.valeur, couleur: "#0b1b3f" },
                    { libelle: "Encaissé", valeur: r.encaisse.valeur, couleur: "#00a3a6" },
                    { libelle: "Résultat", valeur: r.resultat.valeur, couleur: "#9aa8c4" },
                  ]}
                />
                <p className="petit">
                  Estimé : {r.revenu_estime.methode} ({r.revenu_estime.nature}). {r.resultat.message}
                </p>
              </>
            )}
          </Bloc>
        </div>
        <div className="carte-bloc">
          <h3>Coût unitaire de maintenance</h3>
          <Bloc etat={cu}>
            {(c) => (
              <>
                <div style={{ fontSize: "1.6rem", fontWeight: 700 }}>
                  {c.valeur === null ? "indéterminé" : nombre(c.valeur, 3)} <span className="petit">{c.unite}</span>
                </div>
                <dl className="def">
                  <dt>Numérateur</dt>
                  <dd>
                    {nombre(c.numerateur.cout_maintenance_eur, 2)} EUR — {c.numerateur.definition} ({c.numerateur.ordres.join(", ") || "aucun OT"})
                  </dd>
                  <dt>Dénominateur</dt>
                  <dd>
                    {nombre(c.denominateur.production_mwh, 3)} MWh — source {c.denominateur.source} ({c.denominateur.statut})
                  </dd>
                </dl>
                <div className="message avert">{c.limite}</div>
              </>
            )}
          </Bloc>
        </div>
      </div>
      <div className="grille g2" style={{ marginTop: 14 }}>
        <div className="carte-bloc">
          <h3>Budgets, engagements, réalisé (2026)</h3>
          <Bloc etat={synth}>
            {(s) => (
              <>
                <Tableau
                  lignes={s.lignes}
                  colonnes={[
                    { cle: "poste", titre: "Poste" },
                    { cle: "entite_id", titre: "Entité #" },
                    { cle: "montant", titre: "Budget (EUR)", num: true },
                    { cle: "engage", titre: "Engagé", num: true },
                    { cle: "realise", titre: "Réalisé", num: true },
                    { cle: "reste_a_engager", titre: "Reste", num: true },
                  ]}
                />
                <Json valeur={s.definitions} titre="Définitions" />
              </>
            )}
          </Bloc>
        </div>
        <div className="carte-bloc">
          <h3>Marge brute carburant — Relais des Tilleuls</h3>
          <Bloc etat={marge}>
            {(m) => (
              <>
                <Tableau
                  lignes={m.lignes.map((l: any) => ({ id: l.produit_id, ...l }))}
                  colonnes={[
                    { cle: "produit_id", titre: "Produit #" },
                    { cle: "volume_vendu_l_observe", titre: "Volume (L obs.)", num: true },
                    { cle: "chiffre_affaires_ht", titre: "CA HT", num: true },
                    { cle: "cout_achat_eur_par_l", titre: "Coût achat (EUR/L)", num: true },
                    { cle: "marge_brute_ht", titre: "Marge brute HT", num: true },
                    { cle: "source_cout", titre: "Source du coût" },
                  ]}
                />
                <p className="petit">
                  <b>Définition :</b> {m.definition} <b>Limites :</b> {m.limites}
                </p>
              </>
            )}
          </Bloc>
        </div>
      </div>
      <div className="carte-bloc" style={{ marginTop: 14 }}>
        <h3>Trésorerie prévisionnelle (factures)</h3>
        <Bloc etat={treso}>
          {(t) => (
            <>
              <Tableau
                lignes={t.semaines.map((s: any) => ({ id: s.semaine_debut, ...s }))}
                colonnes={[
                  { cle: "semaine_debut", titre: "Semaine du" },
                  { cle: "encaissements_attendus", titre: "Encaissements attendus (EUR)", num: true },
                  { cle: "decaissements_attendus", titre: "Décaissements attendus (EUR)", num: true },
                  { cle: "solde_net", titre: "Solde net (EUR)", num: true },
                ]}
              />
              <p className="petit">{t.methode}</p>
            </>
          )}
        </Bloc>
      </div>
      <div style={{ marginTop: 14 }}>
        <Investissement siteId={pv?.id} />
      </div>
    </>
  );
}
