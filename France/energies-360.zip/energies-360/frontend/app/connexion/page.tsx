"use client";
import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { api, enregistrerSession, ErreurApi, post, Profil } from "@/lib/api";
import { Erreur } from "@/components/ui";

type Compte = { identifiant: string; nom: string; roles: string[]; mfa: boolean };

export default function Connexion() {
  const routeur = useRouter();
  const [comptes, setComptes] = useState<Compte[]>([]);
  const [idt, setIdt] = useState("direction");
  const [mdp, setMdp] = useState("");
  const [mfa, setMfa] = useState("");
  const [demandeMfa, setDemandeMfa] = useState(false);
  const [erreur, setErreur] = useState<ErreurApi | null>(null);
  const [mdpDemo, setMdpDemo] = useState<string | null>(null);

  useEffect(() => {
    api<{ comptes: Compte[]; mot_de_passe_demo: string }>("/api/auth/demo/comptes")
      .then((r) => {
        setComptes(r.comptes);
        setMdpDemo(r.mot_de_passe_demo);
      })
      .catch(() => setComptes([]));
  }, []);

  async function connecter(e?: React.FormEvent) {
    e?.preventDefault();
    setErreur(null);
    try {
      const r = await post<{ jeton: string; utilisateur: Profil }>("/api/auth/connexion", {
        identifiant: idt,
        mot_de_passe: mdp,
        code_mfa: mfa || undefined,
      });
      enregistrerSession(r.jeton, r.utilisateur);
      routeur.replace("/");
    } catch (x) {
      const err = x as ErreurApi;
      if (err.message.includes("MFA requis")) setDemandeMfa(true);
      setErreur(err);
    }
  }

  async function codeDemo() {
    try {
      const r = await api<{ code: string }>(`/api/auth/demo/code-mfa/${encodeURIComponent(idt)}`);
      setMfa(r.code);
    } catch (x) {
      setErreur(x as ErreurApi);
    }
  }

  return (
    <div className="connexion">
      <div className="carte-bloc">
        <h1>TOTALENERGIES — ÉNERGIES 360</h1>
        <p className="petit">
          Concept indépendant de plateforme intégrée multi-énergies. Aucune affiliation, aucun accès aux systèmes de TotalEnergies ; toutes les
          données sont synthétiques.
        </p>
        <form onSubmit={connecter} aria-label="Connexion">
          <div className="grille g2">
            <label>
              Identifiant (annuaire organisationnel simulé)
              <input value={idt} onChange={(e) => setIdt(e.target.value)} autoComplete="username" required />
            </label>
            <label>
              Mot de passe
              <input type="password" value={mdp} onChange={(e) => setMdp(e.target.value)} autoComplete="current-password" required />
            </label>
          </div>
          {(demandeMfa || comptes.find((c) => c.identifiant === idt)?.mfa) && (
            <div className="ligne">
              <label style={{ flex: 1 }}>
                Code MFA (TOTP, 6 chiffres)
                <input value={mfa} onChange={(e) => setMfa(e.target.value)} inputMode="numeric" maxLength={6} />
              </label>
              <button type="button" className="secondaire" onClick={codeDemo}>
                Code de démonstration
              </button>
            </div>
          )}
          <button type="submit">Se connecter</button>
        </form>
        <Erreur e={erreur} />
      </div>
      {comptes.length > 0 && (
        <div className="carte-bloc" style={{ marginTop: 14 }}>
          <h3>Comptes fictifs de démonstration</h3>
          <p className="petit">
            Mot de passe commun : <code>{mdpDemo}</code>. Cliquer sur un compte pour le présélectionner. Les comptes marqués MFA exigent un code TOTP
            (bouton « Code de démonstration », disponible uniquement en mode démonstration).
          </p>
          <div className="comptes">
            {comptes.map((c) => (
              <button
                key={c.identifiant}
                className="compte"
                onClick={() => {
                  setIdt(c.identifiant);
                  setMdp(mdpDemo ?? "");
                  setMfa("");
                  setDemandeMfa(c.mfa);
                }}
              >
                <div>
                  <b>{c.identifiant}</b> {c.mfa && <span className="badge b-information">MFA</span>}
                </div>
                <div className="r">{c.roles.join(", ")}</div>
              </button>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
