import type { Metadata } from "next";
import "./globals.css";
import Shell from "@/components/Shell";

export const metadata: Metadata = {
  title: "Énergies 360 — concept indépendant",
  description: "Prototype indépendant de plateforme multi-énergies — données synthétiques, sans affiliation.",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="fr">
      <body>
        <div className="bandeau" role="note">
          Prototype indépendant — données synthétiques — sans affiliation ni accès aux systèmes de TotalEnergies
        </div>
        <Shell>{children}</Shell>
      </body>
    </html>
  );
}
