"use client";
import { useEffect, useState } from "react";
import { useApi, usePeriode } from "@/lib/api";
import { date, nombre } from "@/lib/format";
import Carte from "@/components/Carte";
import { Bloc, EntetePage, Json, Onglets, Statut, Tableau } from "@/components/ui";

export default function Actifs() {
  const per = usePeriode();
  const arbre = useApi<any[]>("/api/patrimoine/arbre");
  const carte = useApi("/api/patrimoine/carte");
  const [siteId, setSiteId] = useState<number | null>(null);
  const [actifId, setActifId] = useState<number | null>(null);
  useEffect(() => {
    if (!siteId && arbre.donnees) {
      const s = arbre.donnees[0]?.entites?.flatMap((e: any) => e.sites)?.[0];
      if (s) setSiteId(s.id);
    }
  }, [arbre.donnees, siteId]);
  const site = useApi<any>(siteId && per ? `/api/patrimoine/sites/${siteId}` : null, per ? { instant: per.fin } : undefined);
  const hist = useApi<any[]>(actifId ? `/api/patrimoine/actifs/${actifId}/historique` : null);
  const etudes = useApi<any[]>("/api/patrimoine/etudes");
  const bilans = useApi<any[]>("/api/industrie/bilans");

  return (
    <>
      <EntetePage titre="Référentiel des actifs" sousTitre="Groupe → entités → sites → installations → équipements → points de mesure, versionnés (dates d'effet et provenance)." />
      <div className="grille g2">
        <div className="carte-bloc">
          <h3>Organisation</h3>
          <Bloc etat={arbre}>
            {(g) => (
              <>
                {g.map((gr) => (
                  <div key={gr.id}>
                    <b>{gr.nom}</b>
                    {gr.entites.map((e: any) => (
                      <div key={e.id} style={{ marginLeft: 12, marginTop: 6 }}>
                        <div>
                          {e.nom} <span className="badge b-neutre">{e.domaine}</span>
                        </div>
                        <div className="petit" style={{ marginLeft: 4 }}>{e.responsabilites}</div>
                        <ul style={{ margin: "2px 0 0 18px", padding: 0 }}>
                          {e.sites.map((s: any) => (
                            <li key={s.id}>
                              <button className={siteId === s.id ? "" : "secondaire"} style={{ padding: "1px 8px", margin: "2px 0" }} onClick={() => { setSiteId(s.id); setActifId(null); }}>
                                {s.nom}
                              </button>{" "}
                              <span className="petit">{s.nb_actifs} actifs</span>
                            </li>
                          ))}
                          {e.sites.length === 0 && <li className="petit">aucun site (ou hors de votre périmètre)</li>}
                        </ul>
                      </div>
                    ))}
                  </div>
                ))}
              </>
            )}
          </Bloc>
        </div>
        <div className="carte-bloc">
          <h3>Localisation</h3>
          <Bloc etat={carte}>{(d: any) => <Carte sites={d.features} surSelection={(id) => { setSiteId(id); setActifId(null); }} />}</Bloc>
        </div>
      </div>

      <Bloc etat={site}>
        {(d) => (
          <div className="carte-bloc" style={{ marginTop: 16 }}>
            <h2 style={{ marginTop: 0 }}>{d.site.nom}</h2>
            <p className="petit">
              {d.site.code} · {d.site.commune} · {nombre(d.site.latitude, 3)}°N {nombre(d.site.longitude, 3)}°E · fuseau {d.site.fuseau_horaire} · état{" "}
              <Statut s={d.site.etat} /> · version {d.site.version} · effet depuis {date(d.site.date_effet_debut, false)} · provenance : {d.site.provenance}
            </p>
            <Onglets onglets={["Installations et équipements", "Points de mesure", "Responsables et contrats", "Documents"]}>
              {(o) => (
                <>
                  {o === "Installations et équipements" && (
                    <Tableau
                      lignes={d.actifs}
                      surClic={(a: any) => setActifId(a.id)}
                      selection={(a: any) => a.id === actifId}
                      colonnes={[
                        { cle: "code", titre: "Code" },
                        { cle: "nom", titre: "Nom" },
                        { cle: "niveau", titre: "Niveau" },
                        { cle: "type_actif", titre: "Type" },
                        { cle: "etat", titre: "État", rendu: (a: any) => <Statut s={a.etat} /> },
                        {
                          cle: "capacites",
                          titre: "Capacités (installée / disponible)",
                          rendu: (a: any) =>
                            a.capacites.length
                              ? a.capacites.map((c: any) => (
                                  <div key={c.id} title={`${c.provenance}${c.motif ? " — " + c.motif : ""}`}>
                                    {c.nature} {c.grandeur} : <b>{nombre(c.valeur, 1)} {c.unite}</b>
                                  </div>
                                ))
                              : "—",
                        },
                        { cle: "version", titre: "Version", num: true, rendu: (a: any) => a.version },
                        { cle: "provenance", titre: "Provenance" },
                      ]}
                    />
                  )}
                  {o === "Points de mesure" && (
                    <Tableau
                      lignes={d.actifs.flatMap((a: any) => a.points_mesure.map((p: any) => ({ ...p, actif: a.code })))}
                      colonnes={[
                        { cle: "code", titre: "Point" },
                        { cle: "actif", titre: "Actif" },
                        { cle: "grandeur", titre: "Grandeur" },
                        { cle: "unite", titre: "Unité" },
                        { cle: "nature_grandeur", titre: "Nature" },
                        { cle: "type_signal", titre: "Signal" },
                        { cle: "role_comptage", titre: "Rôle de comptage", rendu: (p: any) => <span className={`badge ${p.role_comptage === "principal" ? "b-ok" : "b-neutre"}`}>{p.role_comptage}</span> },
                        { cle: "perimetre_comptage", titre: "Périmètre" },
                        { cle: "pas_attendu_s", titre: "Pas (s)", num: true },
                        { cle: "seuil_peremption_s", titre: "Péremption (s)", num: true },
                        { cle: "bornes", titre: "Bornes physiques", rendu: (p: any) => `[${p.borne_min ?? "—"} ; ${p.borne_max ?? "—"}]` },
                      ]}
                    />
                  )}
                  {o === "Responsables et contrats" && (
                    <>
                      <Tableau lignes={d.responsables} vide="Aucun responsable déclaré." colonnes={[
                        { cle: "nom", titre: "Nom (fictif)" }, { cle: "fonction", titre: "Fonction" }, { cle: "responsabilite", titre: "Responsabilité" }, { cle: "date_debut", titre: "Depuis" },
                      ]} />
                      <h3>Contrats de maintenance</h3>
                      <Tableau lignes={d.contrats_maintenance} vide="Aucun contrat de maintenance." colonnes={[
                        { cle: "numero", titre: "N°" }, { cle: "prestataire", titre: "Prestataire" }, { cle: "perimetre", titre: "Périmètre" },
                        { cle: "delai_intervention_h", titre: "Délai (h)", num: true }, { cle: "taux_horaire", titre: "Taux horaire (EUR/h)", num: true },
                        { cle: "date_fin", titre: "Fin" },
                      ]} />
                    </>
                  )}
                  {o === "Documents" && (
                    <Tableau lignes={d.documents} vide="Aucun document." colonnes={[
                      { cle: "titre", titre: "Titre" }, { cle: "type_document", titre: "Type" }, { cle: "confidentialite", titre: "Confidentialité" },
                      { cle: "sha256", titre: "Empreinte SHA-256", rendu: (x: any) => <code>{x.sha256.slice(0, 16)}…</code> },
                      { cle: "taille_octets", titre: "Taille (octets)", num: true }, { cle: "depose_par", titre: "Déposé par" },
                    ]} />
                  )}
                </>
              )}
            </Onglets>
          </div>
        )}
      </Bloc>

      {actifId && (
        <div className="carte-bloc" style={{ marginTop: 16 }}>
          <h3>Historique des versions de l&apos;actif #{actifId}</h3>
          <p className="petit">Chaque modification crée une version ; les études approuvées conservent la version figée qu&apos;elles référencent.</p>
          <Bloc etat={hist}>
            {(h) => (
              <Tableau lignes={h} colonnes={[
                { cle: "version", titre: "Version", num: true, rendu: (v: any) => v.version },
                { cle: "valide_de", titre: "Valide de" }, { cle: "valide_a", titre: "Valide à" },
                { cle: "enregistre_par", titre: "Par" }, { cle: "motif", titre: "Motif" },
                { cle: "donnees", titre: "Modèle / état", rendu: (v: any) => `${v.donnees.modele ?? "—"} / ${v.donnees.etat}` },
              ]} />
            )}
          </Bloc>
        </div>
      )}

      <div className="grille g2" style={{ marginTop: 16 }}>
        <div className="carte-bloc">
          <h3>Études (instantanés figés)</h3>
          <Bloc etat={etudes}>
            {(l) => <Tableau lignes={l} vide="Aucune étude." colonnes={[
              { cle: "titre", titre: "Titre" }, { cle: "statut", titre: "Statut", rendu: (e: any) => <Statut s={e.statut} /> },
              { cle: "approuvee_par", titre: "Approuvée par" }, { cle: "approuvee_le", titre: "Le" },
              { cle: "empreinte", titre: "Empreinte", rendu: (e: any) => (e.empreinte ? <code>{e.empreinte.slice(0, 12)}…</code> : "—") },
              { cle: "references", titre: "Références", rendu: (e: any) => e.references.map((r: any) => `${r.objet_type}#${r.objet_id} v${r.version ?? "?"}`).join(", ") },
            ]} />}
          </Bloc>
        </div>
        <div className="carte-bloc">
          <h3>Sites industriels — bilans matière</h3>
          <Bloc etat={bilans}>
            {(l) => (
              <>
                {l.map((b) => (
                  <div key={b.id}>
                    <dl className="def">
                      <dt>Période</dt><dd>{date(b.periode_debut, false)} → {date(b.periode_fin, false)}</dd>
                      <dt>Entrées</dt><dd>{nombre(b.total_entrees, 2)} {b.unite}</dd>
                      <dt>Sorties</dt><dd>{nombre(b.total_sorties, 2)} {b.unite}</dd>
                      <dt>Pertes déclarées</dt><dd>{nombre(b.pertes_declarees_total, 2)} {b.unite}</dd>
                      <dt>Écart non expliqué</dt><dd><b>{nombre(b.ecart_non_explique, 3)} {b.unite}</b> ({nombre(b.ecart_pct_entrees, 2)} % des entrées)</dd>
                      <dt>Statut</dt><dd><Statut s={b.statut} /></dd>
                    </dl>
                    <div className="petit">{b.equation} — {b.note}</div>
                    <Json valeur={{ entrees: b.entrees, sorties: b.sorties, pertes: b.pertes_declarees }} titre="Lignes du bilan" />
                  </div>
                ))}
              </>
            )}
          </Bloc>
        </div>
      </div>
    </>
  );
}
