"use client";
import { useState } from "react";
import { useApi, usePeriode } from "@/lib/api";
import { date, nombre } from "@/lib/format";
import { GraphiqueBarres, GraphiqueLignes } from "@/components/Graphiques";
import { Bloc, EntetePage, Statut, Tableau } from "@/components/ui";

function Rapprochement({ id, fin }: { id: number; fin: string }) {
  const r = useApi<any>(`/api/contrats/${id}/rapprochement`);
  const cot = useApi<any>(`/api/contrats/${id}/cotation`, { date: fin });
  return (
    <div className="carte-bloc" style={{ marginTop: 14 }}>
      <Bloc etat={r}>
        {(d) => (
          <>
            <h3>
              Rapprochement {d.contrat.numero} ({d.unite}, {d.devise})
            </h3>
            <div className="etapes">
              {d.chaine.map((c: string) => (
                <span key={c} className="fait">
                  {c}
                </span>
              ))}
            </div>
            <GraphiqueBarres
              titre="Quantités le long de la chaîne contractuelle"
              unite={d.unite + (d.contrat.nature_quantite ? ` (${d.contrat.nature_quantite.replace("_", " ")})` : "")}
              barres={[
                { libelle: "Contractuelle (annuelle)", valeur: d.quantites.contractuelle, couleur: "#9aa8c4" },
                { libelle: "Prévue (échéancier)", valeur: d.quantites.prevue, couleur: "#0b1b3f" },
                { libelle: "Engagement confirmé", valeur: d.quantites.confirmee, couleur: "#1e3a75" },
                { libelle: "Livraison mesurée", valeur: d.quantites.mesuree, couleur: "#00a3a6" },
                { libelle: "Facturée", valeur: d.quantites.facturee, couleur: "#f39200" },
              ]}
            />
            <dl className="def">
              <dt>Facturé TTC</dt>
              <dd>
                {nombre(d.montants.facture_ttc, 2)} {d.devise}
              </dd>
              <dt>Payé</dt>
              <dd>
                {nombre(d.montants.paye, 2)} {d.devise}
              </dd>
              <dt>Formule de prix</dt>
              <dd>
                <code>{d.contrat.formule_prix}</code> ({d.contrat.unite_prix})
              </dd>
              <dt>Fuseau / période</dt>
              <dd>
                {d.contrat.fuseau_horaire} · {date(d.contrat.date_debut, false)} → {date(d.contrat.date_fin, false)}
              </dd>
            </dl>
            {d.ecarts.length > 0 ? (
              d.ecarts.map((e: any) => (
                <div key={e.type} className="message avert">
                  <b>Écart {e.type.replace(/_/g, " ")} :</b> {e.message}
                </div>
              ))
            ) : (
              <div className="message ok">Aucun écart au-delà des tolérances.</div>
            )}
            <h3>Factures et paiements</h3>
            <Tableau
              lignes={d.detail.factures}
              vide="Aucune facture."
              colonnes={[
                { cle: "numero", titre: "N°" },
                { cle: "sens", titre: "Sens" },
                { cle: "quantite_facturee", titre: "Quantité", num: true },
                { cle: "prix_unitaire", titre: "Prix unitaire", num: true },
                { cle: "montant_ht", titre: "HT", num: true },
                { cle: "montant_ttc", titre: "TTC", num: true },
                { cle: "date_echeance", titre: "Échéance" },
              ]}
            />
            <Tableau lignes={d.detail.paiements} vide="Aucun paiement." colonnes={[{ cle: "reference", titre: "Référence" }, { cle: "date_paiement", titre: "Date" }, { cle: "montant", titre: "Montant", num: true }, { cle: "devise", titre: "Devise" }]} />
          </>
        )}
      </Bloc>
      <Bloc etat={cot}>
        {(c) => (
          <div className="message avert" style={{ marginTop: 10 }}>
            <b>
              Cotation au {date(c.date)} : {nombre(c.prix, 4)} {c.unite}
            </b>{" "}
            — {c.nature}. Indices : {c.indices.map((i: any) => `${i.indice} = ${i.valeur} ${i.unite} (valeur du ${date(i.date_valeur)}, publiée ${date(i.publie_le)}, source : ${i.source})`).join(" ; ")}
          </div>
        )}
      </Bloc>
    </div>
  );
}

export default function Contrats() {
  const per = usePeriode();
  const contrats = useApi<any[]>("/api/contrats");
  const indices = useApi<any[]>("/api/contrats/indices");
  const titres = useApi<any[]>(per ? "/api/amont/titres" : null, per ? { instant: per.fin } : undefined);
  const [sel, setSel] = useState<number | null>(null);
  return (
    <>
      <EntetePage titre="Contrats et opérations commerciales" sousTitre="Contrat → prévision → engagement confirmé → livraison mesurée → facture → paiement. Opérations de marché simulées, aucun ordre réel." />
      <div className="carte-bloc">
        <Bloc etat={contrats}>
          {(l) => (
            <Tableau
              lignes={l}
              surClic={(c: any) => setSel(c.id)}
              selection={(c: any) => c.id === sel}
              colonnes={[
                { cle: "numero", titre: "N°" },
                { cle: "type", titre: "Type" },
                { cle: "tiers", titre: "Tiers (fictif)" },
                { cle: "produit", titre: "Produit" },
                { cle: "quantite_contractuelle", titre: "Quantité", num: true },
                { cle: "unite", titre: "Unité", rendu: (c: any) => `${c.unite}${c.nature_quantite ? " " + c.nature_quantite : ""}` },
                { cle: "formule_prix", titre: "Formule", rendu: (c: any) => <code>{c.formule_prix}</code> },
                { cle: "devise", titre: "Devise" },
                { cle: "statut", titre: "Statut", rendu: (c: any) => <Statut s={c.statut} /> },
              ]}
            />
          )}
        </Bloc>
        <p className="petit">Cliquer sur un contrat pour son rapprochement et sa cotation indicative.</p>
      </div>
      {sel && per && <Rapprochement key={sel} id={sel} fin={per.fin} />}
      <div className="carte-bloc" style={{ marginTop: 14 }}>
        <h3>Indices de prix (simulés)</h3>
        <Bloc etat={indices}>
          {(l) => (
            <>
              {l.map((i) => (
                <div key={i.id} style={{ marginBottom: 10 }}>
                  <GraphiqueLignes
                    titre={`${i.code} — ${i.libelle} (source : ${i.source}, nature : ${i.nature})`}
                    uniteY={i.unite}
                    hauteur={200}
                    zeroInclus={false}
                    temps={i.valeurs.map((v: any) => v.date_valeur)}
                    series={[{ nom: i.code, couleur: "#1e3a75", valeurs: i.valeurs.map((v: any) => v.valeur) }]}
                  />
                </div>
              ))}
            </>
          )}
        </Bloc>
      </div>
      <div className="carte-bloc" style={{ marginTop: 14 }}>
        <h3>Suivi administratif des activités pétrolières et gazières (titres fictifs)</h3>
        <Bloc etat={titres}>
          {(l) => (
            <>
              {l.map((t) => (
                <div key={t.id}>
                  <p>
                    <b>{t.code}</b> — {t.nom} · {t.type.replace(/_/g, " ")} · {t.pays_fictif} · opérateur {t.operateur} · participation {nombre(t.participation_pct)} % · échéance du
                    titre {date(t.date_echeance, false)} ({t.jours_avant_echeance_titre} j) · <Statut s={t.statut} />
                  </p>
                  <Tableau
                    lignes={t.obligations.map((o: any, k: number) => ({ id: k, ...o }))}
                    colonnes={[
                      { cle: "libelle", titre: "Obligation" },
                      { cle: "echeance", titre: "Échéance" },
                      { cle: "jours_restants", titre: "Jours restants", num: true },
                      { cle: "etat_calcule", titre: "État", rendu: (o: any) => <Statut s={o.etat_calcule === "realisee" ? "conforme" : o.etat_calcule} libelle={o.etat_calcule.replace(/_/g, " ")} /> },
                    ]}
                  />
                  <p className="petit">{t.mention}</p>
                </div>
              ))}
            </>
          )}
        </Bloc>
      </div>
    </>
  );
}
