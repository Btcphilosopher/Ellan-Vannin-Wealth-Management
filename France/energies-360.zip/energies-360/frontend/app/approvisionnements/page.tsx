"use client";
import { useApi } from "@/lib/api";
import { date, nombre } from "@/lib/format";
import { Bloc, EntetePage, Json, Statut, Tableau } from "@/components/ui";

export default function Approvisionnements() {
  const cmds = useApi<any[]>("/api/approvisionnements/commandes");
  const ecarts = useApi<any[]>("/api/logistique/ecarts");
  const docs = useApi<any[]>("/api/logistique/documents-transport");
  return (
    <>
      <EntetePage
        titre="Approvisionnements"
        sousTitre="Commandes → livraisons annoncées (document de transport) → réceptions éventuellement partielles → écarts et quarantaine. Aucune commande automatique."
      />
      <Bloc etat={cmds}>
        {(l) => (
          <>
            {l.length === 0 && <div className="petit">Aucune commande dans votre périmètre.</div>}
            {l.map((c) => (
              <div className="carte-bloc" key={c.id} style={{ marginBottom: 14 }}>
                <h3>
                  Commande {c.numero} — {c.fournisseur} <Statut s={c.statut} />
                </h3>
                <p className="petit">
                  Émise le {date(c.emise_le)} par {c.cree_par}
                </p>
                <Tableau
                  lignes={c.lignes}
                  colonnes={[
                    { cle: "produit", titre: "Produit" },
                    { cle: "quantite", titre: "Commandé", num: true },
                    { cle: "quantite_recue", titre: "Reçu", num: true },
                    { cle: "reste", titre: "Reste à recevoir", num: true, rendu: (x: any) => nombre(x.quantite - x.quantite_recue, 2) },
                    { cle: "unite", titre: "Unité" },
                    { cle: "prix_unitaire", titre: "Prix unitaire", num: true },
                    { cle: "devise", titre: "Devise" },
                  ]}
                />
                <h3>Livraisons</h3>
                <Tableau
                  lignes={c.livraisons}
                  colonnes={[
                    { cle: "id", titre: "#" },
                    { cle: "date_prevue", titre: "Prévue le" },
                    { cle: "statut", titre: "Statut", rendu: (x: any) => <Statut s={x.statut} /> },
                    { cle: "lignes_annoncees", titre: "Annoncé au document de transport", rendu: (x: any) => x.lignes_annoncees.map((a: any) => `ligne ${a.ligne_commande_id} : ${a.quantite}`).join(" · ") },
                  ]}
                />
              </div>
            ))}
          </>
        )}
      </Bloc>
      <div className="grille g2">
        <div className="carte-bloc">
          <h3>Écarts de réception et de transfert</h3>
          <Bloc etat={ecarts}>
            {(l) => (
              <Tableau
                lignes={l}
                vide="Aucun écart."
                colonnes={[
                  { cle: "type", titre: "Type" },
                  { cle: "objet_type", titre: "Objet", rendu: (e: any) => `${e.objet_type} #${e.objet_id}` },
                  { cle: "quantite", titre: "Quantité", num: true },
                  { cle: "unite", titre: "Unité" },
                  { cle: "description", titre: "Description" },
                  { cle: "statut", titre: "Statut", rendu: (e: any) => <Statut s={e.statut} /> },
                ]}
              />
            )}
          </Bloc>
        </div>
        <div className="carte-bloc">
          <h3>Documents de transport (fictifs)</h3>
          <Bloc etat={docs}>
            {(l) => (
              <>
                <Tableau lignes={l} vide="Aucun document." colonnes={[{ cle: "type", titre: "Type" }, { cle: "numero", titre: "Numéro" }, { cle: "emis_le", titre: "Émis le" }]} />
                {l.map((d) => (
                  <Json key={d.id} valeur={d.contenu} titre={`Contenu ${d.numero}`} />
                ))}
              </>
            )}
          </Bloc>
        </div>
      </div>
    </>
  );
}
