"use client";
import { useState } from "react";
import { API_URL, ErreurApi, jeton, post, useApi, usePeriode, useSites } from "@/lib/api";
import { date } from "@/lib/format";
import { Bloc, EntetePage, Erreur, Json, Onglets, Statut, Tableau } from "@/components/ui";

async function telecharger(id: number, format: "json" | "html") {
  const rep = await fetch(`${API_URL}/api/rapports/${id}/telecharger?format=${format}`, { headers: { Authorization: `Bearer ${jeton()}` } });
  if (!rep.ok) throw new ErreurApi(rep.status, (await rep.json().catch(() => ({ detail: "erreur" }))).detail);
  const blob = await rep.blob();
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = `rapport_${id}.${format}`;
  a.click();
  setTimeout(() => URL.revokeObjectURL(url), 2000);
}

function Rapports() {
  const per = usePeriode();
  const sites = useSites();
  const pv = sites.find((s) => s.code === "SITE-PV-GAR");
  const liste = useApi<any[]>("/api/rapports");
  const [err, setErr] = useState<ErreurApi | null>(null);
  const [verif, setVerif] = useState<any>(null);
  async function generer() {
    setErr(null);
    try {
      await post("/api/rapports", { type: "parcours_solaire", site_id: pv?.id, debut: per?.debut, fin: per?.fin });
      liste.recharger();
    } catch (e) {
      setErr(e as ErreurApi);
    }
  }
  return (
    <>
      <div className="ligne">
        <button onClick={generer} disabled={!pv || !per}>
          Générer le rapport « parcours solaire »
        </button>
        <span className="petit">JSON + HTML + manifeste (sources, méthodes, empreintes SHA-256, signature HMAC), stockés dans le stockage objet protégé.</span>
      </div>
      <Erreur e={err} />
      <Bloc etat={liste}>
        {(l) => (
          <Tableau
            lignes={l}
            vide="Aucun rapport."
            colonnes={[
              { cle: "id", titre: "#" },
              { cle: "titre", titre: "Titre" },
              { cle: "genere_par", titre: "Par" },
              { cle: "genere_le", titre: "Le" },
              { cle: "sha256_json", titre: "SHA-256 (JSON)", rendu: (r: any) => <code>{r.sha256_json.slice(0, 16)}…</code> },
              {
                cle: "act",
                titre: "Actions",
                rendu: (r: any) => (
                  <div className="ligne">
                    <button className="secondaire" onClick={() => telecharger(r.id, "json").catch(setErr)}>JSON</button>
                    <button className="secondaire" onClick={() => telecharger(r.id, "html").catch(setErr)}>HTML</button>
                    <button
                      className="secondaire"
                      onClick={() =>
                        fetch(`${API_URL}/api/rapports/${r.id}/verifier`, { headers: { Authorization: `Bearer ${jeton()}` } })
                          .then((x) => x.json())
                          .then(setVerif)
                      }
                    >
                      Vérifier
                    </button>
                  </div>
                ),
              },
            ]}
          />
        )}
      </Bloc>
      {verif && (
        <div className={`message ${verif.empreinte_contenu_ok && verif.signature_ok ? "ok" : "erreur"}`}>
          Rapport #{verif.rapport_id} : fichier {verif.empreinte_fichier_ok ? "intègre" : "altéré"} · contenu {verif.empreinte_contenu_ok ? "conforme au manifeste" : "non conforme"} · signature{" "}
          {verif.signature_ok ? "valide" : "invalide (secret de signature différent ?)"}
        </div>
      )}
    </>
  );
}

function Audit() {
  const [filtre, setFiltre] = useState<string>("");
  const journal = useApi<any[]>("/api/admin/audit", { limite: 300, resultat: filtre || undefined });
  const chaine = useApi<any>("/api/admin/audit/verifier");
  return (
    <>
      <Bloc etat={chaine}>
        {(c) => (
          <div className={`message ${c.integre ? "ok" : "erreur"}`}>
            Chaîne d&apos;audit : <b>{c.integre ? "intègre" : `rompue à l'entrée #${c.premiere_rupture}`}</b> — {c.entrees_verifiees} entrées vérifiées
            {c.derniere_empreinte ? ` · dernière empreinte ${c.derniere_empreinte.slice(0, 16)}…` : ""}
          </div>
        )}
      </Bloc>
      <label style={{ maxWidth: 260 }}>
        Filtrer par résultat
        <select value={filtre} onChange={(e) => setFiltre(e.target.value)}>
          <option value="">tous</option>
          <option value="succes">succès</option>
          <option value="refus">refus (accès non autorisé)</option>
          <option value="echec">échec (connexion)</option>
        </select>
      </label>
      <Bloc etat={journal}>
        {(l) => (
          <Tableau
            lignes={l}
            colonnes={[
              { cle: "id", titre: "#" },
              { cle: "horodatage", titre: "Horodatage (réel)" },
              { cle: "acteur", titre: "Acteur" },
              { cle: "action", titre: "Action" },
              { cle: "ressource", titre: "Ressource" },
              { cle: "resultat", titre: "Résultat", rendu: (e: any) => <Statut s={e.resultat} /> },
              { cle: "details", titre: "Détails (expurgés)", rendu: (e: any) => <code>{JSON.stringify(e.details).slice(0, 120)}</code> },
              { cle: "empreinte", titre: "Empreinte", rendu: (e: any) => <code>{e.empreinte.slice(0, 10)}…</code> },
            ]}
          />
        )}
      </Bloc>
    </>
  );
}

export default function Administration() {
  const adapt = useApi<any>("/api/admin/adaptateurs");
  const statut = useApi<any>("/api/admin/statut-fonctionnalites");
  const users = useApi<any[]>("/api/admin/utilisateurs");
  const taches = useApi<any[]>("/api/admin/taches");
  const sante = useApi<any>("/api/sante");
  return (
    <>
      <EntetePage
        titre="Administration"
        sousTitre="Rapports traçables, audit, adaptateurs, statut des fonctionnalités, habilitations."
        droite={
          <Bloc etat={sante}>
            {(s) => (
              <span className="petit">
                API {s.version} · base {s.base} · données {s.donnees} · mode démo {s.mode_demo ? "oui" : "non"}
              </span>
            )}
          </Bloc>
        }
      />
      <Onglets onglets={["Rapports", "Audit", "Adaptateurs", "Statut des fonctionnalités", "Utilisateurs", "Tâches"]}>
        {(o) => (
          <div className="carte-bloc">
            {o === "Rapports" && <Rapports />}
            {o === "Audit" && <Audit />}
            {o === "Adaptateurs" && (
              <Bloc etat={adapt}>
                {(a) => (
                  <>
                    <div className="message info">{a.principe}</div>
                    <Tableau
                      lignes={a.adaptateurs.map((x: any) => ({ id: x.nom, ...x }))}
                      colonnes={[
                        { cle: "nom", titre: "Adaptateur" },
                        { cle: "domaine", titre: "Domaine" },
                        { cle: "mode", titre: "Mode", rendu: (x: any) => <Statut s={x.mode === "integre" ? "conforme" : x.mode === "simulation" ? "estimation" : "indetermine"} libelle={x.mode.replace(/_/g, " ")} /> },
                        { cle: "protocole_cible", titre: "Protocole cible" },
                        { cle: "capacites", titre: "Capacités", rendu: (x: any) => x.capacites.join(" ; ") },
                        { cle: "interdits", titre: "Interdits", rendu: (x: any) => x.interdits.join(" ; ") || "—" },
                        { cle: "documentation_a_verifier", titre: "Documentation à vérifier" },
                      ]}
                    />
                  </>
                )}
              </Bloc>
            )}
            {o === "Statut des fonctionnalités" && (
              <Bloc etat={statut}>
                {(s) => (
                  <div className="grille g2">
                    {(["operationnel", "simule", "integre", "reporte"] as const).map((k) => (
                      <div key={k}>
                        <h3>
                          {{ operationnel: "Opérationnel", simule: "Simulé", integre: "Intégré", reporte: "Reporté" }[k]} ({s[k].length})
                        </h3>
                        <ul>
                          {s[k].map((x: string) => (
                            <li key={x}>{x}</li>
                          ))}
                        </ul>
                      </div>
                    ))}
                  </div>
                )}
              </Bloc>
            )}
            {o === "Utilisateurs" && (
              <Bloc etat={users}>
                {(l) => (
                  <Tableau
                    lignes={l}
                    colonnes={[
                      { cle: "identifiant", titre: "Identifiant" },
                      { cle: "nom_affiche", titre: "Nom (fictif)" },
                      { cle: "mfa_obligatoire", titre: "MFA" },
                      { cle: "est_compte_service", titre: "Compte de service" },
                      { cle: "habilitations", titre: "Habilitations", rendu: (u: any) => u.habilitations.map((h: any) => `${h.role}${h.site_id ? ` (site #${h.site_id})` : h.entite_id ? ` (entité #${h.entite_id})` : " (global)"}`).join(", ") },
                    ]}
                  />
                )}
              </Bloc>
            )}
            {o === "Tâches" && (
              <Bloc etat={taches}>
                {(l) => (
                  <>
                    <Tableau
                      lignes={l}
                      vide="Aucune tâche en arrière-plan."
                      colonnes={[
                        { cle: "id", titre: "#" },
                        { cle: "type", titre: "Type" },
                        { cle: "statut", titre: "Statut", rendu: (t: any) => <Statut s={t.statut === "terminee" ? "conforme" : t.statut} libelle={t.statut.replace(/_/g, " ")} /> },
                        { cle: "demandee_par", titre: "Par" },
                        { cle: "cree_le", titre: "Créée" },
                        { cle: "fin", titre: "Fin" },
                        { cle: "erreur", titre: "Erreur" },
                      ]}
                    />
                    <Json valeur={l.map((t) => t.resultat)} titre="Résultats" />
                  </>
                )}
              </Bloc>
            )}
          </div>
        )}
      </Onglets>
      <p className="petit" style={{ marginTop: 10 }}>
        Horodatages affichés en UTC ({date(new Date().toISOString())} à l&apos;ouverture). Aucune certification de cybersécurité ou de conformité industrielle n&apos;est revendiquée.
      </p>
    </>
  );
}
