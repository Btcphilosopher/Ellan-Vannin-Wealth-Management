"use client";
import { useApi } from "@/lib/api";
import { nombre } from "@/lib/format";
import { Bloc, EntetePage, Onglets, Statut, Tableau } from "@/components/ui";

export default function Logistique() {
  const stocks = useApi<any>("/api/logistique/stocks");
  const mvts = useApi<any[]>("/api/logistique/mouvements");
  const transferts = useApi<any[]>("/api/logistique/transferts");
  const regles = useApi<any[]>("/api/logistique/regles");
  const empl = useApi<any[]>("/api/logistique/emplacements");
  const coh = useApi<any>("/api/logistique/coherence");
  return (
    <>
      <EntetePage
        titre="Logistique et stocks"
        sousTitre="Journal de mouvements immuable, corrections liées, réservations atomiques. Aucune commande de pompe, de vanne ou de procédé."
        droite={
          <Bloc etat={coh}>
            {(c) => (
              <div className={`message ${c.coherent ? "ok" : "erreur"}`} style={{ margin: 0 }}>
                Journal ↔ soldes : <b>{c.coherent ? "cohérent" : "incohérent"}</b> ({c.soldes_verifies} soldes recalculés depuis le journal)
              </div>
            )}
          </Bloc>
        }
      />
      <Onglets onglets={["Stocks", "Mouvements", "Transferts", "Emplacements et règles"]}>
        {(o) => (
          <div className="carte-bloc">
            {o === "Stocks" && (
              <Bloc etat={stocks}>
                {(d) => (
                  <>
                    <Tableau
                      lignes={d.soldes}
                      colonnes={[
                        { cle: "emplacement", titre: "Emplacement" },
                        { cle: "produit_nom", titre: "Produit" },
                        { cle: "lot", titre: "Lot" },
                        { cle: "statut_lot", titre: "Statut du lot", rendu: (x: any) => (x.statut_lot ? <Statut s={x.statut_lot === "libre" ? "conforme" : "refus"} libelle={x.statut_lot} /> : "—") },
                        { cle: "physique", titre: "Physique", num: true },
                        { cle: "reserve", titre: "Réservé", num: true },
                        { cle: "quarantaine", titre: "Quarantaine", num: true },
                        { cle: "disponible", titre: "Disponible", num: true, rendu: (x: any) => <b>{nombre(x.disponible, 2)}</b> },
                        { cle: "en_transit_entrant", titre: "En transit (entrant)", num: true },
                        { cle: "unite", titre: "Unité" },
                      ]}
                    />
                    <dl className="def">
                      {Object.entries(d.definitions).map(([k, v]) => (
                        <div key={k} style={{ display: "contents" }}>
                          <dt>{k.replace(/_/g, " ")}</dt>
                          <dd>{String(v)}</dd>
                        </div>
                      ))}
                    </dl>
                  </>
                )}
              </Bloc>
            )}
            {o === "Mouvements" && (
              <Bloc etat={mvts}>
                {(l) => (
                  <Tableau
                    lignes={l}
                    vide="Aucun mouvement."
                    colonnes={[
                      { cle: "id", titre: "#" },
                      { cle: "horodatage", titre: "Horodatage" },
                      { cle: "type", titre: "Type" },
                      { cle: "produit", titre: "Produit" },
                      { cle: "emplacement", titre: "Emplacement" },
                      { cle: "quantite", titre: "Quantité (signée)", num: true },
                      { cle: "unite", titre: "Unité" },
                      { cle: "reference_type", titre: "Référence", rendu: (m: any) => (m.reference_type ? `${m.reference_type} #${m.reference_id}` : "—") },
                      { cle: "corrige_mouvement_id", titre: "Corrige #" },
                      { cle: "auteur", titre: "Auteur" },
                    ]}
                  />
                )}
              </Bloc>
            )}
            {o === "Transferts" && (
              <Bloc etat={transferts}>
                {(l) => (
                  <Tableau
                    lignes={l}
                    vide="Aucun transfert."
                    colonnes={[
                      { cle: "numero", titre: "N°" },
                      { cle: "statut", titre: "Statut", rendu: (t: any) => <Statut s={t.statut} /> },
                      { cle: "source_id", titre: "Source #" },
                      { cle: "destination_id", titre: "Destination #" },
                      { cle: "quantite", titre: "Expédié", num: true },
                      { cle: "quantite_recue", titre: "Reçu", num: true },
                      { cle: "unite", titre: "Unité" },
                      { cle: "expedie_le", titre: "Expédié le" },
                      { cle: "recu_le", titre: "Reçu le" },
                    ]}
                  />
                )}
              </Bloc>
            )}
            {o === "Emplacements et règles" && (
              <>
                <Bloc etat={empl}>
                  {(l) => (
                    <Tableau
                      lignes={l}
                      colonnes={[
                        { cle: "code", titre: "Code" },
                        { cle: "nom", titre: "Nom" },
                        { cle: "type", titre: "Type" },
                        { cle: "capacite", titre: "Capacité", num: true },
                        { cle: "unite_capacite", titre: "Unité" },
                        { cle: "groupes_autorises", titre: "Groupes autorisés", rendu: (e: any) => e.groupes_autorises.join(", ") },
                        { cle: "est_quarantaine", titre: "Quarantaine" },
                      ]}
                    />
                  )}
                </Bloc>
                <h3>Règles de compatibilité (seules les règles validées s&apos;appliquent)</h3>
                <Bloc etat={regles}>
                  {(l) => (
                    <Tableau
                      lignes={l}
                      colonnes={[
                        { cle: "groupe_a", titre: "Groupe A" },
                        { cle: "groupe_b", titre: "Groupe B" },
                        { cle: "autorise", titre: "Cohabitation", rendu: (r: any) => <Statut s={r.autorise ? "conforme" : "refus"} libelle={r.autorise ? "autorisée" : "interdite"} /> },
                        { cle: "statut", titre: "Statut", rendu: (r: any) => <Statut s={r.statut === "validee" ? "valide_interne" : "brouillon"} libelle={r.statut === "validee" ? "validée (appliquée)" : "proposée (non appliquée)"} /> },
                        { cle: "justification", titre: "Justification" },
                        { cle: "reference_documentaire", titre: "Référence" },
                        { cle: "valide_par", titre: "Validée par" },
                      ]}
                    />
                  )}
                </Bloc>
              </>
            )}
          </div>
        )}
      </Onglets>
    </>
  );
}
