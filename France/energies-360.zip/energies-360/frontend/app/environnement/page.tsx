"use client";
import { useApi } from "@/lib/api";
import { date, nombre } from "@/lib/format";
import { GraphiqueBarres } from "@/components/Graphiques";
import { Bloc, EntetePage, Json, Statut, Tableau } from "@/components/ui";

export default function Environnement() {
  const inv = useApi<any>("/api/environnement/inventaire", { annee: 2026 });
  const fact = useApi<any[]>("/api/environnement/facteurs");
  return (
    <>
      <EntetePage titre="Environnement et émissions" sousTitre="Données d'activité, facteurs sourcés, méthodes, hypothèses, incertitude, validation. Émissions évitées en registre séparé." />
      <Bloc etat={inv}>
        {(d) => (
          <>
            <div className="message avert">
              <b>Mention :</b> {d.mention}
            </div>
            <div className="grille g2">
              <div className="carte-bloc">
                <GraphiqueBarres
                  titre={`Inventaire ${d.annee} par scope (± incertitude combinée)`}
                  unite="tCO2e"
                  barres={[1, 2, 3].map((k) => ({
                    libelle: `Scope ${k} (± ${nombre(d.incertitude_par_scope_tco2e[`scope_${k}`], 3)})`,
                    valeur: d.totaux_par_scope[`scope_${k}`],
                    couleur: ["#e4002b", "#f39200", "#00a3a6"][k - 1],
                  }))}
                />
                <dl className="def">
                  <dt>Total scopes 1 + 2</dt>
                  <dd>
                    <b>{nombre(d.total_scopes_1_2, 3)} tCO2e</b>
                  </dd>
                  <dt>Par nature</dt>
                  <dd>
                    {Object.entries(d.par_nature).map(([k, v]) => `${k} : ${nombre(v as number, 3)} t`).join(" · ") || "—"}
                  </dd>
                  <dt>Statuts de validation</dt>
                  <dd>{d.statuts_validation.map((s: string) => <Statut key={s} s={s} />)}</dd>
                </dl>
              </div>
              <div className="carte-bloc">
                <h3>Émissions évitées (registre séparé)</h3>
                <p className="petit">{d.regle_evitees}</p>
                <Tableau lignes={d.emissions_evitees_registre_separe} vide="Aucune estimation d'émissions évitées enregistrée." colonnes={[{ cle: "libelle", titre: "Libellé" }, { cle: "estimation_kgco2e", titre: "kgCO2e (estimation)", num: true }, { cle: "methode", titre: "Méthode" }]} />
              </div>
            </div>
            <div className="carte-bloc" style={{ marginTop: 14 }}>
              <h3>Calculs (activité × facteur)</h3>
              <Tableau
                lignes={d.lignes.map((l: any) => ({ id: l.calcul.id, ...l }))}
                vide="Aucun calcul."
                colonnes={[
                  { cle: "a", titre: "Catégorie", rendu: (l: any) => l.activite.categorie },
                  { cle: "s", titre: "Scope", rendu: (l: any) => `${l.activite.scope}${l.activite.categorie_scope3 ? ` cat. ${l.activite.categorie_scope3}` : ""}` },
                  { cle: "q", titre: "Activité", rendu: (l: any) => `${nombre(l.activite.quantite, 1)} ${l.activite.unite} ${l.activite.nature_quantite ?? ""}` },
                  { cle: "p", titre: "Période", rendu: (l: any) => `${date(l.activite.periode_debut, false)} → ${date(l.activite.periode_fin, false)}` },
                  { cle: "f", titre: "Facteur", rendu: (l: any) => `${l.facteur.code} = ${l.facteur.valeur} ${l.facteur.unite}` },
                  { cle: "e", titre: "Émission (kgCO2e)", num: true, rendu: (l: any) => nombre(l.calcul.emission_kgco2e, 1) },
                  { cle: "i", titre: "Incertitude", num: true, rendu: (l: any) => `± ${nombre(l.calcul.incertitude_pct, 1)} %` },
                  { cle: "n", titre: "Nature", rendu: (l: any) => l.calcul.nature },
                  { cle: "v", titre: "Validation", rendu: (l: any) => <Statut s={l.activite.statut_validation} /> },
                  { cle: "m", titre: "Méthode", rendu: (l: any) => <span className="petit">{l.calcul.methode}</span> },
                ]}
              />
              <Json valeur={d.lignes.map((l: any) => ({ cle_origine: l.activite.cle_origine, exclusions: l.activite.exclusions, source: l.activite.source_reference, hypotheses: l.calcul.hypotheses }))} titre="Clés d'origine, exclusions et hypothèses (anti-double comptage)" />
            </div>
          </>
        )}
      </Bloc>
      <div className="carte-bloc" style={{ marginTop: 14 }}>
        <h3>Facteurs d&apos;émission (fictifs, sourcés)</h3>
        <Bloc etat={fact}>
          {(l) => (
            <Tableau
              lignes={l}
              colonnes={[
                { cle: "code", titre: "Code" },
                { cle: "libelle", titre: "Libellé" },
                { cle: "valeur", titre: "Valeur", num: true },
                { cle: "unite", titre: "Unité", rendu: (f: any) => `${f.unite}${f.nature_denominateur ? ` (${f.nature_denominateur})` : ""}` },
                { cle: "annee_reference", titre: "Année" },
                { cle: "geographie", titre: "Géographie" },
                { cle: "incertitude_pct", titre: "Incertitude (%)", num: true },
                { cle: "perimetre", titre: "Périmètre" },
                { cle: "source", titre: "Source" },
              ]}
            />
          )}
        </Bloc>
      </div>
    </>
  );
}
