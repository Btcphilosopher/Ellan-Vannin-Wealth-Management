"use client";
import { useEffect, useState } from "react";
import { useApi, usePeriode } from "@/lib/api";
import { date, nombre } from "@/lib/format";
import { GraphiqueBarres } from "@/components/Graphiques";
import { Bloc, EntetePage, Json, Statut, Tableau } from "@/components/ui";

function Station({ id, per }: { id: number; per: Record<string, string> }) {
  const s = useApi<any>(`/api/distribution/stations/${id}/synthese`, { debut: per.debut, fin: per.fin });
  return (
    <Bloc etat={s}>
      {(d) => (
        <>
          <div className="grille g2">
            <div className="carte-bloc">
              <GraphiqueBarres
                titre="Ventes de la période (volume au volucompteur, température ambiante)"
                unite="L observés"
                barres={d.ventes.map((v: any) => ({ libelle: v.produit, valeur: v.volume_observe_l, couleur: v.produit.startsWith("GO") ? "#0b1b3f" : "#f39200" }))}
              />
              <Tableau
                lignes={d.ventes.map((v: any) => ({ id: v.produit, ...v }))}
                colonnes={[
                  { cle: "produit", titre: "Produit" },
                  { cle: "volume_observe_l", titre: "Volume (L observés)", num: true },
                  { cle: "montant_ttc", titre: "Montant TTC (EUR)", num: true },
                  { cle: "transactions", titre: "Transactions", num: true },
                ]}
              />
            </div>
            <div className="carte-bloc">
              <h3>Prix affichés datés</h3>
              <Tableau
                lignes={d.prix_dates}
                colonnes={[
                  { cle: "produit", titre: "Produit" },
                  { cle: "prix_ttc", titre: "Prix TTC", num: true },
                  { cle: "unite_prix", titre: "Unité" },
                  { cle: "valide_de", titre: "Valide de" },
                  { cle: "valide_a", titre: "Valide à" },
                  { cle: "source", titre: "Source" },
                ]}
              />
              <h3>Livraisons de carburant</h3>
              <Tableau
                lignes={d.livraisons}
                vide="Aucune livraison sur la période."
                colonnes={[
                  { cle: "horodatage", titre: "Date" },
                  { cle: "volume_observe_l", titre: "Volume observé (L)", num: true },
                  { cle: "temperature_c", titre: "T (°C)", num: true },
                  { cle: "volume_15c_bl_l", titre: "Volume à 15 °C (BL)", num: true },
                  { cle: "contrat_id", titre: "Contrat #" },
                ]}
              />
            </div>
          </div>
          <h2>Rapprochement physique des cuves (volume corrigé à 15 °C)</h2>
          <div className="grille g2">
            {d.cuves.map((c: any) => (
              <div className="carte-bloc" key={c.cuve}>
                <h3>
                  {c.cuve} — {c.produit}
                </h3>
                {c.volumes_15c_l ? (
                  <>
                    <Tableau
                      lignes={[
                        { id: 1, terme: "Stock initial", obs: c.volumes_observes_l.stock_initial, c15: c.volumes_15c_l.stock_initial },
                        { id: 2, terme: "+ Livraisons", obs: c.volumes_observes_l.livraisons, c15: c.volumes_15c_l.livraisons_bl },
                        { id: 3, terme: "− Ventes", obs: c.volumes_observes_l.ventes, c15: c.volumes_15c_l.ventes_corrigees },
                        { id: 4, terme: "= Stock théorique", obs: null, c15: c.volumes_15c_l.stock_theorique },
                        { id: 5, terme: "Stock jaugé", obs: c.volumes_observes_l.stock_final, c15: c.volumes_15c_l.stock_jauge },
                      ]}
                      colonnes={[
                        { cle: "terme", titre: "Terme" },
                        { cle: "obs", titre: "L observés", num: true },
                        { cle: "c15", titre: "L à 15 °C", num: true },
                      ]}
                    />
                    <div className={`message ${Math.abs(c.ecart_pct_ventes ?? 0) <= 0.5 ? "ok" : "avert"}`}>
                      Écart : <b>{nombre(c.ecart_l15)} L15</b> ({nombre(c.ecart_pct_ventes, 3)} % des ventes) — {c.interpretation}
                    </div>
                    <p className="petit">{c.volumes_observes_l.note}</p>
                    <Json valeur={c.hypotheses} titre="Hypothèses de correction" />
                  </>
                ) : (
                  <div className="petit">
                    <Statut s={c.statut} /> {c.message}
                  </div>
                )}
              </div>
            ))}
          </div>
        </>
      )}
    </Bloc>
  );
}

export default function Distribution() {
  const per = usePeriode();
  const stations = useApi<any[]>("/api/distribution/stations");
  const [sel, setSel] = useState<number | null>(null);
  useEffect(() => {
    if (!sel && stations.donnees?.length) setSel(stations.donnees[0].id);
  }, [stations.donnees, sel]);
  return (
    <>
      <EntetePage
        titre="Distribution — réseau de stations"
        sousTitre={per ? `Ventes, prix datés, livraisons, stocks de cuves · ${date(per.debut, false)} → ${date(per.fin, false)}` : ""}
        droite={
          <Bloc etat={stations}>
            {(l) => (
              <div className="ligne">
                {l.map((s) => (
                  <button key={s.id} className={sel === s.id ? "" : "secondaire"} onClick={() => setSel(s.id)}>
                    {s.nom}
                  </button>
                ))}
              </div>
            )}
          </Bloc>
        }
      />
      {sel && per && <Station key={sel} id={sel} per={per} />}
    </>
  );
}
